import json
import re
import base64
import math
import os
import shutil
import sqlite3
import sys
import uuid
import csv
import io
import html
import webbrowser
import traceback
import subprocess
from collections import deque
from contextlib import contextmanager, ExitStack
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk
from tkinter import font as tkfont
import workflow_v224 as workflow


# Shown version = KST date + number of that day (26.11.21.01, .02 ...; next day starts at .01).
# The update number (version.json, workflow_v<N>.py) stays an integer: V215.
APP_VERSION_LABEL = "26.11.22.07"
APP_UPDATE_NUMBER = 224
APP_TITLE = f"통신 코어 도면 - Windows 통합판 {APP_VERSION_LABEL}"
AUTO_HTML_ON_START = False  # V212: set only when the program itself starts (not in checks)
CORE_SIZES = (12, 36, 72, 144, 288)
NODE_TYPES = {"함체": "hamche", "RN": "rn", "가입자": "sub"}
NODE_LABELS = {v: k for k, v in NODE_TYPES.items()}
SUBSCRIBER_TYPES = {"가입자":"subscriber","중계기":"repeater","IJP":"ijp"}
STATUS_VALUES = ("기설", "신설", "철거", "절단")
CORE_STATUS_LABELS={"":"확인필요","unknown":"확인필요","normal":"정상","error":"오류코어","exception":"예외코어","cancel":"해지","cancel_expected":"해지예상","broken":"끊김","pathdiff":"경로다름","noinfo":"내역없음"}
CORE_STATUS_VALUES=("확인필요","정상","오류코어","예외코어","해지","해지예상","끊김","내역없음")
CORE_STATUS_FROM_LABEL={v:k for k,v in CORE_STATUS_LABELS.items() if k!="unknown"}
SIGNAL_LABELS={"":"확인필요","unknown":"확인필요","on":"ON","off":"OFF","exception":"예외","error":"오류"}
SIGNAL_VALUES=("확인필요","ON","OFF","예외","오류")
SIGNAL_FROM_LABEL={v:k for k,v in SIGNAL_LABELS.items() if k!="unknown"}

STATUS_COLORS={"기설":"#1565c0","신설":"#f9a825","철거":"#424242","절단":"#d32f2f","remove":"#424242","cut":"#d32f2f"}

def status_color(value):return STATUS_COLORS.get(str(value or "기설"),"#1565c0")

def node_name_colors(node):
    try:locked=node['type']=='hamche' and bool(json.loads(node['extra_json'] or '{}').get('editLocked'))
    except (KeyError,TypeError,ValueError):locked=False
    return ('#000000','#ffeb3b') if locked else ('#222222','#ffffff')

CORE_PATH_COLORS={'left':'#ff7a00','right':'#7c3aed','shared':'#16a34a'}

def core_path_colors(left,right,left_slot=None,right_slot=None):
    colors={cid:CORE_PATH_COLORS['shared' if cid in left and cid in right else 'left' if cid in left else 'right'] for cid in left|right}
    for side,path,slot in (('left',left,left_slot),('right',right,right_slot)):
        if slot and slot[0] in path:colors[slot[0]]=CORE_PATH_COLORS[side]
    return colors

def core_path_number_labels(left_rows,right_rows=()):
    sides=[]
    for rows in (left_rows,right_rows):
        grouped={}
        for row in rows:
            if not str(row['cable_id']).startswith('PORT:'):grouped.setdefault(row['cable_id'],set()).add(int(row['core_index']))
        sides.append(grouped)
    left,right=sides;labels={}
    def numbers(values):return '·'.join(str(i) for i in sorted(values))+'번'
    for cid in left.keys()|right.keys():
        a,b=left.get(cid,set()),right.get(cid,set())
        labels[cid]=f'좌 {numbers(a)} / 우 {numbers(b)}' if a and b and a!=b else numbers(a or b)
    return labels

ROUTE_LEGEND_LIMIT=10

def render_route_legend(view,model):
    """Fixed legend above the map: one row per route color with core ID and full core name."""
    old=view.__dict__.pop('_route_legend',None);view._route_legend_swatches=[]
    if old is not None:
        try:old.destroy()
        except tk.TclError:pass
    rows=list((model or {}).get('legend') or ())
    canvas=view.__dict__.get('canvas')
    if not rows or canvas is None or not view.__dict__.get('highlight_cables'):return
    try:host=canvas.master
    except (AttributeError,tk.TclError):return
    frame=tk.Frame(host,bg='#ffffff',highlightbackground='#94a3b8',highlightthickness=1,padx=8,pady=6)
    tk.Label(frame,text='코어 경로 안내',font=('Malgun Gothic',9,'bold'),fg='#192b46',bg='#ffffff').grid(row=0,column=0,columnspan=4,sticky='w',pady=(0,4))
    # Steady swatches (no blinking); the full core name wraps instead of being cut.
    wrap=max(320,min(720,int(canvas.winfo_width()*.45))) if canvas.winfo_width()>1 else 520
    for index,row in enumerate(rows[:ROUTE_LEGEND_LIMIT],start=1):
        swatch=tk.Label(frame,text='  ',width=3,bg=row['color'],relief='flat');swatch.grid(row=index,column=0,sticky='nw',pady=2)
        view._route_legend_swatches.append((swatch,row['color']))
        # Read-only text widgets: drag to select, Ctrl+C (or right-click) to copy.
        color='#c62828' if row.get('fault') else '#172033'
        core=row['core_text'];ident=tk.Entry(frame,font=('Malgun Gothic',9,'bold'),fg=color,readonlybackground='#ffffff',relief='flat',bd=0,highlightthickness=0,width=max(4,min(28,len(core)+1)))
        ident.insert(0,core);ident.configure(state='readonly');ident.grid(row=index,column=1,sticky='nw',padx=(6,6),pady=2)
        # Saved signal of this segment: 신호 있음 (ON) / 신호 없음 (OFF) / 신호 미입력.
        if row.get('signal_text'):
            tk.Label(frame,text=row['signal_text'],font=('Malgun Gothic',8,'bold'),fg='#ffffff',bg=row.get('signal_color') or '#475569',padx=4).grid(row=index,column=2,sticky='nw',padx=(0,6),pady=2)
        name=row.get('name_text') or '(코어명 없음)'
        if row.get('fault'):name+=' · '+row['fault']
        chars=max(12,wrap//7);lines=route_legend_lines(frame,name,min(chars,max(4,len(name)+1)))
        text=tk.Text(frame,font=('Malgun Gothic',9),fg='#c62828' if row.get('fault') else '#334155',bg='#ffffff',relief='flat',bd=0,highlightthickness=0,
                     wrap='char',width=min(chars,max(4,len(name)+1)),height=lines,cursor='xterm',selectbackground='#bfdbfe',selectforeground='#0f172a',inactiveselectbackground='#bfdbfe')
        text.insert('1.0',name);text.configure(state='disabled');text.grid(row=index,column=3,sticky='nw',pady=2)
        for widget in (ident,text):bind_route_legend_copy(widget)
    if len(rows)>ROUTE_LEGEND_LIMIT:
        tk.Label(frame,text=f'외 {len(rows)-ROUTE_LEGEND_LIMIT}개 구간 · 아래 상태줄 참고',font=('Malgun Gothic',8),fg='#64748b',bg='#ffffff').grid(row=ROUTE_LEGEND_LIMIT+1,column=0,columnspan=4,sticky='w')
    try:frame.place(in_=canvas,relx=1.0,x=-12,y=12,anchor='ne');frame.lift()
    except tk.TclError:frame.destroy();return
    view._route_legend=frame

def route_legend_lines(master,name,chars):
    """Measured char-wrap line count, so wide (Korean) glyphs never get cut."""
    try:
        font=tkfont.Font(root=master,family='Malgun Gothic',size=9);limit=chars*max(1,font.measure('0'))
        lines=0
        for part in name.split('\n'):
            lines+=1;used=0
            for ch in part:
                w=font.measure(ch)
                if used and used+w>limit:lines+=1;used=0
                used+=w
        return max(1,lines)
    except tk.TclError:return max(1,sum(-(-max(1,len(part))//max(1,chars//2)) for part in name.split('\n')))

def route_legend_copy(widget):
    try:
        if isinstance(widget,tk.Text):value=widget.get('sel.first','sel.last') if widget.tag_ranges('sel') else widget.get('1.0','end-1c')
        else:value=widget.selection_get() if widget.selection_present() else widget.get()
    except tk.TclError:value=widget.get() if isinstance(widget,tk.Entry) else widget.get('1.0','end-1c')
    widget.clipboard_clear();widget.clipboard_append(value);return 'break'

def bind_route_legend_copy(widget):
    # A disabled Text never takes focus by itself; focus it so Ctrl+C reaches it.
    widget.bind('<Button-1>',lambda e:widget.focus_set(),add='+')
    for sequence in ('<Control-c>','<Control-C>','<<Copy>>'):widget.bind(sequence,lambda e:route_legend_copy(widget))
    widget.bind('<Button-3>',lambda e:route_legend_copy(widget))

def route_legend_text(view):
    """Visible legend text (labels, core IDs and names) for checks and copying."""
    legend=view.__dict__.get('_route_legend');parts=[]
    if legend is None:return ''
    for widget in legend.winfo_children():
        if isinstance(widget,tk.Text):parts.append(widget.get('1.0','end-1c'))
        elif isinstance(widget,tk.Entry):parts.append(widget.get())
        else:
            try:parts.append(str(widget.cget('text')))
            except tk.TclError:pass
    return ' '.join(p for p in parts if p)

def blink_route_legend(view):
    """Legend swatches stay steady by request; only the cables blink."""

def node_badge_rows(warning):
    rows=[]
    if warning.get('rn_in'):rows.append(('RN 내부 배정필요','#ff1744','#ffffff'))
    elif warning.get('count'):rows.append((f"배정필요 {warning['count']}",'#ff1744','#ffffff'))
    if warning.get('duplicate_count'):rows.append((f"코어ID 중복 오류 {warning['duplicate_count']}개",'#c62828','#ffffff'))
    if warning.get('waiting_count'):rows.append((f"연결대기 {warning['waiting_count']}개",'#1565c0','#ffffff'))
    local=warning.get('field_local')
    if local and local['total']:
        rows.append((f"OK {local['ok']}",'#15803d','#ffffff'))
        if local['not_ok']:rows.append((f"NOT OK {local['not_ok']}",'#c62828','#ffffff'))
    field=warning.get('field')
    if field and not local:
        if field['done']:rows.append((f"현장 확인 {field['done']}",'#15803d','#ffffff'))
        if field['pending']:rows.append((f"현장 미확인 {field['pending']}",'#facc15','#172033'))
        if field['issues']:rows.append((f"현장 불일치·이상 {field['issues']}",'#c62828','#ffffff'))
    return rows

def node_display_badges(store,node,warning,options):
    rows=node_badge_rows(visible_node_warning(warning,options))
    badge=workflow.survey_status_badge(store,node,options)
    if badge:rows.append(badge)
    return rows

DISPLAY_DEFAULTS={"survey_status":True,"grid":True,"cable_id":False,"cable_lot":False,"cable_missing_info":True,"cable_check_mark":True,"hamche_spec":False,"hamche_id":False,"rn_computer":False,"badges":True,"auto_labels":True,"field_checks":True,"hamche_assignment":True,"cable_unassigned":True,"cable_incomplete":True,"cable_temporary":True}
DISPLAY_LABELS={"survey_status":"선번조사 상태 표시 (함체·RN / 현장반영)","grid":"배경 격자 표시","cable_id":"케이블ID 항상 표시 (선택 시에는 항상 확인 가능)","cable_lot":"케이블 LOT NO. 항상 표시","cable_missing_info":"ID·LOT 미입력 케이블 노란 테두리 표시","cable_check_mark":"확인 표시 케이블 테두리색 표시 (회색·빨강·파랑)","hamche_spec":"함체·RN 규격 항상 표시","hamche_id":"함체·RN ID 항상 표시","rn_computer":"RN 전산화번호 항상 표시","badges":"도면의 오류·미배정·미완료·연결대기 표시","auto_labels":"케이블 라벨 겹침 자동 조정","field_checks":"현장 OK / NOT OK 건수 표시","hamche_assignment":"배정필요 표시","cable_unassigned":"미배정코어 표시","cable_incomplete":"미완료코어 표시","cable_temporary":"연결완료임시코어 표시"}
DISPLAY_GROUPS=(("공통",("grid","badges","auto_labels")),("함체·RN",("hamche_spec","hamche_id","rn_computer","hamche_assignment","field_checks","survey_status")),("케이블",("cable_id","cable_lot","cable_missing_info","cable_check_mark","cable_unassigned","cable_incomplete","cable_temporary")))

def visible_node_warning(warning,options):
    if not warning:return {}
    result=dict(warning) if options.get('badges',True) else {}
    result.pop('field',None);result.pop('field_local',None)
    if not options.get('hamche_assignment',True):result.pop('count',None);result.pop('rn_in',None)
    if options.get('field_checks',True):
        for key in ('field','field_local'):
            if warning.get(key):result[key]=warning[key]
    return result if any(result.values()) else {}

def read_display_options(path):
    options=dict(DISPLAY_DEFAULTS)
    try:
        data=json.loads(Path(path).read_text(encoding="utf-8"))
        if isinstance(data,dict):
            options.update({k:v for k,v in data.items() if k in options and isinstance(v,bool)})
            # V154 explicitly replaces legacy always-visible ID/LOT defaults.
            # Only a subsequent settings Apply opts back into persistent detail.
            if data.get('cable_label_policy')!='compact_v153':
                options.update(cable_id=False,cable_lot=False)
            if data.get('facility_label_policy')!='compact_v154':
                options.update(hamche_spec=False,hamche_id=False,rn_computer=False)
    except (OSError,ValueError):pass
    return options

def save_display_options(path,options):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+".tmp")
    data={k:bool(options[k]) for k in DISPLAY_DEFAULTS}
    data['cable_label_policy']='compact_v153'
    data['facility_label_policy']='compact_v154'
    temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    os.replace(temporary,path)

class LabelOccupancy:
    """Spatial index for labels: bounded local candidates, deterministic fallback."""
    def __init__(self,cell=160):self.cell=max(20,cell);self.buckets={};self.extent=None
    def cells(self,r):
        for x in range(math.floor(r[0]/self.cell),math.floor(r[2]/self.cell)+1):
            for y in range(math.floor(r[1]/self.cell),math.floor(r[3]/self.cell)+1):yield x,y
    def add(self,r):
        r=tuple(r)
        for cell in self.cells(r):self.buckets.setdefault(cell,[]).append(r)
        self.extent=r if self.extent is None else (min(r[0],self.extent[0]),min(r[1],self.extent[1]),max(r[2],self.extent[2]),max(r[3],self.extent[3]))
    def free(self,r):
        for cell in self.cells(r):
            for other in self.buckets.get(cell,()):
                if r[0]<other[2] and r[2]>other[0] and r[1]<other[3] and r[3]>other[1]:return False
        return True
    def place(self,x,y,width,height,enabled=True):
        def box(cx,cy):return (cx-width/2-4,cy-height/2-4,cx+width/2+4,cy+height/2+4)
        candidates=[(x,y)]
        if enabled:
            for step in range(1,9):
                dy=(height+10)*step;dx=(width+10)*step
                candidates.extend(((x,y-dy),(x,y+dy),(x-dx,y),(x+dx,y),(x-dx,y-dy),(x+dx,y+dy)))
        for cx,cy in candidates:
            r=box(cx,cy)
            if enabled and (r[0]<0 or r[1]<0):continue
            if not enabled or self.free(r):self.add(r);return cx,cy
        # Extremely dense drawings: keep every label readable rather than drop one.
        x=max(width/2+5,x);cy=self.extent[3]+height/2+10 if self.extent else max(height/2+5,y)
        self.add(box(x,cy));return x,cy

def cable_status_style(status):
    """Return the drawing pattern used by both the canvas and SVG export."""
    status=str(status or "기설")
    if status=="신설":return NEW_CABLE_DASH,None
    if status=="철거":return None,"×"
    if status=="절단":return None,"★"
    return None,None

NEW_CABLE_DASH=(16,8)
NEW_CABLE_SVG_DASH="16 8"

def new_cable_dash(width):
    """신설 케이블의 긴 대시(- - -) 패턴. 선 굵기에 맞춰 길이를 늘린다.

    Windows Tk는 첫 대시 길이가 선 굵기의 4배 이하이면 점선(PS_DOT)으로
    바꿔 그리므로, 항상 굵기의 4배보다 길게 잡아 대시로 보이게 한다.
    """
    try:width=float(width)
    except (TypeError,ValueError):width=1.0
    width=max(1.0,width)
    return (min(255,max(NEW_CABLE_DASH[0],int(round(width*4))+6)),min(255,max(NEW_CABLE_DASH[1],int(round(width*2))+4)))

def quadratic_point(x1,y1,mx,my,x2,y2,t):
    u=1-t
    return u*u*x1+2*u*t*mx+t*t*x2,u*u*y1+2*u*t*my+t*t*y2

def quadratic_even_points(x1,y1,mx,my,x2,y2,spacing):
    """이차 곡선의 실제 길이를 근사해 표시점을 거의 같은 간격으로 배치한다."""
    chord=max(1.0,math.hypot(x2-x1,y2-y1));samples=max(40,min(400,int(chord/4)))
    points=[quadratic_point(x1,y1,mx,my,x2,y2,index/samples) for index in range(samples+1)];lengths=[0.0]
    for index in range(1,len(points)):lengths.append(lengths[-1]+math.hypot(points[index][0]-points[index-1][0],points[index][1]-points[index-1][1]))
    total=lengths[-1]
    if total<=1:return [quadratic_point(x1,y1,mx,my,x2,y2,.5)]
    count=max(1,int(total/max(1.0,spacing)));targets=[(index+.5)*total/count for index in range(count)];result=[];cursor=1
    for target in targets:
        while cursor<len(lengths)-1 and lengths[cursor]<target:cursor+=1
        before=max(0,cursor-1);span=max(.0001,lengths[cursor]-lengths[before]);ratio=(target-lengths[before])/span
        result.append((points[before][0]+(points[cursor][0]-points[before][0])*ratio,points[before][1]+(points[cursor][1]-points[before][1])*ratio))
    return result

PARALLEL_CABLE_GAP=26
PARALLEL_CABLE_END=18
PARALLEL_CABLE_TAPER=65

def parallel_cable_path(x1,y1,x2,y2,index,count,scale=1):
    """V205: cables sharing the same two enclosures run as straight parallel
    lines. A lone cable keeps the old 3-point (x1,mid,x2) straight form."""
    if count<=1:return [(x1,y1),((x1+x2)/2,(y1+y2)/2),(x2,y2)]
    dx,dy=x2-x1,y2-y1;length=max(1.0,math.hypot(dx,dy));ux,uy=dx/length,dy/length;px,py=-uy,ux
    offset=(index-(count-1)/2)*PARALLEL_CABLE_GAP*scale
    end=max(-PARALLEL_CABLE_END*scale,min(PARALLEL_CABLE_END*scale,offset))
    if end==offset:return [(x1+px*offset,y1+py*offset),(x2+px*offset,y2+py*offset)]
    taper=min(PARALLEL_CABLE_TAPER*scale,length*.25)
    return [(x1+px*end,y1+py*end),(x1+ux*taper+px*offset,y1+uy*taper+py*offset),(x2-ux*taper+px*offset,y2-uy*taper+py*offset),(x2+px*end,y2+py*end)]

def cable_size_color(size):
    size=int(size or 0)
    return "#d32f2f" if size<=12 else ("#1769aa" if size<=36 else ("#19703a" if size<=72 else ("#e24a9b" if size<=144 else "#795548")))

def cable_path_coords(points):return [v for point in points for v in point]

def cable_path_smooth(points):return len(points)==3

def cable_path_points(coords):return [(coords[i],coords[i+1]) for i in range(0,len(coords)-1,2)]

def _polyline_lengths(points):
    lengths=[0.0]
    for i in range(1,len(points)):lengths.append(lengths[-1]+math.hypot(points[i][0]-points[i-1][0],points[i][1]-points[i-1][1]))
    return lengths

def cable_path_point(points,t):
    if len(points)==3:return quadratic_point(*cable_path_coords(points),t)
    lengths=_polyline_lengths(points);target=max(0.0,min(1.0,t))*lengths[-1]
    for i in range(1,len(points)):
        if lengths[i]>=target or i==len(points)-1:
            span=max(.0001,lengths[i]-lengths[i-1]);r=max(0.0,min(1.0,(target-lengths[i-1])/span))
            return points[i-1][0]+(points[i][0]-points[i-1][0])*r,points[i-1][1]+(points[i][1]-points[i-1][1])*r
    return points[0]

def cable_path_even_points(points,spacing):
    if len(points)==3:return quadratic_even_points(*cable_path_coords(points),spacing)
    total=_polyline_lengths(points)[-1]
    if total<=1:return [cable_path_point(points,.5)]
    count=max(1,int(total/max(1.0,spacing)))
    return [cable_path_point(points,(index+.5)/count) for index in range(count)]

def cable_path_svg(points):
    if len(points)==3:(ax,ay),(mx,my),(bx,by)=points;return f"M {ax} {ay} Q {mx} {my} {bx} {by}"
    return "M "+" L ".join(f"{x} {y}" for x,y in points)

def removal_mark_obstacles(layout,nodes,scale=1,positions=None):
    """Place labels first; removal crosses yield to labels and facility symbols."""
    occupied=LabelOccupancy(max(80,160*scale));positions=positions or {}
    for entry in layout:occupied.add(entry['bounds'])
    for node in nodes.values():
        x,y=positions.get(node['id'],(node['x'],node['y']));rx,ry=node_half_size(node['type'])
        occupied.add(((x-rx-6)*scale,(y-ry-6)*scale,(x+rx+6)*scale,(y+ry+6)*scale))
    return occupied

def removal_mark_points(x1,y1,mx,my,x2,y2,occupied,scale=1):
    return removal_mark_path_points([(x1,y1),(mx,my),(x2,y2)],occupied,scale)

def removal_mark_path_points(path,occupied,scale=1):
    """Keep regular spacing, omitting the full cross wherever a label is drawn."""
    (x1,y1),(x2,y2)=path[0],path[-1]
    radius=max(5,9*scale)+max(2,3*scale)/2+max(4,4*scale)
    def visible(point):
        x,y=point
        return occupied.free((x-radius,y-radius,x+radius,y+radius))
    result=[p for p in cable_path_even_points(path,150*scale) if visible(p)]
    if result:return result
    # A short cable's sole mark may fall behind its centered label. Try the
    # exposed portions without moving the text or crowding crosses together.
    fallback_spacing=max(2,6*scale,math.hypot(x2-x1,y2-y1)/400)
    for point in cable_path_even_points(path,fallback_spacing):
        if visible(point) and all(math.hypot(point[0]-p[0],point[1]-p[1])>=max(30,75*scale) for p in result):result.append(point)
    return result

def star_points(cx,cy,outer,inner):
    points=[]
    for index in range(10):
        radius=outer if index%2==0 else inner;angle=-math.pi/2+index*math.pi/5
        points.extend((cx+math.cos(angle)*radius,cy+math.sin(angle)*radius))
    return points

def draw_trace_diagram(canvas,trace):
    canvas.delete("all");max_x=900;y=28
    groups=trace.get("groups") or []
    if not groups:
        canvas.create_text(24,30,anchor="w",text="표시할 연결 경로가 없습니다.",fill="#777",font=("Malgun Gothic",11));canvas.configure(scrollregion=(0,0,900,180));return
    for group in groups:
        issues=group.get("issues") or [];title=group.get("title") or f'경로 {group.get("number",1)} · '+("확인필요" if issues else "연결 정상")
        title_color="#c62828" if issues else group.get("color","#137333")
        canvas.create_text(20,y,anchor="w",text=title,fill=title_color,font=("Malgun Gothic",11,"bold"));y+=34
        for steps in group.get("paths") or [[]]:
            if not steps:y+=48;continue
            x=30
            first=steps[0].get("from") or "?";w=max(90,min(190,len(first)*13+24))
            canvas.create_rectangle(x,y-19,x+w,y+19,fill="#eef5ff",outline="#1769aa",width=2)
            canvas.create_text(x+w/2,y,text=first,font=("Malgun Gothic",9,"bold"),width=w-10);x+=w
            for step in steps:
                line_w=180;line_color=step.get("draw_color") or group.get("color") or "#ff7a00";canvas.create_line(x+5,y,x+line_w-5,y,fill=line_color,width=4,arrow="last")
                cable_text=f'{step.get("cable","")}({step.get("index","")}번 코어)'
                canvas.create_rectangle(x+18,y-29,x+line_w-18,y-7,fill="#fff7e6",outline="#e6a23c")
                canvas.create_text(x+line_w/2,y-18,text=cable_text,font=("Malgun Gothic",8,"bold"),width=line_w-42)
                if 'identity_result' in step:
                    canvas.create_text(x+line_w/2,y+22,text=(display_core_id(step.get('core_id')) or '(ID 없음)')+' · '+step['identity_result'],fill='#c62828' if step.get('identity_mismatch') else '#415a77',font=('Malgun Gothic',8,'bold'),width=line_w-12)
                x+=line_w;node_text=step.get("to") or "?";w=max(90,min(190,len(node_text)*13+24))
                canvas.create_rectangle(x,y-19,x+w,y+19,fill="#eef5ff",outline="#1769aa",width=2)
                canvas.create_text(x+w/2,y,text=node_text,font=("Malgun Gothic",9,"bold"),width=w-10);x+=w
            max_x=max(max_x,x+30);y+=85 if any('identity_result' in step for step in steps) else 60
        if issues:
            for issue in issues[:5]:canvas.create_text(32,y,anchor="w",text="● "+issue,fill="#c62828",font=("Malgun Gothic",9));y+=22
            if len(issues)>5:canvas.create_text(32,y,anchor="w",text=f"● 그 외 {len(issues)-5}건",fill="#c62828",font=("Malgun Gothic",9));y+=22
        y+=18
    canvas.configure(scrollregion=(0,0,max_x,max(180,y+20)))

TRACE_COLORS=("#e53935","#1565c0","#2e7d32","#8e24aa","#ef6c00","#00838f","#6d4c41","#c2185b")

def normalize_trace_core_id(value):
    value=str(value or '').strip()
    match=re.fullmatch(r'임시\s*코어\s*(\d+)',value)
    return '임시-'+match.group(1) if match else value

def parse_core_ids(value):
    """쉼표로 입력한 코어ID를 입력 순서대로 중복 없이 정리한다."""
    return list(dict.fromkeys(normalize_trace_core_id(part) for part in str(value or "").replace("，",",").split(",") if part.strip()))

def combined_trace_view(traces,colors=None):
    """여러 코어 경로를 한 그림으로 합치고 공통 케이블은 검정색으로 표시한다."""
    colors=colors or (TRACE_COLORS[1:] if any(t.get('field_trace') for t in traces) else TRACE_COLORS);owners={}
    for trace in traces:
        core_id=trace.get("core_id","")
        for cable_id in set(trace.get("highlight") or ()):owners.setdefault(cable_id,set()).add(core_id)
    cable_colors={}
    core_colors={trace.get("core_id",""):colors[index%len(colors)] for index,trace in enumerate(traces)}
    for cable_id,core_ids in owners.items():cable_colors[cable_id]="#111111" if len(core_ids)>1 else core_colors[next(iter(core_ids))]
    groups=[];issues=[]
    for trace in traces:
        core_id=trace.get("core_id","");core_color=core_colors.get(core_id,"#ff7a00")
        for group in trace.get("groups") or ():
            clone=dict(group);clone["title"]=f'{display_core_id(core_id)} · '+(group.get('title') or f'경로 {group.get("number",1)} · '+("확인필요" if group.get("issues") else "연결 정상"));clone["color"]=core_color
            clone["paths"]=[[dict(step,draw_color='#c62828' if step.get('identity_mismatch') else cable_colors.get(step.get("cable_id"),core_color)) for step in path] for path in group.get("paths") or ()]
            groups.append(clone)
        issues.extend(trace.get("issues") or ())
    return {"groups":groups,"issues":list(dict.fromkeys(issues)),"highlight":set(cable_colors),"cable_colors":cable_colors,"core_colors":core_colors}


def connection_trace_view(store,traces):
    """The map and detail diagram share physical segment numbers and colors."""
    slots=[(r['cable_id'],int(r['core_index'])) for trace in traces for r in trace['rows']]
    model=workflow.core_connection_highlight(store,slots);groups=[];issues=[]
    for segment in model['groups']:
        slot=segment['slots'][0];row=store.core(*slot)
        trace=workflow.field_core_trace(store,str(row['core_id'] or '') if row else '',slot=slot)
        for group in trace['groups']:
            clone=dict(group,number=segment['number'],color=segment['color'])
            clone['title']=f"구간 {segment['number']} · "+(' / '.join(segment['ids']) or '임시·ID 없음')
            if not segment['selected']:clone['title']+=' · 같은 ID의 별도 접속 구간'
            clone['paths']=[[dict(step,draw_color=model['colors'].get(step.get('cable_id'),segment['color'])) for step in path] for path in group['paths']]
            groups.append(clone)
        issues.extend(trace['issues'])
    return dict(groups=groups,issues=list(dict.fromkeys(issues)),highlight=set(model['colors']),cable_colors=model['colors'],
                core_colors={},segments=model,summary=model['summary'])

def trace_path_text(trace):
    texts=[]
    for group in trace.get("groups") or []:
        for steps in group.get("paths") or []:
            if not steps:continue
            parts=[steps[0].get("from") or "?"]
            for step in steps:parts.extend((f'{step.get("cable","")}({step.get("index","")}번)',step.get("to") or "?"))
            texts.append(" → ".join(parts))
    return " / ".join(texts)

def select_entry_text(entry):
    entry.selection_range(0,"end");entry.icursor("end");return "break"

def status_label(value):return CORE_STATUS_LABELS.get(str(value or ""),str(value or ""))
def signal_label(value):return SIGNAL_LABELS.get(str(value or ""),str(value or ""))
def display_core_id(value):
    value=str(value or "")
    if value.startswith("임시-"):
        suffix=value.split("-",1)[1]
        return "임시코어"+(suffix if suffix.isdigit() else "")
    return value

def normalize_core_id_input(value):
    """화면용 임시코어1 표기를 저장용 임시-1 표기로 되돌린다.

    V179: 임시코어 123 / 임시 코어123 / 임시123 / 임시-123 모두 그 번호 그대로.
    """
    value=str(value or "").strip()
    match=re.fullmatch(r"임시\s*(?:코어)?\s*-?\s*(\d+)",value)
    return f"임시-{match.group(1)}" if match else value

def confirm_temporary_identity(parent,store,cable_id,changes):
    """V179: ask once when a typed 임시코어N is already used on other numbers."""
    notes=store.temporary_identity_conflicts(cable_id,changes)
    if not notes:return True
    text=("입력한 임시코어 번호가 이미 다른 곳에 있습니다.\n같은 번호는 같은 코어로 보며, 함체에서 만나면 이어질 수 있습니다.\n\n"
          +"\n".join(notes[:10])+(f"\n외 {len(notes)-10}건" if len(notes)>10 else "")
          +"\n\n그래도 이 번호로 바꿀까요?\n(아니오: 바꾸지 않고 입력은 그대로 둡니다)")
    return messagebox.askyesno("같은 임시코어 번호 있음",text,parent=parent)

def parse_core_identity_paste(raw,start,start_col,available):
    """Parse Excel cells without collapsing blank row positions or clearing data.

    Returns (number, ID-or-None, detail-or-None) rows and a preserved-blank-cell
    count. None explicitly means leave the current draft cell untouched.
    """
    raw=str(raw).replace('\r\n','\n').replace('\r','\n')
    try:records=list(csv.reader(io.StringIO(raw),delimiter='\t',strict=True))
    except csv.Error as error:raise ValueError('Excel 표의 따옴표·줄바꿈 형식을 확인하세요.') from error
    result=[];blank_cells=0;offset=0;seen=set();errors=[]
    header_names={'번호','코어번호','코어id','코어아이디','코어명','코어내역','내역'}
    for source_index,cols in enumerate(records):
        labels=[c.strip().lstrip('\ufeff').replace(' ','').lower() for c in cols]
        if source_index==0 and labels and all(not c or c in header_names for c in labels) and any(c in header_names for c in labels):continue
        index=int(start)+offset;offset+=1
        if len(cols)>=3:
            if not cols[0].strip().isdigit():
                if any(c.strip() for c in cols):errors.append(f'{source_index+1}행: 3열 표는 번호 / 코어ID / 코어명 순서여야 합니다.')
                continue
            index=int(cols[0].strip());fields=cols[1:3]
            if any(c.strip() for c in cols[3:]):errors.append(f'{source_index+1}행: 번호·코어ID·코어명 외의 열이 있습니다.');continue
        elif start_col=='#3':
            if any(c.strip() for c in cols[1:]):errors.append(f'{source_index+1}행: 2열 표는 코어ID 칸을 선택하고 붙여넣으세요.');continue
            fields=[None,cols[0] if cols else '']
        else:fields=[cols[0] if cols else '',cols[1] if len(cols)>1 else None]
        blank_cells+=sum(v is not None and not str(v).strip() for v in fields)
        new_id,new_detail=[str(v).strip() if v is not None and str(v).strip() else None for v in fields]
        if new_id is None and new_detail is None:continue
        if index not in available:errors.append(f'{index}번: 케이블 규격 범위 밖입니다.');continue
        if index in seen:errors.append(f'{index}번: 같은 번호가 두 번 입력됐습니다.');continue
        seen.add(index);result.append((index,new_id,new_detail))
    if errors:raise ValueError('붙여넣기를 적용하지 않았습니다.\n'+'\n'.join(errors[:12]))
    return result,blank_cells

def core_row_tag(row):
    if not str(row["core_id"] or "").strip():return "empty"
    values=workflow.statuses(row)|{str(row["signal"] or "")}
    if "cancel" in values:return "cancel"
    if "error" in values and not workflow.is_exception(row):return "error"
    if "broken" in values:return "broken"
    if "pathdiff" in values:return "pathdiff"
    return "used"

def core_signal_tag(row):
    signal=str(row["signal"] or "")
    # V166: an empty number (no ID/내역) still shows an entered OFF/ON mark.
    if not str(row["core_id"] or "").strip() and signal in ("","unknown"):return "signal_unset"
    if signal=="on":return "signal_on"
    if signal=="off":return "signal_off"
    if signal=="exception":return "signal_exception"
    if signal=="error":return "signal_error"
    return "signal_unset"

def core_row_signal_text(row):
    """Signal column: shown for assigned numbers, and for empty numbers once a signal is entered (V166)."""
    signal=str(row["signal"] or "")
    return signal_label(signal) if str(row["core_id"] or "").strip() or signal not in ("","unknown") else ""

def confirm_signal_mix(parent,store,slots,signal):
    """V166: ask first when the new signal would make the connected path 신호 섞임."""
    try:text=workflow.signal_mix_warning(store,slots,signal)
    except (ValueError,KeyError,sqlite3.Error):text=''
    return not text or messagebox.askyesno('신호 섞임 주의',text,parent=parent)

def configure_core_tags(tree):
    tree.tag_configure("empty",background="#ffffff");tree.tag_configure("error",background="#ead7ff",foreground="#6a1b9a")
    tree.tag_configure("dangling",background="#ffb6d5",foreground="#8a174b")
    tree.tag_configure("cancel",background="#d9d9d9",foreground="#111111");tree.tag_configure("broken",background="#ffd6d6",foreground="#a00000")
    tree.tag_configure("pathdiff",background="#fff0b8",foreground="#7a5200")
    tree.tag_configure("signal_on",foreground="#d00000");tree.tag_configure("signal_off",foreground="#111111");tree.tag_configure("signal_unset",foreground="#1769aa");tree.tag_configure("signal_error",foreground="#6a1b9a")
    tree.tag_configure('signal_exception',foreground='#64748b')
    tree.tag_configure('core_issue',background='#fff176')


def app_dir():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    shared_home=os.environ.get("TELECOM_APP_HOME")
    return Path(shared_home).resolve() if shared_home else Path(__file__).resolve().parent


def cable_lot_no(cable):
    if not cable:return ""
    extra=json.loads(cable["extra_json"] or "{}")
    value=extra.get("lotNo","")
    return "" if value is None else str(value)


def cable_missing_fields(cable):
    # V204: 신설 케이블은 ID·LOT NO.가 아직 없는 게 정상이라 미입력(노란 테두리)로 보지 않는다.
    try:status=str(cable['status'] or '').strip()
    except (KeyError,IndexError,TypeError):status=''
    if status=='신설':return ()
    return tuple(label for label,missing in (('ID',not clean_cable_id(cable['cable_id'])),('LOT',not cable_lot_no(cable).strip())) if missing)


CABLE_CHECK_MARKS={'gray':('회색','#9ca3af'),'red':('빨강','#ef4444'),'blue':('파랑','#3b82f6')}


def cable_check_mark(cable):
    """User's own per-cable 'checked' border colour (extra_json checkMark)."""
    try:extra=json.loads(cable['extra_json'] or '{}')
    except (TypeError,ValueError):return ''
    value=str(extra.get('checkMark') or '') if isinstance(extra,dict) else ''
    return value if value in CABLE_CHECK_MARKS else ''


def cable_label_text(cable,options,selected=False):
    label=cable["spec"] or f'{cable["size"]}C'
    lot=cable_lot_no(cable).strip()
    show_lot=selected or options.get('cable_lot',False)
    if lot and show_lot:label+=f' ={lot}='
    cid=clean_cable_id(cable["cable_id"]) if selected or options.get('cable_id',False) else ''
    suffix=(' ' if lot and show_lot else '')+f'({cid})' if cid else ''
    missing=cable_missing_fields(cable) if selected else ()
    return label+suffix+(' ['+' · '.join(x+' 미입력' for x in missing)+']' if missing else '')


def clean_cable_id(value):
    value = str(value or "").strip()
    if "/" in value:
        left, right = value.rsplit("/", 1)
        suffix=right.strip().upper()
        # Quick-create presets do not limit imported or custom cable sizes.
        size=re.fullmatch(r"([0-9]+)\s*C",suffix)
        if suffix in {"드랍", "DROP"} or (size and int(size.group(1))>0):
            return left.strip()
    return value


def is_auto_new_cable_id(value):
    """신설 상태에서 프로그램이 자동 발급한 NEW번호인지 확인한다."""
    value=clean_cable_id(value).strip().upper()
    return value.startswith("NEW") and value[3:].isdigit() and int(value[3:])>0


def subscriber_kind(node):
    try:extra=json.loads(node['extra_json'] or '{}')
    except (KeyError,IndexError,TypeError,ValueError):extra={}
    if not isinstance(extra,dict):extra={}
    value=extra.get('subscriberKind','subscriber')
    return value if value in SUBSCRIBER_TYPES.values() else 'subscriber'

def hamche_details(node):
    if not node or node['type']!='hamche':return '',''
    extra=json.loads(node['extra_json'] or '{}')
    return str(extra.get('hamcheSpec') or '').strip(),str(extra.get('hamcheId') or '').strip()

def normalize_hamche_spec(value):
    value=str(value or '').strip()
    number=re.fullmatch(r'([0-9]+)\s*[cC]?',value)
    return number.group(1)+'C' if number else value

def rn_details(node):
    if not node or node['type']!='rn':return '',''
    extra=json.loads(node['extra_json'] or '{}')
    return tuple('' if extra.get(key) is None else str(extra.get(key,'')).strip() for key in ('rnId','rnComputerNo'))

def hamche_lot_no(node):
    if not node or node['type']!='hamche':return ''
    extra=json.loads(node['extra_json'] or '{}');value=extra.get('lotNo','')
    return '' if value is None else str(value).strip()

def hamche_detail_text(node,options,selected=False):
    if not node or node['type'] not in ('hamche','rn'):return ''
    spec,identifier=hamche_details(node);computer=''
    if node['type']=='rn':
        identifier,computer=rn_details(node)
        extra=json.loads(node['extra_json'] or '{}');saved=extra.get('rnSpec')
        spec=' / '.join(str(k).upper()+' '+str(saved[k]) for k in ('mp','sp','p') if k in saved) if isinstance(saved,dict) else str(saved or '').strip()
    parts=[]
    if selected or options.get('hamche_spec',False):
        if spec or selected:parts.append('규격: '+(spec or '미입력'))
    if selected or options.get('hamche_id',False):
        if identifier or selected:parts.append('ID: '+(identifier or '미입력'))
    if node['type']=='rn' and (selected or options.get('rn_computer',False)):
        if computer or selected:parts.append('전산화번호: '+(computer or '미입력'))
    return ' · '.join(parts)


def node_half_size(node_type):return (36,34) if node_type=='sub' else (32,32)

def subscriber_points(shape,x,y,r=32):
    points=((0,-1),(1,.875),(-1,.875)) if shape=='triangle' else ((0,-.85),(1.08,0),(0,.85),(-1.08,0))
    return [v for dx,dy in points for v in (x+dx*r,y+dy*r)]

def subscriber_symbol(canvas,x,y,visual,scale=1,tags=()):
    items=[];shape=visual['shape']
    if shape in ('triangle','diamond'):
        points=subscriber_points(shape,x,y,32*scale)
        items.append(canvas.create_polygon(points,fill=visual['fill'],outline='#ffffff',width=max(3,12*scale),joinstyle='miter',tags=tags))
        items.append(canvas.create_polygon(points,fill=visual['fill'],outline=visual['outline'],width=max(1,3*scale),joinstyle='miter',tags=tags))
    else:
        r=27*scale;box=(x-r,y-r,x+r,y+r)
        items.append(canvas.create_oval(*box,fill='#ffffff',outline='#ffffff',width=max(3,12*scale),tags=tags))
        items.append(canvas.create_oval(*box,fill=visual['fill'],outline=visual['outline'],width=max(1,3*scale),tags=tags))
    return items

def subscriber_svg(x,y,visual):
    if visual['shape'] in ('triangle','diamond'):
        coords=subscriber_points(visual['shape'],x,y);points=' '.join(f'{coords[i]},{coords[i+1]}' for i in range(0,len(coords),2))
        shape=f'polygon points="{points}"'
    else:shape=f'circle cx="{x}" cy="{y}" r="27"'
    return [f'<{shape} fill="{visual["fill"]}" stroke="white" stroke-width="12" stroke-linejoin="miter"/>',f'<{shape} fill="{visual["fill"]}" stroke="{visual["outline"]}" stroke-width="3"/>']

def node_visual(node):
    node_type=str(node["type"] or "hamche");status=str(node["status"] or "기설")
    color=str(node["color"] or "").strip().lower()
    if node_type=="rn":
        if status=="신설":return {"shape":"circle","fill":"#ffeb3b","outline":"#f44336","text":"RN","text_fill":"#f44336","label_above":True}
        if status=="철거":return {"shape":"circle","fill":"#000000","outline":"#000000","text":"RN","text_fill":"#ffffff","label_above":True}
        if status=="절단":return {"shape":"circle","fill":"#b71c1c","outline":"#b71c1c","text":"RN","text_fill":"#ffffff","label_above":True}
        return {"shape":"circle","fill":"#2196f3","outline":"#2196f3","text":"RN","text_fill":"#ffffff","label_above":True}
    if node_type=="sub":
        fills={"blue":"#0000ff","파란색":"#0000ff","red":"#f44336","빨간색":"#f44336","green":"#00c853","초록색":"#00c853","pink":"#ff4fa3","분홍색":"#ff4fa3"}
        kind=subscriber_kind(node)
        if kind=='ijp':return {"shape":"info","fill":"#ffffff","outline":fills.get(color,'#299962'),"text":"i","text_fill":fills.get(color,'#009d35'),"symbol_font":34,"label_above":True}
        return {"shape":"diamond" if kind=='repeater' else "triangle","fill":fills.get(color,"#0000ff"),"outline":"#000000","text":"","text_fill":"#ffffff","label_above":True}
    if status=="신설":fill,outline="#ffeb3b","#f44336"
    elif status=="철거":fill,outline="#d9d9d9","#2196f3"
    elif status=="절단":fill,outline="#ffd7d7","#f44336"
    else:fill,outline="#ffffff","#2196f3"
    return {"shape":"circle_x","fill":fill,"outline":outline,"text":"","text_fill":outline,"label_above":True}


def recorded(label):
    def decorate(fn):
        def wrapper(self,*args,**kwargs):
            with self.action(label):return fn(self,*args,**kwargs)
        return wrapper
    return decorate


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.conn = sqlite3.connect(self.path, factory=workflow.AtomicConnection)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self._history_group="";self._history_depth=0;self._history_disabled=0;self._warning_cache=None;self._cable_warning_cache=None;self._trace_context_cache=None;self._trace_context_revision=None
        self.conn.create_function("history_group",0,lambda:self._history_group if not self._history_disabled else "")
        self._history_label=''
        self.conn.create_function('annotation_transport',0,lambda:int(not getattr(self,'_slot_identity_edit',False) and self._history_label not in ('케이블 코어순서 교환','RN/가입자 포트 변경','현장 비교 선택 수정')))
        self.create_schema()

    def create_schema(self):
        self._view_generation=getattr(self,'_view_generation',0)+1
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS nodes(
          id TEXT PRIMARY KEY, name TEXT NOT NULL, x REAL NOT NULL, y REAL NOT NULL,
          type TEXT NOT NULL DEFAULT 'hamche', status TEXT DEFAULT '', color TEXT DEFAULT '',
          extra_json TEXT DEFAULT '{}'
        );
        CREATE TABLE IF NOT EXISTS cables(
          id TEXT PRIMARY KEY, n1id TEXT NOT NULL, n2id TEXT NOT NULL,
          cable_id TEXT DEFAULT '', size INTEGER NOT NULL DEFAULT 12,
          spec TEXT NOT NULL DEFAULT '12C', status TEXT NOT NULL DEFAULT '기설', extra_json TEXT DEFAULT '{}',
          FOREIGN KEY(n1id) REFERENCES nodes(id) ON DELETE CASCADE,
          FOREIGN KEY(n2id) REFERENCES nodes(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS cores(
          cable_id TEXT NOT NULL, core_index INTEGER NOT NULL,
          core_id TEXT DEFAULT '', detail TEXT DEFAULT '',
          status1 TEXT DEFAULT '', status2 TEXT DEFAULT '', signal TEXT DEFAULT '',
          PRIMARY KEY(cable_id, core_index),
          FOREIGN KEY(cable_id) REFERENCES cables(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS splices(
          node_id TEXT NOT NULL,
          cable1_id TEXT NOT NULL, core1_index INTEGER NOT NULL,
          cable2_id TEXT NOT NULL, core2_index INTEGER NOT NULL,
          PRIMARY KEY(node_id, cable1_id, core1_index, cable2_id, core2_index)
        );
        CREATE INDEX IF NOT EXISTS idx_cables_nodes ON cables(n1id,n2id);
        CREATE INDEX IF NOT EXISTS idx_cores_id ON cores(core_id);
        CREATE INDEX IF NOT EXISTS idx_splices_left ON splices(cable1_id,core1_index);
        CREATE INDEX IF NOT EXISTS idx_splices_right ON splices(cable2_id,core2_index);
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS workflow_state(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS core_annotations(core_id TEXT PRIMARY KEY, labels TEXT NOT NULL, memo TEXT NOT NULL DEFAULT '');
        CREATE TABLE IF NOT EXISTS survey_rows(
          id TEXT PRIMARY KEY, node_id TEXT NOT NULL,
          left_cable TEXT DEFAULT '', left_index INTEGER DEFAULT 0,
          right_cable TEXT DEFAULT '', right_index INTEGER DEFAULT 0,
          invalid INTEGER NOT NULL DEFAULT 0, error_message TEXT DEFAULT '',
          created_at TEXT DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_survey_node ON survey_rows(node_id);
        CREATE TABLE IF NOT EXISTS ports(
          node_id TEXT NOT NULL, port_index INTEGER NOT NULL, label TEXT NOT NULL,
          core_id TEXT DEFAULT '', detail TEXT DEFAULT '', status1 TEXT DEFAULT '',
          status2 TEXT DEFAULT '', signal TEXT DEFAULT '',
          PRIMARY KEY(node_id,port_index), FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_ports_id ON ports(core_id);
        CREATE TABLE IF NOT EXISTS history_groups(
          id TEXT PRIMARY KEY,label TEXT,created_at TEXT,undone INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS history_events(
          seq INTEGER PRIMARY KEY AUTOINCREMENT,group_id TEXT NOT NULL,table_name TEXT NOT NULL,
          op TEXT NOT NULL,old_json TEXT,new_json TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_history_group ON history_events(group_id,seq);
        """)
        cols = {r[1] for r in self.conn.execute("PRAGMA table_info(cables)")}
        if "spec" not in cols:
            self.conn.execute("ALTER TABLE cables ADD COLUMN spec TEXT NOT NULL DEFAULT ''")
            self.conn.execute("UPDATE cables SET spec=CAST(size AS TEXT)||'C' WHERE spec='' OR spec IS NULL")
        self._create_history_triggers();self._cleanup_empty_history()
        if not workflow.locked(self) and not workflow.any_node_locked(self):self._normalize_temp_core_ids()
        workflow.install_lock_triggers(self);workflow.install_annotation_triggers(self);workflow.install_node_lock_triggers(self);self.conn.commit()

    def _normalize_temp_core_ids(self):
        values=[]
        for table in ("cores","ports"):
            for row in self.conn.execute(f"SELECT core_id FROM {table} WHERE core_id LIKE '임시-%' ORDER BY rowid"):
                value=str(row[0] or "")
                if value and value not in values:values.append(value)
        used={int(value.split("-",1)[1]) for value in values if value.split("-",1)[1].isdigit()}
        row=self.conn.execute("SELECT value FROM meta WHERE key='temp_core_seq'").fetchone()
        try:sequence=max(max(used,default=0),int(row[0]) if row else 0)
        except (TypeError,ValueError):sequence=max(used,default=0)
        for old in values:
            suffix=old.split("-",1)[1]
            if suffix.isdigit():continue
            sequence+=1
            while sequence in used:sequence+=1
            new=f"임시-{sequence}";self.conn.execute("UPDATE cores SET core_id=? WHERE core_id=?",(new,old));self.conn.execute("UPDATE ports SET core_id=? WHERE core_id=?",(new,old));used.add(sequence)
        self.conn.execute("INSERT INTO meta(key,value) VALUES('temp_core_seq',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(str(sequence),))

    def next_temp_core_id(self):
        row=self.conn.execute("SELECT value FROM meta WHERE key='temp_core_seq'").fetchone()
        if not row:self._normalize_temp_core_ids();row=self.conn.execute("SELECT value FROM meta WHERE key='temp_core_seq'").fetchone()
        try:sequence=int(row[0]) if row else 0
        except (TypeError,ValueError):sequence=0
        while True:
            sequence+=1;candidate=f"임시-{sequence}"
            exists=self.conn.execute("SELECT 1 FROM cores WHERE core_id=? UNION ALL SELECT 1 FROM ports WHERE core_id=? LIMIT 1",(candidate,candidate)).fetchone()
            if not exists:break
        self.conn.execute("INSERT INTO meta(key,value) VALUES('temp_core_seq',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(str(sequence),))
        return candidate

    def _create_history_triggers(self):
        for table in ("nodes","cables","cores","splices","ports","survey_rows","workflow_state","core_annotations"):
            cols=[r[1] for r in self.conn.execute(f"PRAGMA table_info({table})")]
            new_json="json_object("+",".join([f"'{c}',NEW.{c}" for c in cols])+")"
            old_json="json_object("+",".join([f"'{c}',OLD.{c}" for c in cols])+")"
            changed=" OR ".join(f"OLD.{c} IS NOT NEW.{c}" for c in cols)
            self.conn.executescript(f"""
            DROP TRIGGER IF EXISTS hist_{table}_i;
            DROP TRIGGER IF EXISTS hist_{table}_d;
            DROP TRIGGER IF EXISTS hist_{table}_u;
            CREATE TRIGGER hist_{table}_i AFTER INSERT ON {table} WHEN history_group()<>'' BEGIN
              INSERT INTO history_events(group_id,table_name,op,old_json,new_json) VALUES(history_group(),'{table}','insert',NULL,{new_json}); END;
            CREATE TRIGGER hist_{table}_d AFTER DELETE ON {table} WHEN history_group()<>'' BEGIN
              INSERT INTO history_events(group_id,table_name,op,old_json,new_json) VALUES(history_group(),'{table}','delete',{old_json},NULL); END;
            CREATE TRIGGER hist_{table}_u AFTER UPDATE ON {table} WHEN history_group()<>'' AND ({changed}) BEGIN
              INSERT INTO history_events(group_id,table_name,op,old_json,new_json) VALUES(history_group(),'{table}','update',{old_json},{new_json}); END;
            """)

    def _cleanup_empty_history(self):
        """예전 버전에서 저장된 무변화 UPDATE와 빈 실행취소 단계를 제거한다."""
        self.conn.execute("DELETE FROM history_events WHERE op='update' AND old_json=new_json")
        self.conn.execute("DELETE FROM history_groups WHERE NOT EXISTS(SELECT 1 FROM history_events e WHERE e.group_id=history_groups.id)")

    @contextmanager
    def action(self,label):
        if not label.startswith('작업정책:') and workflow.locked(self):
            raise ValueError('전도면 편집 잠금 상태입니다. 작업 검사 옵션에서 잠금을 해제하세요.')
        if self._history_disabled:
            yield
            return
        outer=self._history_depth==0
        savepoint='action_'+str(self._history_depth)
        if outer:
            self.conn.hold_commit+=1
            self._history_label=label
            self._history_group="H"+uuid.uuid4().hex
            self.conn.execute("INSERT INTO history_groups(id,label,created_at) VALUES(?,?,?)",(self._history_group,label,datetime.now().isoformat(timespec="seconds")))
        else:self.conn.execute('SAVEPOINT '+savepoint)
        self._history_depth+=1
        try:
            yield
            if outer:
                workflow.after_auto_changed(self)
                workflow.temporary_auto_changed(self)
                workflow.preserve_removed_work_status(self)
        except Exception as error:
            if outer:self.conn.rollback()
            else:self.conn.execute('ROLLBACK TO '+savepoint)
            if isinstance(error,sqlite3.IntegrityError) and str(error).startswith('함체 잠금:'):raise ValueError(str(error)) from error
            raise
        finally:
            self._history_depth-=1
            if not outer:self.conn.execute('RELEASE '+savepoint)
            if outer:
                gid=self._history_group;self._history_group="";self._history_label=''
                count=self.conn.execute("SELECT COUNT(*) FROM history_events WHERE group_id=?",(gid,)).fetchone()[0]
                if not count:
                    self.conn.execute("DELETE FROM history_groups WHERE id=?",(gid,))
                else:
                    self._bump_revision()
                    # 실제 새 변경이 생긴 경우에만 기존 다시실행 가지를 폐기한다.
                    undone=[r[0] for r in self.conn.execute("SELECT id FROM history_groups WHERE undone=1 AND id<>?",(gid,))]
                    for old_id in undone:
                        self.conn.execute("DELETE FROM history_events WHERE group_id=?",(old_id,));self.conn.execute("DELETE FROM history_groups WHERE id=?",(old_id,))
                    old_ids=[r[0] for r in self.conn.execute("SELECT id FROM history_groups WHERE undone=0 ORDER BY rowid DESC LIMIT -1 OFFSET 100")]
                    for old_id in old_ids:
                        self.conn.execute("DELETE FROM history_events WHERE group_id=?",(old_id,));self.conn.execute("DELETE FROM history_groups WHERE id=?",(old_id,))
                self.conn.hold_commit-=1;self.conn.commit();self._warning_cache=None;self._cable_warning_cache=None

    @contextmanager
    def no_history(self):
        self._history_disabled+=1;self.conn.hold_commit+=1
        try:yield
        except Exception:
            self.conn.rollback();raise
        finally:
            self._history_disabled-=1;self.conn.hold_commit-=1;self.conn.commit()

    def _bump_revision(self):
        self.conn.execute("""INSERT INTO meta(key,value) VALUES('data_revision','1')
          ON CONFLICT(key) DO UPDATE SET value=CAST(COALESCE(value,'0') AS INTEGER)+1""")

    def data_revision(self):
        row=self.conn.execute("SELECT value FROM meta WHERE key='data_revision'").fetchone()
        try:return int(row[0]) if row else 0
        except (TypeError,ValueError):return 0

    def _restore_row(self,table,data):
        cols=list(data);marks=",".join("?" for _ in cols)
        self.conn.execute(f"INSERT OR REPLACE INTO {table}({','.join(cols)}) VALUES({marks})",tuple(data[c] for c in cols))

    def _delete_row(self,table,data):
        pks=[r[1] for r in self.conn.execute(f"PRAGMA table_info({table})") if r[5]]
        self.conn.execute(f"DELETE FROM {table} WHERE "+" AND ".join(f"{c}=?" for c in pks),tuple(data[c] for c in pks))

    def _update_row(self,table,data):
        pks=[r[1] for r in self.conn.execute(f"PRAGMA table_info({table})") if r[5]];cols=[c for c in data if c not in pks]
        self.conn.execute(f"UPDATE {table} SET "+",".join(f"{c}=?" for c in cols)+" WHERE "+" AND ".join(f"{c}=?" for c in pks),tuple(data[c] for c in cols+pks))

    def undo(self):
        self.pending_auto_splice_report=None
        g=self.conn.execute("SELECT * FROM history_groups WHERE undone=0 ORDER BY rowid DESC LIMIT 1").fetchone()
        if not g:return "되돌릴 작업이 없습니다."
        with self.no_history():
            for e in self.conn.execute("SELECT * FROM history_events WHERE group_id=? ORDER BY seq DESC",(g["id"],)).fetchall():
                old=json.loads(e["old_json"]) if e["old_json"] else None;new=json.loads(e["new_json"]) if e["new_json"] else None
                if e["op"]=="insert":self._delete_row(e["table_name"],new)
                elif e["op"]=="delete":self._restore_row(e["table_name"],old)
                else:self._update_row(e["table_name"],old)
            self.conn.execute("UPDATE history_groups SET undone=1 WHERE id=?",(g["id"],));self._bump_revision();self.conn.commit()
            self._warning_cache=None;self._cable_warning_cache=None
        return f'{g["label"]} 실행취소'

    def redo(self):
        self.pending_auto_splice_report=None
        g=self.conn.execute("SELECT * FROM history_groups WHERE undone=1 ORDER BY rowid ASC LIMIT 1").fetchone()
        if not g:return "다시 실행할 작업이 없습니다."
        with self.no_history():
            for e in self.conn.execute("SELECT * FROM history_events WHERE group_id=? ORDER BY seq",(g["id"],)).fetchall():
                old=json.loads(e["old_json"]) if e["old_json"] else None;new=json.loads(e["new_json"]) if e["new_json"] else None
                if e["op"]=="delete":self._delete_row(e["table_name"],old)
                elif e["op"]=="insert":self._restore_row(e["table_name"],new)
                else:self._update_row(e["table_name"],new)
            self.conn.execute("UPDATE history_groups SET undone=0 WHERE id=?",(g["id"],));self._bump_revision();self.conn.commit()
            self._warning_cache=None;self._cable_warning_cache=None
        return f'{g["label"]} 다시실행'

    def history_rows(self):
        return [dict(r) for r in self.conn.execute('''SELECT h.rowid position,h.*,
          (SELECT COUNT(*) FROM history_events e WHERE e.group_id=h.id) event_count
          FROM history_groups h ORDER BY h.rowid''')]

    def history_restore_plan(self,group_id,before=False,expected_revision=None):
        if expected_revision is not None and self.data_revision()!=expected_revision:
            raise ValueError('이력 확인 중 도면이 변경됐습니다. 목록을 새로고침하세요.')
        rows=self.history_rows();ids=[r['id'] for r in rows]
        if group_id not in ids:raise ValueError('선택한 이력이 더 이상 없습니다. 목록을 새로고침하세요.')
        current=sum(not r['undone'] for r in rows)
        if any(r['undone'] for r in rows[:current]) or any(not r['undone'] for r in rows[current:]):
            raise ValueError('이력 순서가 맞지 않습니다. 기존 자료를 유지합니다.')
        target=ids.index(group_id)+(0 if before else 1)
        selected=list(reversed(rows[target:current])) if target<current else rows[current:target]
        return dict(direction='undo' if target<current else 'redo',steps=selected,current=current,target=target,revision=self.data_revision())

    def restore_history(self,group_id,before=False,expected_revision=None):
        if self.conn.hold_commit or self._history_depth:raise ValueError('현재 변경이 끝난 뒤 다시 실행하세요.')
        plan=self.history_restore_plan(group_id,before,expected_revision)
        if not plan['steps']:return dict(count=0,backup=None,direction=plan['direction'])
        backup=None
        if str(self.path)!=':memory:':
            backup=self.path.parent/'backup'/f"{self.path.stem}_history_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.sqlite3"
            self.backup_to(backup)
        # All selected undo/redo groups form one transaction. If a lock or a
        # constraint blocks a later group, roll back every earlier group too.
        with self.no_history():
            for group in plan['steps']:
                (self.undo if plan['direction']=='undo' else self.redo)()
        self._view_generation=getattr(self,'_view_generation',0)+1
        return dict(count=len(plan['steps']),backup=backup,direction=plan['direction'])

    def close(self):
        self.conn.close()

    def nodes(self):
        return self.conn.execute("SELECT * FROM nodes ORDER BY rowid").fetchall()

    def cables(self):
        return self.conn.execute("SELECT * FROM cables ORDER BY rowid").fetchall()

    def node(self, node_id):
        return self.conn.execute("SELECT * FROM nodes WHERE id=?", (node_id,)).fetchone()

    def cable(self, cable_id):
        return self.conn.execute("SELECT * FROM cables WHERE id=?", (cable_id,)).fetchone()

    def next_new_cable_id(self):
        """현재 작업에서 비어 있는 가장 빠른 NEW번호를 반환한다."""
        used={clean_cable_id(row[0]).strip().upper() for row in self.conn.execute("SELECT cable_id FROM cables")}
        number=1
        while f"NEW{number}" in used:number+=1
        return f"NEW{number}"

    def cable_id_for_status(self,status,current_id="",cable_key=None,previous_status=None,creating=False):
        """상태 전환 규칙에 따라 자동 NEW번호 또는 빈 ID를 결정한다."""
        status=str(status or "기설");current=clean_cable_id(current_id)
        changed=creating or previous_status is None or str(previous_status or "기설")!=status
        if status=="신설" and changed:
            owners=[row[0] for row in self.conn.execute("SELECT id FROM cables WHERE UPPER(TRIM(cable_id))=?",(current.upper(),))] if is_auto_new_cable_id(current) else []
            if is_auto_new_cable_id(current) and (not owners or all(owner==cable_key for owner in owners)):return current
            return self.next_new_cable_id()
        if status=="기설" and changed and not creating and is_auto_new_cable_id(current):return ""
        return current

    @recorded('함체 잠금 변경')
    def set_node_locked(self,node_id,locked):
        node=self.node(node_id)
        if not node or node['type']!='hamche':raise ValueError('잠금을 변경할 함체를 찾지 못했습니다.')
        extra=json.loads(node['extra_json'] or '{}');extra['editLocked']=bool(locked)
        self.conn.execute('UPDATE nodes SET extra_json=? WHERE id=?',(json.dumps(extra,ensure_ascii=False),node_id))

    def all_enclosures_locked(self):
        total,locked=self.conn.execute("SELECT COUNT(*),SUM(CASE WHEN COALESCE(json_extract(extra_json,'$.editLocked'),0)=1 THEN 1 ELSE 0 END) FROM nodes WHERE type='hamche'").fetchone()
        return bool(total) and total==locked

    @recorded('전체 함체 잠금 변경')
    def set_all_enclosures_locked(self,locked):
        count=0
        for node in self.nodes():
            if node['type']=='hamche' and workflow.node_locked(self,node['id'])!=bool(locked):
                self.set_node_locked(node['id'],locked);count+=1
        return count

    @recorded('시설 말단 설정')
    def set_node_terminal(self,node_id,terminal):
        node=self.node(node_id)
        if not node or node['type'] not in ('hamche','sub','rn'):raise ValueError('끝단으로 처리할 시설을 선택하세요.')
        extra=json.loads(node['extra_json'] or '{}');extra['rn_terminal_v128' if node['type']=='rn' else 'terminal']=bool(terminal)
        self.conn.execute('UPDATE nodes SET extra_json=? WHERE id=?',(json.dumps(extra,ensure_ascii=False),node_id))

    @recorded("시설 만들기")
    def add_node(self, name, x, y, node_type="hamche",subscriber_type="subscriber"):
        if node_type=='sub' and subscriber_type not in SUBSCRIBER_TYPES.values():raise ValueError('가입자 종류를 다시 선택하세요.')
        nid = "N" + uuid.uuid4().hex[:10]
        extra={'subscriberKind':subscriber_type} if node_type=='sub' else {}
        self.conn.execute("INSERT INTO nodes(id,name,x,y,type,status,extra_json) VALUES(?,?,?,?,?,?,?)",
                          (nid, name, x, y, node_type,"기설",json.dumps(extra,ensure_ascii=False)))
        self.conn.commit()
        if node_type in ("rn","sub"):self.ensure_ports(nid)
        return nid

    @recorded('가입자 종류 변경')
    def set_subscriber_kind(self,node_id,kind):
        node=self.node(node_id)
        if not node or node['type']!='sub' or kind not in SUBSCRIBER_TYPES.values():raise ValueError('가입자 종류를 다시 선택하세요.')
        extra=json.loads(node['extra_json'] or '{}');extra['subscriberKind']=kind
        self.conn.execute('UPDATE nodes SET extra_json=? WHERE id=?',(json.dumps(extra,ensure_ascii=False),node_id))

    @recorded('함체 규격·ID·LOT NO. 변경')
    def set_hamche_details(self,node_id,spec,identifier,lot_no=None):
        node=self.node(node_id)
        if not node or node['type']!='hamche':raise ValueError('함체를 선택하세요.')
        extra=json.loads(node['extra_json'] or '{}')
        # Keep the internal node key and all other facility settings intact.
        extra['hamcheSpec']=normalize_hamche_spec(spec);extra['hamcheId']=str(identifier or '').strip()
        if lot_no is not None:
            lot_no=str(lot_no).strip()
            if lot_no:extra['lotNo']=lot_no
            else:extra.pop('lotNo',None)
        self.conn.execute('UPDATE nodes SET extra_json=? WHERE id=?',(json.dumps(extra,ensure_ascii=False),node_id))

    @recorded('RN ID·전산화번호 변경')
    def set_rn_details(self,node_id,identifier,computer_no):
        node=self.node(node_id)
        if not node or node['type']!='rn':raise ValueError('RN을 선택하세요.')
        extra=json.loads(node['extra_json'] or '{}')
        for key,value in (('rnId',identifier),('rnComputerNo',computer_no)):
            extra[key]=str(value or '').strip()
        self.conn.execute('UPDATE nodes SET extra_json=? WHERE id=?',(json.dumps(extra,ensure_ascii=False),node_id))

    @recorded('시설 정보 저장')
    def set_node_details(self,node_id,name,hamche=None,rn=None):
        if not self.node(node_id):raise ValueError('시설을 찾을 수 없습니다.')
        name=str(name or '').strip()
        if not name:raise ValueError('시설명을 입력하세요.')
        self.conn.execute('UPDATE nodes SET name=? WHERE id=?',(name,node_id))
        if hamche is not None:self.set_hamche_details(node_id,*hamche)
        if rn is not None:self.set_rn_details(node_id,*rn)

    @recorded("시설 상태 변경")
    def set_node_status(self,node_id,status):
        if status not in STATUS_VALUES:raise ValueError("올바른 시설 상태가 아닙니다.")
        self.conn.execute("UPDATE nodes SET status=? WHERE id=?",(status,node_id));self.conn.commit()

    @recorded("여러 시설 상태 변경")
    def set_nodes_status(self,node_ids,status):
        if status not in STATUS_VALUES:raise ValueError("올바른 시설 상태가 아닙니다.")
        ids=[str(x) for x in node_ids if self.node(x)]
        if ids:self.conn.executemany("UPDATE nodes SET status=? WHERE id=?",[(status,x) for x in ids]);self.conn.commit()
        return len(ids)

    @recorded("가입자 색상 변경")
    def set_subscriber_colors(self,node_ids,color):
        if color not in ("파란색","빨간색","초록색","분홍색"):raise ValueError("올바른 가입자 색상이 아닙니다.")
        ids=[str(x) for x in node_ids if self.node(x) and self.node(x)["type"]=="sub"]
        if ids:self.conn.executemany("UPDATE nodes SET color=? WHERE id=?",[(color,x) for x in ids]);self.conn.commit()
        return len(ids)

    def update_node_pos(self, node_id, x, y):
        self.conn.execute("UPDATE nodes SET x=?,y=? WHERE id=?", (x, y, node_id))

    @recorded("케이블 만들기")
    def add_cable(self, n1id, n2id, cable_name, spec, status, lot_no=""):
        cid = "C" + uuid.uuid4().hex[:10]
        spec = str(spec).strip()
        size = 1 if spec == "드랍" else int(spec.upper().replace("C", ""))
        cable_name=self.cable_id_for_status(status,cable_name,creating=True)
        lot_no=str(lot_no or "").strip()
        extra={"lotNo":lot_no} if lot_no else {}
        self.conn.execute("INSERT INTO cables(id,n1id,n2id,cable_id,size,spec,status,extra_json) VALUES(?,?,?,?,?,?,?,?)",
                          (cid, n1id, n2id, cable_name, size, spec, status, json.dumps(extra,ensure_ascii=False)))
        self.conn.executemany(
            "INSERT INTO cores(cable_id,core_index) VALUES(?,?)",
            [(cid, i) for i in range(1, int(size) + 1)])
        self.conn.commit()
        return cid

    @recorded("케이블 LOT NO. 변경")
    def set_cable_lot_no(self,cable_id,lot_no):
        cable=self.cable(cable_id)
        if not cable:raise ValueError("케이블을 찾을 수 없습니다.")
        extra=json.loads(cable["extra_json"] or "{}")
        lot_no=str(lot_no or "").strip()
        if lot_no:extra["lotNo"]=lot_no
        else:extra.pop("lotNo",None)
        self.conn.execute("UPDATE cables SET extra_json=? WHERE id=?",(json.dumps(extra,ensure_ascii=False),cable_id))
        self.conn.commit()

    @recorded("케이블 확인 표시")
    def set_cables_check_mark(self,cable_ids,mark):
        mark=str(mark or '')
        if mark and mark not in CABLE_CHECK_MARKS:raise ValueError("올바른 확인 표시 색이 아닙니다.")
        count=0
        for cable_id in dict.fromkeys(str(x) for x in cable_ids):
            cable=self.cable(cable_id)
            if not cable or cable_check_mark(cable)==mark:continue
            extra=json.loads(cable["extra_json"] or "{}")
            if mark:extra["checkMark"]=mark
            else:extra.pop("checkMark",None)
            self.conn.execute("UPDATE cables SET extra_json=? WHERE id=?",(json.dumps(extra,ensure_ascii=False),cable_id));count+=1
        self.conn.commit();return count

    @recorded("케이블 상태 변경")
    def set_cable_status(self,cable_id,status):
        if status not in STATUS_VALUES:raise ValueError("올바른 케이블 상태가 아닙니다.")
        cable=self.cable(cable_id)
        if not cable:return
        cable_name=self.cable_id_for_status(status,cable["cable_id"],cable_id,cable["status"])
        self.conn.execute("UPDATE cables SET status=?,cable_id=? WHERE id=?",(status,cable_name,cable_id));self.conn.commit()

    def cable_end_move_preview(self,cable_id,old_node_id,new_node_id):
        """Moving one end keeps the cable row and its cores; only that end's splices go."""
        cable=self.cable(cable_id)
        if not cable:raise ValueError("케이블을 찾을 수 없습니다.")
        old=str(old_node_id);new=str(new_node_id)
        if old not in (cable["n1id"],cable["n2id"]):raise ValueError("옮길 끝이 이 케이블에 연결되어 있지 않습니다.")
        column="n1id" if cable["n1id"]==old else "n2id";other=cable["n2id"] if column=="n1id" else cable["n1id"]
        if not self.node(new):raise ValueError("새로 붙일 시설을 찾을 수 없습니다.")
        if new==old:raise ValueError("지금 붙어 있는 시설입니다. 다른 시설을 클릭하세요.")
        if new==other:raise ValueError("케이블 반대쪽 시설입니다. 다른 시설을 클릭하세요.")
        splices=self.conn.execute("SELECT COUNT(*) FROM splices WHERE node_id=? AND (cable1_id=? OR cable2_id=?)",(old,cable_id,cable_id)).fetchone()[0]
        cores=self.conn.execute("SELECT COUNT(*) FROM cores WHERE cable_id=? AND (COALESCE(core_id,'')<>'' OR COALESCE(detail,'')<>'')",(cable_id,)).fetchone()[0]
        return dict(column=column,other=other,splices=splices,cores=cores)

    @recorded("케이블 끝 옮기기 (코어내역 유지)")
    def move_cable_end(self,cable_id,old_node_id,new_node_id):
        preview=self.cable_end_move_preview(cable_id,old_node_id,new_node_id)
        self.conn.execute("DELETE FROM splices WHERE node_id=? AND (cable1_id=? OR cable2_id=?)",(str(old_node_id),cable_id,cable_id))
        self.conn.execute(f"UPDATE cables SET {preview['column']}=? WHERE id=?",(str(new_node_id),cable_id))
        self.conn.commit();return preview

    @recorded("여러 케이블 상태 변경")
    def set_cables_status(self,cable_ids,status):
        if status not in STATUS_VALUES:raise ValueError("올바른 케이블 상태가 아닙니다.")
        ids=[str(x) for x in cable_ids if self.cable(x)]
        used={};
        for row in self.conn.execute("SELECT cable_id FROM cables"):
            value=clean_cable_id(row[0]).strip().upper();used[value]=used.get(value,0)+1
        next_number=1
        for cable_id in ids:
            cable=self.cable(cable_id);cable_name=clean_cable_id(cable["cable_id"]);upper=cable_name.strip().upper()
            changed=str(cable["status"] or "기설")!=status
            if status=="신설" and changed and not (is_auto_new_cable_id(cable_name) and used.get(upper,0)==1):
                while used.get(f"NEW{next_number}",0):next_number+=1
                cable_name=f"NEW{next_number}";used[cable_name]=1;next_number+=1
            elif status=="기설" and changed and is_auto_new_cable_id(cable_name):cable_name=""
            self.conn.execute("UPDATE cables SET status=?,cable_id=? WHERE id=?",(status,cable_name,cable_id))
        if ids:self.conn.commit()
        return len(ids)

    @recorded("케이블 규격 변경")
    def resize_cable(self, cable_id, new_spec):
        old = self.cable(cable_id)
        if not old:
            return
        new_spec = str(new_spec).strip()
        new_size = 1 if new_spec == "드랍" else int(new_spec.upper().replace("C", ""))
        old_size = old["size"]
        if new_size > old_size:
            self.conn.executemany("INSERT OR IGNORE INTO cores(cable_id,core_index) VALUES(?,?)",
                                  [(cable_id, i) for i in range(old_size + 1, new_size + 1)])
        elif new_size < old_size:
            self.conn.execute("DELETE FROM splices WHERE (cable1_id=? AND core1_index>?) OR (cable2_id=? AND core2_index>?)",
                              (cable_id, new_size, cable_id, new_size))
            self.conn.execute("DELETE FROM cores WHERE cable_id=? AND core_index>?", (cable_id, new_size))
        self.conn.execute("UPDATE cables SET size=?,spec=? WHERE id=?", (new_size, new_spec, cable_id))
        self.conn.commit()

    def cores(self, cable_id):
        if str(cable_id).startswith("PORT:"):
            nid=str(cable_id).split(":",1)[1]
            return [workflow.annotate(self,r) for r in self.conn.execute("""SELECT ? cable_id,port_index core_index,core_id,detail,status1,status2,signal,label
              FROM ports WHERE node_id=? ORDER BY port_index""",(cable_id,nid)).fetchall()]
        return [workflow.annotate(self,r) for r in self.conn.execute("SELECT * FROM cores WHERE cable_id=? ORDER BY core_index", (cable_id,)).fetchall()]

    def cable_usage(self,cable_id):
        """케이블의 전체 코어수와 코어ID가 배정된 사용 코어수를 반환한다."""
        cable=self.cable(cable_id)
        if not cable:return {"total":0,"used":0,"rate":0.0}
        used=self.conn.execute("SELECT COUNT(*) FROM cores WHERE cable_id=? AND TRIM(COALESCE(core_id,''))<>''",(cable_id,)).fetchone()[0]
        total=int(cable["size"] or 0);rate=(used*100.0/total) if total else 0.0
        return {"total":total,"used":int(used),"rate":rate}

    def core(self, cable_id, index):
        if str(cable_id).startswith("PORT:"):
            nid=str(cable_id).split(":",1)[1]
            return workflow.annotate(self,self.conn.execute("""SELECT ? cable_id,port_index core_index,core_id,detail,status1,status2,signal,label
              FROM ports WHERE node_id=? AND port_index=?""",(cable_id,nid,index)).fetchone())
        return workflow.annotate(self,self.conn.execute("SELECT * FROM cores WHERE cable_id=? AND core_index=?",
                                 (cable_id, index)).fetchone())

    @recorded("RN/가입자 포트 변경")
    def ensure_ports(self,node_id,spec=None):
        n=self.node(node_id)
        if not n or n["type"] not in ("rn","sub"):return
        if n["type"]=="rn":
            spec=spec or {"mp":4,"sp":0,"p":4};labels=["IN"]+[f"MP{i}" for i in range(1,int(spec["mp"])+1)]+[f"SP{i}" for i in range(1,int(spec["sp"])+1)]+[f"P{i}" for i in range(1,int(spec["p"])+1)]
        else:
            spec=spec or {"p":4};labels=[f"P{i}" for i in range(1,int(spec["p"])+1)]
        old={r["label"]:r for r in self.conn.execute("SELECT * FROM ports WHERE node_id=? ORDER BY port_index",(node_id,))}
        extra=json.loads(n["extra_json"] or "{}");spec_key="rnSpec" if n["type"]=="rn" else "subSpec"
        if list(old)==labels and extra.get(spec_key)==spec:return
        self.conn.execute("DELETE FROM ports WHERE node_id=?",(node_id,))
        for i,label in enumerate(labels,1):
            r=old.get(label)
            self.conn.execute("INSERT INTO ports VALUES(?,?,?,?,?,?,?,?)",(node_id,i,label,r["core_id"] if r else "",r["detail"] if r else "",r["status1"] if r else "",r["status2"] if r else "",r["signal"] if r else ""))
        extra[spec_key]=spec
        self.conn.execute("UPDATE nodes SET extra_json=? WHERE id=?",(json.dumps(extra,ensure_ascii=False),node_id))
        for old_row in old.values():
            old_id=old_row['core_id']
            if old_id:self.conn.execute('DELETE FROM core_annotations WHERE core_id=? AND NOT EXISTS(SELECT 1 FROM cores WHERE core_id=?) AND NOT EXISTS(SELECT 1 FROM ports WHERE core_id=?)',(old_id,old_id,old_id))

    def node_cables(self, node_id):
        return self.conn.execute("SELECT * FROM cables WHERE n1id=? OR n2id=? ORDER BY rowid",
                                 (node_id, node_id)).fetchall()

    def opposite_name(self, cable, node_id):
        other_id = cable["n2id"] if cable["n1id"] == node_id else cable["n1id"]
        row = self.node(other_id)
        return row["name"] if row else "?"

    def cable_choice(self, cable, node_id):
        other = self.opposite_name(cable, node_id)
        spec = cable["spec"] or f'{cable["size"]}C'
        cid = clean_cable_id(cable["cable_id"])
        suffix = f" · {cid}" if cid else ""
        return f'{other} · {spec}{suffix}'

    def node_cable_choices(self,node_id):
        cables=self.node_cables(node_id);bases=[self.cable_choice(c,node_id) for c in cables];counts={x:bases.count(x) for x in set(bases)};seen={};out=[]
        for c,base in zip(cables,bases):
            seen[base]=seen.get(base,0)+1;label=base+(f" · {seen[base]}번선" if counts[base]>1 else "");out.append((label,c["id"]))
        return out

    def node_assignment_needs(self,node_id):
        """Read only this facility's slots; pink means a local assignment is needed."""
        if workflow.field_slot_mode(self):return workflow.field_slot_needs(self,node_id)
        node=self.node(node_id)
        if not node:return {}
        if workflow.completion_kind(self)=='after':
            report=workflow.completion_report(self);result={};extra=json.loads(node['extra_json'] or '{}')
            exceptions=extra.get('assignmentExceptions') or {}
            for cid,index in report['assignment_needs'].get(node_id,()):
                if workflow.hamche_temporary_exempt(node,self.core(cid,index)) or exceptions.get(f'{cid}::{index}'):continue
                result.setdefault(cid,set()).add(index)
            return result
        cables=[c for c in self.node_cables(node_id) if str(c['spec'] or '').strip()!='드랍']
        extra=json.loads(node['extra_json'] or '{}')
        if workflow.assignment_terminal(node,len(cables),extra):return {}
        rows={}
        if cables:
            ids=[c['id'] for c in cables];marks=','.join('?' for _ in ids)
            for r in self.conn.execute(f'SELECT * FROM cores WHERE cable_id IN ({marks})',ids):
                rows[(r['cable_id'],int(r['core_index']))]=workflow.annotate(self,r)
        for r in self.conn.execute('SELECT * FROM ports WHERE node_id=?',(node_id,)):
            rows[('PORT:'+node_id,int(r['port_index']))]=workflow.annotate(self,r)
        linked=set()
        for sp in self.conn.execute('SELECT * FROM splices WHERE node_id=?',(node_id,)):
            a=(sp['cable1_id'],int(sp['core1_index']));b=(sp['cable2_id'],int(sp['core2_index']))
            ar=rows.get(a);br=rows.get(b)
            if a[0]!=b[0] and ar and br and str(ar['core_id'] or '').strip() and ar['core_id']==br['core_id']:
                linked.update((a,b))
        result={};exceptions=extra.get('assignmentExceptions') or {};required_slots=workflow.completion_report(self)['required_slots']
        for slot,row in rows.items():
            if slot not in required_slots or slot in linked or workflow.core_connection_exempt(row):continue
            if workflow.hamche_temporary_exempt(node,row):continue
            if exceptions.get(f'{slot[0]}::{slot[1]}'):continue
            result.setdefault(slot[0],set()).add(slot[1])
        return result

    def waiting_connection_groups(self,node_id):
        """Free same-ID cable slots at this facility, matching its waiting badge."""
        node=self.node(node_id)
        if not node or node['type'] not in ('hamche','rn'):return []
        if workflow.terminal_marked(node):return []
        cables=[c for c in self.node_cables(node_id) if str(c['spec'] or '').strip()!='드랍']
        linked=set()
        for sp in self.conn.execute('SELECT * FROM splices WHERE node_id=?',(node_id,)):
            linked.update(((sp['cable1_id'],int(sp['core1_index'])),(sp['cable2_id'],int(sp['core2_index']))))
        grouped={};report=workflow.completion_report(self);required_slots=report['required_slots']
        if report['kind']=='after':
            required_slots=required_slots & report['waiting_slots'].get(node_id,frozenset());linked=set()
        for cable in cables:
            for row in self.cores(cable['id']):
                slot=(cable['id'],int(row['core_index']));core_id=str(row['core_id'] or '').strip()
                if not core_id or slot in linked or slot not in required_slots or workflow.core_connection_exempt(row):continue
                if workflow.hamche_temporary_exempt(node,row):continue
                member={'slot':slot,'direction':self.opposite_name(cable,node_id),
                        'cable_id':clean_cable_id(cable['cable_id']) or '(ID 없음)',
                        'spec':cable['spec'] or f"{cable['size']}C",'core_id':core_id,
                        'detail':str(row['detail'] or ''),'status':workflow.annotation_text(self,row),
                        'signal':signal_label(row['signal'])}
                grouped.setdefault(core_id,[]).append(member)
        return [{'core_id':core_id,'members':sorted(members,key=lambda r:(r['direction'],r['cable_id'],r['slot'][1],r['slot'][0]))}
                for core_id,members in sorted(grouped.items()) if len({r['slot'][0] for r in members})>=2]

    def connect_waiting_pairs(self,node_id,pairs,expected_revision):
        """Apply reviewed local pairs atomically; never choose an ambiguous pair."""
        if workflow.node_locked(self,node_id):raise ValueError('함체 잠금: 자물쇠를 해제한 뒤 연결하세요.')
        if self.data_revision()!=expected_revision:raise ValueError('확인 중 도면이 변경되었습니다. 새로고침한 뒤 양쪽 코어를 다시 확인하세요.')
        if not pairs:raise ValueError('연결할 항목을 선택하세요.')
        groups={group['core_id']:{r['slot'] for r in group['members']} for group in self.waiting_connection_groups(node_id)}
        selected=[];used=set()
        for core_id,left,right in pairs:
            left=tuple(left);right=tuple(right);available=groups.get(core_id,set())
            if left[0]==right[0]:raise ValueError('서로 다른 케이블의 코어 두 개를 선택하세요.')
            if left not in available or right not in available:
                raise ValueError(f'{display_core_id(core_id)}: 배정·접속·예외 상태가 변경되었습니다. 연결대기를 다시 확인하세요.')
            if left in used or right in used:raise ValueError('같은 코어를 두 연결에 중복 선택했습니다.')
            used.update((left,right));selected.append((left,right))
        self.conn.hold_commit+=1
        try:
            with self.action('연결대기 최종 연결'):
                for left,right in selected:self.connect(node_id,left,right)
        except Exception:
            self.conn.rollback();raise
        finally:self.conn.hold_commit-=1
        self.conn.commit();return len(selected)

    def node_warning_summary(self):
        if self._warning_cache is not None:return self._warning_cache
        if workflow.completion_kind(self)=='after':
            result={};report=workflow.completion_report(self);rn_net=workflow.Network(self.conn)
            for nid in set(report['assignment_needs'])|set(report['waiting_slots']):
                node=self.node(nid)
                if not node:continue
                missing=self.node_assignment_needs(nid)
                ids={str(self.core(cid,index)['core_id'] or '').strip() or (cid,index) for cid,indices in missing.items() for index in indices}
                if ids and node['type'] in ('hamche','rn') and not workflow.after_rn_in_connected(self,nid,rn_net):result[nid]={'count':len(ids),'rn_in':node['type']=='rn'}
                waiting=frozenset(group['core_id'] for group in self.waiting_connection_groups(nid))
                if waiting:result.setdefault(nid,{'count':0,'rn_in':False}).update(waiting_count=len(waiting),waiting_ids=waiting)
            for conflict in report.get('automatic_conflicts',()):
                item=result.setdefault(conflict['node_id'],{'count':0,'rn_in':False})
                item['duplicate_count']=item.get('duplicate_count',0)+1
            self._warning_cache=result;return result
        nodes={n["id"]:n for n in self.nodes()};cables={c["id"]:c for c in self.cables()};by_node={nid:[] for nid in nodes}
        marked_ends={nid for nid,node in nodes.items() if workflow.terminal_marked(node)}
        for c in cables.values():
            if str(c["spec"] or "").strip()=="드랍":continue
            by_node.setdefault(c["n1id"],[]).append(c);by_node.setdefault(c["n2id"],[]).append(c)
        connected=set()
        for s in self.conn.execute("SELECT * FROM splices"):
            connected.add((s["node_id"],s["cable1_id"],s["core1_index"]));connected.add((s["node_id"],s["cable2_id"],s["core2_index"]))
        need={nid:set() for nid in nodes}
        used_by_node={nid:[] for nid in nodes};waiting_by_node={nid:{} for nid in nodes}
        required_slots=workflow.completion_report(self)['required_slots']
        for r in self.conn.execute("SELECT cable_id,core_index,core_id,status1,status2,signal FROM cores"):
            c=cables.get(r["cable_id"])
            if not c or str(c["spec"] or "").strip()=="드랍":continue
            if workflow.core_connection_exempt(workflow.annotate(self,r)):continue
            if (r['cable_id'],int(r['core_index'])) not in required_slots:continue
            core_id=str(r['core_id'] or '').strip()
            for nid in (c['n1id'],c['n2id']):
                node=nodes.get(nid)
                if workflow.hamche_temporary_exempt(node,r):continue
                if core_id and node and nid not in marked_ends and node['type'] in ('hamche','rn') and (nid,r['cable_id'],r['core_index']) not in connected:
                    waiting_by_node[nid].setdefault(core_id,set()).add(r['cable_id'])
            for nid in (c["n1id"],c["n2id"]):
                if not workflow.hamche_temporary_exempt(nodes.get(nid),r):used_by_node.setdefault(nid,[]).append((r["cable_id"],r["core_index"],r["core_id"]))
        result={}
        for nid,n in nodes.items():
            if nid in marked_ends:continue
            extra=json.loads(n["extra_json"] or "{}")
            if n["type"]=="hamche" and len(by_node.get(nid,()))>1 and not extra.get("terminal"):
                for cid,idx,core_id in used_by_node.get(nid,()):
                    exceptions=extra.get("assignmentExceptions") or {}
                    if (nid,cid,idx) not in connected and not exceptions.get(f"{cid}::{idx}"):need[nid].add(str(core_id) or (cid,idx))
            elif n["type"]=="rn":
                missing=self.node_assignment_needs(nid)
                ids={str(self.core(cid,index)['core_id']) or (cid,index) for cid,indices in missing.items() for index in indices}
                if ids:result[nid]={"count":len(ids),"rn_in":True}
            if need[nid]:result[nid]={"count":len(need[nid]),"rn_in":False}
        # Count distinct IDs with free slots on at least two different cables
        # at this facility. Connections at the opposite end do not consume them.
        for nid,groups in waiting_by_node.items():
            ids=frozenset(core_id for core_id,cids in groups.items() if len(cids)>=2)
            if ids:result.setdefault(nid,{'count':0,'rn_in':False}).update(waiting_count=len(ids),waiting_ids=ids)
        mode=self.conn.execute("SELECT value FROM meta WHERE key='active_scenario'").fetchone()
        if mode and mode[0]=='before':
            records=workflow.field_records(self)
            for nid,node in nodes.items():
                if not workflow.field_required(self,node,len(by_node.get(nid,()))):continue
                field=workflow.field_summary(self,nid,records.get(nid,{}))
                if field['total']:result.setdefault(nid,{'count':0,'rn_in':False})['field']=field
                local=workflow.field_local_summary(self,nid,records.get(nid,{}))
                if local['total']:result.setdefault(nid,{'count':0,'rn_in':False})['field_local']=local
        self._warning_cache=result;return result

    def cable_core_warning_summary(self):
        """One cached topology pass supplies cable badges, the dashboard and error details."""
        if workflow.field_slot_mode(self):return workflow.field_slot_warning_summary(self)
        key=(self.data_revision(),self.conn.total_changes)
        if self._cable_warning_cache is not None and getattr(self,'_diagnostics_key',None)==key:
            return self._cable_warning_cache
        nodes={n['id']:n for n in self.nodes()};cables={c['id']:c for c in self.cables()}
        rows=self.all_core_rows();row_by_slot={(r['cable_id'],int(r['core_index'])):r for r in rows}
        if workflow.completion_kind(self)=='after':
            report=workflow.completion_report(self)
            for slot in report.get('off_slots',()):
                if slot in row_by_slot:row_by_slot[slot]=dict(row_by_slot[slot],signal='off')
            port_ids=report.get('rn_port_identities',{})
            for slot,cid in port_ids.items():row_by_slot[slot]['core_id']=cid
        exception_ids={str(r['core_id'] or '').strip() for r in rows if workflow.is_exception(r)}-{''}
        exception_slots={slot for slot,row in row_by_slot.items() if workflow.is_exception(row) or str(row['core_id'] or '').strip() in exception_ids}
        extras={};degree={nid:0 for nid in nodes}
        for nid,n in nodes.items():
            try:extras[nid]=json.loads(n['extra_json'] or '{}')
            except (ValueError,TypeError):extras[nid]={}
        for c in cables.values():
            if str(c['spec'] or '').strip()=='드랍':continue
            for nid in (c['n1id'],c['n2id']):degree[nid]=degree.get(nid,0)+1
        errors={};error_causes={};adjacency={};links={};by_id={};marked_ids=set()
        unassigned={cid:set() for cid in cables};incomplete={cid:set() for cid in cables};temporary={cid:set() for cid in cables}

        def add_error(slot,reason,cause):
            if workflow.core_connection_exempt(row_by_slot.get(slot)):
                if cause in ('unconnected','endpoints'):return
                if cause=='port' and not adjacency.get(slot):return
                if cause=='split':return
            if slot[0] in cables or (slot[0].startswith('PORT:') and slot[0][5:] in nodes):
                errors.setdefault(slot,set()).add(reason)
                error_causes.setdefault(slot,set()).add(cause)

        def at_node(slot,nid):
            if slot[0].startswith('PORT:'):return slot[0][5:]==nid and slot in row_by_slot
            cable=cables.get(slot[0]);return bool(cable and nid in (cable['n1id'],cable['n2id']) and slot in row_by_slot)

        for slot,row in row_by_slot.items():
            core_id=str(row['core_id'] or '').strip()
            if core_id:by_id.setdefault(core_id,set()).add(slot)
            if core_id and core_id not in exception_ids and 'error' in workflow.statuses(row):marked_ids.add(core_id)
            if core_id.startswith('임시-') and slot[0] in cables:temporary[slot[0]].add(slot[1])
            fields=(['상태'] if 'error' in workflow.statuses(row) else [])+(['신호'] if row['signal']=='error' else [])
            if fields:add_error(slot,', '.join(fields)+'에 오류코어로 표시되어 있습니다.','marked')

        invalid_net=None
        for sp in self.conn.execute('SELECT * FROM splices'):
            a=(sp['cable1_id'],int(sp['core1_index']));b=(sp['cable2_id'],int(sp['core2_index']));nid=sp['node_id']
            if nid not in nodes or a[0]==b[0] or not at_node(a,nid) or not at_node(b,nid):
                if invalid_net is None:invalid_net=workflow.Network(self.conn)
                reason=invalid_net.splice_issue(nid,a,b)['reason']
                for slot in (a,b):add_error(slot,reason,'invalid')
                continue
            for slot,other in ((a,b),(b,a)):
                adjacency.setdefault(slot,set()).add(other);links.setdefault((nid,slot),[]).append(other)
            aid=str(row_by_slot[a]['core_id'] or '').strip();bid=str(row_by_slot[b]['core_id'] or '').strip()
            if not aid or not bid or aid!=bid:
                reason=f'서로 다른 코어ID 또는 빈 코어와 접속됨: {display_core_id(aid) or "빈 코어"} / {display_core_id(bid) or "빈 코어"}'
                for slot in (a,b):add_error(slot,reason,'identity')

        if workflow.completion_kind(self)=='after':
            # V187: checked 「도면 밖 연결」 marks join two drawn ends; a mark
            # that no longer matches is reported instead of being trusted.
            for item in workflow.offmap_evaluate(self):
                a,b=item['slots'];na,nb=item['nodes']
                if item['state']=='ok' and a in row_by_slot and b in row_by_slot:
                    adjacency.setdefault(a,set()).add(b);adjacency.setdefault(b,set()).add(a)
                    links.setdefault((na,a),[]).append(b);links.setdefault((nb,b),[]).append(a)
                elif item['state']=='problem':
                    for slot in (a,b):
                        if slot in row_by_slot:add_error(slot,workflow.OFFMAP_NOTE+': '+item['reason'],'offmap')
        done=0;progress_rows=[];end_cable_slots=set();complete_temporary_slots=set()
        exempt_components=workflow.field_slot_audit(self)['exempt_component_slots']
        for core_id,slots in sorted(by_id.items()):
            if slots-exempt_components:slots=slots-exempt_components
            slots={s for s in slots if not workflow.core_connection_exempt(row_by_slot[s]) or adjacency.get(s) or errors.get(s)
                   or (s[0] in cables and all(workflow.cable_terminal(nodes.get(n),degree.get(n,0),extras.get(n,{})) for n in (cables[s[0]]['n1id'],cables[s[0]]['n2id'])))}
            if not slots:continue
            remaining=set(slots);components=0;ends=[]
            while remaining:
                components+=1;stack=[next(iter(remaining))]
                while stack:
                    slot=stack.pop()
                    if slot not in remaining:continue
                    remaining.remove(slot);stack.extend(other for other in adjacency.get(slot,()) if other in remaining)
            for slot in slots:
                cid,index=slot;row=row_by_slot[slot]
                if cid.startswith('PORT:'):
                    nid=cid[5:];node=nodes.get(nid);label=str(row['label'] or '').upper();local=links.get((nid,slot),[])
                    kind=workflow.port_endpoint_kind(node,extras.get(nid,{}))
                    if len(local)==1 and local[0] in slots and kind:
                        ends.append((kind,nid))
                    else:
                        add_error(slot,'RN 포트 미접속·중복 접속 또는 완료기준이 아닌 포트','port')
                        if not local:add_error(slot,'RN 포트에서 다음 코어와 연결되지 않음','unconnected')
                        elif len(local)>1:add_error(slot,'RN 포트에서 중복/분기 접속','branch')
                    continue
                cable=cables.get(cid)
                if not cable:continue
                # A path ends on this cable if either facility has no same-ID cable continuation.
                # RN ports terminate the path and do not count as another cable section.
                if any(not any(other in slots and other[0] in cables for other in links.get((nid,slot),()))
                       for nid in (cable['n1id'],cable['n2id'])):
                    end_cable_slots.add(slot)
                for nid in (cable['n1id'],cable['n2id']):
                    node=nodes.get(nid);local=links.get((nid,slot),[])
                    if len(local)>1:add_error(slot,f'{node["name"] if node else nid}에서 중복/분기 접속','branch')
                    if local:continue
                    terminal=workflow.cable_terminal(node,degree.get(nid,0),extras.get(nid,{}))
                    if terminal:ends.append(('terminal',nid));continue
                    exempt=(extras.get(nid,{}).get('assignmentExceptions') or {}).get(f'{cid}::{index}')
                    if not exempt and slot not in exception_slots and not ({'cancel','broken'} & workflow.statuses(row)):unassigned[cid].add(index)
                    add_error(slot,f'{node["name"] if node else nid}에서 다음 코어와 연결되지 않음','unconnected')
            pair=workflow.valid_endpoint_pair(ends)
            has_error=any(errors.get(slot) for slot in slots)
            if components>1 and not has_error:
                for slot in slots:add_error(slot,f'같은 코어ID 경로가 {components}개로 분리됨','split')
            elif not pair and not has_error:
                for slot in slots:add_error(slot,f'정상 끝점 {len(ends)}개: 서로 다른 시설의 끝단·RN 내부 간 연결 필요','endpoints')
            complete=components==1 and pair and not any(errors.get(slot) for slot in slots)
            if complete and core_id.startswith('임시-'):
                signals={str(row_by_slot[s].get('signal') or '').strip() for s in slots}-{'','unknown','확인필요'}
                active=workflow.completion_kind(self)!='after' or all(cables[s[0]]['status'] not in ('철거','절단') for s in slots if s[0] in cables)
                if len(signals)<=1 and signals<={'on','off','exception'} and active:complete_temporary_slots.update(slots)
            if complete:done+=1
            else:
                for cid,index in slots:
                    if cid in cables:incomplete[cid].add(index)
            reasons=sorted({reason for slot in slots for reason in errors.get(slot,())})
            causes={cause for slot in slots for cause in error_causes.get(slot,())}
            if components>1:causes.add('split')
            if not pair:causes.add('endpoints')
            progress_rows.append({'core_id':core_id,'complete':complete,'slots':sorted(slots),'reason':' / '.join(reasons),'reason_items':tuple(reasons),'causes':frozenset(causes)})

        same_id_conflicts=workflow.completion_report(self).get('automatic_conflicts',())
        for conflict in same_id_conflicts:
            for slot in conflict['slots']:add_error(slot,conflict['reason'],'branch')
        cable_errors={cid:{} for cid in cables};error_entries=[]
        def diagnostic_entry(slot,reason):
            cid,index=slot
            row=row_by_slot.get((cid,index));core_id=display_core_id(row['core_id'] if row else '') or 'ID 없음'
            if cid in cables:
                cable=cables[cid];nids=(cable['n1id'],cable['n2id']);a=nodes.get(nids[0]);b=nodes.get(nids[1]);name=clean_cable_id(cable['cable_id']) or cable['spec'] or f'{cable["size"]}C'
                location=f'{a["name"] if a else "?"} ↔ {b["name"] if b else "?"} / {name}';title=f'{index}번 · {core_id}'
            else:
                nids=(cid[5:],);node=nodes.get(nids[0]);location=node['name'] if node else nids[0];title=f'{row["label"] if row else index} · {core_id}'
            return {'nodes':nids,'slot':slot,'core_id':str(row['core_id'] or '') if row else '',
                    'detail':str(row['detail'] or '') if row else '', 'row':(location,title,reason)}
        for slot,reasons in sorted(errors.items()):
            # Keep topology diagnostics for completion checks, but exempt
            # these cores from the visible error lists and cable counts.
            if slot in exception_slots:continue
            error_entries.append(diagnostic_entry(slot,' / '.join(sorted(reasons))))
            if slot[0] in cables:cable_errors[slot[0]][slot[1]]=reasons
        self._same_id_error_entries=[]
        for conflict in same_id_conflicts:
            for slot in conflict['slots']:
                if slot not in exception_slots:self._same_id_error_entries.append(diagnostic_entry(slot,conflict['reason']))
        marked_entries=[];marked_by_cable={cid:set() for cid in cables}
        for core_id in sorted(marked_ids):
            for slot in sorted(by_id[core_id]):
                memo=str(row_by_slot[slot].get('annotation_memo') or '').strip()
                marked_entries.append(diagnostic_entry(slot,'상태에 오류코어로 선택됨'+(' · '+memo if memo else '')))
                if slot[0] in cables:marked_by_cable[slot[0]].add(core_id)
        # Explicit error badges describe the outer extent of an ID on the
        # drawing. Missing splice records must not repeat the badge on every
        # intermediate section. This display-only index creates no connections;
        # unassigned/incomplete diagnostics still use the real splice topology.
        marked_boundaries={cid:set() for cid in cables}
        for core_id in marked_ids:
            slots=by_id[core_id];members={cid for cid,index in slots if cid in cables};incident={};port_ends=set()
            for cid in members:
                cable=cables[cid]
                for nid in (cable['n1id'],cable['n2id']):incident.setdefault(nid,set()).add(cid)
            for slot in slots:
                if slot[0] in cables and any(other in slots and other[0].startswith('PORT:') for other in adjacency.get(slot,())):port_ends.add(slot[0])
            for cid in members:
                cable=cables[cid]
                if cid in port_ends or any(len(incident[nid])==1 or extras.get(nid,{}).get('terminal') or
                                          (nodes.get(nid) and nodes[nid]['type']=='sub') for nid in (cable['n1id'],cable['n2id'])):
                    marked_boundaries[cid].add(core_id)
        completion=workflow.completion_report(self)
        # V167: a core shown in 오류코어확인 is not counted again as 미완료코어.
        error_slots={slot for core_id in marked_ids for slot in by_id[core_id]}
        if workflow.completion_kind(self)=='after':
            error_slots|={e['slot'] for e in self._same_id_error_entries}
            error_slots|={slot for slot,causes in error_causes.items() if 'invalid' in causes and slot not in exception_slots}
        progress_rows=completion['rows'];incomplete={cid:set() for cid in cables};unassigned={cid:set() for cid in cables}
        for progress in progress_rows:
            if progress['complete']:continue
            for cid,index in progress['slots']:
                if (cid,index) in error_slots:continue
                if cid in cables and not workflow.core_connection_exempt(row_by_slot.get((cid,index))):incomplete[cid].add(index)
            for cid,index in (() if completion['kind']=='after' else progress['active_slots']):
                if cid not in cables or workflow.core_connection_exempt(row_by_slot.get((cid,index))):continue
                for nid in (cables[cid]['n1id'],cables[cid]['n2id']):
                    terminal=workflow.cable_terminal(nodes.get(nid),completion['degree'].get(nid,0),extras.get(nid,{}))
                    local=links.get((nid,(cid,index)),[])
                    valid=len(local)==1 and local[0] in progress['active_slots'] and bool(progress['core_id'])
                    if not terminal and not valid:unassigned[cid].add(index)
        cut_cables=set()
        if completion['kind']=='after':
            # V183: 절단/철거 cables in 후도면 also show 미완료코어 N, the same
            # rows the cable window marks [미완료코어] (user request).
            cut_cables={cid for cid,c in cables.items() if str(c['status'] or '').strip() in workflow.CUT_CABLE_STATUSES}
            for slot,row in row_by_slot.items():
                if slot[0] not in cut_cables or slot in error_slots or workflow.core_connection_exempt(row):continue
                # Read the report directly: core_completion_brief would call
                # back into this summary (completed_temporary_slots) and recurse.
                entry=completion['by_slot'].get(slot)
                if (entry and entry.get('required') and not entry['complete'] and slot not in completion.get('off_slots',())
                        and slot not in complete_temporary_slots):incomplete[slot[0]].add(slot[1])
            for slots in completion['assignment_needs'].values():
                for cid,index in slots:
                    if cid in cables:unassigned[cid].add(index)
        incomplete_entries=[]
        for progress in progress_rows:
            if progress['complete']:continue
            for nid in progress.get('pending_nodes',()):
                node=nodes.get(nid)
                incomplete_entries.append({'nodes':(nid,),'slot':('PORT:'+nid,0),'core_id':progress['core_id'],'detail':progress['detail'],
                                           'key':progress['key'],'causes':progress['causes'],'reason_items':progress['reason_items'],'pending_identity':True,
                                           'row':(node['name'] if node else nid,progress['core_id'],progress['reason'])})
            for slot in progress['slots']:
                if workflow.core_connection_exempt(row_by_slot.get(slot)) or slot in error_slots:continue
                reason=progress['reason']
                entry=diagnostic_entry(slot,reason);entry['key']=progress['key'];entry['causes']=progress['causes'];entry['reason_items']=progress['reason_items'];incomplete_entries.append(entry)
        listed={e.get('slot') for e in incomplete_entries}
        for cid in sorted(cut_cables):
            for index in sorted(incomplete[cid]):
                slot=(cid,index);progress=completion['by_slot'].get(slot)
                if slot in listed or not progress:continue
                entry=diagnostic_entry(slot,progress['reason']);entry['key']=progress['key'];entry['causes']=progress['causes'];entry['reason_items']=progress['reason_items'];incomplete_entries.append(entry)
        input_entries=[]
        for nid,title,reason in self.survey_errors(row_by_slot=row_by_slot):
            node=nodes.get(nid);item={'nodes':(nid,),'row':(node['name'] if node else nid,title,'일괄입력 오류: '+reason)}
            if item not in input_entries:input_entries.append(item)
        result={}
        end_indices={cid:set() for cid in cables}
        for cid,index in end_cable_slots:end_indices[cid].add(index)
        for cid in cables:
            messages=[]
            for index,reasons in sorted(cable_errors[cid].items()):
                row=row_by_slot.get((cid,index));core_id=display_core_id(row['core_id'] if row else '') or 'ID 없음'
                messages.append(f'{index}번 {core_id}: '+ ' / '.join(sorted(reasons)))
            visible_incomplete=incomplete[cid] if cid in cut_cables else incomplete[cid] & end_indices[cid];visible_temporary=temporary[cid] & end_indices[cid]
            marked_ends=marked_boundaries[cid]
            result[cid]={'unassigned':len(unassigned[cid]),'incomplete':len(visible_incomplete),'incomplete_indices':frozenset(visible_incomplete),
                         'incomplete_badge':len(visible_incomplete - unassigned[cid]),
                         'incomplete_total':len(incomplete[cid]),'temporary':len(visible_temporary),'temporary_total':len(temporary[cid]),
                         'temporary_complete':sum((cid,index) in complete_temporary_slots for index in end_indices[cid]),
                         'marked_error':len(marked_ends),'marked_error_ids':frozenset(marked_ends),'marked_error_total':len(marked_by_cable[cid]),
                         'error':len(cable_errors[cid]),'error_messages':messages}
        self._completed_temporary_slots=frozenset(complete_temporary_slots)
        self._invalid_splice_entries=[diagnostic_entry(slot,' / '.join(sorted(errors[slot]))) for slot,causes in error_causes.items() if 'invalid' in causes and slot not in exception_slots]
        self._connection_progress=completion
        self._connection_errors=error_entries;self._marked_error_entries=marked_entries;self._input_errors=input_entries;self._incomplete_entries=incomplete_entries
        self._diagnostics_key=key;self._cable_warning_cache=result
        return result

    def drawing_connection_progress(self):
        """The current stage mandatory-core denominator, shared with incomplete lists."""
        self.cable_core_warning_summary();return self._connection_progress

    def error_core_summary(self,node_id=None):
        self.cable_core_warning_summary()
        def relevant(entry):return not node_id or node_id in entry['nodes'] or '전체' in entry['nodes']
        cores=[e for e in self._marked_error_entries+(getattr(self,'_same_id_error_entries',[])+getattr(self,'_invalid_splice_entries',[]) if workflow.completion_kind(self)=='after' else []) if relevant(e)]
        inputs=[e for e in self._input_errors if relevant(e)]
        core_count=len({e['core_id'] for e in cores})
        return {'core_count':core_count,'core_locations':len(cores),'input_errors':len(inputs),
                'total':core_count,'rows':[e['row'] for e in cores],'entries':cores}

    def error_core_slots(self):
        key=(self.data_revision(),self.conn.total_changes,getattr(self,'_view_generation',0))
        cached=getattr(self,'_error_core_slots_cache',None)
        if cached and cached[0]==key:return cached[1]
        value=frozenset(tuple(e['slot']) for e in self.error_core_summary()['entries'] if e.get('slot'))
        self._error_core_slots_cache=(key,value);return value

    def error_core_groups(self,node_id=None):
        grouped={}
        for entry in self.error_core_summary(node_id)['entries']:
            core_id=entry['core_id']
            if not str(core_id or '').strip():continue
            group=grouped.setdefault(core_id,{'members':[],'details':{},'reasons':{}})
            group['members'].append(entry)
            detail=str(entry.get('detail') or '').strip();reason=str(entry['row'][2] or '').strip()
            if detail:group['details'][detail]=None
            if reason:group['reasons'][reason]=None
        return [{'core_id':core_id,'members':group['members'],'detail':' / '.join(group['details']),
                 'reason_items':tuple(group['reasons']),
                 'row':('',display_core_id(core_id),' / '.join(group['reasons']))}
                for core_id,group in grouped.items()]

    def incomplete_core_entries(self,cable_id=None):
        self.cable_core_warning_summary()
        return [e for e in self._incomplete_entries if cable_id is None or e['slot'][0]==cable_id]

    def incomplete_core_groups(self,cable_id=None):
        grouped={}
        for entry in self.incomplete_core_entries(cable_id):
            group_key=entry.get('key',('id',entry['core_id']))
            if group_key not in grouped:
                # Diagnostics attach the same complete reason tuple to every slot of this ID.
                grouped[group_key]={'key':group_key,'core_id':entry['core_id'],'members':[],'details':{},
                                           'reasons':dict.fromkeys(entry.get('reason_items') or ()),'causes':set()}
            group=grouped[group_key]
            group['members'].append(entry);group['causes'].update(entry.get('causes',()))
            detail=str(entry.get('detail') or '').strip()
            if detail:group['details'][detail]=None
            if not entry.get('reason_items') and entry['row'][2]:group['reasons'][entry['row'][2]]=None
        error_slots={e.get('slot') for e in self._connection_errors}
        results=[]
        for group in grouped.values():
            members=sorted(group['members'],key=lambda e:(e['slot'] not in error_slots,e['row'][0],e['slot']))
            reasons=tuple(group['reasons']);reason=' / '.join(reasons)
            results.append({'key':group['key'],'core_id':group['core_id'],'members':members,'detail':' / '.join(group['details']),
                            'reason_items':reasons,'causes':frozenset(group['causes']),
                            'row':('',display_core_id(group['core_id']),reason)})
        return results

    def issue_position(self,entry):
        slot=entry.get('slot')
        if slot and not str(slot[0]).startswith('PORT:'):
            c=self.cable(slot[0])
            if not c:return None
            a=self.node(c['n1id']);b=self.node(c['n2id'])
            if a and b:return c['id'],(a['x']+b['x'])/2,(a['y']+b['y'])/2
            return None
        nids=(str(slot[0])[5:],) if slot else entry.get('nodes',())
        for nid in nids:
            node=self.node(nid)
            if node:return node['id'],node['x'],node['y']
        return None


    @recorded("예외코어 지정 변경")
    def set_cores_exception(self,slots,enabled=True):
        """V167: add/remove the 예외코어 status per core ID; signal, splices and other labels stay."""
        changed=[];done=set()
        for slot in slots:
            row=self.core(*slot);core_id=str(row['core_id'] or '').strip() if row else ''
            if not core_id or core_id in done:continue
            done.add(core_id);current=workflow.annotate(self,row)
            labels=[v for v in current['annotation_labels'] if v!='예외코어']
            if enabled:labels=['예외코어']+labels
            if labels==current['annotation_labels']:continue
            workflow.save_annotations(self,slot,labels,current['annotation_memo']);changed.append(core_id)
        return changed

    def core_id_slots(self,core_ids):
        wanted={str(v or '').strip() for v in core_ids}-{''};found={}
        for r in self.all_core_rows():
            cid=str(r['core_id'] or '').strip()
            if cid in wanted and cid not in found:found[cid]=(r['cable_id'],int(r['core_index']))
        return list(found.values())

    @recorded("배정필요 예외 변경")
    def toggle_assignment_exception(self,node_id,cable_id,index):
        n=self.node(node_id)
        if not n:return False
        extra=json.loads(n["extra_json"] or "{}");items=extra.get("assignmentExceptions") or {};key=f"{cable_id}::{index}";enabled=not bool(items.get(key))
        if enabled:items[key]=True
        else:items.pop(key,None)
        extra["assignmentExceptions"]=items;self.conn.execute("UPDATE nodes SET extra_json=? WHERE id=?",(json.dumps(extra,ensure_ascii=False),node_id));self.conn.commit();return enabled

    def splice_for(self, node_id, cable_id, index):
        return self.conn.execute("""
          SELECT * FROM splices WHERE node_id=? AND
          ((cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?)) LIMIT 1
        """, (node_id, cable_id, index, cable_id, index)).fetchone()

    def component(self, start):
        cached=getattr(self,'_auto_splice_adjacency',None)
        if cached is not None:
            seen=set();stack=[start]
            while stack:
                item=stack.pop()
                if item not in seen:seen.add(item);stack.extend(cached.get(item,()))
            return seen
        if not self.conn.execute("SELECT 1 FROM splices WHERE (cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?) LIMIT 1",(start[0],start[1],start[0],start[1])).fetchone():return {start}
        adjacency={}
        for r in self.conn.execute("SELECT cable1_id,core1_index,cable2_id,core2_index FROM splices"):
            a=(r["cable1_id"],r["core1_index"]);b=(r["cable2_id"],r["core2_index"]);adjacency.setdefault(a,set()).add(b);adjacency.setdefault(b,set()).add(a)
        seen, stack = set(), [start]
        while stack:
            item = stack.pop()
            if item in seen:
                continue
            seen.add(item)
            stack.extend(adjacency.get(item,()))
        return seen

    @recorded("코어 연결")
    def connect(self, node_id, a, b, temporary=False):
        if workflow.field_slot_mode(self):return workflow.field_slot_connect(self,node_id,a,b)
        if a == b:
            raise ValueError("같은 코어끼리는 연결할 수 없습니다.")
        if a[0] == b[0]:
            raise ValueError("같은 케이블의 코어끼리는 이 함체에서 연결할 수 없습니다.")
        if self.splice_for(node_id, *a) or self.splice_for(node_id, *b):
            existing = self.conn.execute("""
              SELECT 1 FROM splices WHERE node_id=? AND
              ((cable1_id=? AND core1_index=? AND cable2_id=? AND core2_index=?) OR
               (cable1_id=? AND core1_index=? AND cable2_id=? AND core2_index=?))
            """, (node_id, *a, *b, *b, *a)).fetchone()
            if existing:
                return "이미 같은 연결이 있습니다."+workflow.merge_connected_temporary_ids(self,a,b)
            raise ValueError("선택한 코어 중 하나가 이 함체에서 이미 다른 코어와 연결되어 있습니다.")
        comp = self.component(a) | self.component(b)
        comp |= {a, b}
        values = [];temporary_values=[]
        details = []
        for cid, idx in comp:
            c = self.core(cid, idx)
            if c:
                value = str(c["core_id"] or "").strip()
                if value:
                    if value.startswith("임시-"):temporary_values.append(value)
                    else:values.append(value)
                if str(c["detail"] or "").strip():
                    details.append(str(c["detail"]).strip())
        distinct = sorted(set(values))
        if len(distinct) > 1:
            raise ValueError(f"오류코어: 서로 다른 코어ID {', '.join(distinct)} 는 연결하지 않았습니다.")
        if distinct:
            target_id = distinct[0]
        elif temporary_values:
            target_id = temporary_values[0]
        elif temporary:
            target_id = self.next_temp_core_id()
        else:
            target_id = ""
        if not target_id:
            raise ValueError("코어ID를 입력하거나 '임시코어 연결'을 사용하세요.")
        detail = details[0] if details else ""
        c1, c2 = sorted((a, b))
        self.conn.execute("INSERT INTO splices(node_id,cable1_id,core1_index,cable2_id,core2_index) VALUES(?,?,?,?,?)",
                          (node_id, c1[0], c1[1], c2[0], c2[1]))
        if not getattr(self,'_auto_splice_running',False):self.set_auto_splice_exclusions(node_id,(a,b),False)
        both_temporary=all(str((self.core(*slot) or {}).get('core_id') or '').strip().startswith('임시-') for slot in (a,b))
        merged=workflow.merge_connected_temporary_ids(self,a,b) if both_temporary else ''
        if not both_temporary:
            for cid, idx in comp:
                current=self.core(cid,idx);keep_detail=current["detail"] if current and current["detail"] else detail
                self._write_core_identity(cid,idx,target_id,keep_detail,True)
                workflow.phase_promote_identity(self,str(current['core_id'] or '') if current else '',target_id)
        # Promote identities only through the connections already in this
        # component. Other matching IDs remain unconnected until selected.
        self.conn.commit()
        return f"{a[1]}번 ↔ {b[1]}번 연결 완료"+merged

    @recorded("코어 연결 해제")
    def disconnect(self, node_id, cable_id, index):
        row = self.splice_for(node_id, cable_id, index)
        if not row:
            return False
        self.set_auto_splice_exclusions(node_id,((row['cable1_id'],row['core1_index']),(row['cable2_id'],row['core2_index'])))
        self.conn.execute("DELETE FROM splices WHERE node_id=? AND cable1_id=? AND core1_index=? AND cable2_id=? AND core2_index=?",
                          (row["node_id"], row["cable1_id"], row["core1_index"], row["cable2_id"], row["core2_index"]))
        self.conn.commit()
        return True

    @recorded("코어 삭제")
    def delete_core_assignment(self,cable_id,index):
        """한 케이블/포트의 한 코어만 비우고 그 슬롯의 접속만 제거한다."""
        current=self.core(cable_id,index)
        if not current:return False
        has_value=any(str(current[key] or "").strip() for key in ("core_id","detail","status1","status2","signal"))
        has_link=bool(self.conn.execute("SELECT 1 FROM splices WHERE (cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?) LIMIT 1",(cable_id,index,cable_id,index)).fetchone())
        if not has_value and not has_link:return False
        self.exclude_deleted_core_from_auto(cable_id,index)
        self._write_core(cable_id,index,["","","","",""])
        self.conn.execute("DELETE FROM splices WHERE (cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?)",(cable_id,index,cable_id,index))
        self.conn.commit();return True

    @recorded("코어 정보 변경")
    def update_core(self, cable_id, index, values):
        if str(values[2] or "") not in ("","unknown") and str(values[2] or "")==str(values[3] or ""):
            raise ValueError(f"상태1과 상태2에 {status_label(values[2])}을 중복으로 선택할 수 없습니다.")
        # V160: screens show 임시코어N; store it back as 임시-N.
        values=[normalize_core_id_input(values[0])]+list(values[1:])
        if workflow.field_slot_mode(self):
            previous=self.core(cable_id,index)
            if not previous:raise ValueError('케이블·코어번호를 찾지 못했습니다.')
            values=[str(v or '').strip() for v in values]
            if not values[0] and self.conn.execute('SELECT 1 FROM splices WHERE (cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?)',(cable_id,index,cable_id,index)).fetchone():values[0]=self.next_temp_core_id()
            old_id=str(previous['core_id'] or '').strip();old_detail=str(previous['detail'] or '').strip()
            # A connected temporary core is one core: an ID/name edit at one
            # number reaches every connected temporary number (V160).
            renamed=old_id.startswith('임시-') and values[0] and (values[0]!=old_id or values[1]!=old_detail)
            # V161: the signal follows the same connected temporary path.
            resignal=old_id.startswith('임시-') and values[4]!=str(previous['signal'] or '')
            targets=workflow.temporary_route_targets(self,(cable_id,index),old_id) if renamed or resignal else []
            workflow.field_slot_write(self,(cable_id,index),values)
            if renamed:workflow.propagate_temporary_identity(self,targets,old_id,values[0],values[1])
            if resignal:workflow.propagate_temporary_signal(self,(cable_id,index),values[4],targets)
            return
        previous=self.core(cable_id,index);old_id=str(previous["core_id"] or "").strip() if previous else "";new_id=str(values[0] or "").strip()
        # V179: a typed 임시코어N renames this connected real core to exactly N.
        real_to_temp=bool(old_id) and not old_id.startswith("임시-") and new_id.startswith("임시-")
        if not new_id:
            component_before={(cable_id,index)}
        elif old_id.startswith("임시-") and not new_id.startswith("임시-"):
            component_before={(r["cable_id"],r["core_index"]) for r in self.all_core_rows(old_id)}
            # Unmerged temporary numbers on the same spliced path follow too.
            component_before|={(cable_id,index)}|set(workflow.temporary_route_targets(self,(cable_id,index),old_id))
        else:component_before = self.component((cable_id, index))
        core_id = str(values[0] or "").strip()
        detail = str(values[1] or "").strip()
        if core_id:
            for cid, idx in component_before:
                if (cid,idx)==(cable_id,index):continue
                other = self.core(cid, idx)
                other_id = str(other["core_id"] or "").strip()
                if other_id and not other_id.startswith("임시-") and other_id != core_id and not (real_to_temp and other_id==old_id):
                    raise ValueError(f"오류코어: 연결된 반대편은 {other_id}입니다. 변경하지 않았습니다.")
            # V194: an emptied number given an ID again in a 후도면 releases the
            # 「자동접속 제외」 its deletion left on its free same-ID partners.
            if not old_id:workflow.after_reassign_release(self,(cable_id,index),core_id)
            self._write_core(cable_id,index,values)
            for cid, idx in component_before:
                self._write_core_identity(cid,idx,core_id,detail,False)
            status1,status2,signal=values[2],values[3],values[4]
            # After identities may meet an ON section and an unknown section.
            # Editing one number must retain every other number's signal.
            local_signal=workflow.completion_kind(self)=='after'
            self.conn.execute("UPDATE cores SET status1=?,status2=?,signal=CASE WHEN ? THEN signal ELSE ? END,detail=CASE WHEN ?<>'' THEN ? ELSE detail END WHERE core_id=?",(status1,status2,local_signal,signal,detail,detail,core_id))
            self.conn.execute("UPDATE ports SET status1=?,status2=?,signal=CASE WHEN ? THEN signal ELSE ? END,detail=CASE WHEN ?<>'' THEN ? ELSE detail END WHERE core_id=?",(status1,status2,local_signal,signal,detail,detail,core_id))
            if local_signal and old_id.startswith("임시-") and core_id.startswith("임시-") and str(signal or '')!=str(previous["signal"] or ''):
                workflow.propagate_temporary_signal(self,(cable_id,index),signal)
        else:
            if old_id:self.exclude_deleted_core_from_auto(cable_id,index)
            self._write_core(cable_id,index,values)
            # 이 케이블의 해당 코어만 비운다. 이전에는 연결된 전체 구간의
            # 코어ID까지 지워져 반대편 케이블 정보도 함께 사라졌다.
            # 해당 슬롯이 참여한 접속만 끊으면 반대편 코어는 그대로 남고,
            # 함체의 배정필요 계산에서 연결할 코어 1개로 다시 잡힌다.
            self.conn.execute("DELETE FROM splices WHERE (cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?)",
                              (cable_id, index, cable_id, index))
        workflow.phase_promote_identity(self,old_id,new_id)
        self.conn.commit()

    @recorded("빈 코어 신호 변경")
    def set_empty_core_signal(self,slot,signal):
        """V166: an empty number keeps its own signal (e.g. OFF) without
        getting a temporary ID or losing its splices."""
        row=self.core(*slot)
        if not row:raise ValueError('케이블·코어번호를 찾지 못했습니다.')
        if str(row['core_id'] or '').strip():raise ValueError('코어ID가 있는 번호입니다. 다시 선택하세요.')
        if signal not in SIGNAL_LABELS:raise ValueError('올바른 신호를 선택하세요.')
        values=[row[k] for k in ('core_id','detail','status1','status2')]+[signal]
        if workflow.field_slot_mode(self):workflow.field_slot_write(self,tuple(slot),values)
        else:self._write_core(*slot,values)

    @recorded("코어 신호 일괄수정")
    def set_cores_signal(self,cable_id,indices,signal):
        """V163: one signal for several numbers of one cable, as one undo step.

        Each number goes through update_core, so a connected temporary path
        still follows (V161). Empty numbers keep only the signal (V166: never
        assigned or disconnected) and a refused number keeps its old value.
        """
        changed=[];skipped=[];errors=[]
        for index in sorted({int(i) for i in indices}):
            row=self.core(cable_id,index)
            if not row or str(row['signal'] or '')==str(signal or ''):skipped.append(index);continue
            if not str(row['core_id'] or '').strip():
                try:self.set_empty_core_signal((cable_id,index),signal)
                except ValueError as exc:errors.append((index,str(exc)))
                else:changed.append(index)
                continue
            try:self.update_core(cable_id,index,[row['core_id'],row['detail'],row['status1'],row['status2'],signal])
            except ValueError as exc:errors.append((index,str(exc)))
            else:changed.append(index)
        return changed,skipped,errors

    @recorded("코어ID·코어명 일괄수정")
    def apply_core_identity_changes(self,cable_id,changes):
        """별도 수정표의 코어ID/내역을 검증 후 적용한다.

        기존 실코어를 다른 실코어 ID로 바꾸는 행은 원본을 보존하고
        상태1만 오류코어로 표시한다. 임시코어는 실코어로 승격할 수 있다.
        V179: 실코어에 임시코어N을 직접 입력하면 그 번호 그대로 바꾼다.
        빈칸은 기존 값 유지이며, 삭제는 별도 명시적 삭제 동작만 사용한다.
        """
        applied=[];unchanged=[];errors=[]
        for index,new_id,new_detail in changes:
            current=self.core(cable_id,int(index))
            if not current:
                errors.append((int(index),"케이블 규격 범위 밖입니다."));continue
            old_id=str(current["core_id"] or "").strip()
            new_id=normalize_core_id_input(new_id)
            new_detail=str(new_detail or "").strip()
            if not new_id and not new_detail:
                unchanged.append(int(index));continue
            # Guard in the storage layer as well as in the clipboard editor:
            # a blank spreadsheet cell must never call update_core with an empty
            # ID, because that deliberately deletes the local splice assignment.
            if not new_id:new_id=old_id
            if not new_detail:new_detail=str(current['detail'] or '')
            old_real=bool(old_id and not old_id.startswith("임시-"))
            if old_real and new_id and old_id!=new_id and not new_id.startswith("임시-") and not workflow.field_slot_mode(self):
                self.conn.execute("UPDATE cores SET status1='error' WHERE cable_id=? AND core_index=?",(cable_id,int(index)))
                errors.append((int(index),f"기존 {old_id} → 입력 {new_id}: 기존 코어ID와 코어내역은 수정하지 않았습니다."))
                continue
            if old_id==new_id and str(current["detail"] or "").strip()==new_detail:
                unchanged.append(int(index));continue
            values=[new_id,new_detail,current["status1"],current["status2"],current["signal"]]
            try:self.update_core(cable_id,int(index),values)
            except ValueError as exc:
                self.conn.execute("UPDATE cores SET status1='error' WHERE cable_id=? AND core_index=?",(cable_id,int(index)))
                errors.append((int(index),str(exc)))
            else:applied.append(int(index))
        self.conn.commit()
        return applied,unchanged,errors

    def temporary_identity_conflicts(self,cable_id,changes):
        """V179: typed 임시코어N that already exist on numbers not connected here.

        The same 임시 ID is one core (joined at facilities), so the user confirms.
        """
        notes=[]
        for index,new_id in changes:
            new_id=normalize_core_id_input(new_id);slot=(cable_id,int(index));row=self.core(*slot)
            if not row or not new_id.startswith("임시-") or str(row["core_id"] or "").strip()==new_id:continue
            mine=self.component(slot)
            others=[(r["cable_id"],int(r["core_index"])) for r in self.all_core_rows(new_id) if (r["cable_id"],int(r["core_index"])) not in mine]
            if others:
                places=", ".join(self._slot_title(*s) for s in others[:3])+(f" 외 {len(others)-3}곳" if len(others)>3 else "")
                notes.append(f"{index}번 → {display_core_id(new_id)}: 이미 {len(others)}곳에 있음 ({places})")
        return list(dict.fromkeys(notes))

    def _write_core(self,cable_id,index,values):
        if str(cable_id).startswith("PORT:"):
            nid=str(cable_id).split(":",1)[1];self.conn.execute("UPDATE ports SET core_id=?,detail=?,status1=?,status2=?,signal=? WHERE node_id=? AND port_index=?",tuple(values)+(nid,index))
        else:self.conn.execute("UPDATE cores SET core_id=?,detail=?,status1=?,status2=?,signal=? WHERE cable_id=? AND core_index=?",tuple(values)+(cable_id,index))

    def _write_core_identity(self,cable_id,index,core_id,detail,force_detail):
        table="ports" if str(cable_id).startswith("PORT:") else "cores"
        owner=str(cable_id).split(":",1)[1] if table=="ports" else cable_id
        owner_col="node_id" if table=="ports" else "cable_id";index_col="port_index" if table=="ports" else "core_index"
        if force_detail:self.conn.execute(f"UPDATE {table} SET core_id=?,detail=? WHERE {owner_col}=? AND {index_col}=?",(core_id,detail,owner,index))
        else:self.conn.execute(f"UPDATE {table} SET core_id=?,detail=CASE WHEN ?<>'' THEN ? ELSE detail END WHERE {owner_col}=? AND {index_col}=?",(core_id,detail,detail,owner,index))

    def clear_all(self):
        if workflow.any_node_locked(self):raise ValueError('함체 잠금: 잠긴 함체를 해제한 뒤 현재 도면을 교체하세요.')
        if workflow.locked(self):raise ValueError("전도면 편집 잠금을 해제한 후 가져오세요.")
        self._view_generation=getattr(self,'_view_generation',0)+1
        for table in ('survey_rows','splices','ports','cores','cables','nodes','meta','history_events','history_groups','workflow_state','core_annotations'):
            self.conn.execute('DELETE FROM '+table)
        self.conn.commit();self._warning_cache=None;self._cable_warning_cache=None;self._trace_context_cache=None;self._trace_context_revision=None

    def backup_to(self, path):
        path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
        if path.resolve()==self.path.resolve():return
        target = sqlite3.connect(path)
        try:self.conn.backup(target)
        finally:target.close()

    def integrity_report(self):
        checks=[]
        result=self.conn.execute("PRAGMA integrity_check").fetchone()[0]
        checks.append(("SQLite 구조", result == "ok", result))
        fk=len(self.conn.execute("PRAGMA foreign_key_check").fetchall());checks.append(("시설·케이블 참조",fk==0,f"{fk}건"))
        orphan_splices=self.conn.execute("""SELECT COUNT(*) FROM splices s WHERE
          NOT (EXISTS(SELECT 1 FROM cores c WHERE c.cable_id=s.cable1_id AND c.core_index=s.core1_index)
               OR (s.cable1_id LIKE 'PORT:%' AND EXISTS(SELECT 1 FROM ports p WHERE p.node_id=substr(s.cable1_id,6) AND p.port_index=s.core1_index)))
          OR NOT (EXISTS(SELECT 1 FROM cores c WHERE c.cable_id=s.cable2_id AND c.core_index=s.core2_index)
               OR (s.cable2_id LIKE 'PORT:%' AND EXISTS(SELECT 1 FROM ports p WHERE p.node_id=substr(s.cable2_id,6) AND p.port_index=s.core2_index)))""").fetchone()[0]
        checks.append(("존재하지 않는 코어 연결", orphan_splices==0, f"{orphan_splices}건"))
        bad_ranges=self.conn.execute("""SELECT COUNT(*) FROM cores c JOIN cables b ON b.id=c.cable_id
          WHERE c.core_index<1 OR c.core_index>b.size""").fetchone()[0]
        checks.append(("케이블 규격 밖 코어",bad_ranges==0,f"{bad_ranges}건"))
        duplicate_slots=self.conn.execute("""SELECT COUNT(*) FROM (
          SELECT node_id,cable_id,core_index,COUNT(*) n FROM (
            SELECT node_id,cable1_id cable_id,core1_index core_index FROM splices
            UNION ALL SELECT node_id,cable2_id,core2_index FROM splices
          ) GROUP BY node_id,cable_id,core_index HAVING n>1)""").fetchone()[0]
        checks.append(("함체 내 중복 코어 연결",duplicate_slots==0,f"{duplicate_slots}건"))
        return checks

    def before_drawing_check_rows(self):
        """전 도면을 후 도면의 기준으로 쓰기 전에 확인할 항목을 모은다.

        화면을 열 때 한 번만 계산하며, 도면 편집 중 상시 실행하지 않아
        일반 작업 속도에는 영향을 주지 않는다.
        """
        nodes={row["id"]:row for row in self.nodes()};cables={row["id"]:row for row in self.cables()}
        rows=[];seen=set()

        def add(level,category,location,target,message,node_id="",cable_id="",core_id="",core_index=""):
            item={"level":str(level),"category":str(category),"location":str(location or "전체"),
                  "target":str(target or ""),"message":str(message or ""),"node_id":str(node_id or ""),
                  "cable_id":str(cable_id or ""),"core_id":str(core_id or ""),"core_index":core_index}
            if not item["core_id"] and core_index=="" and item["target"]:
                item["message"]=item["target"]+" · "+item["message"]
            key=(item["level"],item["category"],item["location"],item["core_id"],core_index,item["message"])
            if key not in seen:seen.add(key);rows.append(item)

        def cable_title(cable):
            left=nodes.get(cable["n1id"]);right=nodes.get(cable["n2id"]);name=clean_cable_id(cable["cable_id"]) or (cable["spec"] or f'{cable["size"]}C')
            return f'{left["name"] if left else "?"} ↔ {right["name"] if right else "?"} / {name}'

        if not nodes:add("오류","도면 구성","전체","시설 없음","전 도면에 시설이 없습니다.")
        if not cables:add("경고","도면 구성","전체","케이블 없음","전 도면에 케이블이 없습니다.")

        for name,ok,detail in self.integrity_report():
            if not ok:add("오류","데이터 구조","전체",name,f'{name} 점검 결과 {detail}입니다. 파일·출력·점검의 데이터점검에서 정리하세요.')

        names={}
        for node in nodes.values():
            name=str(node["name"] or "").strip()
            if not name:add("오류","시설 정보",NODE_LABELS.get(node["type"],node["type"]),"이름 없음","시설명을 입력하세요.",node_id=node["id"])
            else:names.setdefault(name.casefold(),[]).append(node)
        for group in names.values():
            if len(group)>1:
                shown=group[0]["name"]
                add("경고","시설 정보",shown,f'동일 이름 {len(group)}개',"시설명이 같으면 케이블 선택과 경로 확인이 어려울 수 있습니다.",node_id=group[0]["id"])

        # 같은 위치 또는 매우 가까운 시설은 공간 버킷으로 빠르게 찾는다.
        buckets={}
        for node in nodes.values():
            bx=int(float(node["x"])//160);by=int(float(node["y"])//160)
            for nx in range(bx-1,bx+2):
                for ny in range(by-1,by+2):
                    for other in buckets.get((nx,ny),()):
                        if abs(float(node["x"])-float(other["x"]))<76 and abs(float(node["y"])-float(other["y"]))<76:
                            add("경고","시설 배치",node["name"],other["name"],"두 시설이 겹치거나 너무 가깝습니다. 전 도면에서 위치를 확인하세요.",node_id=node["id"])
            buckets.setdefault((bx,by),[]).append(node)

        attached_ids={}
        core_counts={row["cable_id"]:int(row["n"]) for row in self.conn.execute("SELECT cable_id,COUNT(*) n FROM cores GROUP BY cable_id")}
        for cable in cables.values():
            title=cable_title(cable);cid=clean_cable_id(cable["cable_id"])
            if cable["n1id"]==cable["n2id"]:add("오류","케이블 구성",title,"양 끝 시설 동일","케이블의 양 끝이 같은 시설입니다.",cable_id=cable["id"])
            count=core_counts.get(cable["id"],0)
            if count!=int(cable["size"]):add("오류","케이블 구성",title,f'코어 {count}/{cable["size"]}',"케이블 규격과 실제 코어 행 수가 다릅니다.",cable_id=cable["id"])
            if cid:
                for nid in (cable["n1id"],cable["n2id"]):attached_ids.setdefault((nid,cid.casefold()),[]).append(cable)
        for (nid,cid),group in attached_ids.items():
            if len(group)>1:
                node=nodes.get(nid);shown=clean_cable_id(group[0]["cable_id"])
                add("오류","케이블 식별",node["name"] if node else nid,shown,f'이 시설에 같은 케이블ID가 {len(group)}개 있어 Excel 일괄연결에서 구분할 수 없습니다.',node_id=nid,cable_id=group[0]["id"])

        if workflow.field_slot_mode(self):
            return sorted(rows+workflow.field_slot_check_rows(self),key=lambda item:(item['level']!='오류',item['core_id'],item['location']))
        # Keep an exact ID/slot on every core issue. A cable's aggregate count
        # cannot identify the path the user clicked.
        for nid,node in nodes.items():
            for cable_id,indices in self.node_assignment_needs(nid).items():
                for index in sorted(indices):
                    core=self.core(cable_id,index)
                    if not core:continue
                    location=cable_title(cables[cable_id]) if cable_id in cables else node["name"]
                    add("오류","코어 연결",location,"배정필요",f'{node["name"]}에서 {index}번 코어의 다음 연결이 필요합니다.',
                        node_id=nid,cable_id=cable_id,core_id=core["core_id"],core_index=index)
        for group in self.incomplete_core_groups():
            members=group["members"];slot=members[0]["slot"]
            location=" / ".join(dict.fromkeys(member["row"][0] for member in members))
            reason=" / ".join(group["reason_items"]) or "끝단까지 이어지지 않았거나 같은 코어ID 경로가 나뉘어 있습니다."
            add("오류","코어 경로",location,"미완료",reason,cable_id=slot[0],core_index=slot[1],core_id=group["core_id"])

        core_groups={}
        for row in self.conn.execute("SELECT * FROM cores ORDER BY cable_id,core_index"):
            if workflow.core_connection_exempt(row):continue
            cid=str(row["core_id"] or "").strip();marked=bool(str(row["detail"] or "").strip() or str(row["status1"] or "") not in ("","unknown") or str(row["status2"] or "") not in ("","unknown") or str(row["signal"] or "") not in ("","unknown"))
            info=core_groups.setdefault((row["cable_id"],cid),{"blank_marked":[],"temporary":[],"no_detail":[]})
            if not cid and marked:info["blank_marked"].append(int(row["core_index"]))
            elif cid.startswith("임시-"):info["temporary"].append(int(row["core_index"]))
            elif cid and not str(row["detail"] or "").strip():info["no_detail"].append(int(row["core_index"]))
        for (cable_id,core_id),info in core_groups.items():
            cable=cables.get(cable_id)
            if not cable:continue
            title=cable_title(cable)
            if info["blank_marked"]:
                nums=", ".join(map(str,info["blank_marked"]))
                add("오류","코어 입력",title,f'ID 없음 {len(info["blank_marked"])}개',f'{nums}번 코어는 내역/상태/신호가 있지만 코어ID가 없습니다.',cable_id=cable_id,core_index=info["blank_marked"][0])
            if info["temporary"]:
                nums=", ".join(map(str,info["temporary"]))
                add("오류","임시코어",title,display_core_id(core_id),f'{nums}번에 임시코어가 남아 있습니다. 실제 코어ID로 바꾼 뒤 후 도면을 작성하세요.',cable_id=cable_id,core_id=core_id,core_index=info["temporary"][0])
            if info["no_detail"]:
                nums=", ".join(map(str,info["no_detail"]))
                add("경고","코어 입력",title,display_core_id(core_id),f'{nums}번 코어에 코어ID는 있지만 코어내역이 없습니다.',cable_id=cable_id,core_id=core_id,core_index=info["no_detail"][0])

        for entry in self._connection_errors:
            location,title,reason=entry["row"];slot=entry["slot"]
            add("오류","연결·입력 점검",location,title,f'{title} · {reason}',cable_id=slot[0],core_index=slot[1],core_id=entry["core_id"])
        for nid,title,reason,slots in self.survey_errors(with_slots=True):
            location=nodes[nid]["name"] if nid in nodes else "전체";identities={}
            for slot in slots:
                core=self.core(*slot);cid=str(core["core_id"] or "").strip() if core else ""
                identities.setdefault(cid,slot)
            for core_id,slot in (identities or {"":("","")}).items():
                add("오류","연결·입력 점검",location,title,f'{title} · 일괄입력 오류: {reason}',
                    node_id=nid if nid in nodes else "",cable_id=slot[0],core_index=slot[1],core_id=core_id)

        required=self.work_required_cores()
        for source in required:
            core_id=str(source.get("core_id") or "")
            if not source.get("input_missing") and not core_id.startswith("임시-"):continue
            slots=list(source.get("source_slots") or ());cable_id=slots[0][0] if slots else "";index=slots[0][1] if slots else ""
            route=" / ".join(source.get("source_routes") or []) or "철거·절단 작업대상"
            target="코어ID 없음" if source.get("input_missing") else display_core_id(core_id)
            message="철거·절단 작업대상 코어에 실제 코어ID가 없습니다." if source.get("input_missing") else "철거·절단 작업대상에 임시코어가 남아 있습니다."
            add("오류","작업대상",route,target,message,cable_id=cable_id,core_id=core_id,core_index=index)
        order={"오류":0,"경고":1,"확인":2}
        mode=self.conn.execute("SELECT value FROM meta WHERE key='active_scenario'").fetchone()
        if mode and mode[0]=='before':rows.extend(workflow.field_check_rows(self))
        completion=workflow.completion_report(self)
        for item in rows:
            if item['level']!='오류' or item['category'] not in ('코어 연결','코어 경로','코어 입력','임시코어','작업대상','연결·입력 점검'):continue
            if item['category']=='연결·입력 점검' and workflow.core_signal_off(self.core(item['cable_id'],item['core_index'])):continue
            policy=completion['by_id'].get(item['core_id']) if item['core_id'] else completion['by_slot'].get((item['cable_id'],item['core_index']))
            if (policy is not None and not policy['required']) or (policy is None and item['core_index']!='' and item['category']=='코어 입력'):
                item['level']='경고';item['message']='완료율 제외 · '+(policy['excluded_reason'] if policy else '신호·코어ID 없음')+' · '+item['message']
            elif item['category']=='임시코어' or (item['category']=='작업대상' and item['core_id'].startswith('임시-')):
                item['level']='경고';item['message']='신호 있는 임시코어는 필수 연결 대상입니다. '+item['message'].replace('실제 코어ID로 바꾼 뒤 후 도면을 작성하세요.','실제 코어ID는 조사 후 보완할 수 있습니다.')
        return sorted(rows,key=lambda item:(order.get(item["level"],9),item["category"],item["core_id"],item["location"]))

    @recorded("데이터 연결정보 정리")
    def repair_links(self):
        if workflow.completion_kind(self)=='after':
            removed=workflow.after_invalid_repair_apply(self,workflow.after_invalid_repair_plan(self))
            workflow.after_auto_apply(self,workflow.after_auto_pairs(self))
            return removed
        removed=0
        for r in self.conn.execute("SELECT rowid,* FROM splices ORDER BY rowid").fetchall():
            if not self.core(r["cable1_id"],r["core1_index"]) or not self.core(r["cable2_id"],r["core2_index"]):self.conn.execute("DELETE FROM splices WHERE rowid=?",(r["rowid"],));removed+=1
        seen=set()
        for r in self.conn.execute("SELECT rowid,* FROM splices ORDER BY rowid").fetchall():
            a=(r["node_id"],r["cable1_id"],r["core1_index"]);b=(r["node_id"],r["cable2_id"],r["core2_index"])
            if a in seen or b in seen:self.conn.execute("DELETE FROM splices WHERE rowid=?",(r["rowid"],));removed+=1
            else:seen|={a,b}
        self.conn.commit();return removed

    def resolve_node_cable(self, node_id, text):
        wanted=clean_cable_id(text).casefold()
        exact=[]; fuzzy=[]
        for c in self.node_cables(node_id):
            cid=clean_cable_id(c["cable_id"])
            other=self.opposite_name(c,node_id)
            candidates={cid.casefold(), clean_cable_id(self.cable_choice(c,node_id)).casefold(), other.casefold()}
            if wanted in candidates and wanted:exact.append(c)
            elif wanted and any(wanted in x for x in candidates if x):fuzzy.append(c)
        rows=exact or fuzzy
        if len(rows)==1:return rows[0],""
        if not rows:return None,f'케이블 "{text}"을 찾지 못했습니다. 케이블ID 또는 연결 함체명을 확인하세요.'
        return None,f'케이블 "{text}"과 일치하는 케이블이 {len(rows)}개입니다. 케이블ID를 더 정확히 입력하세요.'

    def survey_errors(self, node_id=None, row_by_slot=None, with_slots=False):
        query="SELECT * FROM survey_rows";args=[]
        if node_id:query+=" WHERE node_id=?";args=[node_id]
        rows=self.conn.execute(query,args).fetchall();errors=[];seen={}
        if row_by_slot is None:row_by_slot={(row["cable_id"],int(row["core_index"])):row for row in self.all_core_rows()}
        def add(nid,title,reason,slots):
            item=(nid,title,reason)
            errors.append(item+(tuple(slots),) if with_slots else item)
        for r in rows:
            label=f'{r["left_index"]}번 ↔ {r["right_index"]}번'
            slots=((r["left_cable"],int(r["left_index"])),(r["right_cable"],int(r["right_index"])))
            if r["invalid"]:add(r["node_id"],label,r["error_message"],slots);continue
            a=row_by_slot.get((r["left_cable"],int(r["left_index"])));b=row_by_slot.get((r["right_cable"],int(r["right_index"])))
            if not a or not b:add(r["node_id"],label,"조사한 케이블 또는 코어번호가 현재 도면에 없습니다.",slots);continue
            aid=str(a["core_id"] or "").strip();bid=str(b["core_id"] or "").strip()
            if aid and bid and not aid.startswith("임시-") and not bid.startswith("임시-") and aid!=bid:
                add(r["node_id"],label,f"오류코어: 왼쪽 {aid}, 오른쪽 {bid}로 서로 다릅니다.",slots)
            for slot in ((r["left_cable"],r["left_index"]),(r["right_cable"],r["right_index"])):
                seen.setdefault(slot,[]).append(label)
        for slot,labels in seen.items():
            if len(labels)>1:add(node_id or "전체",f"{slot[1]}번",f"같은 케이블 코어가 조사자료 {len(labels)}곳에 중복 입력되었습니다.",(slot,))
        return errors

    def error_core_rows(self,node_id=None):
        return self.error_core_summary(node_id)['rows']

    def connection_issue_rows(self,node_id=None):
        self.cable_core_warning_summary()
        return [e['row'] for e in self._connection_errors+self._input_errors
                if node_id is None or node_id in e['nodes'] or '전체' in e['nodes']]

    def all_core_rows(self, core_id=None):
        where=" WHERE core_id=?" if core_id is not None else ""
        args=(core_id,) if core_id is not None else ()
        sql=f"""SELECT cable_id,core_index,core_id,detail,status1,status2,signal,'' label FROM cores{where}
          UNION ALL SELECT 'PORT:'||node_id,port_index,core_id,detail,status1,status2,signal,label FROM ports{where}
          ORDER BY core_id,cable_id,core_index"""
        return [workflow.annotate(self,r) for r in self.conn.execute(sql,args+args).fetchall()]

    def _slot_title(self,cid,idx):
        if str(cid).startswith("PORT:"):
            n=self.node(str(cid).split(":",1)[1]);r=self.core(cid,idx)
            return f'{n["name"] if n else "내부"}/{r["label"] if r else idx}'
        c=self.cable(cid)
        if not c:return f"삭제된 케이블/{idx}"
        a=self.node(c["n1id"]);b=self.node(c["n2id"]);name=clean_cable_id(c["cable_id"]) or (c["spec"] or f'{c["size"]}C')
        return f'{a["name"] if a else "?"}-{b["name"] if b else "?"}/{name}/{idx}번'

    def trace_context(self):
        revision=self.data_revision()
        if getattr(self,"_trace_context_revision",None)==revision and getattr(self,"_trace_context_cache",None) is not None:return self._trace_context_cache
        rows=self.all_core_rows();row_by_slot={(row["cable_id"],int(row["core_index"])):row for row in rows};by_id={}
        for row in rows:
            core_id=str(row["core_id"] or "").strip()
            if core_id:by_id.setdefault(core_id,[]).append(row)
        net=workflow.Network(self.conn);links=net.links
        nodes={node["id"]:node for node in self.nodes()};cables={cable["id"]:cable for cable in self.cables()};node_counts={nid:0 for nid in nodes}
        for cable in cables.values():node_counts[cable["n1id"]]=node_counts.get(cable["n1id"],0)+1;node_counts[cable["n2id"]]=node_counts.get(cable["n2id"],0)+1
        extras={}
        for nid,node in nodes.items():
            try:extras[nid]=json.loads(node["extra_json"] or "{}")
            except Exception:extras[nid]={}
        context={"rows":rows,"row_by_slot":row_by_slot,"by_id":by_id,"links":links,"nodes":nodes,"cables":cables,"node_counts":node_counts,"extras":extras,"invalid":net.bad}
        self._trace_context_revision=revision;self._trace_context_cache=context;return context

    def trace_core_paths(self,core_id,context=None,slot=None):
        """코어ID의 연결요소를 도식화할 수 있는 순서형 경로와 오류지점으로 변환한다."""
        core_id=normalize_trace_core_id(core_id);context=context or self.trace_context()
        if workflow.field_slot_mode(self):return workflow.field_core_trace(self,core_id,context,slot=slot)
        items=context["by_id"].get(core_id,[])
        row_by_slot=context["row_by_slot"];links=context["links"];nodes=context["nodes"];cables=context["cables"];node_counts=context["node_counts"];extras=context["extras"]
        slots={(row["cable_id"],int(row["core_index"])) for row in items};remaining=set(slots);components=[]
        while remaining:
            start=next(iter(remaining));component=set();stack=[start]
            while stack:
                current=stack.pop()
                if current in component or current not in slots:continue
                component.add(current);stack.extend(other for _,other in links.get(current,()) if other in slots)
            components.append(component);remaining-=component

        def node_name(nid):
            node=nodes.get(nid);return str(node["name"] if node else "?")
        def terminal(nid):
            node=nodes.get(nid)
            return workflow.cable_terminal(node,node_counts.get(nid,0),extras.get(nid,{}))
        def port_label(slot):
            row=row_by_slot.get(slot);return str(row["label"] or slot[1]) if row else str(slot[1])
        def endpoint_label(slot,nid,component):
            ports=[other for link_node,other in links.get(slot,()) if link_node==nid and other in component and str(other[0]).startswith("PORT:")]
            return f'{node_name(nid)}({port_label(ports[0])})' if ports else node_name(nid)

        groups=[];global_issues=[];highlight=set()
        for number,component in enumerate(components,1):
            group_issues=[];cable_slots={slot for slot in component if slot[0] in cables};highlight.update(slot[0] for slot in cable_slots)
            for slot in component:
                row=row_by_slot.get(slot)
                group_issues.extend(context.get('invalid',{}).get(slot,()))
                if row and "error" in (str(row["status1"] or ""),str(row["status2"] or ""),str(row["signal"] or "")):group_issues.append(f'{self._slot_title(*slot)} 오류코어 표시')
                for nid,other in links.get(slot,()):
                    if other not in component:
                        other_row=row_by_slot.get(other);other_id=str(other_row["core_id"] or "").strip() if other_row else ""
                        group_issues.append(f'{node_name(nid)}에서 다른 코어ID({other_id or "빈 코어"})와 접속')
            for slot in cable_slots:
                cable=cables[slot[0]]
                for nid in (cable["n1id"],cable["n2id"]):
                    same=[other for link_node,other in links.get(slot,()) if link_node==nid and other in component]
                    if len(same)>1:group_issues.append(f'{node_name(nid)}에서 {slot[1]}번 연결이 여러 갈래입니다.')
                    if not same and not terminal(nid):group_issues.append(f'{node_name(nid)}에서 {slot[1]}번 코어가 연결되지 않았습니다.')
                    for other in same:
                        if str(other[0]).startswith("PORT:"):
                            label=port_label(other).upper()
                            if not (workflow.port_endpoint_kind(nodes.get(nid),extras.get(nid,{}))):group_issues.append(f'{node_name(nid)}/{label} 포트는 완료 끝점이 아닙니다.')
            paths=[];unused=set(cable_slots)
            while unused:
                candidates=[]
                for slot in unused:
                    cable=cables[slot[0]]
                    for nid in (cable["n1id"],cable["n2id"]):
                        next_cables=[other for link_node,other in links.get(slot,()) if link_node==nid and other in unused and other[0] in cables]
                        if not next_cables:candidates.append((slot,nid))
                current,entry=(sorted(candidates,key=lambda x:(x[0][0],x[0][1],x[1]))[0] if candidates else (next(iter(unused)),cables[next(iter(unused))[0]]["n1id"]))
                steps=[];previous=None
                while current in unused:
                    cable=cables[current[0]];exit_node=cable["n2id"] if cable["n1id"]==entry else cable["n1id"]
                    name=clean_cable_id(cable["cable_id"]) or (cable["spec"] or f'{cable["size"]}C')
                    steps.append({"from":endpoint_label(current,entry,component),"to":endpoint_label(current,exit_node,component),"cable":name,"index":current[1],"cable_id":current[0],"status":cable["status"]})
                    unused.remove(current);next_slots=[other for link_node,other in links.get(current,()) if link_node==exit_node and other in unused and other[0] in cables and other!=previous]
                    if not next_slots:break
                    if len(next_slots)>1:group_issues.append(f'{node_name(exit_node)}에서 경로가 여러 갈래라 첫 경로만 표시했습니다.')
                    previous,current=current,sorted(next_slots)[0];entry=exit_node
                paths.append(steps)
            if not cable_slots and component:
                ports=[f'{node_name(str(slot[0]).split(":",1)[1])}({port_label(slot)})' for slot in component if str(slot[0]).startswith("PORT:")]
                group_issues.append("외부 케이블 없이 내부 포트에만 코어ID가 있습니다.");paths.append([{"from":ports[0] if ports else "내부포트","to":"","cable":"","index":"","cable_id":"","status":""}])
            groups.append({"number":number,"paths":paths,"issues":list(dict.fromkeys(group_issues)),"slots":set(component)})
        if len(components)>1:global_issues.append(f'같은 코어ID가 서로 이어지지 않은 {len(components)}개 경로로 나뉘어 있습니다.')
        for group in groups:global_issues.extend(group["issues"])
        global_issues=list(dict.fromkeys(global_issues))
        return {"core_id":core_id,"rows":items,"groups":groups,"issues":global_issues,"highlight":highlight,"complete":bool(items) and not global_issues and len(groups)==1}

    def core_analysis(self):
        rows=self.all_core_rows();by_id={};row_by_slot={};completion=workflow.completion_report(self)
        for r in rows:
            cid=str(r["core_id"] or "").strip()
            row_by_slot[(r["cable_id"],r["core_index"])]=r
            if cid and (not cid.startswith("임시-") or completion["by_id"].get(cid,{}).get("required") or workflow.is_exception(r)):by_id.setdefault(cid,[]).append(r)
        nodes={n["id"]:n for n in self.nodes()};cables={c["id"]:c for c in self.cables()};node_cable_count={nid:0 for nid in nodes}
        node_extras={nid:json.loads(n["extra_json"] or "{}") for nid,n in nodes.items()}
        for c in cables.values():
            node_cable_count[c["n1id"]]=node_cable_count.get(c["n1id"],0)+1;node_cable_count[c["n2id"]]=node_cable_count.get(c["n2id"],0)+1
        adjacency={};connected_at=set()
        for s in self.conn.execute("SELECT * FROM splices"):
            a=(s["cable1_id"],s["core1_index"]);b=(s["cable2_id"],s["core2_index"])
            adjacency.setdefault(a,set()).add(b);adjacency.setdefault(b,set()).add(a);connected_at.add((s["node_id"],a[0],a[1]));connected_at.add((s["node_id"],b[0],b[1]))
        result=[]
        for core_id,items in by_id.items():
            slots={(r["cable_id"],r["core_index"]) for r in items};remaining=set(slots);components=[]
            while remaining:
                start=next(iter(remaining));comp=set();stack=[start]
                while stack:
                    cur=stack.pop()
                    if cur in comp or cur not in slots:continue
                    comp.add(cur);stack.extend(adjacency.get(cur,()))
                components.append(comp);remaining-=comp
            endpoints=[];degree_error=False;cable_states=set();route=[]
            for cid,idx in slots:
                degree=len(adjacency.get((cid,idx),()))
                if degree>2:degree_error=True
                if str(cid).startswith("PORT:"):
                    nid=str(cid).split(":",1)[1]
                    if (nid,cid,idx) not in connected_at:endpoints.append(nid)
                else:
                    c=cables.get(cid)
                    if not c:continue
                    cable_states.add(c["status"]);a=nodes.get(c["n1id"]);b=nodes.get(c["n2id"]);name=clean_cable_id(c["cable_id"]) or (c["spec"] or f'{c["size"]}C')
                    route.append(f'{a["name"] if a else "?"}-{b["name"] if b else "?"}/{name}/{idx}번')
                    for nid in (c["n1id"],c["n2id"]):
                        exceptions=node_extras.get(nid,{}).get("assignmentExceptions") or {}
                        if (nid,cid,idx) not in connected_at and not exceptions.get(f"{cid}::{idx}"):endpoints.append(nid)
            nonterminal=[]
            for nid in endpoints:
                n=nodes.get(nid)
                terminal=False
                if n:
                    try:terminal=bool(json.loads(n["extra_json"] or "{}").get("terminal"))
                    except Exception:terminal=False
                if n and n["type"]=="hamche" and node_cable_count.get(nid,0)>1 and not terminal and not workflow.hamche_temporary_exempt(n,items[0]):nonterminal.append(nid)
            first=items[0];status_set=set().union(*(workflow.statuses(x) for x in items))
            is_exception='exception' in status_set
            work="절단절체" if "절단" in cable_states else ("코어절체" if "철거" in cable_states else "")
            policy=completion['by_id'].get(core_id,{})
            accepted=is_exception or policy.get('exception_complete',False)
            nonconnect=not policy.get('required',False)
            result.append({"core_id":core_id,"detail":first["detail"],"status1":first["status1"],"status2":first["status2"],"signal":first["signal"],
              "route":" → ".join(sorted(set(route))),"components":len(components),"endpoints":len(endpoints),"need":bool(nonterminal) and not nonconnect and not accepted,
              "incomplete":not policy.get("complete",False) and not nonconnect and not accepted,"patherror":(degree_error or len(endpoints)>2) and not accepted,"disconnected":len(components)>1 and not accepted,"work":'' if accepted else work,
              "count":len(items),"noinfo":core_id.replace(" ","").startswith("내역없음"),"cancel":"cancel" in status_set,"broken":"broken" in status_set,"error":"error" in status_set and not accepted,"exception":is_exception,"complete":bool(accepted or policy.get('complete')),
              "on":policy.get("on",False),"off":not policy.get("on",False) and first["signal"]=="off","signal_exception":first['signal']=='exception',"unknown":str(first["signal"] or "") in ("","unknown")})
        return result

    @staticmethod
    def _work_required_from_connection(conn):
        """전 도면의 철거/절단 케이블 또는 철거 함체·RN에 연결된 사용 코어를 묶는다."""
        conn.row_factory=sqlite3.Row
        rows=conn.execute("""SELECT co.cable_id internal_cable,co.core_index,co.core_id,co.detail,
          co.status1,co.status2,co.signal,b.cable_id,b.spec,b.size,b.status,
          n1.name n1_name,n1.type n1_type,n1.status n1_status,
          n2.name n2_name,n2.type n2_type,n2.status n2_status
          FROM cores co JOIN cables b ON b.id=co.cable_id
          JOIN nodes n1 ON n1.id=b.n1id JOIN nodes n2 ON n2.id=b.n2id
          WHERE b.status IN ('철거','절단','remove','cut')
             OR (n1.type IN ('hamche','rn') AND n1.status IN ('철거','remove'))
             OR (n2.type IN ('hamche','rn') AND n2.status IN ('철거','remove'))
          ORDER BY co.core_id,b.rowid,co.core_index""").fetchall()
        grouped={}
        for row in rows:
            core_id=str(row["core_id"] or "").strip()
            if not core_id:
                marked=bool(str(row["detail"] or "").strip() or str(row["status1"] or "") not in ("","unknown") or str(row["status2"] or "") not in ("","unknown") or str(row["signal"] or "") not in ("","unknown"))
                if not marked:continue
            group_key=core_id or f'__EMPTY__{row["internal_cable"]}::{row["core_index"]}'
            item=grouped.setdefault(group_key,{
                "core_id":core_id,"detail":"","signal":"","source_slots":set(),"source_cables":set(),
                "source_routes":[],"source_states":set(),"source_facilities":set(),"input_missing":not bool(core_id)})
            if not item["detail"] and str(row["detail"] or "").strip():item["detail"]=str(row["detail"]).strip()
            if not item["signal"] and str(row["signal"] or "").strip():item["signal"]=str(row["signal"]).strip()
            item["source_slots"].add((row["internal_cable"],int(row["core_index"])))
            item["source_cables"].add(row["internal_cable"])
            if row["status"] in ("절단","cut"):item["source_states"].add("절단")
            elif row["status"] in ("철거","remove"):item["source_states"].add("철거")
            row_facilities=[]
            if row["n1_type"] in ("hamche","rn") and row["n1_status"] in ("철거","remove"):item["source_facilities"].add(row["n1_name"]);row_facilities.append(row["n1_name"])
            if row["n2_type"] in ("hamche","rn") and row["n2_status"] in ("철거","remove"):item["source_facilities"].add(row["n2_name"]);row_facilities.append(row["n2_name"])
            cable_name=clean_cable_id(row["cable_id"]) or (row["spec"] or f'{row["size"]}C')
            facility_note=(" [시설철거: "+", ".join(sorted(row_facilities))+"]") if row_facilities else ""
            route=f'{row["n1_name"]}-{row["n2_name"]}/{cable_name}/{row["core_index"]}번{facility_note}'
            if route not in item["source_routes"]:item["source_routes"].append(route)
        for item in grouped.values():
            item["method"]="절단절체" if "절단" in item["source_states"] else ("코어절체" if "철거" in item["source_states"] else "코어절체")
        return list(grouped.values())

    def work_required_cores(self):
        return self._work_required_from_connection(self.conn)

    @classmethod
    def work_required_from_path(cls,path):
        path=Path(path)
        if not path.exists():return []
        conn=sqlite3.connect(path)
        try:return cls._work_required_from_connection(conn)
        finally:conn.close()

    def check_work_required(self,required):
        """후 도면에서 작업필요코어의 경로와 양 끝단 완결 여부를 검사한다."""
        rows=self.all_core_rows();row_by_slot={};by_id={}
        for row in rows:
            slot=(row["cable_id"],int(row["core_index"]));row_by_slot[slot]=row
            core_id=str(row["core_id"] or "").strip()
            if core_id:by_id.setdefault(core_id,[]).append(row)
        nodes={n["id"]:n for n in self.nodes()};cables={c["id"]:c for c in self.cables()}
        node_cable_count={nid:0 for nid in nodes}
        for cable in cables.values():
            node_cable_count[cable["n1id"]]=node_cable_count.get(cable["n1id"],0)+1
            node_cable_count[cable["n2id"]]=node_cable_count.get(cable["n2id"],0)+1
        links={}
        for splice in self.conn.execute("SELECT * FROM splices"):
            a=(splice["cable1_id"],int(splice["core1_index"]));b=(splice["cable2_id"],int(splice["core2_index"]));nid=splice["node_id"]
            links.setdefault(a,[]).append((nid,b));links.setdefault(b,[]).append((nid,a))

        def terminal_node(nid):
            node=nodes.get(nid)
            if not node:return False
            if node["type"] in ("hamche","rn") and node["status"] in ("철거","remove"):return False
            return workflow.cable_terminal(node,node_cable_count.get(nid,0))

        results=[]
        for source in required:
            core_id=source["core_id"];items=by_id.get(core_id,[]);base=dict(source)
            base.update({"result":"누락","complete":False,"missing":False,"error":False,"current_route":"","note":""})
            if source.get("input_missing"):
                base.update({"result":"입력누락","error":True,"note":"전 도면의 사용 표시가 있는 코어인데 코어ID가 없습니다."});results.append(base);continue
            if core_id.startswith("임시-"):
                base.update({"result":"오류","error":True,"note":"전 도면의 임시코어입니다. 실제 코어ID를 먼저 입력하세요."});results.append(base);continue
            if not items:
                base.update({"result":"누락","missing":True,"note":"후 도면에서 같은 코어ID를 찾지 못했습니다."});results.append(base);continue
            slots={(row["cable_id"],int(row["core_index"])) for row in items};remaining=set(slots);components=[]
            while remaining:
                start=next(iter(remaining));component=set();stack=[start]
                while stack:
                    current=stack.pop()
                    if current in component or current not in slots:continue
                    component.add(current);stack.extend(other for _,other in links.get(current,()) if other in slots)
                components.append(component);remaining-=component
            mismatch=[];degree_error=False
            for slot in slots:
                if len(links.get(slot,()))>2:degree_error=True
                for _,other in links.get(slot,()):
                    other_row=row_by_slot.get(other);other_id=str(other_row["core_id"] or "").strip() if other_row else ""
                    if other_id!=core_id:mismatch.append(f'{self._slot_title(*slot)} ↔ {self._slot_title(*other)}({other_id or "빈 코어"})')
            terminal_ends=[];rn_ends=[];physical_ends=[];invalid_ends=[];invalid_ports=[];routes=[];used_cables=set();removed_facilities=set()
            for cid,idx in slots:
                row=row_by_slot[(cid,idx)]
                if str(cid).startswith("PORT:"):
                    nid=str(cid).split(":",1)[1];node=nodes.get(nid);label=str(row["label"] or "").upper();name=node["name"] if node else nid
                    if len(links.get((cid,idx),()))==1:
                        if node and node["status"] in ("철거","remove"):removed_facilities.add(name);invalid_ports.append(f"철거시설 {name}/{label or idx}")
                        elif workflow.port_endpoint_kind(node)=='terminal':terminal_ends.append(name);physical_ends.append(('terminal',nid))
                        elif workflow.port_endpoint_kind(node)=='rn':rn_ends.append(f"{name}/{label}");physical_ends.append(('rn',nid))
                        else:invalid_ports.append(f"{name}/{label or idx}")
                    else:invalid_ends.append(f"{name}/{label or idx} 미접속")
                    continue
                cable=cables.get(cid)
                if not cable:
                    invalid_ends.append(f"삭제된 케이블/{idx}번");continue
                used_cables.add(cid);a=nodes.get(cable["n1id"]);b=nodes.get(cable["n2id"]);name=clean_cable_id(cable["cable_id"]) or (cable["spec"] or f'{cable["size"]}C')
                for endpoint in (a,b):
                    if endpoint and endpoint["type"] in ("hamche","rn") and endpoint["status"] in ("철거","remove"):removed_facilities.add(endpoint["name"])
                routes.append(f'{a["name"] if a else "?"}-{b["name"] if b else "?"}/{name}/{idx}번')
                connected_nodes={nid for nid,_ in links.get((cid,idx),())}
                for nid in (cable["n1id"],cable["n2id"]):
                    if nid in connected_nodes:continue
                    node=nodes.get(nid);title=node["name"] if node else nid
                    if terminal_node(nid):terminal_ends.append(title);physical_ends.append(('terminal',nid))
                    else:invalid_ends.append(f"{title}에서 미접속")
            old_route=used_cables & set(source["source_cables"])
            removed_after=[cid for cid in used_cables if cables.get(cid) and cables[cid]["status"] in ("철거","절단","remove","cut")]
            valid_pair=workflow.valid_endpoint_pair(physical_ends)
            notes=[]
            if len(components)>1:notes.append(f"같은 ID 경로가 {len(components)}개로 끊어짐")
            if mismatch:notes.append("서로 다른 코어ID 접속")
            if degree_error:notes.append("한 코어에 접속이 3개 이상")
            if old_route:notes.append(f"전 도면 작업대상 케이블에 {len(old_route)}개 잔존")
            if removed_after:notes.append(f"후 도면 철거/절단 케이블에 {len(removed_after)}개 존재")
            if removed_facilities:notes.append("후 도면 철거시설 경유: "+", ".join(sorted(removed_facilities)))
            if invalid_ends:notes.append("미완료 끝점: "+", ".join(sorted(set(invalid_ends))))
            if invalid_ports:notes.append("완료기준이 아닌 RN 포트: "+", ".join(sorted(set(invalid_ports))))
            if not valid_pair:notes.append(f"끝단 {len(set(terminal_ends))}개 / RN 내부 {len(set(rn_ends))}개")
            complete=not notes and len(components)==1 and valid_pair
            error=bool(mismatch or degree_error or len(components)>1)
            base.update({"result":"완료" if complete else ("오류" if error else "미완료"),"complete":complete,"error":error,
                         "current_route":" → ".join(sorted(set(routes))),"note":" / ".join(notes) if notes else "끝단 연결 정상"})
            results.append(base)
        return results

    def _auto_connect_same_ids(self,node_ids=None):
        if workflow.field_slot_mode(self):raise ValueError('현장반영에서는 코어ID로 자동 연결하지 않습니다. 현장 선번을 입력하세요.')
        """지정 시설에서 같은 실제 코어ID의 미접속 대상이 정확히 둘이면 접속한다."""
        nodes={n["id"]:n for n in self.nodes()};targets=set(nodes) if node_ids is None else {str(nid) for nid in node_ids if str(nid) in nodes}
        connected=0;errors=[];error_seen=set();processed=set();pending=list(targets)
        bulk_scan=node_ids is None or len(targets)>20
        cables_by_node={};cores_by_cable={};ports_by_node={};splices_by_node={}
        if bulk_scan:
            for cable in self.cables():
                cables_by_node.setdefault(cable["n1id"],[]).append(cable);cables_by_node.setdefault(cable["n2id"],[]).append(cable)
            for row in self.conn.execute("SELECT cable_id,core_index,core_id,detail FROM cores WHERE TRIM(COALESCE(core_id,''))<>''"):
                cores_by_cable.setdefault(row["cable_id"],[]).append(row)
            for row in self.conn.execute("SELECT node_id,port_index,core_id,detail FROM ports WHERE TRIM(COALESCE(core_id,''))<>''"):
                ports_by_node.setdefault(row["node_id"],[]).append(row)
            for splice in self.conn.execute("SELECT * FROM splices"):
                splices_by_node.setdefault(splice["node_id"],[]).append(splice)

        def add_error(message):
            if message not in error_seen:error_seen.add(message);errors.append(message)

        while pending:
            nid=pending.pop()
            if nid in processed:continue
            processed.add(nid);groups={}
            node_cables=cables_by_node.get(nid,()) if bulk_scan else self.node_cables(nid)
            for cable in node_cables:
                if str(cable["spec"] or "").strip()=="드랍":continue
                core_rows=cores_by_cable.get(cable["id"],()) if bulk_scan else self.conn.execute("SELECT cable_id,core_index,core_id,detail FROM cores WHERE cable_id=? AND TRIM(COALESCE(core_id,''))<>''",(cable["id"],))
                for row in core_rows:
                    core_id=str(row["core_id"] or "").strip()
                    if not core_id.startswith("임시-"):groups.setdefault(core_id,[]).append((row["cable_id"],int(row["core_index"]),str(row["detail"] or "").strip()))
            port_rows=ports_by_node.get(nid,()) if bulk_scan else self.conn.execute("SELECT node_id,port_index,core_id,detail FROM ports WHERE node_id=? AND TRIM(COALESCE(core_id,''))<>''",(nid,))
            for row in port_rows:
                core_id=str(row["core_id"] or "").strip()
                if not core_id.startswith("임시-"):groups.setdefault(core_id,[]).append(("PORT:"+nid,int(row["port_index"]),str(row["detail"] or "").strip()))
            used=set()
            splice_rows=splices_by_node.get(nid,()) if bulk_scan else self.conn.execute("SELECT * FROM splices WHERE node_id=?",(nid,))
            for splice in splice_rows:
                used.add((splice["cable1_id"],int(splice["core1_index"])));used.add((splice["cable2_id"],int(splice["core2_index"])))
            for core_id,slots in groups.items():
                excluded=set(json.loads(nodes[nid]['extra_json'] or '{}').get('autoSameNumberExcluded') or ())
                free=[slot for slot in slots if (slot[0],slot[1]) not in used and f'{slot[0]}::{slot[1]}' not in excluded]
                if len(free)>2:
                    add_error(f'{nodes[nid]["name"]} / {core_id}: 빈 연결 대상이 {len(free)}개라 자동접속하지 않았습니다.');continue
                if len(free)!=2:continue
                if free[0][0]==free[1][0]:
                    add_error(f'{nodes[nid]["name"]} / {core_id}: 같은 케이블 안의 두 번호라 자동접속하지 않았습니다.');continue
                details={slot[2] for slot in free if slot[2]}
                if len(details)>1:
                    add_error(f'{nodes[nid]["name"]} / {core_id}: 코어내역이 서로 달라 자동접속하지 않았습니다.');continue
                a,b=sorted(((free[0][0],free[0][1]),(free[1][0],free[1][1])));detail=next(iter(details),"")
                cursor=self.conn.execute("INSERT OR IGNORE INTO splices VALUES(?,?,?,?,?)",(nid,a[0],a[1],b[0],b[1]))
                if not cursor.rowcount:continue
                self._write_core_identity(a[0],a[1],core_id,detail,False);self._write_core_identity(b[0],b[1],core_id,detail,False)
                used.update((a,b));connected+=1
                for cid,_ in (a,b):
                    if str(cid).startswith("PORT:"):continue
                    cable=self.cable(cid)
                    if cable:
                        for next_node in (cable["n1id"],cable["n2id"]):
                            if next_node not in processed:pending.append(next_node)
        return connected,errors

    @recorded("같은 코어ID 자동접속")
    def auto_connect_same_ids(self,node_id=None):
        connected,errors=self._auto_connect_same_ids(None if node_id is None else {node_id})
        self.conn.commit();return connected,errors

    @recorded("전체 코어정보 변경")
    def rename_core_group(self,old_id,new_id,detail,status1,status2,signal):
        old_id=str(old_id or "").strip();new_id=str(new_id or "").strip()
        if not old_id or not new_id:raise ValueError("코어ID는 비워둘 수 없습니다.")
        if status1 not in ("","unknown") and status1==status2:raise ValueError(f"상태1과 상태2에 {status_label(status1)}을 중복으로 선택할 수 없습니다.")
        if new_id!=old_id and self.all_core_rows(new_id):raise ValueError(f"코어ID {new_id}가 이미 존재합니다. 중복 등록하지 않았습니다.")
        if workflow.field_slot_mode(self):
            for row in self.all_core_rows(old_id):
                workflow.field_slot_write(self,(row['cable_id'],int(row['core_index'])),[new_id,detail,status1,status2,row['signal']])
            return
        self.conn.execute("UPDATE cores SET core_id=?,detail=?,status1=?,status2=?,signal=? WHERE core_id=?",(new_id,detail,status1,status2,signal,old_id))
        self.conn.execute("UPDATE ports SET core_id=?,detail=?,status1=?,status2=?,signal=? WHERE core_id=?",(new_id,detail,status1,status2,signal,old_id));self.conn.commit()

    def preview_core_name(self,core_id):
        core_id=str(core_id or '').strip()
        if not core_id:raise ValueError('코어ID가 있는 행을 선택하세요.')
        rows=self.all_core_rows(core_id)
        if not rows:raise ValueError('현재 도면에 이 코어ID가 없습니다. 코어를 배정한 뒤 이름을 수정하세요.')
        if workflow.locked(self):raise ValueError('현재 도면의 편집 잠금을 해제하세요.')
        positions=[]
        for row in rows:
            owner,index=row['cable_id'],int(row['core_index'])
            cable=self.cable(owner) if not owner.startswith('PORT:') else None
            nodes=(cable['n1id'],cable['n2id']) if cable else (owner[5:],)
            if any(workflow.node_locked(self,nid) for nid in nodes):raise ValueError(self._slot_title(owner,index)+': 잠긴 구간이 있어 코어명을 전체 변경할 수 없습니다.')
            positions.append((owner,index,str(row['detail'] or '')))
        return dict(core_id=core_id,positions=positions,revision=self.data_revision(),generation=self._view_generation)

    def commit_core_name(self,preview,detail):
        current=self.preview_core_name(preview['core_id'])
        if current!=preview:raise ValueError('입력 중 도면이 변경됐습니다. 목록을 새로고침해 적용 범위를 확인한 뒤 다시 반영하세요.')
        detail=str(detail or '').strip();changed=sum(name!=detail for owner,index,name in current['positions'])
        if not changed:return 0
        self.backup_to(self.path.parent/'backup'/(self.path.stem+'_core_name_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite3'))
        with self.action('같은 ID 코어명 변경'):
            for table in ('cores','ports'):
                self.conn.execute('UPDATE '+table+" SET detail=? WHERE core_id=? AND COALESCE(detail,'')<>?",(detail,current['core_id'],detail))
        return changed

    @recorded('코어 신호 변경')
    def set_core_signal(self,core_id,signal,slot=None,node_id=None):
        if workflow.field_slot_mode(self):
            if slot is None:raise ValueError('현장 신호는 케이블 번호별로 변경합니다. 케이블 또는 함체에서 번호를 선택하세요.')
            row=self.core(*slot)
            if not row or str(row['core_id'] or '')!=str(core_id or ''):raise ValueError('코어가 변경되었습니다. 다시 선택하세요.')
            if signal not in SIGNAL_LABELS:raise ValueError('올바른 신호를 선택하세요.')
            if node_id is not None:return workflow.field_signal_at_node(self,node_id,slot,signal)
            targets=workflow.temporary_route_targets(self,tuple(slot),str(row['core_id'] or '').strip())
            workflow.field_slot_write(self,tuple(slot),[row[k] for k in ('core_id','detail','status1','status2')]+[signal])
            workflow.propagate_temporary_signal(self,tuple(slot),signal,targets);return
        core_id=str(core_id or '').strip()
        if not core_id or not self.all_core_rows(core_id):raise ValueError('변경할 코어를 찾지 못했습니다. 목록을 새로고침하세요.')
        if signal not in SIGNAL_LABELS:raise ValueError('올바른 신호를 선택하세요.')
        for table in ('cores','ports'):
            self.conn.execute(f'UPDATE {table} SET signal=? WHERE core_id=? AND COALESCE(signal,\'\')<>?',(signal,core_id,signal))

    @recorded("코어 배정 이동")
    def move_or_copy_core(self,source,target,copy_only=False):
        if workflow.field_slot_mode(self):
            if copy_only:raise ValueError('현장 내역은 「케이블별 내역 이동·교환」에서 옮기세요. 연결은 그대로 유지됩니다.')
            return workflow.field_slot_transfer(self,source,target)
        src=self.core(*source);dst=self.core(*target)
        if not src or not dst:raise ValueError("선택한 코어를 찾지 못했습니다.")
        src_id=str(src["core_id"] or "").strip();dst_id=str(dst["core_id"] or "").strip()
        if not src_id:raise ValueError("이동할 원본 코어가 비어 있습니다.")
        if dst_id and not dst_id.startswith("임시-") and dst_id!=src_id:raise ValueError(f"대상 코어에 다른 코어ID {dst_id}가 있습니다.")
        values=[src["core_id"],src["detail"],src["status1"],src["status2"],src["signal"]]
        if not copy_only:self.update_core(source[0],source[1],["","","","",""])
        self.update_core(target[0],target[1],values)

    def used_same_number_indices(self,left,right):
        """양쪽 중 한 곳이라도 실제 사용정보가 있는 같은 번호만 반환한다."""
        left_rows={int(row["core_index"]):row for row in self.cores(left)};right_rows={int(row["core_index"]):row for row in self.cores(right)}
        def used(row):
            if not row:return False
            states=workflow.statuses(row)
            if "cancel" in states or "broken" in states:return False
            return bool(str(row["core_id"] or "").strip() or str(row["detail"] or "").strip())
        return [index for index in sorted(set(left_rows)&set(right_rows)) if used(left_rows[index]) or used(right_rows[index])]

    def set_auto_splice_exclusions(self,node_id,slots,exclude=True,deleted=False):
        node=self.node(node_id)
        if not node:return
        extra=json.loads(node['extra_json'] or '{}');before=set(extra.get('autoSameNumberExcluded') or ());after=set(before)
        keys={f'{cid}::{index}' for cid,index in slots}
        # V194: 「autoSameNumberDeleted」 remembers which exclusions only came
        # from deleting a number, so re-assigning it can release them even
        # when the edit history is gone. An explicit disconnect is never one.
        marked=set(extra.get('autoSameNumberDeleted') or ());marks=set(marked)
        if exclude:
            after.update(keys)
            if deleted:marks.update(keys-before)
            else:marks.difference_update(keys)
        else:after.difference_update(keys);marks.difference_update(keys)
        marks&=after
        if after==before and marks==marked:return
        if after:extra['autoSameNumberExcluded']=sorted(after)
        else:extra.pop('autoSameNumberExcluded',None)
        if marks:extra['autoSameNumberDeleted']=sorted(marks)
        else:extra.pop('autoSameNumberDeleted',None)
        self.conn.execute('UPDATE nodes SET extra_json=? WHERE id=?',(json.dumps(extra,ensure_ascii=False),node_id))

    def exclude_deleted_core_from_auto(self,cable_id,index):
        cable=self.cable(cable_id)
        if cable:
            for nid in (cable['n1id'],cable['n2id']):self.set_auto_splice_exclusions(nid,((cable_id,index),),deleted=True)
        for link in self.conn.execute('SELECT * FROM splices WHERE (cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?)',(cable_id,index,cable_id,index)).fetchall():
            self.set_auto_splice_exclusions(link['node_id'],((link['cable1_id'],link['core1_index']),(link['cable2_id'],link['core2_index'])),deleted=True)

    def auto_splice_changed_slots(self):
        if getattr(self,'_auto_splice_running',False):return
        slots=set();nodes=set()
        for event in self.conn.execute("SELECT table_name,op,old_json,new_json FROM history_events WHERE group_id=? AND table_name IN ('cores','cables') AND new_json IS NOT NULL",(self._history_group,)):
            new=json.loads(event['new_json']);old=json.loads(event['old_json']) if event['old_json'] else {}
            if event['table_name']=='cores':
                if (new.get('core_id') or new.get('detail')) and any(new.get(k)!=old.get(k) for k in ('core_id','detail')):
                    slots.add((new['cable_id'],int(new['core_index'])))
            elif event['op']=='insert' or any(old.get(k)!=new.get(k) for k in ('n1id','n2id','size','spec')):
                nodes.update((new['n1id'],new['n2id']))
        if slots or nodes:self.auto_splice_slots(slots,nodes)

    def auto_splice_slots(self,slots=(),node_ids=()):
        if workflow.field_slot_mode(self):return
        if getattr(self,'_auto_splice_running',False) or workflow.locked(self) or not workflow.state(self)['options']['auto_same_number']:return
        mode=self.conn.execute("SELECT value FROM meta WHERE key='active_scenario'").fetchone();after=bool(mode and mode[0]=='after')
        pairs={};cables={};queue=deque();visited=set();normal=0;errors=[]
        def pair(nid):
            if nid not in pairs:
                node=self.node(nid);attached=self.node_cables(nid) if node and node['type']=='hamche' else []
                extra=json.loads(node['extra_json'] or '{}') if node else {}
                eligible=len(attached)==2 and not extra.get('terminal') and all(c['spec']!='드랍' for c in attached)
                if after and eligible:eligible=all(item['status'] not in ('철거','절단') for item in [node,*attached])
                pairs[nid]=(node,attached,set(extra.get('autoSameNumberExcluded') or ())) if eligible else None
            return pairs[nid]
        def add_slot(slot):
            cid,index=slot
            if str(cid).startswith('PORT:'):return
            if cid not in cables:cables[cid]=self.cable(cid)
            cable=cables[cid]
            if cable:
                for nid in (cable['n1id'],cable['n2id']):
                    if (nid,index) not in visited and pair(nid):queue.append((nid,index))
        for slot in slots:add_slot(slot)
        for nid in node_ids:
            info=pair(nid)
            if info:
                for cable in info[1]:
                    for row in self.conn.execute("SELECT core_index FROM cores WHERE cable_id=? AND (TRIM(COALESCE(core_id,''))<>'' OR TRIM(COALESCE(detail,''))<>'')",(cable['id'],)):
                        queue.append((nid,int(row[0])))
        previous=getattr(self,'_same_number_only',False);self._same_number_only=True;self._auto_splice_running=True
        try:
            while queue:
                nid,index=queue.popleft()
                if (nid,index) in visited:continue
                node,attached,excluded=pair(nid);a=(attached[0]['id'],index);b=(attached[1]['id'],index)
                if any(f'{cid}::{idx}' in excluded for cid,idx in (a,b)):continue
                rows=[self.core(*slot) for slot in (a,b)]
                if any(row is None for row in rows) or not any(row['core_id'] or row['detail'] for row in rows):continue
                visited.add((nid,index))
                if any({'cancel','broken'} & workflow.statuses(row) for row in rows):continue
                if self.splice_for(nid,*a) or self.splice_for(nid,*b):continue
                if getattr(self,'_auto_splice_adjacency',None) is None:
                    self._auto_splice_adjacency={}
                    for link in self.conn.execute('SELECT * FROM splices'):
                        l=(link['cable1_id'],link['core1_index']);r=(link['cable2_id'],link['core2_index'])
                        self._auto_splice_adjacency.setdefault(l,set()).add(r);self._auto_splice_adjacency.setdefault(r,set()).add(l)
                component=self.component(a)|self.component(b)
                try:self.connect(nid,a,b,temporary=True)
                except ValueError as exc:
                    ids=' / '.join(dict.fromkeys(display_core_id(row['core_id']) for row in rows if row['core_id']))
                    details=' / '.join(dict.fromkeys(row['detail'] for row in rows if row['detail']))
                    errors.append((ids,details,f"{node['name']} · {self._slot_title(*a)} ↔ {self._slot_title(*b)}: {exc}"))
                else:
                    normal+=1;self._auto_splice_adjacency.setdefault(a,set()).add(b);self._auto_splice_adjacency.setdefault(b,set()).add(a)
                    for slot in component:add_slot(slot)
        finally:
            self._auto_splice_running=False;self._auto_splice_adjacency=None;self._same_number_only=previous
        for nid in {nid for nid,index in visited}:
            self.conn.execute('INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)',('auto_same_number_checked:'+nid,'1'))
        if normal or errors:
            pending=getattr(self,'pending_auto_splice_report',None) or {'normal':0,'rows':[]}
            rows=list(dict.fromkeys(pending['rows']+errors))
            self.pending_auto_splice_report={'title':'동일번호 자동 중접 결과','normal':pending['normal']+normal,'errors':len(rows),'rows':rows}
        return normal,errors

    def check_auto_splice_on_open(self,node_id):
        if workflow.field_slot_mode(self):return
        if workflow.locked(self) or not workflow.state(self)['options']['auto_same_number']:return
        node=self.node(node_id)
        if not node or node['type']!='hamche' or len(self.node_cables(node_id))!=2:return
        key='auto_same_number_checked:'+node_id
        if self.conn.execute('SELECT 1 FROM meta WHERE key=?',(key,)).fetchone():return
        with self.action('함체 동일번호 자동 중접'):result=self.auto_splice_slots(node_ids=(node_id,))
        # An undo or a later reopen must not silently repeat this initial pass.
        self.conn.execute('INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)',(key,'1'));self.conn.commit()
        return result

    @recorded("같은 번호 중접")
    def full_splice(self,node_id,left,right,used_only=True,start=None,end=None,include_empty=True):
        if start is not None:indices=self.range_splice_plan(node_id,left,right,start,end,include_empty)[0]
        else:indices=self.unconnected_same_number_indices(node_id,left,right) if used_only else range(1,min(len(self.cores(left)),len(self.cores(right)))+1)
        previous=getattr(self,'_same_number_only',False);self._same_number_only=True
        try:result=self.bulk_connect_pairs(node_id,[(f"{idx}번",(left,idx),(right,idx)) for idx in indices])
        finally:self._same_number_only=previous
        return sum(ok for _,ok,_ in result),[f"{label}: {msg}" for label,ok,msg in result if not ok]

    def unconnected_same_number_indices(self,node_id,left,right):
        used=set()
        for s in self.conn.execute('SELECT * FROM splices WHERE node_id=?',(node_id,)):
            used.add((s['cable1_id'],s['core1_index']));used.add((s['cable2_id'],s['core2_index']))
        return [i for i in self.used_same_number_indices(left,right) if (left,i) not in used and (right,i) not in used]

    def range_splice_plan(self,node_id,left,right,start,end,include_empty=True):
        """V189: 직결(같은 번호 중접) for start..end only. Returns (targets, skipped)."""
        total=min(len(self.cores(left)),len(self.cores(right)))
        try:start,end=int(start),int(end)
        except (TypeError,ValueError):raise ValueError('시작 번호와 끝 번호를 숫자로 입력하세요.')
        if start>end:start,end=end,start
        if total<1:raise ValueError('연결할 코어가 없습니다.')
        if start<1 or end>total:raise ValueError(f'번호는 1~{total} 사이로 입력하세요.')
        targets=[];skipped=[]
        for index in range(start,end+1):
            a=(left,index);b=(right,index);rows=[self.core(*slot) for slot in (a,b)]
            if any(row is None for row in rows):skipped.append((index,'코어번호 없음'));continue
            link=self.splice_for(node_id,*a) or self.splice_for(node_id,*b)
            if link:
                pair={(link['cable1_id'],link['core1_index']),(link['cable2_id'],link['core2_index'])}
                skipped.append((index,'이미 직결됨' if pair=={a,b} else '이 함체에서 이미 다른 번호와 연결'));continue
            if any({'cancel','broken'}&workflow.statuses(row) for row in rows):skipped.append((index,'해지·끊김 상태'));continue
            if not include_empty and not any(str(row['core_id'] or '').strip() or str(row['detail'] or '').strip() for row in rows):
                skipped.append((index,'빈 번호'));continue
            targets.append(index)
        return targets,skipped

    def is_single_cable_hamche(self,node_id):
        node=self.node(node_id)
        return bool(node and node['type']=='hamche' and len(self.node_cables(node_id))==1)

    def is_local_terminal(self,node_id):
        cables=[c for c in self.node_cables(node_id) if str(c['spec'] or '').strip()!='드랍']
        return workflow.assignment_terminal(self.node(node_id),len(cables))

    @recorded("코어 일괄연결")
    def bulk_connect_pairs(self,node_id,pairs):
        results=[]
        for label,a,b in pairs:
            title=f"{label}행 · {self._slot_title(*a)} ↔ {self._slot_title(*b)}"
            if not self.core(*a) or not self.core(*b):results.append((title,False,"케이블 또는 코어번호를 찾지 못했습니다."));continue
            valid=True
            for cid,idx in (a,b):
                if str(cid).startswith("PORT:"):belongs=cid[5:]==node_id
                else:
                    cable=self.cable(cid);belongs=bool(cable and node_id in (cable["n1id"],cable["n2id"]))
                if not belongs:valid=False
            if not valid:results.append((title,False,"선택 함체/RN에 연결된 케이블이 아닙니다."));continue
            try:message=self.connect(node_id,a,b,temporary=True)
            except ValueError as exc:results.append((title,False,str(exc)))
            else:results.append((title,True,"기존 연결과 같아 무시" if "무시" in message else "연결 완료"))
        return results

    @recorded('Excel 원본표 연결·임시코어 정보 입력')
    def bulk_connect_source_rows(self,node_id,rows):
        """Keep real identities intact; promote temporary paths as one undoable import."""
        if workflow.field_slot_mode(self):
            # Field sheets supply topology; GIS identities remain on their slots.
            return self.bulk_connect_pairs(node_id,[(item['row'],*map(tuple,item['slots'])) for item in rows if len(item['slots'])==2])
        results=[]
        for item in rows:
            slots=[tuple(slot) for slot in item['slots']]
            core_id=normalize_core_id_input(item.get('core_id'));detail=str(item.get('detail') or '').strip()
            title=f"{item['row']}행 · "+' ↔ '.join(self._slot_title(*slot) for slot in slots)
            self.conn.hold_commit+=1;self.conn.execute('SAVEPOINT source_row')
            old_auto=getattr(self,'_same_number_only',False);self._same_number_only=True
            try:
                if len(slots) not in (1,2):raise ValueError('연결할 코어번호 두 칸 또는 정보만 입력할 한 칸이 필요합니다.')
                for cid,index in slots:
                    row=self.core(cid,index);cable=self.cable(cid)
                    belongs=(cid=='PORT:'+node_id) if str(cid).startswith('PORT:') else bool(cable and node_id in (cable['n1id'],cable['n2id']))
                    if not row or not belongs:raise ValueError('선택 함체/RN의 케이블·코어번호가 아닙니다.')
                scope=set();pending=list(slots);checked_temps=set()
                while pending:
                    slot=pending.pop()
                    if slot in scope:continue
                    component=self.component(slot);scope.update(component)
                    for position in component:
                        current=self.core(*position);old_id=str(current['core_id'] or '').strip() if current else ''
                        if old_id.startswith('임시-') and old_id not in checked_temps:
                            checked_temps.add(old_id)
                            pending.extend((r['cable_id'],int(r['core_index'])) for r in self.all_core_rows(old_id))
                original={slot:dict(self.core(*slot)) for slot in scope if self.core(*slot)}
                real_ids={str(r['core_id']).strip() for r in original.values() if r['core_id'] and not str(r['core_id']).startswith('임시-')}
                conflicts=[f"{self._slot_title(*slot)}: 기존 {r['core_id']} / 입력 {core_id}" for slot,r in original.items()
                           if core_id and r['core_id'] and not str(r['core_id']).startswith('임시-') and str(r['core_id']).strip()!=core_id]
                if conflicts:raise ValueError('오류코어 · 기존 ID 충돌. 이 행은 변경하지 않았습니다. '+'; '.join(sorted(conflicts)))
                if len(real_ids)>1:raise ValueError('오류코어 · 연결 경로의 실제 코어ID가 서로 다릅니다: '+', '.join(sorted(real_ids)))
                if len(slots)==1 and not str(original[slots[0]]['core_id'] or '').strip():
                    raise ValueError('정보만 입력할 때는 해당 번호에 임시코어를 먼저 배정하세요.')
                message=self.connect(node_id,*slots,temporary=True) if len(slots)==2 else ''
                target_id=core_id or next(iter(real_ids),str(self.core(*slots[0])['core_id'] or ''))
                updated=0;old_ids=set()
                for slot,before in original.items():
                    old_id=str(before['core_id'] or '').strip()
                    if old_id and not old_id.startswith('임시-'):continue
                    current=self.core(*slot)
                    if not current:continue
                    new_detail=detail or str(current['detail'] or '')
                    old_ids.update((old_id,str(current['core_id'] or '')))
                    if target_id and (current['core_id']!=target_id or str(current['detail'] or '')!=new_detail):
                        self._write_core_identity(*slot,target_id,new_detail,True);updated+=1
                for old_id in old_ids:workflow.phase_promote_identity(self,old_id,target_id)
                result=('기존 연결 유지' if '무시' in message else '연결 완료') if len(slots)==2 else '정보 입력 검사'
                result+=f" · 임시코어 정보 입력 {updated}곳" if updated else ' · 기존 코어정보 유지'
                if real_ids:result+=' · 실제코어의 기존 이름 유지'
                if core_id:result+=f' · {display_core_id(target_id)}'+(f' / {detail}' if detail else '')
            except ValueError as exc:
                self.conn.execute('ROLLBACK TO source_row');results.append((title,False,str(exc)))
            else:results.append((title,True,result))
            finally:
                self._same_number_only=old_auto;self.conn.execute('RELEASE source_row');self.conn.hold_commit-=1
        self.conn.commit();return results

    @recorded('빠른 코어배정')
    def quick_assign_many(self,selected,core_id,detail):
        saved=0;errors=[]
        for cid,idx in selected:
            old=self.core(cid,idx)
            if not old:errors.append(f'{cid}/{idx}번: 코어 없음');continue
            old_id=str(old['core_id'] or '').strip()
            if old_id and not old_id.startswith('임시-') and old_id!=core_id:errors.append(f'{self._slot_title(cid,idx)}: 기존 {old_id}와 충돌');continue
            try:self.update_core(cid,idx,[core_id,detail,old['status1'],old['status2'],old['signal']]);saved+=1
            except ValueError as exc:errors.append(f'{self._slot_title(cid,idx)}: {exc}')
        return saved,0,errors

    def preview_core_identity_swap(self,cable_id,first,second):
        if first==second:raise ValueError('서로 다른 두 코어번호를 선택하세요.')
        cable=self.cable(cable_id)
        if not cable:raise ValueError('케이블을 찾을 수 없습니다.')
        if workflow.locked(self) or any(workflow.node_locked(self,nid) for nid in (cable['n1id'],cable['n2id'])):
            raise ValueError('케이블 또는 함체의 편집 잠금을 해제하세요.')
        rows=[self.core(cable_id,index) for index in (first,second)]
        if not all(rows):raise ValueError('케이블 규격 안의 코어번호를 선택하세요.')
        before=[(str(r['core_id'] or ''),str(r['detail'] or '')) for r in rows]
        if before[0]==before[1]:raise ValueError('두 번호의 코어ID와 코어내역이 같습니다.')
        return dict(cable_id=cable_id,first=first,second=second,before=before,
                    revision=self.data_revision(),generation=self._view_generation)

    def commit_core_identity_swap(self,preview):
        current=self.preview_core_identity_swap(preview['cable_id'],preview['first'],preview['second'])
        if current!=preview:raise ValueError('확인 중 도면이 변경됐습니다. 교환할 두 번호를 다시 확인하세요.')
        backup=self.path.parent/'backup'/(self.path.stem+'_core_swap_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite3')
        self.backup_to(backup)
        with self.action('케이블 코어내역 교환'):
            previous=getattr(self,'_slot_identity_edit',False);self._slot_identity_edit=True
            try:
                for index,values in zip((preview['first'],preview['second']),reversed(preview['before'])):
                    self.conn.execute('UPDATE cores SET core_id=?,detail=? WHERE cable_id=? AND core_index=?',(*values,preview['cable_id'],index))
            finally:self._slot_identity_edit=previous
        return backup

    def preview_core_move(self,cable_id,first,second):
        if workflow.completion_kind(self)!='after':raise ValueError('코어 옮기기는 후도면에서 사용하세요.')
        if first==second:raise ValueError('서로 다른 두 코어번호를 선택하세요.')
        cable=self.cable(cable_id)
        if not cable:raise ValueError('케이블을 찾을 수 없습니다.')
        if workflow.locked(self) or any(workflow.node_locked(self,nid) for nid in (cable['n1id'],cable['n2id'])):
            raise ValueError('케이블 또는 함체의 편집 잠금을 해제하세요.')
        rows=[self.core(cable_id,index) for index in (first,second)]
        if not all(rows):raise ValueError('케이블 규격 안의 코어번호를 선택하세요.')
        if not str(rows[0]['core_id'] or '').strip():raise ValueError('옮길 코어ID가 있는 번호를 선택하세요.')
        if workflow.plan_used(rows[1]) or self.conn.execute('SELECT 1 FROM splices WHERE (cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?) LIMIT 1',(cable_id,second,cable_id,second)).fetchone():
            raise ValueError(f'{second}번은 사용 중입니다. 코어정보와 접속이 없는 빈 번호를 선택하세요.')
        settings=workflow.plan_settings(self)
        if any(workflow.plan_slot_key((cable_id,i)) in settings['fixed_slots'] for i in (first,second)) or rows[0]['core_id'] in settings['fixed_ids']:
            raise ValueError('고정·예약된 코어입니다. 후도면 작업실에서 고정을 해제한 뒤 옮기세요.')
        for nid in (cable['n1id'],cable['n2id']):
            extra=json.loads(self.node(nid)['extra_json'] or '{}');key=f'{cable_id}::{second}'
            if any(key in extra.get(name,()) for name in ('autoSameNumberExcluded','assignmentExceptions')):
                raise ValueError(f'{second}번은 연결 해제·배정 예외로 지정되어 있습니다. 다른 빈 번호를 선택하세요.')
        before=[tuple(str(r[k] or '') for k in workflow.PLAN_FIELDS) for r in rows]
        after=workflow.completion_kind(self)=='after';splices=[];moved=[];exclusions=[]
        if after:
            def shifted(slot):
                owner,index=slot
                return (owner,second if index==first else first if index==second else index) if owner==cable_id else slot
            splices=[dict(r) for r in self.conn.execute('SELECT * FROM splices WHERE (cable1_id=? AND core1_index IN (?,?)) OR (cable2_id=? AND core2_index IN (?,?)) ORDER BY node_id,cable1_id,core1_index,cable2_id,core2_index',
                (cable_id,first,second,cable_id,first,second))]
            for row in splices:
                if workflow.node_locked(self,row['node_id']):raise ValueError('접속 함체의 편집 잠금을 해제하세요.')
                a,b=sorted((shifted((row['cable1_id'],row['core1_index'])),shifted((row['cable2_id'],row['core2_index']))))
                moved.append((row['node_id'],*a,*b))
            # Disconnect and assignment exceptions follow the moved occupant.
            # Physical reservations and frozen field/GIS evidence stay in place.
            for node in self.nodes():
                extra=json.loads(node['extra_json'] or '{}');changed=False
                for field in ('autoSameNumberExcluded','assignmentExceptions'):
                    values=extra.get(field)
                    if not isinstance(values,(list,dict)):continue
                    def move_key(key):
                        nonlocal changed
                        try:owner,index=key.rsplit('::',1);slot=(owner,int(index))
                        except (ValueError,AttributeError):return key
                        dest=shifted(slot)
                        if dest==slot:return key
                        changed=True;return f'{dest[0]}::{dest[1]}'
                    extra[field]=[move_key(k) for k in values] if isinstance(values,list) else {move_key(k):v for k,v in values.items()}
                if changed:
                    if workflow.node_locked(self,node['id']):raise ValueError('배정 예외가 있는 함체의 편집 잠금을 해제하세요.')
                    exclusions.append((node['id'],node['extra_json'],json.dumps(extra,ensure_ascii=False)))
        return dict(cable_id=cable_id,first=first,second=second,before=before,after=after,
                    splices=splices,moved_splices=moved,exclusions=exclusions,
                    revision=self.data_revision(),generation=self._view_generation)

    def commit_core_move(self,preview):
        current=self.preview_core_move(preview['cable_id'],preview['first'],preview['second'])
        if current!=preview:raise ValueError('확인 중 도면이 변경됐습니다. 옮길 두 번호를 다시 확인하세요.')
        backup=self.path.parent/'backup'/(self.path.stem+'_core_move_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite3')
        self.backup_to(backup)
        with self.action('후도면 코어 옮기기'):
            previous=getattr(self,'_slot_identity_edit',False);self._slot_identity_edit=True
            try:
                for row in preview['splices']:
                    self.conn.execute('DELETE FROM splices WHERE node_id=? AND cable1_id=? AND core1_index=? AND cable2_id=? AND core2_index=?',
                        tuple(row[k] for k in ('node_id','cable1_id','core1_index','cable2_id','core2_index')))
                for index,values in zip((preview['first'],preview['second']),reversed(preview['before'])):
                    self.conn.execute('UPDATE cores SET core_id=?,detail=?,status1=?,status2=?,signal=? WHERE cable_id=? AND core_index=?',(*values,preview['cable_id'],index))
                for row in preview['moved_splices']:self.conn.execute('INSERT INTO splices VALUES(?,?,?,?,?)',row)
                for nid,old,new in preview['exclusions']:self.conn.execute('UPDATE nodes SET extra_json=? WHERE id=?',(new,nid))
            finally:self._slot_identity_edit=previous
        return backup

    @recorded("케이블 코어순서 교환")
    def swap_cable_cores(self,cable_id,first,second):
        if first==second:return
        if workflow.field_slot_mode(self):return workflow.field_slot_transfer(self,(cable_id,first),(cable_id,second))
        a=self.core(cable_id,first);b=self.core(cable_id,second)
        if not a or not b:raise ValueError("바꿀 코어번호가 케이블 규격 범위를 벗어났습니다.")
        fields=("core_id","detail","status1","status2","signal")
        av=tuple(a[x] for x in fields);bv=tuple(b[x] for x in fields)
        affected=self.conn.execute("SELECT * FROM splices WHERE cable1_id=? OR cable2_id=?",(cable_id,cable_id)).fetchall()
        self.conn.execute("DELETE FROM splices WHERE cable1_id=? OR cable2_id=?",(cable_id,cable_id))
        self.conn.execute("UPDATE cores SET core_id=?,detail=?,status1=?,status2=?,signal=? WHERE cable_id=? AND core_index=?",bv+(cable_id,first))
        self.conn.execute("UPDATE cores SET core_id=?,detail=?,status1=?,status2=?,signal=? WHERE cable_id=? AND core_index=?",av+(cable_id,second))
        for r in affected:
            a_slot=(r["cable1_id"],r["core1_index"]);b_slot=(r["cable2_id"],r["core2_index"])
            if a_slot[0]==cable_id:a_slot=(cable_id,second if a_slot[1]==first else first if a_slot[1]==second else a_slot[1])
            if b_slot[0]==cable_id:b_slot=(cable_id,second if b_slot[1]==first else first if b_slot[1]==second else b_slot[1])
            a_slot,b_slot=sorted((a_slot,b_slot))
            self.conn.execute("INSERT OR IGNORE INTO splices VALUES(?,?,?,?,?)",(r["node_id"],a_slot[0],a_slot[1],b_slot[0],b_slot[1]))
        self.conn.commit()


class _LegacyCableDialog(workflow.RememberedToplevel):
    def __init__(self, parent, store, cable_id=None, create_nodes=None):
        super().__init__(parent)
        self.parent, self.store = parent, store
        self.cable_key, self.create_nodes = cable_id, create_nodes
        self.title("케이블 만들기" if not cable_id else "케이블 편집")
        self.dialog_width,self.dialog_height=((1180,760) if cable_id else (760,300));self.geometry(f"{self.dialog_width}x{self.dialog_height}")
        if not cable_id:self.resizable(False,False)
        self.transient(parent)
        self.grab_set()
        top = ttk.Frame(self, padding=10); top.pack(fill="x")
        ttk.Label(top, text="케이블ID(선택)").grid(row=0,column=0,sticky="w")
        self.id_var=tk.StringVar();self.id_entry=ttk.Entry(top,textvariable=self.id_var,width=25);self.id_entry.grid(row=0,column=1,padx=5)
        self.size_var=tk.StringVar(value="12C")
        self.status_var=tk.StringVar(value="기설")
        choices=ttk.Frame(top);choices.grid(row=1,column=0,columnspan=6,sticky="ew",pady=8)
        status_box=ttk.LabelFrame(choices,text="1. 케이블 상태",padding=8);status_box.pack(side="left",fill="both",padx=(0,8))
        spec_box=ttk.LabelFrame(choices,text="2. 케이블 규격",padding=8);spec_box.pack(side="left",fill="both",expand=True)
        for i,value in enumerate(STATUS_VALUES):ttk.Radiobutton(status_box,text=value,value=value,variable=self.status_var).grid(row=i//2,column=i%2,padx=8,pady=4,sticky="w")
        for i,value in enumerate([f"{x}C" for x in CORE_SIZES]+["드랍"]):ttk.Radiobutton(spec_box,text=value,value=value,variable=self.size_var).grid(row=i//3,column=i%3,padx=8,pady=4,sticky="w")
        ttk.Label(spec_box,text="기타").grid(row=2,column=0,padx=8,pady=(6,0),sticky="e");ttk.Entry(spec_box,textvariable=self.size_var,width=10).grid(row=2,column=1,columnspan=2,padx=4,pady=(6,0),sticky="w")
        self.save_button=ttk.Button(top,text="저장 (Space)",command=self.save_header);self.save_button.grid(row=0,column=5,padx=10)
        self.info=tk.StringVar(value="Space 키로도 저장/생성됩니다.")
        ttk.Label(top,textvariable=self.info,foreground="#1769aa").grid(row=2,column=0,columnspan=7,sticky="w",pady=2)
        cols=("status1","status2","signal","number","core_id","detail")
        self.tree=workflow.SortableTreeview(self,columns=cols,show="headings",selectmode="browse")
        labels=("상태1","상태2","신호","번호","코어ID","코어내역")
        widths=(75,75,75,55,180,320)
        for c,l,w in zip(cols,labels,widths): self.tree.heading(c,text=l); self.tree.column(c,width=w,anchor="center" if c!="detail" else "w")
        y=ttk.Scrollbar(self,orient="vertical",command=self.tree.yview); self.tree.configure(yscrollcommand=y.set)
        self.tree.pack(side="left",fill="both",expand=True,padx=(10,0),pady=(0,10)); y.pack(side="left",fill="y",pady=(0,10))
        edit=ttk.LabelFrame(self,text="선택 코어 수정",padding=8); edit.pack(side="right",fill="y",padx=10,pady=(0,10))
        self.edit_vars=[tk.StringVar() for _ in range(5)]
        for i,(lab,var) in enumerate(zip(("코어ID","코어내역","상태1","상태2","신호"),self.edit_vars)):
            ttk.Label(edit,text=lab).grid(row=i,column=0,sticky="w",pady=3)
            if i<2:ttk.Entry(edit,textvariable=var,width=22).grid(row=i,column=1,pady=3)
            else:
                values=SIGNAL_VALUES if i==4 else CORE_STATUS_VALUES
                ttk.Combobox(edit,textvariable=var,values=values,state="readonly",width=19).grid(row=i,column=1,pady=3)
        ttk.Button(edit,text="선택 코어 적용",command=self.apply_core).grid(row=5,column=0,columnspan=2,sticky="ew",pady=8)
        ttk.Button(edit,text="내역없음 자동번호",command=self.assign_noinfo).grid(row=6,column=0,columnspan=2,sticky="ew",pady=(0,8))
        ttk.Label(edit,text="여러 줄 붙여넣기\n코어ID<TAB>코어내역",justify="left").grid(row=7,column=0,columnspan=2,sticky="w")
        self.paste=tk.Text(edit,width=28,height=12); self.paste.grid(row=8,column=0,columnspan=2,pady=5)
        ttk.Button(edit,text="선택 번호부터 적용",command=self.apply_paste).grid(row=9,column=0,columnspan=2,sticky="ew")
        ttk.Separator(edit,orient="horizontal").grid(row=10,column=0,columnspan=2,sticky="ew",pady=10)
        ttk.Button(edit,text="코어순서 바꾸기",command=self.swap_cores).grid(row=11,column=0,columnspan=2,sticky="ew",pady=2)
        ttk.Button(edit,text="코어내역 전체복사",command=self.copy_details).grid(row=12,column=0,columnspan=2,sticky="ew",pady=2)
        self.tree.bind("<<TreeviewSelect>>",self.load_selected)
        self.tree.bind("<Control-v>",self.paste_from_excel);self.tree.bind("<Shift-Insert>",self.paste_from_excel)
        self.bind("<KeyPress-space>",self.space_save);self.id_entry.bind("<KeyPress-space>",self.space_save);self.id_entry.bind("<Control-a>",lambda e:select_entry_text(self.id_entry))
        if cable_id:
            c=store.cable(cable_id); self.id_var.set(c["cable_id"]); self.size_var.set(c["spec"] or f'{c["size"]}C'); self.status_var.set(c["status"]); self.reload();self.info.set("Excel의 코어ID+코어내역 두 열 복사 → 시작 번호 클릭 → Ctrl+V 즉시 입력")
        else:
            self.tree.pack_forget(); y.pack_forget(); edit.pack_forget()
        self.update_idletasks();self.center_on_parent();self.lift();self.focus_id();self.after(50,self.focus_id)

    def focus_id(self):
        if not self.id_entry.winfo_exists():return
        self.id_entry.focus_force();self.id_entry.selection_range(0,"end");self.id_entry.icursor("end")

    def center_on_parent(self):
        workflow.center_popup(self,self.parent)

    def space_save(self,event=None):
        self.save_header();return "break"

    def save_header(self):
        spec=self.size_var.get().strip().upper();
        try:size=1 if spec=="드랍" else int(spec.replace("C",""))
        except ValueError:messagebox.showerror("규격 오류","기타 규격은 24C처럼 코어 수를 숫자로 입력하세요.",parent=self);return
        if spec!="드랍":spec=f"{size}C"
        if not self.cable_key:
            self.cable_key=self.store.add_cable(*self.create_nodes,self.id_var.get(),spec,self.status_var.get())
            self.parent.refresh(); self.destroy(); return
        old=self.store.cable(self.cable_key)
        if size!=old["size"] and size < old["size"]:
            if not messagebox.askyesno("규격 축소",f"{old['size']}C에서 {size}C로 줄이면 뒤 코어와 연결이 삭제됩니다. 계속할까요?",parent=self): return
        with self.store.action("케이블 정보 변경"):
            self.store.resize_cable(self.cable_key,spec)
            self.store.conn.execute("UPDATE cables SET cable_id=?,status=? WHERE id=?",(clean_cable_id(self.id_var.get()),self.status_var.get(),self.cable_key))
        self.reload(); self.parent.refresh(); self.info.set("저장했습니다.")

    def reload(self, keep=None):
        if not self.cable_key:return
        view=self.tree.yview()[0] if self.tree.get_children() else 0
        if keep is None and self.tree.selection(): keep=int(self.tree.selection()[0])
        self.tree.delete(*self.tree.get_children())
        for r in self.store.cores(self.cable_key):
            has_core=bool(str(r["core_id"] or "").strip());s1,s2,sig=(status_label(r["status1"]),status_label(r["status2"]),signal_label(r["signal"])) if has_core else ("","","")
            tags=(workflow.field_slot_tag(self.store,r,core_row_tag(r)),core_signal_tag(r))
            self.tree.insert("", "end", iid=str(r["core_index"]), values=(s1,s2,sig,r["core_index"],display_core_id(r["core_id"]),r["detail"]),tags=tags)
        configure_core_tags(self.tree)
        if keep and self.tree.exists(str(keep)): self.tree.selection_set(str(keep))
        self.tree.yview_moveto(view)

    def load_selected(self,e=None):
        if not self.tree.selection():return
        r=self.store.core(self.cable_key,int(self.tree.selection()[0]))
        for v,x in zip(self.edit_vars,(r["core_id"],r["detail"],status_label(r["status1"]),status_label(r["status2"]),signal_label(r["signal"]))):v.set(x)

    def apply_core(self):
        if not self.tree.selection():return
        idx=int(self.tree.selection()[0])
        values=[self.edit_vars[0].get(),self.edit_vars[1].get(),CORE_STATUS_FROM_LABEL.get(self.edit_vars[2].get(),self.edit_vars[2].get()),CORE_STATUS_FROM_LABEL.get(self.edit_vars[3].get(),self.edit_vars[3].get()),SIGNAL_FROM_LABEL.get(self.edit_vars[4].get(),self.edit_vars[4].get())]
        try:self.store.update_core(self.cable_key,idx,values)
        except ValueError as e:messagebox.showerror("연결 충돌",str(e),parent=self);return
        self.reload(idx)

    def assign_noinfo(self):
        if not self.tree.selection():return
        existing=[]
        for r in self.store.all_core_rows():
            value=str(r["core_id"] or "").replace(" ","")
            if value.startswith("내역없음"):
                try:existing.append(int(value[4:]))
                except ValueError:pass
        self.edit_vars[0].set(f"내역없음{max(existing,default=0)+1}");self.edit_vars[1].set("");self.edit_vars[2].set("내역없음");self.apply_core()

    def apply_paste(self):
        if not self.tree.selection(): messagebox.showinfo("선택 필요","시작할 코어 번호를 먼저 선택하세요.",parent=self); return
        start=int(self.tree.selection()[0]); lines=self.paste.get("1.0","end").splitlines(); errors=[]
        for off,line in enumerate(lines):
            if not line.strip():continue
            idx=start+off
            if not self.tree.exists(str(idx)):break
            cols=line.split("\t"); old=self.store.core(self.cable_key,idx)
            vals=[cols[0].strip(), cols[1].strip() if len(cols)>1 else old["detail"], old["status1"],old["status2"],old["signal"]]
            try:self.store.update_core(self.cable_key,idx,vals)
            except ValueError as e:errors.append(f"{idx}번: {e}")
        self.reload(start)
        if errors:messagebox.showwarning("일부 코어 미적용","\n".join(errors[:20]),parent=self)

    def paste_from_excel(self,event=None):
        """코어표의 선택 번호부터 Excel의 ID/내역 두 열을 즉시 적용한다."""
        if not self.cable_key:return "break"
        try:raw=self.clipboard_get().replace("\r\n","\n").replace("\r","\n")
        except tk.TclError:return "break"
        lines=raw.split("\n")
        while lines and not lines[-1].strip():lines.pop()
        if not lines:return "break"
        start=int(self.tree.selection()[0]) if self.tree.selection() else 1;errors=[];saved=0;last=start
        with self.store.action("Excel 코어ID/내역 붙여넣기"):
            for offset,line in enumerate(lines):
                cols=line.split("\t");idx=start+offset;id_col=0;detail_col=1
                if len(cols)>=3 and cols[0].strip().isdigit():idx=int(cols[0].strip());id_col=1;detail_col=2
                if idx<1 or not self.tree.exists(str(idx)):errors.append(f"{idx}번: 케이블 규격 범위 밖이라 적용하지 않았습니다.");continue
                core_id=cols[id_col].strip() if id_col<len(cols) else "";detail=cols[detail_col].strip() if detail_col<len(cols) else None
                if not core_id and (detail is None or not detail):continue
                old=self.store.core(self.cable_key,idx);values=[core_id,old["detail"] if detail is None else detail,old["status1"],old["status2"],old["signal"]]
                try:self.store.update_core(self.cable_key,idx,values);saved+=1;last=idx
                except ValueError as e:errors.append(f"{idx}번: {e}")
        self.reload(last);self.info.set(f"Excel 붙여넣기 {saved}개 즉시 반영"+(f" · 확인필요 {len(errors)}개" if errors else ""))
        if errors:messagebox.showwarning("Excel 붙여넣기 확인필요","\n".join(errors[:30]),parent=self)
        return "break"

    def swap_cores(self):
        if not self.tree.selection():messagebox.showinfo("코어순서","먼저 바꿀 첫 번째 코어를 선택하세요.",parent=self);return
        first=int(self.tree.selection()[0])
        second=simpledialog.askinteger("코어순서 바꾸기",f"{first}번과 바꿀 코어번호를 입력하세요.",parent=self,minvalue=1,maxvalue=self.store.cable(self.cable_key)["size"])
        if second is None:return
        if not messagebox.askyesno("코어순서 바꾸기",(f"{first}번과 {second}번의 코어ID·코어명을 서로 바꿀까요?\n현장 선번과 번호별 신호·상태는 유지합니다." if workflow.field_slot_mode(self.store) else f"{first}번과 {second}번의 코어정보 및 연결 위치를 서로 바꿀까요?"),parent=self):return
        try:self.store.swap_cable_cores(self.cable_key,first,second)
        except ValueError as e:messagebox.showerror("바꾸지 않음",str(e),parent=self);return
        self.reload(second);self.info.set(f"코어순서 {first}번 ↔ {second}번을 바꿨습니다.")

    def copy_details(self):
        lines=["번호\t상태\t신호\t코어ID\t코어내역"]
        for r in self.store.cores(self.cable_key):
            lines.append("\t".join(map(str,(r["core_index"],workflow.core_status_text(self.store,r),workflow.core_copy_signal_label(self.store,r),display_core_id(r["core_id"]),r["detail"] or ""))))
        self.clipboard_clear();self.clipboard_append("\n".join(lines));self.update()
        self.info.set(f"{len(lines)-1}개 코어내역을 클립보드에 복사했습니다.")


CABLE_SIZE_CHOICES=tuple(f"{x}C" for x in CORE_SIZES)+("드랍",)
CHOICE_ON=('#2563eb','#ffffff');CHOICE_OFF=('#f1f5f9','#1f2937')


def cable_choice_columns(parent,status_var,size_var,other_var,status_command=None,compact=False):
    """V204: 케이블 상태(왼쪽)·규격(오른쪽)을 세로 두 줄의 누르는 버튼으로 고른다. 고른 버튼은 파란색.
    compact(편집창): 코어표 높이를 지키려고 같은 버튼을 상태 2칸·규격 4칸씩 줄지어 놓는다."""
    def place(b,i,per):b.grid(row=i//per if compact else i,column=i%per if compact else 0,padx=(0,2) if compact else 0,pady=1,sticky='ew')
    def make(box,text,on_click):
        b=tk.Button(box,text=text,width=8,pady=0,relief='raised',bd=1,cursor='hand2',takefocus=0,font=('Malgun Gothic',10),
                    activebackground='#bfdbfe',command=on_click)
        return b
    def paint(buttons,selected):
        for value,b in buttons.items():
            on=value==selected;bg,fg=CHOICE_ON if on else CHOICE_OFF
            b.configure(bg=bg,fg=fg,relief='sunken' if on else 'raised',font=('Malgun Gothic',10,'bold' if on else 'normal'))
    status_box=ttk.LabelFrame(parent,text="케이블 상태",padding=8);status_box.grid(row=0,column=0,sticky="ns",padx=(0,10))
    spec_box=ttk.LabelFrame(parent,text="케이블 규격",padding=8);spec_box.grid(row=0,column=1,sticky="ns")
    status_buttons={};size_buttons={}
    def pick_status(value):
        status_var.set(value)
        if status_command:status_command()
    for i,value in enumerate(STATUS_VALUES):
        status_buttons[value]=make(status_box,value,lambda v=value:pick_status(v));place(status_buttons[value],i,2)
    for i,value in enumerate(CABLE_SIZE_CHOICES):
        size_buttons[value]=make(spec_box,value,lambda v=value:size_var.set(v));place(size_buttons[value],i,4)
    entry=ttk.Entry(spec_box,textvariable=other_var,width=8)
    def pick_other():
        size_var.set(other_var.get().strip());entry.focus_set();entry.icursor('end')
    size_buttons['기타']=make(spec_box,'기타',pick_other);place(size_buttons['기타'],len(CABLE_SIZE_CHOICES),4)
    n=len(CABLE_SIZE_CHOICES)
    entry.grid(row=n//4 if compact else n,column=n%4+1 if compact else 1,padx=(6,0),sticky="w")
    entry.bind('<FocusIn>',lambda e:size_var.set(other_var.get().strip()) if other_var.get().strip() else None,add='+')
    other_var.trace_add('write',lambda *a:size_var.set(other_var.get().strip()))
    def repaint(*a):
        if not parent.winfo_exists():return
        paint(status_buttons,status_var.get())
        value=size_var.get();paint(size_buttons,value if value in CABLE_SIZE_CHOICES else '기타')
    status_var.trace_add('write',repaint);size_var.trace_add('write',repaint);repaint()
    return status_buttons,size_buttons,entry


class CableDialog(workflow.RememberedToplevel):
    """케이블 정보와 코어 상태/ID 수정을 분리한 편집창."""
    def __init__(self,parent,store,cable_id=None,create_nodes=None):
        super().__init__(parent)
        self.parent,self.store=parent,store
        self.cable_key,self.create_nodes=cable_id,create_nodes
        self._generation=getattr(store,'_view_generation',0);self._lock_state=None
        self._core_trace_enabled=bool(cable_id);self._core_trace_job=None;self._core_trace_key=None;self._core_trace_tree=None
        self.bind('<Destroy>',self.close_core_trace,add='+')
        self.identity_editor=None;self.identity_original={};self.identity_active_col="#2";self.previous_status="기설"
        self.title("케이블 만들기" if not cable_id else "케이블 편집")
        self.dialog_width,self.dialog_height=((1240,840) if cable_id else (800,560))
        self.geometry(f"{self.dialog_width}x{self.dialog_height}")
        if not cable_id:self.resizable(False,False)
        if not cable_id:
            self.transient(parent);self.grab_set()

        workflow.desktop_dialog_heading(self,'케이블 편집' if cable_id else '케이블 만들기','케이블 정보와 코어 연결 상태를 한눈에 확인하세요.')
        top=ttk.Frame(self,padding=(18,10));top.pack(fill="x")
        self.lock_notice=tk.Label(top,text='',anchor='w',font=('Malgun Gothic',10,'bold'))
        self.lock_notice.grid(row=4,column=0,columnspan=7,sticky='ew')
        ttk.Label(top,text="케이블ID(선택)").grid(row=0,column=0,sticky="w")
        self.id_var=tk.StringVar();self.id_entry=ttk.Entry(top,textvariable=self.id_var,width=25)
        self.id_entry.grid(row=0,column=1,padx=5)
        ttk.Label(top,text="LOT NO.").grid(row=1,column=0,sticky="w",pady=(8,0))
        self.lot_var=tk.StringVar()
        self.lot_entry=ttk.Entry(top,textvariable=self.lot_var,width=58)
        self.lot_entry.grid(row=1,column=1,columnspan=5,sticky="ew",padx=5,pady=(8,0))
        self.lot_entry.bind("<Control-a>",lambda e:select_entry_text(self.lot_entry))
        self.size_var=tk.StringVar(value="12C");self.status_var=tk.StringVar(value="기설")
        choices=ttk.Frame(top);choices.grid(row=2,column=0,columnspan=6,sticky="w",pady=8)
        self.other_size_var=tk.StringVar()
        self.status_buttons,self.size_buttons,self.other_size_entry=cable_choice_columns(choices,self.status_var,self.size_var,self.other_size_var,status_command=self.status_choice_changed,compact=bool(cable_id))
        ttk.Button(top,text="저장 (Space)",command=self.save_header).grid(row=0,column=5,padx=10)
        self.info=tk.StringVar(value="Space 키로도 저장/생성됩니다.")
        ttk.Label(top,textvariable=self.info,foreground="#1769aa").grid(row=3,column=0,columnspan=7,sticky="w",pady=2)
        self.completion_title=tk.StringVar(value='선택 코어 · 미완료 이유')
        self.completion_reason=tk.StringVar(value='코어를 선택하세요.')
        self.completion_signal=tk.StringVar();self.completion_signal_detail=tk.StringVar()
        if cable_id:
            top.columnconfigure(6,weight=1)
            self.completion_box=ttk.LabelFrame(top,text='연결 상태',padding=12)
            self.completion_box.grid(row=0,column=6,rowspan=3,sticky='nsew',padx=(24,0),pady=(0,8))
            ttk.Label(self.completion_box,textvariable=self.completion_title,font=('Malgun Gothic',11,'bold')).pack(anchor='w')
            self.completion_reason_label=ttk.Label(self.completion_box,textvariable=self.completion_reason,foreground='#666666',justify='left',wraplength=500)
            self.completion_reason_label.pack(fill='x',anchor='w',pady=(10,0))
            self.completion_signal_label=ttk.Label(self.completion_box,textvariable=self.completion_signal,font=('Malgun Gothic',10,'bold'),wraplength=500)
            self.completion_signal_label.pack(fill='x',anchor='w',pady=(8,0))
            self.completion_signal_detail_label=ttk.Label(self.completion_box,textvariable=self.completion_signal_detail,foreground='#475569',justify='left',wraplength=500)
            self.completion_signal_detail_label.pack(fill='x',anchor='w',pady=(2,0))
            self.map_allocation_button=ttk.Button(self.completion_box,text='도면에서 코어배정',command=lambda:self.open_manual_allocation(on_map=True),style='Primary.TButton')
            self.map_allocation_button.pack(fill='x',pady=(10,0))
            self.completion_details_button=ttk.Button(self.completion_box,text='완료 판정·미연결 위치 확인',command=self.show_completion_locations)
            self.completion_details_button.pack(fill='x',pady=(4,0))
            if workflow.completion_kind(self.store)=='after':
                self.offmap_button=ttk.Button(self.completion_box,text='도면 밖 연결 표시 (그리지 않은 구간)',command=self.open_offmap_links)
                self.offmap_button.pack(fill='x',pady=(4,0))
            self.completion_box.bind('<Configure>',lambda e:[label.configure(wraplength=max(100,e.width-28)) for label in (self.completion_reason_label,self.completion_signal_label,self.completion_signal_detail_label)])

        self.notebook=ttk.Notebook(self)
        self.status_tab=ttk.Frame(self.notebook);self.identity_tab=ttk.Frame(self.notebook)
        self.notebook.add(self.status_tab,text="코어 상태·신호")
        self.notebook.add(self.identity_tab,text="코어ID·코어명 수정")
        self.notebook.pack(fill="both",expand=True,padx=10,pady=(0,10))
        self._build_status_tab();self._build_identity_tab()
        self.notebook.bind('<<NotebookTabChanged>>',lambda e:self.queue_core_trace())

        self.bind("<KeyPress-space>",self.space_save)
        self.id_entry.bind("<KeyPress-space>",self.space_save)
        self.id_entry.bind("<Control-a>",lambda e:select_entry_text(self.id_entry))
        if cable_id:
            c=store.cable(cable_id)
            self.title("케이블 "+str(c["cable_id"] or c["spec"] or cable_id)+" 내역")
            self.lot_var.set(cable_lot_no(c))
            self.id_var.set(c["cable_id"]);self.size_var.set(c["spec"] or f'{c["size"]}C');self.status_var.set(c["status"])
            if self.size_var.get() not in CABLE_SIZE_CHOICES:self.other_size_var.set(self.size_var.get())
            self.previous_status=str(c["status"] or "기설")
            self.reload()
            self.info.set("코어ID·코어명은 별도 탭에서 입력한 뒤 '수정하기'를 눌러야 반영됩니다.")
        else:self.notebook.pack_forget()
        self._header_original=self.header_input_snapshot()
        self.refresh_lock_state();self.bind('<FocusIn>',lambda e:self.refresh_lock_state(),add='+')
        self.update_idletasks();self.center_on_parent();self.lift();self.focus_id()

    def header_input_snapshot(self):
        return tuple(var.get() for var in (self.id_var,self.lot_var,self.size_var,self.status_var))

    def pending_edits(self):
        """Inspect unsaved inputs without applying them to the drawing."""
        self.commit_identity_editor();pending=[]
        if self.header_input_snapshot()!=self._header_original:pending.append('케이블ID·LOT NO.·규격·상태')
        for item in self.identity_tree.get_children():
            original_id,original_detail=self.identity_original.get(int(item),('',''))
            values=self.identity_tree.item(item,'values')
            if tuple(map(str,values[1:3]))!=(display_core_id(original_id),original_detail):
                pending.append('코어ID·코어명 수정표');break
        if self.tree.selection() and self.edit_vars[2].get()!=getattr(self,'_signal_original',self.edit_vars[2].get()):pending.append('선택 코어 신호')
        return pending

    def close_for_switch(self):
        pending=self.pending_edits()
        if pending and not messagebox.askyesno('케이블 변경사항',
            '아직 저장하지 않은 입력이 있습니다: '+', '.join(pending)+'\n\n입력을 버리고 다른 케이블을 열까요?\n예: 입력 취소 후 이동 / 아니오: 현재 창 유지 (저장 후 다시 이동)',
            parent=self,default='no'):
            return False
        self.clear_core_trace();self.cancel_identity_editor();self.destroy();return True

    def refresh_lock_state(self):
        if not self.cable_key:return
        app=owning_app(self)
        if app and (app.store is not self.store or getattr(self.store,'_view_generation',0)!=self._generation):return
        cable=self.store.cable(self.cable_key)
        if not cable:return
        locked=workflow.cable_locked(self.store,self.cable_key)
        protected=any(workflow.node_locked(self.store,nid) for nid in (cable['n1id'],cable['n2id']))
        workflow.set_controls_locked(self,locked,('복사','미완료 목록','도면 수정 이력','입력내용 되돌리기'))
        for button in list(self.status_buttons.values())+list(self.size_buttons.values()):button.configure(state='disabled' if locked else 'normal')
        for tab in (self.status_tab,self.identity_tab):
            workflow.set_controls_locked(tab,protected,('복사','미완료 목록','도면 수정 이력','입력내용 되돌리기'))
        self.lock_notice.configure(text='🔒 자동 잠금 · 양쪽 함체 잠김 · 조회·복사 가능' if locked else ('한쪽 함체 잠금 · 코어·연결·규격 보호 · 케이블ID·LOT NO. 수정 가능' if protected else ''),bg='#ffeb3b' if locked else self.cget('background'),fg='#111111')
        if locked or protected:self.lock_notice.grid()
        else:self.lock_notice.grid_remove()
        self._lock_state=locked
        if getattr(self,'core_find',None) is not None:self.core_find.enable_search()

    def ensure_cable_editable(self,header=False):
        app=owning_app(self)
        if app and (app.store is not self.store or getattr(self.store,'_view_generation',0)!=self._generation):return False
        if not self.cable_key:return True
        cable=self.store.cable(self.cable_key)
        if not cable:return False
        blocked=workflow.cable_locked(self.store,self.cable_key) if header else any(workflow.node_locked(self.store,n) for n in (cable['n1id'],cable['n2id']))
        if blocked:
            self.refresh_lock_state();messagebox.showinfo('케이블 잠금','연결된 함체의 잠금을 해제한 뒤 수정하세요. 조회와 복사는 가능합니다.',parent=self);return False
        return True

    def _build_status_tab(self):
        tools=ttk.Frame(self.status_tab,padding=(0,4));tools.pack(fill='x')
        if workflow.field_slot_mode(self.store):ttk.Button(tools,text='케이블별 내역 이동·확정',command=lambda:workflow.FieldSlotEditorDialog(self,self.store,cable_id=self.cable_key)).pack(side='left',padx=3)
        ttk.Button(tools,text='코어ID 복사',command=lambda:self.copy_status_cell(column='core_id')).pack(side='left',padx=3)
        ttk.Button(tools,text='코어내역 복사',command=lambda:self.copy_status_cell(column='detail')).pack(side='left',padx=3)
        ttk.Label(tools,text='Shift·Ctrl+클릭: 여러 코어 선택 → 신호 한번에 적용 · Ctrl+F: 코어ID 찾기 · 코어 클릭: 경로',foreground='#1769aa').pack(side='left',padx=8)
        ttk.Button(tools,text='미완료 목록',command=lambda:IncompleteCoresDialog(self,self.store,self.cable_key)).pack(side='right',padx=3)
        body=ttk.Frame(self.status_tab);body.pack(fill="both",expand=True);body.rowconfigure(0,weight=1);body.columnconfigure(0,weight=1)
        cols=("annotations","signal","number","core_id","detail")
        self.tree=workflow.SortableTreeview(body,columns=cols,show="headings",selectmode="extended")
        for c,l,w in zip(cols,("상태","신호","번호","코어ID","코어내역"),(170,70,55,140,360)):
            self.tree.heading(c,text=l);self.tree.column(c,width=w,minwidth=200 if c=="detail" else w,stretch=c=="detail",anchor="center" if c!="detail" else "w")
        y=ttk.Scrollbar(body,orient="vertical",command=self.tree.yview);self.tree.configure(yscrollcommand=y.set)
        self.tree.grid(row=0,column=0,sticky="nsew");y.grid(row=0,column=1,sticky="ns")
        x=ttk.Scrollbar(body,orient="horizontal",command=self.tree.xview);x.grid(row=1,column=0,columnspan=2,sticky="ew");self.tree.configure(xscrollcommand=x.set)
        edit_box=ttk.LabelFrame(body,text="선택 코어 수정",padding=8);edit_box.grid(row=0,column=2,rowspan=2,sticky="ns",padx=(12,0))
        self.status_actions=workflow.ScrollableActions(edit_box);self.status_actions.pack(fill='both',expand=True)
        edit=self.status_actions.content;edit.columnconfigure(1,weight=1)
        self.edit_vars=[tk.StringVar() for _ in range(3)]
        ttk.Button(edit,text='상태 여러 항목 편집',command=self.edit_annotations).grid(row=0,column=0,columnspan=2,sticky='ew',pady=6)
        self.manual_allocation_button=ttk.Button(edit,text='별도 창에서 코어분배',command=self.open_manual_allocation)
        self.manual_allocation_button.grid(row=1,column=0,columnspan=2,sticky='ew',pady=4)
        ttk.Label(edit,text='신호').grid(row=2,column=0,sticky='w')
        ttk.Combobox(edit,textvariable=self.edit_vars[2],values=SIGNAL_VALUES,state='readonly',width=19).grid(row=2,column=1,pady=4)
        self.signal_apply_button=ttk.Button(edit,text="신호 적용",command=self.apply_core);self.signal_apply_button.grid(row=3,column=0,columnspan=2,sticky="ew",pady=(10,4))
        ttk.Button(edit,text="선택 코어삭제 (Delete)",command=lambda:self.delete_core(self.tree)).grid(row=4,column=0,columnspan=2,sticky="ew",pady=4)
        ttk.Separator(edit,orient="horizontal").grid(row=5,column=0,columnspan=2,sticky="ew",pady=10)
        ttk.Label(edit,text="직접 입력: 코어ID·코어명 수정 탭\n번호 간 교환: 코어내역 서로 바꾸기",justify="left",foreground="#1769aa").grid(row=6,column=0,columnspan=2,sticky="w")
        ttk.Button(edit,text="코어내역 전체복사",command=self.copy_details).grid(row=7,column=0,columnspan=2,sticky="ew",pady=(14,2))
        self.status_copy_column='core_id';self.copy_value=tk.StringVar();self.copy_field=tk.StringVar(value='선택 칸 · 코어ID')
        ttk.Label(edit,textvariable=self.copy_field).grid(row=8,column=0,columnspan=2,sticky='w',pady=(12,2))
        entry=ttk.Entry(edit,textvariable=self.copy_value,state='readonly',width=26);entry.grid(row=9,column=0,columnspan=2,sticky='ew')
        entry.bind('<Control-a>',lambda e:select_entry_text(entry))
        ttk.Button(edit,text='선택 칸 복사',command=self.copy_status_cell).grid(row=10,column=0,columnspan=2,sticky='ew',pady=4)
        self.swap_identity_button=ttk.Button(edit,text='코어내역 서로 바꾸기',command=self.swap_core_identities)
        self.swap_identity_button.grid(row=11,column=0,columnspan=2,sticky='ew',pady=(12,4))
        if workflow.completion_kind(self.store)=='after':
            self.move_core_button=ttk.Button(edit,text='코어 옮기기',command=self.move_core)
            self.move_core_button.grid(row=12,column=0,columnspan=2,sticky='ew',pady=4)
            ttk.Label(edit,text='옮기기: 빈 번호로 양쪽 접속까지 이동\n내역 바꾸기: ID·내역만 교환',wraplength=210,foreground='#1769aa').grid(row=13,column=0,columnspan=2,sticky='w',pady=4)
        # V206: 작업차수 for the selected cores (follows the core everywhere) or the whole cable.
        self.phase_button=ttk.Button(edit,text='작업차수 지정…',command=self.show_phase_menu)
        self.phase_button.grid(row=14,column=0,columnspan=2,sticky='ew',pady=(12,4))
        self.status_menu=tk.Menu(self,tearoff=False)
        self.status_menu.add_command(label='작업차수 지정…',command=lambda:self.show_phase_menu(pointer=True))
        self.status_menu.add_separator()
        self.status_menu.add_command(label='도면에서 코어배정',command=lambda:self.open_manual_allocation(on_map=True))
        for title,column in [('선택 칸 복사',None),('코어ID 복사','core_id'),('코어내역 복사','detail')]:
            self.status_menu.add_command(label=title,command=lambda c=column:self.copy_status_cell(column=c))
        self.status_menu.add_separator()
        self.status_menu.add_command(label='코어내역 서로 바꾸기',command=self.swap_core_identities)
        if workflow.completion_kind(self.store)=='after':self.status_menu.add_command(label='코어 옮기기',command=self.move_core)
        self.tree.bind('<ButtonPress-1>',self.remember_status_cell,add='+')
        self.tree.bind('<Button-3>',self.status_context_menu)
        for sequence in ('<Control-c>','<Control-C>'):self.tree.bind(sequence,self.copy_status_cell)
        self.tree.bind("<<TreeviewSelect>>",self.load_selected)
        self.tree.bind('<<TreeviewSelect>>',lambda e:self.queue_core_trace(self.tree),add='+')
        self.tree.bind("<Delete>",lambda e:self.delete_core(self.tree))
        for sequence in ('<Control-a>','<Control-A>'):self.tree.bind(sequence,self.select_all_status)

    def select_all_status(self,event=None):
        items=self.tree.get_children()
        if items:self.tree.selection_set(items)
        return 'break'

    def _build_identity_tab(self):
        guide=workflow.FlowToolbar(self.identity_tab);guide.pack(fill='x')
        guide.add(ttk.Button(guide,text='도면에서 코어배정',command=lambda:self.open_manual_allocation(on_map=True)))
        guide.add(ttk.Button(guide,text='Excel 붙여넣기',command=self.paste_identity_from_clipboard))
        guide.add(ttk.Button(guide,text='선택 행 내역없음 자동번호',command=self.assign_noinfo))
        guide.add(ttk.Label(guide,text='열 제목: ▲ → ▼ → 기본 순서 · 여러 행 붙여넣기: 기본 코어번호 순서',foreground='#1769aa'))
        notice=ttk.Label(self.identity_tab,text="빈칸은 기존 코어ID·코어명을 유지합니다. 빈 행도 번호를 차지하므로 다음 행이 당겨지지 않습니다. 삭제는 '선택 코어삭제'에서 확인 후 실행하세요.",foreground='#8a4b08',padding=(8,0,8,6),wraplength=1120)
        notice.pack(fill='x');notice.bind('<Configure>',lambda e:notice.configure(wraplength=max(300,e.width-20)))
        table=ttk.Frame(self.identity_tab);table.pack(fill="both",expand=True,padx=8)
        table.columnconfigure(0,weight=1);table.rowconfigure(0,weight=1)
        self.identity_tree=workflow.SortableTreeview(table,before_sort=self.commit_identity_editor,editor_active=lambda:bool(self.identity_editor),columns=("number","core_id","detail"),show="headings",selectmode="browse")
        for c,l,w,a in (("number","번호",80,"center"),("core_id","코어ID",280,"w"),("detail","코어내역",650,"w")):
            self.identity_tree.heading(c,text=l);self.identity_tree.column(c,width=w,minwidth=280 if c=='detail' else w,stretch=c=='detail',anchor=a)
        y=ttk.Scrollbar(table,orient="vertical",command=self.identity_tree.yview);self.identity_tree.configure(yscrollcommand=y.set)
        self.identity_tree.grid(row=0,column=0,sticky='nsew');y.grid(row=0,column=1,sticky='ns')
        x=ttk.Scrollbar(table,orient='horizontal',command=self.identity_tree.xview);x.grid(row=1,column=0,columnspan=2,sticky='ew');self.identity_tree.configure(xscrollcommand=x.set)
        self.identity_actions=workflow.FlowToolbar(self.identity_tab);self.identity_actions.pack(side='bottom',fill='x')
        if workflow.completion_kind(self.store)=='after':
            self.move_identity_button=ttk.Button(self.identity_actions,text='코어 옮기기',command=self.move_core)
            self.identity_actions.add(self.move_identity_button)
        if workflow.field_slot_mode(self.store):
            self.route_identity_button=ttk.Button(self.identity_actions,text='연결 구간 전체 반영',command=self.review_route_identity)
            self.identity_actions.add(self.route_identity_button)
            notice.configure(text='수정하기: 이 케이블만 반영 / 연결 구간 전체 반영: 실제 연결된 케이블·RN 포트까지 검토 후 반영. 빈칸은 기존 값 유지.')
        for title,command in (
            ('수정하기',self.apply_identity_changes),('입력내용 되돌리기',self.reload_identity),
            ('코어내역 서로 바꾸기',self.swap_core_identities),('코어내역 전체복사',self.copy_details),
            ('선택 코어삭제 (Delete)',lambda:self.delete_core(self.identity_tree)),
            ('입력 실행취소',self.undo_identity_input),('입력 다시실행',lambda:self.undo_identity_input(redo=True)),
            ('도면 수정 이력',lambda:owning_app(self).open_history())):
            self.identity_actions.add(ttk.Button(self.identity_actions,text=title,command=command))
        table.pack_forget();table.pack(fill='both',expand=True,padx=8)
        self.identity_tree.bind("<Double-1>",self.begin_identity_edit)
        self.identity_tree.bind("<Return>",self.begin_identity_edit)
        self.identity_tree.bind("<ButtonPress-1>",self.remember_identity_cell,add="+")
        self.identity_tree.bind("<Control-v>",self.paste_identity_from_clipboard)
        self.identity_tree.bind("<Control-c>",self.copy_identity_cell)
        self.identity_tree.bind("<Shift-Insert>",self.paste_identity_from_clipboard)
        self.identity_tree.bind("<Delete>",lambda e:self.delete_core(self.identity_tree))
        self.identity_tree.bind('<<TreeviewSelect>>',lambda e:self.queue_core_trace(self.identity_tree),add='+')

    def queue_core_trace(self,tree=None):
        if not getattr(self,'_core_trace_enabled',False):return
        active=self.identity_tree if self.notebook.select()==str(self.identity_tab) else self.tree
        if tree is not None and tree is not active:return
        self.refresh_completion_reason(active)
        self._core_trace_tree=active
        if self._core_trace_job is not None:
            try:self.after_cancel(self._core_trace_job)
            except tk.TclError:pass
        self._core_trace_job=self.after_idle(self.run_core_trace)

    def run_core_trace(self):
        self._core_trace_job=None
        app=owning_app(self)
        if app is None or app.store is not self.store:return
        selected=self._core_trace_tree.selection() if self._core_trace_tree is not None else ()
        row=self.store.core(self.cable_key,int(selected[0])) if selected else None
        core_id=str(row['core_id'] or '').strip() if row else ''
        if not core_id:self.clear_core_trace();return
        key=(self.store.data_revision(),core_id,tuple(selected))
        if self._core_trace_key==key and getattr(app,'highlight_owner',None) is self:return
        context=self.store.trace_context()
        trace=self.store.trace_core_paths(core_id,context,slot=(self.cable_key,int(selected[0]))) if workflow.field_slot_mode(self.store) else None
        rows=trace['rows'] if trace else context['by_id'].get(core_id,())
        cables={r['cable_id'] for r in rows if r['cable_id'] in context['cables']}
        if not cables:self.clear_core_trace();return
        self._core_trace_key=key;app.start_highlight_blink(cables,owner=self,core_labels=core_path_number_labels(rows),core_rows=rows,core_slots=[(self.cable_key,int(selected[0]))])
        app.status.set(app.highlight_connection_model['summary']+' · 미접속 함체 안내를 더블클릭해 연결을 확인하세요.')

    def clear_core_trace(self):
        if self._core_trace_job is not None:
            try:self.after_cancel(self._core_trace_job)
            except tk.TclError:pass
            self._core_trace_job=None
        self._core_trace_key=None;app=owning_app(self)
        if app is not None and getattr(app,'highlight_owner',None) is self:app.stop_highlight_blink(clear=True)

    def close_core_trace(self,event):
        if event.widget is self:self.clear_core_trace()

    def focus_id(self):
        if getattr(self,"_focus_core_requested",False):return
        if not self.id_entry.winfo_exists():return
        self.id_entry.focus_force();self.id_entry.selection_range(0,"end");self.id_entry.icursor("end")

    def focus_core(self,index):
        if not self.tree.exists(str(index)):return
        self._focus_core_requested=True;self.notebook.select(self.status_tab)
        self.status_copy_column='core_id';self.tree.selection_set(str(index));self.tree.focus(str(index));self.tree.see(str(index));self.tree.focus_set();self.load_selected()
        self.lift()

    def status_choice_changed(self):
        """신설은 NEW번호를 즉시 보여 주고, 기설 복귀 시 자동 NEW번호를 비운다."""
        current=self.status_var.get();self.id_var.set(self.store.cable_id_for_status(current,self.id_var.get(),self.cable_key,self.previous_status));self.previous_status=current

    def center_on_parent(self):
        workflow.center_popup(self,self.parent)

    def space_save(self,event=None):
        focus=self.focus_get()
        # LOT 번호에 포함된 공백은 신규/기존 케이블 모두 그대로 입력한다.
        if focus is self.lot_entry:return None
        # 케이블ID 입력칸에서는 신규/기존 케이블 모두 Space를 저장키로 사용한다.
        if focus is not self.id_entry and self.cable_key and isinstance(focus,(tk.Entry,ttk.Entry,tk.Text)):return None
        self.save_header();return "break"

    def save_header(self):
        if not self.ensure_cable_editable(header=True):return
        spec=self.size_var.get().strip().upper()
        try:size=1 if spec=="드랍" else int(spec.replace("C",""))
        except ValueError:messagebox.showerror("규격 오류","기타 규격은 24C처럼 코어 수를 숫자로 입력하세요.",parent=self);return
        if spec!="드랍":spec=f"{size}C"
        if not self.cable_key:
            self.cable_key=self.store.add_cable(*self.create_nodes,self.id_var.get(),spec,self.status_var.get(),lot_no=self.lot_var.get())
            self.parent.refresh();self.destroy();return
        old=self.store.cable(self.cable_key)
        if size!=old["size"] and size<old["size"]:
            if not messagebox.askyesno("규격 축소",f"{old['size']}C에서 {size}C로 줄이면 뒤 코어와 연결이 삭제됩니다. 계속할까요?",parent=self):return
        try:
            with self.store.action("케이블 정보 변경"):
                self.store.resize_cable(self.cable_key,spec)
                cable_name=self.store.cable_id_for_status(self.status_var.get(),self.id_var.get(),self.cable_key,old["status"])
                self.store.conn.execute("UPDATE cables SET cable_id=?,status=? WHERE id=?",(cable_name,self.status_var.get(),self.cable_key))
                self.store.set_cable_lot_no(self.cable_key,self.lot_var.get())
        except ValueError as error:messagebox.showwarning('케이블 수정 안 됨',str(error),parent=self);return
        self.lot_var.set(cable_lot_no(self.store.cable(self.cable_key)))
        self.id_var.set(cable_name);self.previous_status=self.status_var.get()
        self._header_original=self.header_input_snapshot()
        self.reload();self.parent.refresh();self.info.set("케이블 정보를 저장했습니다.")

    def reload(self,keep=None):
        self.reload_status(keep);self.reload_identity(keep)

    def after_exception_release(self):
        """V175: show the core's new status after 「예외 해제 후 배정」."""
        self.reload()

    def reload_status(self,keep=None):
        if not self.cable_key:return
        view=self.tree.yview()[0] if self.tree.get_children() else 0
        if keep is None and self.tree.selection():keep=int(self.tree.selection()[0])
        self.tree.delete(*self.tree.get_children())
        for r in self.store.cores(self.cable_key):
            sig=core_row_signal_text(r)
            self.tree.insert("","end",iid=str(r["core_index"]),values=(self.status_annotation(r),sig,r["core_index"],display_core_id(r["core_id"]),r["detail"]),tags=(self.core_tag(r),core_signal_tag(r)))
        configure_core_tags(self.tree)
        if keep and self.tree.exists(str(keep)):self.tree.selection_set(str(keep));self.tree.see(str(keep))
        self.tree.yview_moveto(view)
        self.load_selected()

    def reload_identity(self,keep=None):
        if not self.cable_key:return
        self.cancel_identity_editor()
        self.identity_undo_stack=[];self.identity_redo_stack=[]
        self.identity_loaded_revision=self.store.data_revision();self.identity_loaded_generation=getattr(self.store,'_view_generation',0)
        view=self.identity_tree.yview()[0] if self.identity_tree.get_children() else 0
        if keep is None and self.identity_tree.selection():keep=int(self.identity_tree.selection()[0])
        self.identity_tree.delete(*self.identity_tree.get_children());self.identity_original={}
        for r in self.store.cores(self.cable_key):
            idx=int(r["core_index"]);raw_id=str(r["core_id"] or "");detail=str(r["detail"] or "")
            self.identity_original[idx]=(raw_id,detail)
            self.identity_tree.insert("","end",iid=str(idx),values=(idx,display_core_id(raw_id),detail),tags=(self.core_tag(r),))
        configure_core_tags(self.identity_tree)
        if keep and self.identity_tree.exists(str(keep)):self.identity_tree.selection_set(str(keep));self.identity_tree.see(str(keep))
        self.identity_tree.yview_moveto(view)

    def refresh_shared_rows(self):
        if not self.cable_key or 'tree' not in self.__dict__:return
        stamp=(self.store.data_revision(),self.store.conn.total_changes)
        if getattr(self,'_shared_rows_stamp',None)==stamp:return
        self._shared_rows_stamp=stamp
        cable=self.store.cable(self.cable_key)
        if cable:self.title('케이블 '+str(cable['cable_id'] or cable['spec'] or self.cable_key)+' 내역')
        for row in self.store.cores(self.cable_key):
            iid=str(row['core_index'])
            if self.tree.exists(iid):
                self.tree.item(iid,values=(self.status_annotation(row),core_row_signal_text(row),row['core_index'],display_core_id(row['core_id']),row['detail']),tags=(self.core_tag(row),core_signal_tag(row)))
            # Recolor the draft without replacing typed IDs/names or its undo stack.
            if 'identity_tree' in self.__dict__ and self.identity_tree.exists(iid):
                values=self.identity_tree.item(iid,'values');old_id,old_detail=self.identity_original.get(int(iid),('',''))
                editing=self.identity_editor and self.identity_edit_item==iid
                if not editing and tuple(map(str,values[1:3]))==(display_core_id(old_id),old_detail):
                    self.identity_tree.item(iid,values=(row['core_index'],display_core_id(row['core_id']),row['detail']))
                    self.identity_original[int(iid)]=(str(row['core_id'] or ''),str(row['detail'] or ''))
                self.identity_tree.item(iid,tags=(self.core_tag(row),))
        if 'copy_value' in self.__dict__:self.copy_value.set(self.selected_cell_value() or '')
        self.refresh_completion_reason()
        if getattr(owning_app(self),'highlight_owner',None) is self:self.queue_core_trace()

    def refresh_completion_reason(self,tree=None):
        if not self.cable_key or not hasattr(self,'completion_reason_label'):return
        active=tree or (self.identity_tree if self.notebook.select()==str(self.identity_tab) else self.tree)
        selected=active.selection()
        if not selected:
            self.completion_title.set('선택 코어 · 미완료 이유');self.completion_reason.set('코어를 선택하세요.')
            self.completion_signal.set('');self.completion_signal_detail.set('')
            self.completion_reason_label.configure(foreground='#666666');return
        index=int(selected[0]);status,reason=workflow.core_completion_brief(self.store,(self.cable_key,index))
        self.completion_title.set(f'{index} · {status}')
        self.completion_reason.set(reason or status)
        self.completion_reason_label.configure(foreground='#c62828' if status in ('미완료','연결 오류') else '#1769aa')
        signal=workflow.core_id_signal_summary(self.store,(self.cable_key,index))
        self.completion_signal.set(('전체 신호: ' if signal['core_id'] else '선택 번호 신호: ')+signal['label'])
        self.completion_signal_detail.set(signal['detail'])
        self.completion_signal_label.configure(foreground={'on':'#d00000','off':'#475569','mixed':'#c62828','error':'#c62828','exception':'#1769aa'}.get(signal['signal'],'#666666'))

    def core_tag(self,row):
        """V167: 오류·미완료 cores get a yellow row; 예외코어 never does."""
        base=workflow.field_slot_tag(self.store,row,core_row_tag(row));slot=(row['cable_id'],int(row['core_index']))
        if base in ('empty','cancel') or workflow.core_exception_complete(self.store,slot) or workflow.is_exception(row):return base
        status,_=workflow.core_completion_brief(self.store,slot)
        return 'core_issue' if base=='error' or status in ('미완료','연결 오류') or slot in self.store.error_core_slots() else base

    def status_annotation(self,row):
        text=workflow.core_status_text(self.store,row)
        status,_=workflow.core_completion_brief(self.store,(row['cable_id'],int(row['core_index'])))
        marker={'미완료':'[미완료코어]','연결 오류':'[연결 오류]'}.get(status)
        # V167: 미완료 and 오류 together read as one 오류코어.
        if marker and (row['cable_id'],int(row['core_index'])) in self.store.error_core_slots():marker='[오류코어]'
        if marker and marker not in text:text=marker+' '+text
        return text.strip()

    def open_offmap_links(self):
        active=self.identity_tree if self.notebook.select()==str(self.identity_tab) else self.tree
        selected=active.selection()
        if not selected:messagebox.showinfo('도면 밖 연결','코어를 먼저 선택하세요.',parent=self);return
        row=self.store.core(self.cable_key,int(selected[0]))
        cid=str((row['core_id'] if row else '') or '').strip()
        if not cid:messagebox.showinfo('도면 밖 연결','코어ID가 있는 코어만 표시할 수 있습니다.',parent=self);return
        workflow.open_offmap_links(self,self.store,cid)

    def show_completion_locations(self):
        active=self.identity_tree if self.notebook.select()==str(self.identity_tab) else self.tree
        selected=active.selection()
        if not selected:return
        slot=(self.cable_key,int(selected[0]));status,_=workflow.core_completion_brief(self.store,slot)
        messagebox.showinfo(f'{slot[1]}번 · {status}',workflow.core_completion_locations(self.store,slot),parent=self)

    def remember_status_cell(self,event):
        row=self.tree.identify_row(event.y);col=self.tree.identify_column(event.x)
        columns=('annotations','signal','number','core_id','detail')
        if row and col in ('#1','#2','#3','#4','#5'):
            self.status_copy_column=columns[int(col[1:])-1]
            # V163: Shift/Ctrl+click is left to the Treeview for range/multi selection.
            if getattr(event,'state',0)&0x0005 and getattr(event,'num',1)==1:return
            if event.num==3 and row in self.tree.selection():self.load_selected();return
            self.tree.selection_set(row);self.tree.focus(row);self.load_selected();self.queue_core_trace(self.tree)

    def selected_phase_core_ids(self):
        ids=[]
        for item in self.tree.selection():
            row=self.store.core(self.cable_key,int(item)) if self.cable_key else None
            core_id=str(row['core_id'] or '').strip() if row else ''
            if core_id and core_id not in ids:ids.append(core_id)
        return ids

    def build_phase_menu(self):
        menu=tk.Menu(self,tearoff=False);names=workflow.work_phase_names(self.store);ids=self.selected_phase_core_ids()
        cores=tk.Menu(menu,tearoff=False);own=set()
        if len(ids)==1:
            source,current=workflow.core_phase_source(self.store,ids[0])
            if source=='core':own=set(current)
        for name in names:cores.add_command(label=("✓ " if name in own else "   ")+name,command=lambda value=name:self.apply_core_phase(value))
        cores.add_separator();cores.add_command(label='개별 지정 해제 (케이블 차수 따름)',command=lambda:self.apply_core_phase(''))
        menu.add_cascade(label=f'선택 코어 {len(ids)}개 → 차수 (경로 전체 표시)' if ids else '선택 코어 → 차수 (코어ID 있는 코어를 먼저 선택)',menu=cores,state='normal' if ids else 'disabled')
        whole=tk.Menu(menu,tearoff=False);current=workflow.cable_phase_name(self.store,self.cable_key) if self.cable_key else ''
        for name in ['']+names:whole.add_command(label=("✓ " if name==current else "   ")+(name or '차수 없음'),command=lambda value=name:self.apply_cable_phase(value))
        menu.add_cascade(label='이 케이블 전체 코어 → 차수',menu=whole,state='normal' if self.cable_key else 'disabled')
        menu.add_separator();menu.add_command(label='작업차수 관리 (추가·이름 변경)…',command=lambda:workflow.PhaseDialog(self.parent))
        self._phase_menu=menu;self._phase_core_menu=cores;self._phase_cable_menu=whole
        return menu

    def show_phase_menu(self,pointer=False):
        menu=self.build_phase_menu()
        if pointer:x,y=self.winfo_pointerx(),self.winfo_pointery()
        else:x,y=self.phase_button.winfo_rootx(),self.phase_button.winfo_rooty()+self.phase_button.winfo_height()
        try:menu.tk_popup(x,y)
        finally:menu.grab_release()

    def after_phase_change(self,message):
        self.parent._work_report_key=None
        self.refresh_shared_rows();self.parent.refresh();self.info.set(message)

    def apply_core_phase(self,name):
        ids=self.selected_phase_core_ids()
        if not ids:messagebox.showinfo('코어 선택','코어ID 또는 임시코어가 있는 코어를 먼저 선택하세요.',parent=self);return
        try:count=workflow.set_core_phase(self.store,ids,name)
        except Exception as exc:messagebox.showerror('작업차수',str(exc),parent=self);return
        self.after_phase_change(f'코어 {count}개를 {name}(으)로 지정했습니다. 같은 코어가 지나가는 모든 케이블에 표시됩니다.' if name else f'코어 {count}개의 개별 차수를 지웠습니다. 이제 케이블 차수를 따릅니다.')

    def apply_cable_phase(self,name):
        if not self.cable_key:return
        try:workflow.set_cable_phase(self.store,[self.cable_key],name)
        except Exception as exc:messagebox.showerror('작업차수',str(exc),parent=self);return
        self.after_phase_change(f'이 케이블을 {name}(으)로 지정했습니다. 안의 코어 전체가 {name}(으)로 표시됩니다.' if name else '이 케이블의 작업차수를 지웠습니다.')

    def status_context_menu(self,event):
        if not self.tree.identify_row(event.y):return 'break'
        self.remember_status_cell(event)
        try:self.status_menu.tk_popup(event.x_root,event.y_root)
        finally:self.status_menu.grab_release()
        return 'break'

    def selected_cell_value(self,column=None):
        if not self.tree.selection():return None
        columns=('annotations','signal','number','core_id','detail');col=column or self.status_copy_column
        values=self.tree.item(self.tree.selection()[0],'values')
        return str(values[columns.index(col)]) if col in columns and len(values)==len(columns) else None

    def copy_status_cell(self,event=None,column=None):
        value=self.selected_cell_value(column)
        if value is None:self.info.set('복사할 코어의 칸을 먼저 클릭하세요.');return 'break'
        self.clipboard_clear();self.clipboard_append(value)
        self.info.set('선택 칸을 복사했습니다. Excel이나 입력창에서 Ctrl+V로 붙여넣으세요.');return 'break'

    def load_selected(self,event=None):
        self.refresh_completion_reason()
        value=self.selected_cell_value();self.copy_value.set(value if value is not None else '')
        names={'annotations':'상태','signal':'신호','number':'번호','core_id':'코어ID','detail':'코어내역'}
        self.copy_field.set('선택 칸 · '+names[self.status_copy_column])
        selected=self.tree.selection()
        if not selected:
            if hasattr(self,'signal_apply_button'):self.signal_apply_button.configure(text='신호 적용')
            return
        r=self.store.core(self.cable_key,int(selected[0]))
        for var,value in zip(self.edit_vars,(status_label(r["status1"]),status_label(r["status2"]),signal_label(r["signal"]))):var.set(value)
        if len(selected)>1:
            # Several numbers: show their common signal, or blank when mixed.
            rows=[self.store.core(self.cable_key,int(i)) for i in selected]
            labels={signal_label(x["signal"]) for x in rows if x}
            self.edit_vars[2].set(labels.pop() if len(labels)==1 else '')
        self.signal_apply_button.configure(text=f'선택 {len(selected)}개 신호 적용' if len(selected)>1 else '신호 적용')
        self._signal_original=self.edit_vars[2].get()

    def edit_annotations(self):
        if not self.ensure_cable_editable():return
        if not self.tree.selection():return
        idx=int(self.tree.selection()[0]);row=self.store.core(self.cable_key,idx)
        if not row['core_id']:messagebox.showinfo('코어 선택','코어ID 또는 임시코어를 먼저 배정하세요.',parent=self);return
        workflow.AnnotationDialog(self,self.store,(self.cable_key,idx),lambda:(self.refresh_shared_rows(),self.parent.refresh()))

    def apply_core(self):
        if not self.ensure_cable_editable():return
        if not self.tree.selection():messagebox.showinfo("선택 필요","수정할 코어 번호를 먼저 선택하세요.",parent=self);return
        selected=[int(i) for i in self.tree.selection()]
        if len(selected)>1:return self.apply_signal_batch(selected)
        idx=selected[0];r=self.store.core(self.cable_key,idx)
        values=[r["core_id"],r["detail"],r['status1'],r['status2'],SIGNAL_FROM_LABEL.get(self.edit_vars[2].get(),self.edit_vars[2].get())]
        if str(values[4] or '')!=str(r['signal'] or '') and not confirm_signal_mix(self,self.store,[(self.cable_key,idx)],values[4]):return
        try:
            # V166: an empty number keeps only its signal (no temporary ID, splices stay).
            if not str(r["core_id"] or "").strip():
                if str(values[4] or '')!=str(r['signal'] or ''):self.store.set_empty_core_signal((self.cable_key,idx),values[4])
            else:self.store.update_core(self.cable_key,idx,values)
        except ValueError as exc:messagebox.showerror("상태 변경 안 됨",str(exc),parent=self);return
        self.reload(idx);self.parent.refresh();self.info.set(f"{idx}번 상태·신호를 수정했습니다.")

    def apply_signal_batch(self,selected):
        label=self.edit_vars[2].get()
        if not label:messagebox.showinfo("신호 선택","적용할 신호를 먼저 고르세요.",parent=self);return
        signal=SIGNAL_FROM_LABEL.get(label,label)
        targets=[(self.cable_key,i) for i in selected if str((self.store.core(self.cable_key,i) or {'signal':signal})['signal'] or '')!=signal]
        if targets and not confirm_signal_mix(self,self.store,targets,signal):return
        try:changed,skipped,errors=self.store.set_cores_signal(self.cable_key,selected,signal)
        except ValueError as exc:messagebox.showerror("상태 변경 안 됨",str(exc),parent=self);return
        view=self.tree.yview()[0]
        self.reload(selected[0])
        keep=[str(i) for i in selected if self.tree.exists(str(i))]
        if keep:self.tree.selection_set(keep)
        self.tree.yview_moveto(view);self.load_selected();self.parent.refresh()
        text=f"선택 {len(selected)}개 중 {len(changed)}개 신호를 {label}(으)로 바꿨습니다."
        if skipped:text+=f" 이미 같은 신호 {len(skipped)}개는 그대로입니다."
        if errors:
            text+=f" {len(errors)}개는 바뀌지 않았습니다."
            messagebox.showwarning("일부 코어 미적용","\n".join(f"{i}번: {e}" for i,e in errors[:20]),parent=self)
        self.info.set(text+(" (실행취소 한 번으로 모두 되돌림)" if changed else ""))

    def delete_core(self,tree=None):
        if not self.ensure_cable_editable():return 'break'
        tree=tree or (self.identity_tree if self.notebook.select()==str(self.identity_tab) else self.tree)
        if tree is self.identity_tree:self.commit_identity_editor()
        if not tree.selection():
            messagebox.showinfo("코어삭제","삭제할 코어 하나를 먼저 선택하세요.",parent=self);return "break"
        index=int(tree.selection()[0]);row=self.store.core(self.cable_key,index)
        if not row:return "break"
        cable=self.store.cable(self.cable_key);left=self.store.node(cable["n1id"]);right=self.store.node(cable["n2id"])
        cable_name=clean_cable_id(cable["cable_id"]) or (cable["spec"] or f'{cable["size"]}C')
        core_id=display_core_id(row["core_id"]) or "없음";detail=str(row["detail"] or "").strip() or "없음"
        linked=bool(self.store.conn.execute("SELECT 1 FROM splices WHERE (cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?) LIMIT 1",(self.cable_key,index,self.cable_key,index)).fetchone())
        question=f'{left["name"] if left else "?"} ↔ {right["name"] if right else "?"} / {cable_name}\n{index}번 코어를 삭제하시겠습니까?\n\n코어ID: {core_id}\n코어내역: {detail}'
        if linked:question+="\n\n이 코어가 참여한 접속도 함께 해제됩니다.\n다른 케이블의 코어정보는 지워지지 않습니다."
        if not messagebox.askyesno("코어삭제 확인",question,parent=self):return "break"
        if not self.store.delete_core_assignment(self.cable_key,index):
            messagebox.showinfo("코어삭제","이미 비어 있는 코어입니다.",parent=self);return "break"
        self.reload_status(index)
        if self.identity_tree.exists(str(index)):self.identity_tree.item(str(index),values=(index,"",""),tags=("empty",));self.identity_tree.selection_set(str(index));self.identity_tree.see(str(index))
        self.identity_original[index]=("","")
        self.identity_loaded_revision=self.store.data_revision()
        for var in self.edit_vars:var.set("")
        self.parent.refresh();self.info.set(f"{index}번 코어를 삭제했습니다. 다른 케이블의 코어정보는 유지됩니다.")
        return "break"

    def begin_identity_edit(self,event=None):
        if not self.identity_tree.selection() and (not event or not getattr(event,"y",None)):return "break"
        row=self.identity_tree.identify_row(event.y) if event and getattr(event,"y",None) else self.identity_tree.selection()[0]
        col=self.identity_tree.identify_column(event.x) if event and getattr(event,"x",None) else "#2"
        return self.open_identity_editor(row,col)

    def copy_identity_cell(self,event=None):
        selected=self.identity_tree.selection()
        if selected:
            values=self.identity_tree.item(selected[0],'values');index=2 if self.identity_active_col=='#3' else 1
            self.clipboard_clear();self.clipboard_append(str(values[index]))
        return 'break'

    def remember_identity_cell(self,event):
        row=self.identity_tree.identify_row(event.y);col=self.identity_tree.identify_column(event.x)
        if row:
            self.identity_tree.selection_set(row);self.identity_tree.focus(row);self.queue_core_trace(self.identity_tree)
        if col in ("#2","#3"):self.identity_active_col=col

    def open_identity_editor(self,row,col):
        if not self.ensure_cable_editable():return 'break'
        if not row or col not in ("#2","#3"):return "break"
        self.commit_identity_editor()
        self.identity_tree.selection_set(row);self.identity_tree.see(row)
        bbox=self.identity_tree.bbox(row,col)
        if not bbox:return "break"
        values=list(self.identity_tree.item(row,"values"));value=values[1 if col=="#2" else 2]
        editor=ttk.Entry(self.identity_tree);editor.insert(0,value);editor.select_range(0,"end")
        editor.place(x=bbox[0],y=bbox[1],width=bbox[2],height=bbox[3])
        self.identity_editor=editor;self.identity_edit_item=row;self.identity_edit_col=col
        self.identity_active_col=col
        editor.bind("<Return>",lambda e:self.commit_identity_editor())
        editor.bind("<Tab>",self.identity_editor_tab)
        editor.bind("<Escape>",lambda e:self.cancel_identity_editor())
        editor.bind("<FocusOut>",lambda e:self.commit_identity_editor())
        editor.bind("<Control-a>",lambda e:select_entry_text(editor))
        editor.bind("<Control-v>",self.paste_identity_from_clipboard)
        editor.bind("<Shift-Insert>",self.paste_identity_from_clipboard)
        editor.focus_force();return "break"

    def identity_editor_tab(self,event=None):
        row=self.identity_edit_item;col=self.identity_edit_col;self.commit_identity_editor()
        target_row,target_col=row,"#3"
        if col=="#3":
            target_row=self.identity_tree.next(row);target_col="#2"
        if target_row:self.after_idle(lambda r=target_row,c=target_col:self.open_identity_editor(r,c))
        return "break"

    def commit_identity_editor(self):
        editor=self.identity_editor
        if not editor:return "break"
        row,col=self.identity_edit_item,self.identity_edit_col
        try:value=editor.get()
        except tk.TclError:value=""
        self.identity_editor=None
        try:editor.destroy()
        except tk.TclError:pass
        if self.identity_tree.exists(row):
            values=list(self.identity_tree.item(row,"values"));index=1 if col=='#2' else 2
            if str(values[index])!=value:self.record_identity_input()
            values[index]=value
            self.identity_tree.item(row,values=values)
        return "break"

    def identity_input_snapshot(self):
        return {i:tuple(self.identity_tree.item(i,'values')) for i in self.identity_tree.get_children()}

    def record_identity_input(self):
        snapshot=self.identity_input_snapshot()
        if not self.identity_undo_stack or self.identity_undo_stack[-1]!=snapshot:self.identity_undo_stack.append(snapshot)
        self.identity_undo_stack=self.identity_undo_stack[-100:];self.identity_redo_stack=[]

    def undo_identity_input(self,redo=False,saved_fallback=False):
        self.commit_identity_editor()
        source=self.identity_redo_stack if redo else self.identity_undo_stack
        dest=self.identity_undo_stack if redo else self.identity_redo_stack
        if source:
            dest.append(self.identity_input_snapshot());snapshot=source.pop()
            for i,values in snapshot.items():
                if self.identity_tree.exists(i):self.identity_tree.item(i,values=values)
            self.info.set('수정표 입력 다시실행 · 아직 저장 전' if redo else '수정표 입력 실행취소 · 저장된 도면은 유지됩니다.')
        elif saved_fallback:
            app=owning_app(self)
            if app:app.change_history(redo=redo,editor=self)
        else:self.info.set('다시 실행할 수정표 입력이 없습니다.' if redo else '되돌릴 수정표 입력이 없습니다. 저장된 변경은 도면 수정 이력에서 확인하세요.')
        return 'break'

    def cancel_identity_editor(self):
        editor=self.identity_editor;self.identity_editor=None
        if editor:
            try:editor.destroy()
            except tk.TclError:pass
        return "break"

    def paste_identity_from_clipboard(self,event=None):
        if not self.ensure_cable_editable():return 'break'
        try:raw=self.clipboard_get().replace("\r\n","\n").replace("\r","\n")
        except tk.TclError:return "break"
        edit_row=self.identity_edit_item if self.identity_editor else None
        edit_col=self.identity_edit_col if self.identity_editor else None
        if self.identity_editor and "\t" not in raw and "\n" not in raw:return None
        start=int(edit_row) if edit_row else (int(self.identity_tree.selection()[0]) if self.identity_tree.selection() else 1)
        start_col=edit_col or self.identity_active_col
        try:rows,preserved=parse_core_identity_paste(raw,start,start_col,{int(i) for i in self.identity_tree.get_children()})
        except ValueError as error:messagebox.showwarning('Excel 붙여넣기 확인',str(error),parent=self);return 'break'
        if self.identity_editor:self.commit_identity_editor()
        restored_sort=self.identity_tree.reset_sort() if len(rows)>1 else False
        written=0;last=start
        if rows:self.record_identity_input()
        for idx,new_id,new_detail in rows:
            values=list(self.identity_tree.item(str(idx),"values"))
            if new_id is not None:values[1]=new_id
            if new_detail is not None:values[2]=new_detail
            self.identity_tree.item(str(idx),values=values);written+=1;last=idx
        if self.identity_tree.exists(str(last)):
            self.identity_tree.selection_set(str(last));self.identity_tree.see(str(last))
        self.info.set(("기본 코어번호 순서로 돌아왔습니다. " if restored_sort else "")+f"입력 있는 {written}개 행을 수정표에 반영했습니다. 빈칸 {preserved}개는 기존 값 유지 · 아직 저장 전입니다.")
        return "break"

    def route_identity_draft(self):
        self.commit_identity_editor()
        return tuple((item,tuple(self.identity_tree.item(item,'values'))) for item in sorted(self.identity_tree.get_children(),key=int))

    def review_route_identity(self):
        if not self.ensure_cable_editable():return
        draft=self.route_identity_draft()
        try:
            if self.identity_loaded_revision!=self.store.data_revision() or self.identity_loaded_generation!=self.store._view_generation:
                raise ValueError('수정표를 연 뒤 도면이 변경되었습니다. 입력을 보관하고 새로 불러온 뒤 다시 수정하세요.')
            if self.edit_vars[2].get()!=getattr(self,'_signal_original',self.edit_vars[2].get()):
                raise ValueError('입력 중인 신호를 먼저 적용하세요. 코어 입력은 유지됩니다.')
            changes=[(int(item),normalize_core_id_input(values[1]),str(values[2] or '').strip()) for item,values in draft]
            preview=workflow.field_route_identity_preview(self.store,self.cable_key,changes)
            if not confirm_temporary_identity(self,self.store,self.cable_key,[(i,v) for i,v,_ in preview['changes']]):return
            previous=getattr(self,'_route_identity_dialog',None)
            if previous is not None and previous.winfo_exists():previous.destroy()
            self._route_identity_dialog=workflow.FieldRouteIdentityDialog(self,preview,draft)
            return self._route_identity_dialog
        except (ValueError,sqlite3.Error,OSError) as error:
            messagebox.showerror('연결 구간 반영',str(error),parent=self)

    def apply_identity_changes(self):
        if not self.ensure_cable_editable():return 'break'
        self.commit_identity_editor();changes=[]
        if self.identity_loaded_revision!=self.store.data_revision() or self.identity_loaded_generation!=getattr(self.store,'_view_generation',0):
            messagebox.showwarning('수정표 새로고침 필요','수정표를 연 뒤 도면이 변경됐습니다. 현재 입력을 필요한 곳에 보관한 다음 입력내용 되돌리기로 최신 내용을 불러와 다시 입력하세요.',parent=self);return
        for item in self.identity_tree.get_children():
            idx=int(item);values=self.identity_tree.item(item,"values")
            original_id,original_detail=self.identity_original.get(idx,('',''))
            new_id=normalize_core_id_input(values[1]) or original_id;new_detail=str(values[2] or "").strip() or original_detail
            if (normalize_core_id_input(original_id),str(original_detail).strip())!=(normalize_core_id_input(new_id),str(new_detail).strip()):changes.append((idx,new_id,new_detail))
        if not changes:
            self.reload_identity()
            messagebox.showinfo("수정할 내용 없음","빈칸은 기존 값을 유지합니다. 변경된 코어ID 또는 코어내역이 없습니다.",parent=self);return
        if not confirm_temporary_identity(self,self.store,self.cable_key,[(idx,new_id) for idx,new_id,_ in changes]):return
        result=workflow.run_bulk(self,self.store,'apply_core_identity_changes',(self.cable_key,changes))
        if result is None:return
        applied,unchanged,errors=result
        keep=changes[-1][0];self.reload(keep);self.parent.refresh()
        # V176: a typed real ID that meets the same ID's free end at an enclosure → offer the join.
        joined=workflow.offer_same_id_join(self,self.store,{new_id for idx,new_id,_ in changes if idx in applied})
        if joined:self.reload(keep);self.parent.refresh()
        if errors:
            details="\n".join(f"{idx}번: {reason}" for idx,reason in errors[:30])
            extra=f"\n외 {len(errors)-30}건" if len(errors)>30 else ""
            messagebox.showwarning("일부 코어 수정 안 됨",f"정상 수정: {len(applied)}개\n수정 안 됨·오류코어 표시: {len(errors)}개\n\n{details}{extra}",parent=self)
            self.info.set(f"정상 {len(applied)}개 · 수정 안 됨/오류코어 {len(errors)}개")
        else:
            if not joined:messagebox.showinfo("수정 완료",f"코어ID·코어내역 {len(applied)}개를 수정했습니다.",parent=self)
            self.info.set(f"코어ID·코어내역 {len(applied)}개 수정 완료"+(' · '+joined if joined else ''))

    def assign_noinfo(self):
        if not self.ensure_cable_editable():return 'break'
        self.commit_identity_editor()
        if not self.identity_tree.selection():messagebox.showinfo("선택 필요","내역없음 번호를 넣을 행을 선택하세요.",parent=self);return
        self.record_identity_input()
        existing=[]
        for r in self.store.all_core_rows():
            value=str(r["core_id"] or "").replace(" ","")
            if value.startswith("내역없음"):
                try:existing.append(int(value[4:]))
                except ValueError:pass
        item=self.identity_tree.selection()[0];values=list(self.identity_tree.item(item,"values"))
        values[1]=f"내역없음{max(existing,default=0)+1}";values[2]="";self.identity_tree.item(item,values=values)
        self.info.set(f"{item}번에 {values[1]}을 입력했습니다. '수정하기'를 눌러 반영하세요.")

    def open_manual_allocation(self,on_map=False):
        app=owning_app(self)
        if app is None:return
        tree=self.identity_tree if self.notebook.select()==str(self.identity_tab) else self.tree
        if not tree.selection():messagebox.showinfo('코어분배','배분할 코어번호를 먼저 선택하세요.',parent=self);return
        if self.pending_edits():
            messagebox.showinfo('저장 전 입력 있음','케이블·코어의 입력을 먼저 저장하거나 되돌린 뒤 코어분배를 여세요. 입력 내용은 유지됩니다.',parent=self);return
        try:
            if app.store is not self.store or self._generation!=getattr(self.store,'_view_generation',0):raise ValueError('열린 도면이 바뀌었습니다. 케이블을 다시 여세요.')
            workflow.AfterPlanner(app).require_after()
            source=(self.cable_key,int(tree.selection()[0]))
            panel=getattr(app,'_map_allocation_panel',None)
            if panel is not None and panel.winfo_exists():
                if on_map and panel.service.source==source:
                    self.withdraw();panel.deiconify();panel.lift();panel.matrix.focus_set();return panel
                if not panel.close_requested():return
            if on_map:
                existing=getattr(app,'_manual_allocation_window',None)
                if existing is not None and existing.winfo_exists():existing.destroy()
                return workflow.open_allowing_excluded(self,'도면에서 코어배정',lambda allow:workflow.MapCoreAllocationPanel(app,source,editor=self,allow_excluded=allow))
            existing=getattr(app,'_manual_allocation_window',None)
            if existing is not None and existing.winfo_exists():
                if existing.service.source==source:existing.deiconify();existing.lift();return existing
                existing.destroy()
            dialog=workflow.open_allowing_excluded(self,'코어분배',lambda allow:workflow.ManualCoreAllocationDialog(app,source,editor=self,allow_excluded=allow))
            if dialog is not None:app._manual_allocation_window=dialog
            return dialog
        except (ValueError,sqlite3.Error,OSError) as error:messagebox.showwarning('코어분배',str(error),parent=self)

    def move_core(self):
        if not self.ensure_cable_editable():return
        tree=self.identity_tree if self.notebook.select()==str(self.identity_tab) else self.tree
        if not tree.selection():
            messagebox.showinfo('코어 옮기기','먼저 옮길 코어를 선택하세요.',parent=self);return
        if set(self.pending_edits())&{'코어ID·코어명 수정표','선택 코어 신호'}:
            messagebox.showinfo('저장 전 입력 있음','코어ID·내역 또는 신호 입력을 먼저 적용한 뒤 옮기세요. 현재 입력은 유지됩니다.',parent=self);return
        first=int(tree.selection()[0])
        second=simpledialog.askinteger('코어 옮기기',f'{first}번 코어를 옮길 빈 번호를 입력하세요.\n코어정보와 양쪽 접속이 함께 이동합니다.',parent=self,minvalue=1,maxvalue=self.store.cable(self.cable_key)['size'])
        if second is None:return
        try:
            preview=self.store.preview_core_move(self.cable_key,first,second);values=preview['before'][0]
            text=f'{first}번 → {second}번\n코어ID: {display_core_id(values[0])}\n코어내역: {values[1]}\n\n신호·상태와 양쪽 함체의 접속을 함께 옮깁니다.\n{first}번은 빈 코어가 됩니다.'
            for row in preview['splices']:
                peer,index=(row['cable2_id'],row['core2_index']) if row['cable1_id']==self.cable_key else (row['cable1_id'],row['core1_index'])
                node=self.store.node(row['node_id'])
                text+=f"\n{node['name'] if node else '삭제된 함체'}: {first}번 → {second}번 · 상대 {self.store._slot_title(peer,index)}"
            if not messagebox.askyesno('코어 옮기기 확인',text,parent=self):return
            self.store.commit_core_move(preview)
        except (ValueError,sqlite3.Error,OSError) as error:
            messagebox.showerror('옮기지 않음',str(error),parent=self);return
        self.reload(second);self.parent.refresh();self.queue_core_trace(tree)
        self.info.set(f'{first}번 → {second}번 코어정보·양쪽 접속 이동 완료 · Ctrl+Z로 실행취소')

    def swap_core_identities(self):
        if not self.ensure_cable_editable():return
        tree=self.identity_tree if self.notebook.select()==str(self.identity_tab) else self.tree
        if not tree.selection():
            messagebox.showinfo('코어내역 교환','먼저 교환할 코어를 선택하세요.',parent=self);return
        if '코어ID·코어명 수정표' in self.pending_edits():
            messagebox.showinfo('저장 전 입력 있음','수정표의 입력을 먼저 수정하기로 반영하거나 되돌린 뒤 교환하세요. 현재 입력은 유지됩니다.',parent=self);return
        first=int(tree.selection()[0])
        second=simpledialog.askinteger('코어내역 서로 바꾸기',f'{first}와 코어ID·내역을 교환할 번호를 입력하세요.',parent=self,minvalue=1,maxvalue=self.store.cable(self.cable_key)['size'])
        if second is None:return
        try:
            preview=self.store.preview_core_identity_swap(self.cable_key,first,second)
            left,right=preview['before']
            def show(values):return (display_core_id(values[0]) or '(ID 없음)')+' / '+(values[1] or '(내역 없음)')
            text=f'{first}: {show(left)} → {show(right)}\n\n{second}: {show(right)} → {show(left)}\n\n코어ID와 코어내역만 서로 바꿉니다.\n번호별 신호·상태와 실제 접속은 유지됩니다.'
            if not messagebox.askyesno('코어내역 교환 확인',text,parent=self):return
            self.store.commit_core_identity_swap(preview)
        except (ValueError,sqlite3.Error,OSError) as error:
            messagebox.showerror('교환하지 않음',str(error),parent=self);return
        self.reload_identity(first);self.parent.refresh()
        self.info.set(f'{first} ↔ {second} 코어ID·코어내역 교환 완료 · Ctrl+Z로 실행취소')

    def swap_cores(self):
        if not self.ensure_cable_editable():return 'break'
        tree=self.identity_tree if self.notebook.select()==str(self.identity_tab) else self.tree
        if not tree.selection():messagebox.showinfo("코어순서","먼저 바꿀 첫 번째 코어를 선택하세요.",parent=self);return
        first=int(tree.selection()[0])
        second=simpledialog.askinteger("코어순서 바꾸기",f"{first}번과 바꿀 코어번호를 입력하세요.",parent=self,minvalue=1,maxvalue=self.store.cable(self.cable_key)["size"])
        if second is None:return
        if not messagebox.askyesno("코어순서 바꾸기",(f"{first}번과 {second}번의 코어ID·코어명을 서로 바꿀까요?\n현장 선번과 번호별 신호·상태는 유지합니다." if workflow.field_slot_mode(self.store) else f"{first}번과 {second}번의 코어정보 및 연결 위치를 서로 바꿀까요?"),parent=self):return
        try:self.store.swap_cable_cores(self.cable_key,first,second)
        except ValueError as exc:messagebox.showerror("바꾸지 않음",str(exc),parent=self);return
        self.reload(second);self.parent.refresh();self.info.set(f"코어순서 {first}번 ↔ {second}번을 바꿨습니다.")

    def copy_details(self):
        lines=["번호\t상태\t신호\t코어ID\t코어내역"]
        for r in self.store.cores(self.cable_key):
            lines.append("\t".join(map(str,(r["core_index"],self.status_annotation(r),workflow.core_copy_signal_label(self.store,r),display_core_id(r["core_id"]),r["detail"] or ""))))
        self.clipboard_clear();self.clipboard_append("\n".join(lines));self.update()
        self.info.set(f"{len(lines)-1}개 코어내역을 클립보드에 복사했습니다.")


class CableChoice(tk.Menubutton):
    """Compact read-only chooser with per-cable color and native menu keyboard controls."""
    def __init__(self,parent,variable,command):
        super().__init__(parent,text='케이블을 선택하세요',width=35,anchor='w',relief='sunken',bd=1,
                         indicatoron=True,bg='#ffffff',activebackground='#eef2f7',font=('Malgun Gothic',9),takefocus=True)
        self.variable=variable;self.command=command;self.choice_menu=tk.Menu(self,tearoff=False)
        self.configure(menu=self.choice_menu)

    def set_choices(self,values,counts):
        self.choice_menu.delete(0,'end')
        self.choice_menu.add_command(label='선택 해제',command=lambda:self.choose(''))
        self.choice_menu.add_separator()
        for label in values:
            count=counts.get(label,0);text=label+(f' · 배정필요 {count}' if count else '')
            self.choice_menu.add_command(label=text,command=lambda value=label:self.choose(value),
                background='#ffcdd2' if count else '#ffffff',foreground='#7f1d1d' if count else '#172033',
                activebackground='#f48fb1' if count else '#dbeafe',activeforeground='#172033')
        selected=self.variable.get();count=counts.get(selected,0)
        self.configure(text=selected or '케이블을 선택하세요',bg='#ffcdd2' if count else '#ffffff',
                       activebackground='#f48fb1' if count else '#eef2f7')

    def choose(self,value):
        self.variable.set(value);self.command()


class EnclosureLockControl(tk.Frame):
    def __init__(self,parent,command):
        super().__init__(parent,padx=8,pady=3,bd=1,relief='solid',cursor='hand2',takefocus=True)
        self.command=command;self.icon=tk.Canvas(self,width=48,height=44,highlightthickness=0)
        self.icon.pack(side='left');self.label=tk.Label(self,font=('Malgun Gothic',10,'bold'),justify='left');self.label.pack(side='left',padx=4)
        for widget in (self,self.icon,self.label):widget.bind('<Button-1>',self.activate)
        self.bind('<Return>',self.activate);self.bind('<space>',self.activate)
        self.set_locked(False)

    def activate(self,event=None):self.command();return 'break'

    def set_locked(self,locked):
        bg,ink=('#fff1f2','#be123c') if locked else ('#ecfdf5','#047857')
        self.configure(bg=bg);self.icon.configure(bg=bg);self.label.configure(bg=bg,fg=ink,
            text='함체 잠김\n클릭하여 잠금 해제' if locked else '수정 가능\n클릭하여 함체 잠금')
        self.icon.delete('all')
        x=14 if locked else 25
        self.icon.create_arc(x,4,x+18,28,start=0,extent=180,style='arc',outline=ink,width=4)
        self.icon.create_line(x,16,x,24,fill=ink,width=4)
        self.icon.create_line(x+18,16,x+18,23 if locked else 18,fill=ink,width=4)
        self.icon.create_rectangle(9,22,37,41,fill=ink,outline=ink,width=1)
        self.icon.create_oval(21,27,25,31,fill=bg,outline=bg);self.icon.create_line(23,30,23,35,fill=bg,width=2)


class NodeDialog(workflow.RememberedToplevel):
    def __init__(self,parent,store,node_id):
        super().__init__(parent); self.parent=parent; self.store=store; self.node_id=node_id
        self._generation=getattr(store,'_view_generation',0)
        self.last_selected_side="left"
        self._path_job=None;self._path_key=None
        n=store.node(node_id);self.node_type=n['type']; self.title(f'{NODE_LABELS.get(n["type"],n["type"])} - {n["name"]}')
        self.geometry("1320x840")
        workflow.desktop_dialog_heading(self,NODE_LABELS.get(n['type'],n['type'])+' 연결 편집',n['name'])
        if n['type'] in ('hamche','rn'):
            lockbar=ttk.Frame(self,padding=(8,6,8,0));lockbar.pack(fill='x')
            if n['type']=='hamche':
                self.lock_control=EnclosureLockControl(lockbar,self.toggle_lock);self.lock_control.pack(side='right')
                ttk.Label(lockbar,text='함체 잠금',font=('Malgun Gothic',11,'bold')).pack(side='left')
            self.field_button=ttk.Button(lockbar,text='현장 선번조사 · OK / NOT OK',command=self.field_survey_open);self.field_button.pack(side='left',padx=15)
            if workflow.field_slot_mode(store):ttk.Button(lockbar,text='함체별 내역·이동·확정',command=lambda:workflow.FieldSlotEditorDialog(self,self.store,node_id=self.node_id)).pack(side='left',padx=4)
        namebar=ttk.Frame(self,padding=(8,8,8,0));namebar.pack(fill="x")
        ttk.Label(namebar,text=NODE_LABELS.get(n["type"],"시설")+"명").pack(side="left")
        self.name_var=tk.StringVar(value=n["name"]);self.name_entry=ttk.Entry(namebar,textvariable=self.name_var,width=34);self.name_entry.pack(side="left",padx=6)
        self.save_button=ttk.Button(namebar,text='저장 (Space)' if n['type']=='sub' else '저장',command=self.save_header)
        self.save_button.pack(side='left');self.name_entry.bind('<Return>',self.save_header);self.name_entry.bind('<Control-a>',lambda e:select_entry_text(self.name_entry))
        self.connection_diagram_button=ttk.Button(namebar,text='코어 연결도',command=lambda:open_detail_dialog(self,self.store,'diagram',self.node_id))
        self.connection_diagram_button.pack(side='left',padx=8)
        if n['type']=='sub':
            self.name_entry.bind('<space>',self.save_header)
            self.name_entry.bind('<Shift-space>',self.insert_name_space)
        self.terminal_var=tk.BooleanVar(value=workflow.terminal_marked(n))
        self.terminal_check=ttk.Checkbutton(namebar,text='말단으로 처리',variable=self.terminal_var,command=self.toggle_terminal)
        self.terminal_check.pack(side='right',padx=8)
        workflow.Tooltip(self.terminal_check,'선택하면 이 시설에서 경로를 끝낼 수 있습니다. RN도 내부 포트 접속 없이 끝단으로 인정합니다. 기존 접속은 유지됩니다.')
        if workflow.completion_kind(store)=='before' and n['type'] in ('hamche','rn'):
            self.survey_control=workflow.SurveyStatusControl(self,store,node_id);self.survey_control.pack(fill='x',padx=8,pady=4)
            self.gis_control=workflow.FieldGISControl(self,store,node_id);self.gis_control.pack(fill='x',padx=8,pady=4)
        if n['type']=='hamche':
            spec,identifier=hamche_details(n)
            self.hamche_spec_var=tk.StringVar(value=spec);self.hamche_id_var=tk.StringVar(value=identifier)
            detailsbar=ttk.Frame(self,padding=(8,4,8,0));detailsbar.pack(fill='x')
            for label,var,width in (('함체규격',self.hamche_spec_var,24),('함체ID',self.hamche_id_var,24)):
                ttk.Label(detailsbar,text=label).pack(side='left')
                entry=ttk.Entry(detailsbar,textvariable=var,width=width);entry.pack(side='left',padx=(6,12))
                entry.bind('<Return>',self.save_header);entry.bind('<Control-a>',lambda e,w=entry:select_entry_text(w))
                if var is self.hamche_spec_var:entry.bind('<FocusOut>',lambda e:self.hamche_spec_var.set(normalize_hamche_spec(self.hamche_spec_var.get())))
        if n['type']=='rn':
            identifier,computer_no=rn_details(n)
            self.rn_id_var=tk.StringVar(value=identifier);self.rn_computer_var=tk.StringVar(value=computer_no)
            detailsbar=ttk.Frame(self,padding=(8,4,8,0));detailsbar.pack(fill='x')
            for label,var in (('RN ID',self.rn_id_var),('전산화번호',self.rn_computer_var)):
                ttk.Label(detailsbar,text=label).pack(side='left')
                entry=ttk.Entry(detailsbar,textvariable=var,width=30);entry.pack(side='left',padx=(6,12))
                entry.bind('<Return>',self.save_header);entry.bind('<Control-a>',lambda e,w=entry:select_entry_text(w))
        self.header_status=tk.StringVar(value='Ctrl+V 붙여넣기 → Space 저장 · 이름에 공백 입력: Shift+Space' if n['type']=='sub' else '이름과 아래 정보를 입력한 뒤 저장을 누르세요.')
        ttk.Label(self,textvariable=self.header_status,foreground='#1769aa',padding=(8,4,8,0)).pack(fill='x')
        initial_name=self.name_var.get()
        if n['type']=='sub' or (n["type"]=="hamche" and (not initial_name.strip() or re.fullmatch(r"함체[0-9]*",initial_name.strip()))):
            # Run once after opening, including enclosures that have no cables yet.
            self.after_idle(lambda:self.focus_name_input(initial_name))
        cables=[c for c in store.node_cables(node_id) if str(c["spec"] or "").strip()!="드랍"]
        if not cables and n["type"] not in ("rn","sub"):
            ttk.Label(self,text="이 시설에 연결된 케이블이 없습니다.",padding=30).pack();self.refresh_lock_state();return
        allowed={c["id"] for c in cables};self.by_label={label:cid for label,cid in store.node_cable_choices(node_id) if cid in allowed}
        if n["type"] in ("rn","sub"):
            if not workflow.locked(store):store.ensure_ports(node_id,json.loads(n["extra_json"] or "{}").get("rnSpec" if n["type"]=="rn" else "subSpec"))
            self.by_label={"RN내부 포트" if n["type"]=="rn" else "가입자내부 포트":"PORT:"+node_id,**self.by_label}
        pick=ttk.Frame(self,padding=(12,6));pick.pack(fill="x")
        pick.columnconfigure(0,weight=1,uniform='cable');pick.columnconfigure(1,weight=1,uniform='cable')
        self.left_var=tk.StringVar(value='');self.right_var=tk.StringVar(value='')
        self.assignment_filters={side:tk.BooleanVar(value=False) for side in ('left','right')}
        ttk.Label(pick,text="왼쪽 케이블(연결 함체 기준)").grid(row=0,column=0,sticky="w")
        ttk.Label(pick,text="오른쪽 케이블(연결 함체 기준)").grid(row=0,column=1,sticky="w")
        self.left_combo=CableChoice(pick,self.left_var,lambda:self.cable_changed('left'));self.left_combo.grid(row=1,column=0,padx=(0,12),sticky='ew',pady=4)
        self.right_combo=CableChoice(pick,self.right_var,lambda:self.cable_changed('right'));self.right_combo.grid(row=1,column=1,sticky='ew',pady=4)
        for side,column in (('left',0),('right',1)):
            button=ttk.Checkbutton(pick,text='미배정 케이블만 보기',variable=self.assignment_filters[side],command=self.sync_cable_choices)
            button.grid(row=3,column=column,sticky='w',pady=(3,0))
            workflow.Tooltip(button,'이 시설에서 배정이 필요한 케이블만 표시합니다. 빈 상대 케이블을 고를 쪽은 체크를 해제하세요.')
        self.connection_actions=workflow.FlowToolbar(self);self.connection_actions.pack(fill='x')
        for title,command,style in (
            ('선택 코어 연결',lambda:self.connect(False),'Primary.TButton'),
            ('임시코어 연결',lambda:self.connect(True),'Tool.TButton'),
            ('선택 코어 상태',self.edit_annotations,'Tool.TButton'),
            ('함체 코어내역',lambda:NodeSummaryDialog(self,self.store,self.node_id),'Tool.TButton'),
            ('함체 코어내역 V2',lambda:NodePairSummaryDialog(self,self.store,self.node_id),'Tool.TButton'),
            ('Excel표 일괄연결',self.bulk_table_open,'Tool.TButton'),
            ('미연결코어 동일번호 중접',self.full_splice,'Tool.TButton'),
            ('전체 번호 100% 중접',self.full_splice_all,'Tool.TButton'),
            ('번호 범위 직결',self.full_splice_range,'Tool.TButton'),
            ('코어삭제',self.delete_selected_core,'Danger.TButton')):
            self.connection_actions.add(ttk.Button(self.connection_actions,text=title,command=command,style=style))
        if n['type'] in ('rn','sub'):self.connection_actions.add(ttk.Button(self.connection_actions,text='RN규격/가입자포트',command=self.port_setup))
        if n['type']=='rn':self.rn_identity_button=self.connection_actions.add(ttk.Button(self.connection_actions,text='RN 내부 코어ID·내역 입력',command=self.open_rn_identity))
        self.waiting_button=self.connection_actions.add(ttk.Button(self.connection_actions,text='자동연결 보류 확인' if workflow.completion_kind(self.store)=='after' else '연결대기확인',command=self.open_waiting_connections))
        body=ttk.Panedwindow(self,orient="horizontal");body.pack(fill="both",expand=True,padx=8,pady=4)
        self.left_tree=self.make_tree(body);self.right_tree=self.make_tree(body)
        body.add(self.left_tree.master,weight=1);body.add(self.right_tree.master,weight=1)
        self.msg=tk.StringVar(value="코어 우클릭: 상태·신호 변경. 연결대기확인: 양쪽 배정 코어를 확인하고 최종 연결. 분홍색 케이블: 배정이 필요한 코어가 있음.")
        if workflow.completion_kind(self.store)=='after':self.msg.set('같은 코어ID가 양쪽에서 만나면 자동 연결됩니다. 여러 상대·잠금·충돌로 보류된 코어만 직접 확인하세요. 신호 확인필요는 연결 완료를 막지 않습니다.')
        message_label=ttk.Label(self,textvariable=self.msg,padding=8,foreground="#1769aa",wraplength=1100)
        message_label.pack(fill='x');message_label.bind('<Configure>',lambda e:message_label.configure(wraplength=max(300,e.width-20)))
        self.left_tree.bind("<space>",self.space_connect);self.right_tree.bind("<space>",self.space_connect)
        self.left_tree.bind("<ButtonPress-1>",lambda e:self.remember_side("left"),add="+");self.right_tree.bind("<ButtonPress-1>",lambda e:self.remember_side("right"),add="+")
        self.left_tree.bind("<Delete>",lambda e:self.delete_selected_core("left"));self.right_tree.bind("<Delete>",lambda e:self.delete_selected_core("right"))
        self.left_tree.bind('<Button-3>',lambda e:self.core_context_menu(e,'left'))
        self.right_tree.bind('<Button-3>',lambda e:self.core_context_menu(e,'right'))
        self.left_tree.bind('<<TreeviewSelect>>',self.queue_core_paths)
        self.right_tree.bind('<<TreeviewSelect>>',self.queue_core_paths)
        self.left_tree.bind('<ButtonRelease-1>',self.queue_core_paths,add='+')
        self.right_tree.bind('<ButtonRelease-1>',self.queue_core_paths,add='+')
        legend=ttk.Frame(self,padding=(8,0,8,6));legend.pack(fill='x')
        ttk.Label(legend,text='경로 색상: ').pack(side='left')
        for side,label in (('left','왼쪽 주황   '),('right','오른쪽 보라   '),('shared','공통 구간 초록   ')):
            ttk.Label(legend,text=label,foreground=CORE_PATH_COLORS[side],font=('Malgun Gothic',9,'bold')).pack(side='left')
        ttk.Label(legend,text='선택한 케이블은 각 방향 색상').pack(side='left')
        body.pack_forget();message_label.pack_forget();legend.pack_forget()
        legend.pack(side='bottom',fill='x');message_label.pack(side='bottom',fill='x')
        body.pack(fill='both',expand=True,padx=8,pady=4)
        self.bind('<Destroy>',self.on_node_destroy,add='+')
        self.protocol("WM_DELETE_WINDOW",self.close_dialog)
        self.reload_all()
        self.bind('<FocusIn>',lambda e:self.refresh_lock_state())

    def refresh_lock_state(self):
        app=owning_app(self)
        if app and (app.store is not self.store or getattr(self.store,'_view_generation',0)!=self._generation):return
        if 'survey_control' in self.__dict__:self.survey_control.refresh()
        if 'gis_control' in self.__dict__:self.gis_control.refresh()
        locked=workflow.node_locked(self.store,self.node_id)
        terminal=workflow.terminal_marked(self.store.node(self.node_id))
        render_state=(locked,terminal)
        if getattr(self,'_lock_render_state',None)==render_state and ('terminal_var' not in self.__dict__ or self.terminal_var.get()==terminal):return
        self._lock_render_state=render_state
        if 'lock_control' in self.__dict__:self.lock_control.set_locked(locked)
        terminal_changed=False
        if 'terminal_var' in self.__dict__:
            terminal_changed=terminal!=self.terminal_var.get()
            self.terminal_var.set(terminal);self.terminal_check.configure(state='disabled' if locked else 'normal')
        pending=list(self.winfo_children())
        while pending:
            widget=pending.pop()
            if isinstance(widget,tk.Toplevel):continue
            pending.extend(widget.winfo_children())
            if isinstance(widget,ttk.Entry) and not isinstance(widget,ttk.Combobox):widget.configure(state='readonly' if locked else 'normal')
            elif isinstance(widget,ttk.Button) and not str(widget.cget('text')).startswith(('연결대기확인','함체 코어내역','현장 선번조사','코어 연결도')) and '복사' not in str(widget.cget('text')):
                widget.configure(state='disabled' if locked else 'normal')
        if terminal_changed and 'left_tree' in self.__dict__:self.reload_all()

    def toggle_terminal(self):
        requested=self.terminal_var.get()
        if not self.ensure_node_editable():self.refresh_lock_state();return
        try:self.store.set_node_terminal(self.node_id,requested)
        except ValueError as error:
            self.refresh_lock_state();messagebox.showwarning('말단 설정',str(error),parent=self);return
        if 'left_tree' in self.__dict__:self.reload_all()
        self.parent.refresh()
        if 'msg' in self.__dict__:self.msg.set('말단으로 설정했습니다. 이 시설에서 경로를 끝낼 수 있습니다.' if requested else '말단 설정을 해제했습니다. 기존 연결 기준으로 점검합니다.')

    def toggle_lock(self):
        if not self.current_store():return
        try:self.store.set_node_locked(self.node_id,not workflow.node_locked(self.store,self.node_id))
        except ValueError as error:messagebox.showwarning('함체 잠금',str(error),parent=self);return
        self.refresh_lock_state();self.parent.refresh()
        if 'msg' in self.__dict__:self.msg.set('함체가 잠겼습니다. 조회와 복사는 가능합니다.' if workflow.node_locked(self.store,self.node_id) else '함체 잠금을 해제했습니다. 수정할 수 있습니다.')

    def ensure_node_editable(self):
        if not self.current_store():return False
        if workflow.node_locked(self.store,self.node_id):
            self.refresh_lock_state();messagebox.showwarning('함체 잠금','위쪽 자물쇠를 클릭해 함체 잠금을 해제하세요.',parent=self);return False
        return True

    def focus_name_input(self,initial_name):
        try:
            if not self.winfo_exists() or self.name_var.get()!=initial_name:return
            focused=self.focus_get()
            # Keep an explicit selection in another popup or a core table.
            if focused is not None and focused not in (self,self.name_entry):
                if focused.winfo_toplevel() is not self.parent:return
            self.name_entry.focus_set()
            self.name_entry.selection_range(0,"end")
            self.name_entry.icursor("end")
        except tk.TclError:
            pass  # The window may have closed before the idle callback.

    def close_dialog(self):
        editor=getattr(self,'_rn_identity_dialog',None)
        if editor is not None and editor.winfo_exists():
            editor.close()
            if editor.winfo_exists():return
        self.clear_core_paths()
        self.destroy();self.parent.after_idle(self.parent.focus_force)

    def header_changed(self):
        node=self.store.node(self.node_id)
        if not node:return False
        if self.name_var.get().strip()!=node['name']:return True
        if node['type']=='hamche':
            return (normalize_hamche_spec(self.hamche_spec_var.get()),self.hamche_id_var.get().strip())!=hamche_details(node)
        return False

    def close_for_switch(self):
        """Close an enclosure before replacing it, honoring real unsaved edits."""
        if self.header_changed():
            choice=messagebox.askyesnocancel('함체 변경사항',
                '입력한 함체명·규격·ID를 저장하고 다른 함체로 이동할까요?\n예: 저장 후 이동 / 아니오: 입력 취소 후 이동 / 취소: 현재 함체 유지',parent=self)
            if choice is None:return False
            if choice:
                self.save_header()
                if self.header_changed():return False
        # A non-modal field sheet has its own save/cancel close action.
        for child in list(self.winfo_children()):
            if isinstance(child,workflow.FieldSurveyDialog):
                child.close_dialog()
                if child.winfo_exists():return False
        self.clear_core_paths();self.destroy()
        return True

    def queue_core_paths(self,event=None):
        if self._path_job is not None:self.after_cancel(self._path_job)
        self._path_job=self.after_idle(self.show_core_paths)

    def show_core_paths(self):
        self._path_job=None
        if self.parent.store is not self.store or getattr(self.store,'_view_generation',0)!=self._generation:return
        selections=[self.selected(self.left_tree,self.left_var),self.selected(self.right_tree,self.right_var)]
        key=(self.store.data_revision(),tuple(selections))
        if key==self._path_key and getattr(self.parent,'highlight_owner',None) is self:return
        if not any(selections):
            self._path_key=key
            if getattr(self.parent,'highlight_owner',None) is self:self.parent.stop_highlight_blink(clear=True)
            return
        context=self.store.trace_context();paths=[];path_rows=[];traces=[]
        for slot in selections:
            row=self.store.core(*slot) if slot else None;core_id=str(row['core_id'] or '').strip() if row else ''
            trace=self.store.trace_core_paths(core_id,context,slot=slot) if slot and workflow.field_slot_mode(self.store) else None
            if trace:traces.append(trace)
            rows=[r for r in (trace['rows'] if trace else context['by_id'].get(core_id,())) if r['cable_id'] in context['cables']];path_rows.append(rows)
            paths.append({r['cable_id'] for r in rows})
        colors=core_path_colors(paths[0],paths[1],selections[0],selections[1]);self._path_key=key
        if colors:self.parent.start_highlight_blink(colors,owner=self,core_labels=core_path_number_labels(*path_rows),core_rows=[r for rows in path_rows for r in rows],core_slots=[s for s in selections if s])
        elif getattr(self.parent,'highlight_owner',None) is self:self.parent.stop_highlight_blink(clear=True)
        if colors:self.parent.status.set(self.parent.highlight_connection_model['summary']+' · 미접속 함체 안내를 더블클릭해 연결을 확인하세요.')

    def clear_core_paths(self):
        if self._path_job is not None:
            try:self.after_cancel(self._path_job)
            except tk.TclError:pass
            self._path_job=None
        if getattr(self.parent,'highlight_owner',None) is self:self.parent.stop_highlight_blink(clear=True)

    def on_node_destroy(self,event):
        if event.widget is self:self.clear_core_paths()

    def space_connect(self,event=None):
        self.connect_auto();return "break"

    def insert_name_space(self,event=None):
        if self.name_entry.selection_present():self.name_entry.delete('sel.first','sel.last')
        self.name_entry.insert('insert',' ');return 'break'

    def save_header(self,event=None):
        if not self.ensure_node_editable():return 'break'
        node=self.store.node(self.node_id)
        if not node:return 'break'
        hamche=(self.hamche_spec_var.get(),self.hamche_id_var.get()) if node['type']=='hamche' else None
        rn=(self.rn_id_var.get(),self.rn_computer_var.get()) if node['type']=='rn' else None
        try:self.store.set_node_details(self.node_id,self.name_var.get(),hamche=hamche,rn=rn)
        except (ValueError,sqlite3.Error) as error:
            messagebox.showwarning('시설 정보 저장',str(error),parent=self);return 'break'
        node=self.store.node(self.node_id);self.name_var.set(node['name'])
        if hamche is not None:
            spec,identifier=hamche_details(node);self.hamche_spec_var.set(spec);self.hamche_id_var.set(identifier)
        if rn is not None:
            identifier,computer_no=rn_details(node);self.rn_id_var.set(identifier);self.rn_computer_var.set(computer_no)
        self.title(f'{NODE_LABELS.get(node["type"],node["type"])} - {node["name"]}');self.parent.refresh()
        fields={'hamche':'함체명·규격·ID','rn':'RN명·RN ID·전산화번호','sub':'가입자명'}
        self.header_status.set(fields.get(node['type'],'시설 정보')+' 저장 완료')
        return 'break'

    def make_tree(self,parent):
        frame=ttk.Frame(parent); cols=("tags","signal","num","id","detail","link","field")
        frame.columnconfigure(0,weight=1);frame.rowconfigure(0,weight=1)
        tree=workflow.SortableTreeview(frame,columns=cols,show="headings",selectmode="browse")
        for c,l,w in zip(cols,("상태","신호","번호","코어ID","코어내역","연결","이 함체 확인"),(150,60,50,110,165,55,100)):tree.heading(c,text=l);tree.column(c,width=w,minwidth=w,stretch=c=='detail',anchor="center" if c!="detail" else "w")
        y=ttk.Scrollbar(frame,orient="vertical",command=tree.yview);tree.configure(yscrollcommand=y.set)
        tree.grid(row=0,column=0,sticky='nsew');y.grid(row=0,column=1,sticky='ns')
        x=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview);x.grid(row=1,column=0,columnspan=2,sticky='ew');tree.configure(xscrollcommand=x.set)
        return tree

    def reload_side(self,tree,var,keep=None):
        view=tree.yview()[0] if tree.get_children() else 0
        if keep is None and tree.selection():keep=int(tree.selection()[0])
        label=var.get();tree.delete(*tree.get_children())
        if label not in self.by_label:return
        cid=self.by_label[label]
        needed=self.assignment_needs().get(cid,set())
        field_checks=workflow.field_local_slots(self.store,self.node_id)
        link_map={}
        for sp in self.store.conn.execute("SELECT * FROM splices WHERE node_id=?",(self.node_id,)):
            a=(sp["cable1_id"],sp["core1_index"]);b=(sp["cable2_id"],sp["core2_index"]);link_map[a]=b;link_map[b]=a
        for r in self.store.cores(cid):
            other=link_map.get((cid,r["core_index"]));sp=other is not None;link=f'{other[1]}번' if other else ""
            number=r["label"] if "label" in r.keys() else r["core_index"]
            tag=workflow.field_slot_tag(self.store,r,core_row_tag(r));tag="dangling" if tag=="used" and r['core_index'] in needed else tag
            sig=core_row_signal_text(r)
            tree.insert("","end",iid=str(r["core_index"]),values=(workflow.core_status_text(self.store,r),sig,number,display_core_id(r["core_id"]),r["detail"],link,field_checks.get((cid,int(r["core_index"])),'')),tags=(tag,core_signal_tag(r)))
        configure_core_tags(tree)
        if keep and tree.exists(str(keep)):tree.selection_set(str(keep))
        tree.yview_moveto(view)

    def refresh_shared_rows(self):
        if 'survey_control' in self.__dict__:self.survey_control.refresh()
        if 'left_tree' not in self.__dict__:return
        stamp=(self.store.data_revision(),self.store.conn.total_changes)
        if getattr(self,'_shared_rows_stamp',None)==stamp:return
        self._shared_rows_stamp=stamp;needed=self.assignment_needs()
        field_checks=workflow.field_local_slots(self.store,self.node_id)
        links={}
        for sp in self.store.conn.execute('SELECT * FROM splices WHERE node_id=?',(self.node_id,)):
            a=(sp['cable1_id'],sp['core1_index']);b=(sp['cable2_id'],sp['core2_index']);links[a]=b;links[b]=a
        for tree,var in ((self.left_tree,self.left_var),(self.right_tree,self.right_var)):
            cid=self.by_label.get(var.get())
            if not cid:continue
            for row in self.store.cores(cid):
                iid=str(row['core_index'])
                if not tree.exists(iid):continue
                values=list(tree.item(iid,'values'))
                values[0]=workflow.core_status_text(self.store,row);values[1]=signal_label(row['signal']) if row['core_id'] else ''
                values[3]=display_core_id(row['core_id']);values[4]=row['detail']
                other=links.get((cid,int(row['core_index'])));values[5]=str(other[1])+'번' if other else ''
                values[6]=field_checks.get((cid,int(row['core_index'])),'')
                base=workflow.field_slot_tag(self.store,row,core_row_tag(row));tag='dangling' if base=='used' and row['core_index'] in needed.get(cid,set()) else base
                tree.item(iid,values=values,tags=(tag,core_signal_tag(row)))
        count=self.store.node_warning_summary().get(self.node_id,{}).get('waiting_count',0)
        self.waiting_button.configure(text=f'연결대기확인 ({count}개)')
        self.connection_actions.schedule()
        if hasattr(self,'field_button'):
            local=self.store.node_warning_summary().get(self.node_id,{}).get('field_local',{})
            self.field_button.configure(text=f"현장 선번조사 · OK {local.get('ok',0)} / NOT OK {local.get('not_ok',0)}")

        if getattr(self.parent,'highlight_owner',None) is self:self.queue_core_paths()

    def reload_all(self,ka=None,kb=None):
        self.sync_cable_choices()
        self.reload_side(self.left_tree,self.left_var,ka);self.reload_side(self.right_tree,self.right_var,kb)
        count=self.store.node_warning_summary().get(self.node_id,{}).get('waiting_count',0)
        self.waiting_button.configure(text=f'연결대기확인 ({count}개)')
        self.connection_actions.schedule()
        if hasattr(self,'field_button'):
            local=self.store.node_warning_summary().get(self.node_id,{}).get('field_local',{})
            self.field_button.configure(text=f"현장 선번조사 · OK {local.get('ok',0)} / NOT OK {local.get('not_ok',0)}")
        self.parent.schedule_auto_splice_notice()
        self.refresh_lock_state()
        self.queue_core_paths()

    def assignment_needs(self):
        key=(self.store.data_revision(),self.store.conn.total_changes)
        if getattr(self,'_assignment_key',None)!=key:
            self._assignment_value=self.store.node_assignment_needs(self.node_id);self._assignment_key=key
        return self._assignment_value

    def sync_cable_choices(self):
        labels=list(self.by_label);left_id=self.by_label.get(self.left_var.get());right_id=self.by_label.get(self.right_var.get())
        left_values=[label for label in labels if self.by_label[label]!=right_id]
        right_values=[label for label in labels if self.by_label[label]!=left_id]
        if self.left_var.get() not in left_values:self.left_var.set('')
        if self.right_var.get() not in right_values:self.right_var.set('')
        needs=self.assignment_needs();counts={label:len(needs.get(cid,())) for label,cid in self.by_label.items()}
        filters=getattr(self,'assignment_filters',{})
        if filters.get('left') and filters['left'].get():left_values=[label for label in left_values if counts[label]]
        if filters.get('right') and filters['right'].get():right_values=[label for label in right_values if counts[label]]
        self.left_combo.set_choices(left_values,counts);self.right_combo.set_choices(right_values,counts)

    def cable_changed(self,side):
        selected_id=self.by_label.get(self.left_var.get() if side=="left" else self.right_var.get())
        other=self.right_var if side=="left" else self.left_var
        cleared=bool(selected_id and self.by_label.get(other.get())==selected_id)
        if cleared:other.set("")
        tree=self.left_tree if side=='left' else self.right_tree
        tree.selection_remove(*tree.selection());tree.yview_moveto(0)
        self.sync_cable_choices()
        self.reload_side(tree,self.left_var if side=='left' else self.right_var)
        if cleared:self.reload_side(self.right_tree if side=='left' else self.left_tree,other)
        self.queue_core_paths()

    def selected(self,tree,var):
        return (self.by_label[var.get()],int(tree.selection()[0])) if var.get() in self.by_label and tree.selection() else None

    def remember_side(self,side):
        self.last_selected_side=side

    def current_store(self):
        if self.parent.store is self.store and getattr(self.store,'_view_generation',0)==self._generation:return True
        messagebox.showwarning('다시 열기','작업 도면이 변경되었습니다. 함체 창을 다시 열어 주세요.',parent=self);return False

    def core_for_edit(self,slot,expected_core_id=None):
        if not self.ensure_node_editable():return None
        row=self.store.core(*slot) if slot else None
        if not row or not str(row['core_id'] or '').strip():
            messagebox.showinfo('코어 선택','코어ID 또는 임시코어가 있는 코어를 선택하세요.',parent=self);return None
        if expected_core_id is not None and row['core_id']!=expected_core_id:
            messagebox.showwarning('다시 선택','선택한 코어의 배정이 변경되었습니다. 다시 선택하세요.',parent=self);return None
        if workflow.locked(self.store):
            messagebox.showwarning('전도면 잠금','작업 검사 옵션에서 전도면 편집 잠금을 해제하세요.',parent=self);return None
        return row

    def core_context_menu(self,event,side):
        tree,var=(self.right_tree,self.right_var) if side=='right' else (self.left_tree,self.left_var)
        iid=tree.identify_row(event.y)
        if not iid or not self.current_store():return 'break'
        tree.selection_set(iid);tree.focus(iid);tree.focus_set();self.remember_side(side)
        slot=self.selected(tree,var);row=self.store.core(*slot) if slot else None
        previous=getattr(self,'_core_menu',None)
        if previous is not None:previous.destroy()
        menu=tk.Menu(self,tearoff=False);self._core_menu=menu
        if row and not str(row['core_id'] or '').strip():
            # V166: an empty number can still be marked OFF (or ON) and keep it.
            menu.add_command(label='빈 코어 · 신호만 표시할 수 있습니다.',state='disabled')
            signals=tk.Menu(menu,tearoff=False)
            for label in SIGNAL_VALUES:
                signals.add_command(label=label,command=lambda value=label:self.change_empty_core_signal(slot,SIGNAL_FROM_LABEL[value]))
            menu.add_cascade(label='신호 변경',menu=signals)
        elif not row:
            menu.add_command(label='코어ID 또는 임시코어를 먼저 배정하세요.',state='disabled')
        else:
            core_id=row['core_id']
            menu.add_command(label='코어 상태 변경…',command=lambda:self.edit_annotations(slot,core_id))
            signals=tk.Menu(menu,tearoff=False)
            for label in SIGNAL_VALUES:
                signals.add_command(label=label,command=lambda value=label:self.change_core_signal(slot,core_id,SIGNAL_FROM_LABEL[value]))
            menu.add_cascade(label='신호 변경',menu=signals)
        mode=self.store.conn.execute("SELECT value FROM meta WHERE key='active_scenario'").fetchone()
        if mode and mode[0]=='before' and slot in workflow.field_local_slots(self.store,self.node_id):
            menu.add_separator()
            revision=self.store.data_revision();generation=self.store._view_generation
            for value in ('OK','NOT OK'):
                menu.add_command(label='이 함체 '+value,command=lambda status=value:self.mark_local_core(slot,status,revision,generation))
        try:menu.tk_popup(event.x_root,event.y_root)
        finally:menu.grab_release()
        return 'break'

    def mark_local_core(self,slot,status,revision,generation):
        if not self.current_store():return
        try:
            rows=workflow.FieldSurvey(self.store,self.node_id).report()
            keys={r['key'] for r in rows if slot in r['slots']}
            workflow.field_local_mark(self.store,self.node_id,keys,status,revision,generation)
            self.reload_all();self.parent.refresh()
        except (ValueError,sqlite3.Error) as error:messagebox.showerror('함체별 확인',str(error),parent=self)

    def change_empty_core_signal(self,slot,signal):
        if not self.ensure_node_editable():return
        if workflow.locked(self.store):
            messagebox.showwarning('전도면 잠금','작업 검사 옵션에서 전도면 편집 잠금을 해제하세요.',parent=self);return
        if not confirm_signal_mix(self,self.store,[slot],signal):return
        try:self.store.set_empty_core_signal(slot,signal)
        except ValueError as error:messagebox.showerror('신호 변경',str(error),parent=self);return
        self.reload_all();self.parent.refresh()
        self.msg.set(f"빈 코어 {slot[1]}번 신호를 {signal_label(signal)}(으)로 표시했습니다.")

    def change_core_signal(self,slot,expected_core_id,signal):
        row=self.core_for_edit(slot,expected_core_id)
        if row is None:return
        follow=[slot]+[(sp['cable2_id'],sp['core2_index']) if (sp['cable1_id'],sp['core1_index'])==tuple(slot) else (sp['cable1_id'],sp['core1_index'])
                       for sp in self.store.conn.execute('SELECT * FROM splices WHERE node_id=? AND ((cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?))',(self.node_id,slot[0],slot[1],slot[0],slot[1]))]
        if str(row['signal'] or '')!=signal and not confirm_signal_mix(self,self.store,follow if workflow.field_slot_mode(self.store) else [slot],signal):return
        try:positions=self.store.set_core_signal(row['core_id'],signal,slot=slot,node_id=self.node_id)
        except ValueError as error:messagebox.showerror('신호 변경',str(error),parent=self);return
        self.reload_all();self.parent.refresh()
        self.msg.set((f'이 함체의 직접 접속 {len(positions)}개 번호만 변경 · ' if positions else '')+f"{display_core_id(row['core_id'])} 신호를 {signal_label(signal)}(으)로 변경했습니다.")

    def edit_annotations(self,slot=None,expected_core_id=None):
        if slot is None:
            tree,var=(self.right_tree,self.right_var) if self.last_selected_side=='right' else (self.left_tree,self.left_var)
            slot=self.selected(tree,var)
        if self.core_for_edit(slot,expected_core_id) is None:return
        workflow.AnnotationDialog(self,self.store,slot,lambda:(self.reload_all(),self.parent.refresh()))

    def open_waiting_connections(self):
        if self.current_store():WaitingConnectionsDialog(self,self.store,self.node_id)

    def connect(self,temp):
        if not self.ensure_node_editable():return
        a=self.selected(self.left_tree,self.left_var);b=self.selected(self.right_tree,self.right_var)
        if not a or not b:messagebox.showinfo("선택 필요","양쪽 케이블에서 코어를 하나씩 선택하세요.",parent=self);return
        try:msg=workflow.reconnect_selected(self.store,self.node_id,a,b,temp)
        except ValueError as e:messagebox.showerror("연결하지 않음",f"{a[1]}번 ↔ {b[1]}번\n{e}",parent=self);return
        self.msg.set(msg+" — 다음 번호를 선택할 수 있도록 현재 위치를 유지했습니다.");self.reload_all(a[1],b[1])
        self.parent.refresh()

    def connect_auto(self):
        a=self.selected(self.left_tree,self.left_var);b=self.selected(self.right_tree,self.right_var)
        if not a or not b:self.connect(False);return
        ca=self.store.core(*a);cb=self.store.core(*b);temporary=not str(ca["core_id"] or "").strip() and not str(cb["core_id"] or "").strip()
        self.connect(temporary)

    def delete_selected_core(self,side=None):
        if not self.ensure_node_editable():return 'break'
        side=side if side in ("left","right") else self.last_selected_side
        choices=((side,self.left_tree,self.left_var) if side=="left" else (side,self.right_tree,self.right_var),)
        choices+=(("right",self.right_tree,self.right_var) if side=="left" else ("left",self.left_tree,self.left_var),)
        selected=None
        for picked_side,tree,var in choices:
            slot=self.selected(tree,var)
            if slot:selected=(picked_side,tree,var,slot);break
        if not selected:
            messagebox.showinfo("코어삭제","삭제할 코어 하나를 먼저 클릭하세요.",parent=self);return "break"
        picked_side,tree,var,(cable_id,index)=selected;row=self.store.core(cable_id,index)
        if not row:return "break"
        core_id=display_core_id(row["core_id"]) or "없음";detail=str(row["detail"] or "").strip() or "없음"
        linked=bool(self.store.conn.execute("SELECT 1 FROM splices WHERE (cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?) LIMIT 1",(cable_id,index,cable_id,index)).fetchone())
        question=f'{var.get()}\n{index}번 코어를 삭제하시겠습니까?\n\n코어ID: {core_id}\n코어내역: {detail}'
        if linked:question+="\n\n이 코어가 참여한 접속도 함께 해제됩니다.\n반대편 케이블 코어정보는 지워지지 않습니다."
        if not messagebox.askyesno("코어삭제 확인",question,parent=self):return "break"
        if not self.store.delete_core_assignment(cable_id,index):
            messagebox.showinfo("코어삭제","이미 비어 있는 코어입니다.",parent=self);return "break"
        self.last_selected_side=picked_side
        self.reload_all(index if picked_side=="left" else None,index if picked_side=="right" else None);self.parent.refresh()
        self.msg.set(f"{var.get()} / {index}번 코어를 삭제했습니다. 반대편 코어정보는 유지됩니다.")
        return "break"

    def bulk_open(self):
        BulkConnectDialog(self, self.store, self.node_id)

    def bulk_table_open(self):
        if not self.ensure_node_editable():return
        BulkTableConnectDialog(self,self.store,self.node_id)

    def field_survey_open(self):
        app=owning_app(self)
        if not app or app.store is not self.store or getattr(self.store,'_view_generation',0)!=self._generation:return
        if app.scenario_kind()!='before':
            messagebox.showinfo('현장반영 단계','2 전도면작성(현장반영)으로 전환한 뒤 현장 선번조사를 입력하세요.',parent=self);return
        workflow.FieldSurveyDialog(self,self.store,self.node_id)

    def open_rn_identity(self):
        if not self.ensure_node_editable():return
        previous=getattr(self,'_rn_identity_dialog',None)
        if previous is not None and previous.winfo_exists():previous.lift();previous.focus_force();return
        self._rn_identity_dialog=workflow.RNIdentityDialog(self,self.store,self.node_id)

    def port_setup(self):
        PortConfigDialog(self,self.store,self.node_id,self.reload_all)

    def full_splice(self):
        self.run_full_splice(True)

    def full_splice_all(self):
        self.run_full_splice(False)

    def ask_splice_range(self,total):
        """V189: ask start/end numbers; returns (start,end,include_empty) or None."""
        last=getattr(self,'_last_splice_range',(1,total,True))
        return SpliceRangeDialog.ask(self,total,*last)

    def full_splice_range(self):
        """V189: 직결 only the numbers start..end between the two chosen cables."""
        if not self.ensure_node_editable():return
        title="번호 범위 직결"
        if self.left_var.get() not in self.by_label or self.right_var.get() not in self.by_label:messagebox.showinfo(title,"서로 다른 케이블을 양쪽에서 선택하세요.",parent=self);return
        left=self.by_label[self.left_var.get()];right=self.by_label[self.right_var.get()]
        if left==right:messagebox.showinfo(title,"서로 다른 케이블을 선택하세요.",parent=self);return
        total=min(len(self.store.cores(left)),len(self.store.cores(right)))
        if total<1:messagebox.showinfo(title,"연결할 코어가 없습니다.",parent=self);return
        answer=self.ask_splice_range(total)
        if not answer:return
        start,end,include_empty=answer
        try:targets,skipped=self.store.range_splice_plan(self.node_id,left,right,start,end,include_empty)
        except ValueError as exc:messagebox.showwarning(title,str(exc),parent=self);return
        start,end=min(int(start),int(end)),max(int(start),int(end))
        self._last_splice_range=(start,end,include_empty)
        if not targets:
            reasons="\n".join(f"{idx}번: {reason}" for idx,reason in skipped[:30])
            messagebox.showinfo(title,f"{start}~{end}번에서 새로 연결할 번호가 없습니다.\n\n{reasons}",parent=self);return
        preview=", ".join(map(str,targets[:20]))+("…" if len(targets)>20 else "")
        skip_text=""
        if skipped:
            skip_text="\n\n건너뜀 "+str(len(skipped))+"개: "+", ".join(f"{idx}번({reason})" for idx,reason in skipped[:10])+("…" if len(skipped)>10 else "")
        question=(f"{start}~{end}번 중 {len(targets)}개 번호를 같은 번호끼리 직결할까요?\n대상 번호: {preview}{skip_text}\n\n"
                  "빈 번호는 임시코어가 생성되고, 서로 다른 실제 코어ID끼리는 연결하지 않고 오류로 보여줍니다. Ctrl+Z 한 번으로 되돌릴 수 있습니다.")
        if not messagebox.askyesno(title,question,parent=self):return
        result=workflow.run_bulk(self,self.store,'full_splice',(self.node_id,left,right,False,start,end,include_empty))
        if result is None:return
        ok,errors=result
        self.reload_all();self.parent.refresh()
        self.msg.set(f"{title} {start}~{end}번 · 연결 {ok}건 · 건너뜀 {len(skipped)}건 · 확인필요 {len(errors)}건")
        if errors:messagebox.showwarning(title+" 확인필요","\n".join(errors[:100]),parent=self)

    def prepare_same_number_report(self,left,right,indices):
        rows=[{r['core_index']:r for r in self.store.cores(cid)} for cid in (left,right)]
        self.same_number_identities={};self.last_same_number_report=None
        for index in indices:
            ids={};details={}
            for side in rows:
                core=side.get(index)
                if core is None:continue
                if core['core_id']:ids[display_core_id(core['core_id'])]=None
                if core['detail']:details[str(core['detail'])]=None
            self.same_number_identities[index]=(' / '.join(ids),' / '.join(details))

    def report_same_number_splice(self,result,external_errors=()):
        normal,errors=result;grouped={}
        for error in list(errors)+list(external_errors):
            reason=str(error);match=re.match(r'^(\d+)번',reason)
            key=int(match.group(1)) if match else reason
            grouped.setdefault(key,{})[reason]=None
        rows=[]
        for key,reasons in grouped.items():
            core_id,detail=self.same_number_identities.get(key,('',''))
            rows.append((core_id,detail,'\n'.join(reasons)))
        report={'title':'미연결코어 동일번호 중접 결과','normal':normal,'errors':len(rows),'rows':rows}
        self.last_same_number_report=report
        return report

    def run_full_splice(self,used_only):
        if not self.ensure_node_editable():return
        if self.left_var.get() not in self.by_label or self.right_var.get() not in self.by_label:messagebox.showinfo("100% 중접","서로 다른 케이블을 양쪽에서 선택하세요.",parent=self);return
        left=self.by_label[self.left_var.get()];right=self.by_label[self.right_var.get()]
        if left==right:messagebox.showinfo("100% 중접","서로 다른 케이블을 선택하세요.",parent=self);return
        if used_only:
            indices=self.store.unconnected_same_number_indices(self.node_id,left,right)
            if not indices:messagebox.showinfo("미연결코어 동일번호 중접","이 함체에서 양쪽 모두 미연결이고 사용정보가 있는 동일번호 코어가 없습니다.",parent=self);return
            preview=", ".join(map(str,indices[:20]))+("…" if len(indices)>20 else "");title="미연결코어 동일번호 중접";question=f"미연결 {len(indices)}개 번호를 동일번호로 연결할까요?\n대상 번호: {preview}\n\n한쪽이라도 이 함체에서 연결돼 있으면 건너뜁니다. 양쪽 빈 코어는 전체중접을 사용하세요. 다른 실제 코어ID끼리는 연결하지 않습니다."
        else:
            total=min(len(self.store.cores(left)),len(self.store.cores(right)));title="전체 번호 100% 중접";question=f"1번부터 {total}번까지 모든 번호를 같은 번호끼리 연결할까요?\n\n빈 번호는 임시코어가 생성되며, 서로 다른 실제 코어ID는 오류로 남깁니다."
        if not messagebox.askyesno(title,question,parent=self):return
        reporter=None
        if used_only:
            self.prepare_same_number_report(left,right,indices);reporter=self.report_same_number_splice
        result=workflow.run_bulk(self,self.store,'full_splice',(self.node_id,left,right,used_only),reporter=reporter)
        if result is None:
            if used_only and self.last_same_number_report is not None:
                report=self.last_same_number_report
                self.msg.set(f"{title} · 정상 {report['normal']}건 · 오류 {report['errors']}건 · 검사 결과 / 미적용")
            return
        ok,errors=result
        self.reload_all()
        self.parent.refresh()
        if used_only:
            report=reporter(result)
            self.msg.set(f"{title} · 정상 {report['normal']}건 · 오류 {report['errors']}건 · 적용 완료")
            previous_grab=self.grab_current()
            dialog=workflow.BulkSummaryDialog(self,report,'적용 완료');self.wait_window(dialog)
            try:
                if previous_grab is not None and previous_grab.winfo_exists():previous_grab.grab_set()
            except tk.TclError:pass
            return
        self.msg.set(f"{title} {ok}건 완료, 확인필요 {len(errors)}건")
        if errors:messagebox.showwarning(title+" 확인필요","\n".join(errors[:100]),parent=self)


class SpliceRangeDialog(tk.Toplevel):
    """V189: small start/end number picker for 번호 범위 직결."""
    def __init__(self,parent,total,start=1,end=None,include_empty=True):
        super().__init__(parent);self.result=None;self.total=int(total)
        self.title("번호 범위 직결");self.transient(parent);self.resizable(False,False)
        frame=ttk.Frame(self,padding=14);frame.pack(fill="both",expand=True)
        ttk.Label(frame,text=f"직결할 번호 범위를 입력하세요. (1~{self.total}번)",font=("Malgun Gothic",10,"bold")).grid(row=0,column=0,columnspan=4,sticky="w",pady=(0,8))
        end=self.total if end is None else end
        self.start_var=tk.StringVar(value=str(min(max(1,int(start)),self.total)));self.end_var=tk.StringVar(value=str(min(max(1,int(end)),self.total)))
        ttk.Label(frame,text="시작 번호").grid(row=1,column=0,sticky="w")
        self.start_box=ttk.Spinbox(frame,from_=1,to=self.total,width=7,textvariable=self.start_var);self.start_box.grid(row=1,column=1,padx=(6,14))
        ttk.Label(frame,text="끝 번호").grid(row=1,column=2,sticky="w")
        self.end_box=ttk.Spinbox(frame,from_=1,to=self.total,width=7,textvariable=self.end_var);self.end_box.grid(row=1,column=3,padx=(6,0))
        self.empty_var=tk.BooleanVar(value=bool(include_empty))
        ttk.Checkbutton(frame,text="빈 번호도 임시코어로 직결",variable=self.empty_var).grid(row=2,column=0,columnspan=4,sticky="w",pady=(10,0))
        ttk.Label(frame,text="이 함체에서 이미 연결된 번호, 해지·끊김 번호는 건너뜁니다.",foreground="#1769aa").grid(row=3,column=0,columnspan=4,sticky="w",pady=(4,0))
        self.error=tk.StringVar();ttk.Label(frame,textvariable=self.error,foreground="#a00000").grid(row=4,column=0,columnspan=4,sticky="w")
        buttons=ttk.Frame(frame);buttons.grid(row=5,column=0,columnspan=4,sticky="e",pady=(10,0))
        ttk.Button(buttons,text="확인",command=self.accept,style="Primary.TButton").pack(side="left",padx=(0,6))
        ttk.Button(buttons,text="취소",command=self.destroy).pack(side="left")
        self.bind("<Return>",lambda e:self.accept());self.bind("<Escape>",lambda e:self.destroy())
        self.start_box.focus_set();self.start_box.selection_range(0,"end")

    def values(self):
        try:start=int(self.start_var.get().strip());end=int(self.end_var.get().strip())
        except ValueError:raise ValueError("시작 번호와 끝 번호를 숫자로 입력하세요.")
        if start>end:start,end=end,start
        if start<1 or end>self.total:raise ValueError(f"번호는 1~{self.total} 사이로 입력하세요.")
        return start,end,bool(self.empty_var.get())

    def accept(self):
        try:self.result=self.values()
        except ValueError as exc:self.error.set(str(exc));return
        self.destroy()

    @classmethod
    def ask(cls,parent,total,start=1,end=None,include_empty=True):
        previous_grab=parent.grab_current()
        dialog=cls(parent,total,start,end,include_empty)
        try:dialog.grab_set()
        except tk.TclError:pass
        parent.wait_window(dialog)
        try:
            if previous_grab is not None and previous_grab.winfo_exists():previous_grab.grab_set()
        except tk.TclError:pass
        return dialog.result


def waiting_member_fields(member):
    return (f"{member['slot'][1]}번",display_core_id(member['core_id']),member['direction'],member['cable_id']) if member else ('선택 필요',)*4


class WaitingPairConfirmDialog(workflow.ConnectionRouteDialog):
    def __init__(self,parent,left,right):
        super().__init__(parent,parent.store,parent.node_id,
                         [(display_core_id(left['core_id']),left['slot'],right['slot'])],
                         accept='최종 확인 · 연결')


class WaitingConnectionsDialog(workflow.RememberedToplevel):
    """Review exact cable/core pairs before making any local connections."""
    def __init__(self,parent,store,node_id):
        super().__init__(parent);self.parent=parent;self.store=store;self.node_id=node_id
        self._generation=getattr(store,'_view_generation',0);self._closing=False
        self._previous_grab=self.grab_current();self.transient(parent);self.grab_set()
        node=store.node(node_id);self.title(f"{node['name'] if node else '함체'} · 연결대기확인")
        self.geometry('1220x740');self.minsize(1040,650)
        ttk.Label(self,text='1번방향 ↔ 2번방향의 배정 코어를 확인하고, 가운데 화살표를 눌러 최종 연결하세요.',
                  padding=(10,10,10,3),font=('Malgun Gothic',10,'bold')).pack(fill='x')
        ttk.Label(self,text='함체는 각 케이블의 반대편 함체입니다. 후보가 여러 개면 두 방향을 직접 선택하세요. 같은 코어ID끼리만 연결합니다.',
                  padding=(10,0,10,6),foreground='#1769aa').pack(fill='x')
        tools=ttk.Frame(self,padding=(10,0,10,6));tools.pack(fill='x')
        ttk.Button(tools,text='연결 가능한 항목 전체 선택',command=lambda:self.select_all(True)).pack(side='left')
        ttk.Button(tools,text='전체 선택 해제',command=lambda:self.select_all(False)).pack(side='left',padx=6)
        ttk.Button(tools,text='새로고침',command=self.reload).pack(side='right')
        self.summary=tk.StringVar();ttk.Label(tools,textvariable=self.summary).pack(side='left',padx=12)
        box=ttk.Frame(self);box.pack(fill='both',expand=True,padx=10)
        columns=('check','core_id','left_direction','left_cable','left_core','right_direction','right_cable','right_core','review')
        self.tree=workflow.SortableTreeview(box,columns=columns,show='headings',selectmode='browse')
        self.tree.configure(displaycolumns=('check','core_id','review'))
        for key,label,width in zip(columns,('연결','코어ID','왼쪽 함체 방향','왼쪽 케이블ID / 규격','코어번호','오른쪽 함체 방향','오른쪽 케이블ID / 규격','코어번호','확인사항'),(48,150,160,180,65,160,180,65,230)):
            self.tree.heading(key,text=label);self.tree.column(key,width=width,minwidth=45,stretch=key not in ('check','left_core','right_core'),anchor='center' if key in ('check','left_core','right_core') else 'w')
        y=ttk.Scrollbar(box,orient='vertical',command=self.tree.yview);x=ttk.Scrollbar(box,orient='horizontal',command=self.tree.xview)
        self.tree.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        self.tree.grid(row=0,column=0,sticky='nsew');y.grid(row=0,column=1,sticky='ns');x.grid(row=1,column=0,sticky='ew')
        box.rowconfigure(0,weight=1);box.columnconfigure(0,weight=1)
        self.tree.tag_configure('choose',background='#fff3cd',foreground='#725500')
        self.tree.bind('<<TreeviewSelect>>',self.pick);self.tree.bind('<Button-1>',self.click_check);self.tree.bind('<space>',self.toggle_current)
        pairbox=ttk.Frame(self,padding=(10,8));pairbox.pack(fill='x');pairbox.columnconfigure(0,weight=1);pairbox.columnconfigure(2,weight=1)
        self.choice_vars={};self.detail_vars={};self.combos={};self.choice_maps={};self.field_vars={}
        for column,side,title in ((0,'left','1번방향'),(2,'right','2번방향')):
            frame=ttk.LabelFrame(pairbox,text=title,padding=10);frame.grid(row=0,column=column,sticky='nsew')
            var=tk.StringVar();self.choice_vars[side]=var
            combo=ttk.Combobox(frame,textvariable=var,state='readonly',width=48);combo.pack(fill='x')
            combo.bind('<<ComboboxSelected>>',lambda e,s=side:self.choose_pair(s));self.combos[side]=combo
            fields=ttk.Frame(frame,padding=(0,6));fields.pack(fill='x');fields.columnconfigure(1,weight=1)
            self.field_vars[side]=[tk.StringVar(value='선택 필요') for _ in range(4)]
            for row,(label,field) in enumerate(zip(('코어번호','코어ID','함체','케이블ID'),self.field_vars[side])):
                ttk.Label(fields,text=label,width=10).grid(row=row,column=0,sticky='w',pady=3)
                ttk.Label(fields,textvariable=field,wraplength=420,font=('Malgun Gothic',10,'bold')).grid(row=row,column=1,sticky='w',pady=3)
            details=tk.StringVar(value='위 목록에서 코어ID를 선택하세요.');self.detail_vars[side]=details
            ttk.Label(frame,textvariable=details,justify='left',wraplength=500,padding=(0,6,0,0)).pack(fill='x')
        self.arrow_button=ttk.Button(pairbox,text='↔\n연결 확인',command=self.confirm_active_pair,state='disabled',width=12)
        self.arrow_button.grid(row=0,column=1,padx=12)
        ttk.Button(pairbox,text='양방향 경로 보기',command=self.view_active_route).grid(row=1,column=1,pady=3)
        bottom=ttk.Frame(self,padding=10);bottom.pack(fill='x')
        self.message=tk.StringVar(value='가운데 ↔ 버튼을 누르면 두 방향의 최종 확인창이 열립니다. 여러 건은 체크 후 아래 버튼으로 연결할 수 있습니다.')
        ttk.Label(bottom,textvariable=self.message,foreground='#1769aa',wraplength=850).pack(side='left',fill='x',expand=True)
        self.apply_button=ttk.Button(bottom,text='최종 확인 · 선택 0건 연결',command=self.apply);self.apply_button.pack(side='right',padx=5)
        ttk.Button(bottom,text='닫기',command=self.destroy).pack(side='right')
        self.bind('<Escape>',lambda e:self.destroy());self.protocol('WM_DELETE_WINDOW',self.destroy)
        self.items={};self.active_item=None;self.reload()

    def current_store(self):
        if self.parent.current_store() and getattr(self.store,'_view_generation',0)==self._generation:return True
        return False

    def reload(self):
        if not self.current_store():return
        self.items={};self.active_item=None;self.tree.delete(*self.tree.get_children())
        for index,group in enumerate(self.store.waiting_connection_groups(self.node_id)):
            members=group['members'];slots=[r['slot'] for r in members]
            unique=len(slots)==2 and slots[0][0]!=slots[1][0]
            item={'core_id':group['core_id'],'members':{r['slot']:r for r in members},
                  'left':slots[0] if unique else None,'right':slots[1] if unique else None,'checked':False}
            iid=str(index);self.items[iid]=item;self.tree.insert('','end',iid=iid)
            self.render_row(iid)
        self.revision=self.store.data_revision();self.update_summary()
        if self.items:
            first=next(iter(self.items));self.tree.selection_set(first);self.tree.focus(first);self.pick()
        else:
            for side in ('left','right'):
                self.choice_vars[side].set('');self.combos[side].configure(values=());self.choice_maps[side]={}
                self.detail_vars[side].set('이 함체의 연결대기 코어가 없습니다.')
                for var in self.field_vars[side]:var.set('—')

    @staticmethod
    def pair_ready(item):
        return bool(item['left'] in item['members'] and item['right'] in item['members'] and item['left'][0]!=item['right'][0])

    def render_row(self,iid):
        item=self.items[iid];values=['☑' if item['checked'] else '□',display_core_id(item['core_id'])]
        for side in ('left','right'):
            member=item['members'].get(item[side])
            values.extend((member['direction'],member['cable_id']+' / '+member['spec'],f"{member['slot'][1]}번") if member else ('아래에서 선택','',''))
        ready=self.pair_ready(item)
        if not ready:note=f"후보 {len(item['members'])}개 · 양쪽 선택 필요"
        else:
            left=item['members'][item['left']];right=item['members'][item['right']]
            notes=[]
            if left['detail'].strip()!=right['detail'].strip():notes.append('양쪽 코어내역 다름')
            notes.extend(dict.fromkeys(m['status'] for m in (left,right) if m['status']))
            note=' · '.join(notes) or '양쪽 확인 후 연결'
        values.append(note);self.tree.item(iid,values=values,tags=() if ready else ('choose',))

    def update_summary(self):
        selected=sum(item['checked'] and self.pair_ready(item) for item in self.items.values())
        unresolved=sum(not self.pair_ready(item) for item in self.items.values())
        self.summary.set(f'연결대기 {len(self.items)}개 · 선택 {selected}건 · 양쪽 선택 필요 {unresolved}개')
        locked=workflow.node_locked(self.store,self.node_id)
        self.apply_button.configure(text=f'최종 확인 · 선택 {selected}건 연결',state='normal' if selected and not locked else 'disabled')
        item=self.items.get(self.active_item)
        self.arrow_button.configure(state='normal' if item and self.pair_ready(item) and not locked else 'disabled')
        if locked:self.message.set('함체가 잠겨 있습니다. 함체 창의 자물쇠를 해제하면 연결할 수 있습니다.')

    def pick(self,event=None):
        selected=self.tree.selection()
        if not selected or selected[0] not in self.items:return
        self.active_item=selected[0];self.render_choices();self.update_summary()

    def render_choices(self):
        if self.active_item not in self.items:return
        item=self.items[self.active_item];left=item['left']
        for side in ('left','right'):
            choices={}
            for index,(slot,member) in enumerate(item['members'].items(),1):
                if side=='right' and (left is None or slot[0]==left[0]):continue
                label=f"{index}. {member['direction']} 방향 | {member['cable_id']} / {member['spec']} | {slot[1]}번"
                choices[label]=slot
            self.choice_maps[side]=choices;self.combos[side].configure(values=tuple(choices))
            self.choice_vars[side].set(next((label for label,slot in choices.items() if slot==item[side]),''))
            member=item['members'].get(item[side])
            for var,value in zip(self.field_vars[side],waiting_member_fields(member)):var.set(value)
            self.detail_vars[side].set((f"규격: {member['spec']} · 신호: {member['signal']}\n코어내역: {member['detail'] or '(없음)'}\n상태: {member['status'] or '(없음)'}" if member else '연결할 코어를 선택하세요.'))

    def choose_pair(self,side):
        if self.active_item not in self.items:return
        item=self.items[self.active_item];item[side]=self.choice_maps[side].get(self.choice_vars[side].get())
        if side=='left' and item['right'] is not None and (item['left'] is None or item['left'][0]==item['right'][0]):item['right']=None
        item['checked']=self.pair_ready(item);self.render_row(self.active_item);self.render_choices();self.update_summary()

    def click_check(self,event):
        iid=self.tree.identify_row(event.y)
        if not iid or self.tree.identify_column(event.x)!='#1':return
        self.tree.selection_set(iid);self.tree.focus(iid);self.tree.focus_set();self.pick();self.toggle_current();return 'break'

    def toggle_current(self,event=None):
        selected=self.tree.selection()
        if not selected or selected[0] not in self.items:return 'break'
        iid=selected[0];item=self.items[iid]
        if not self.pair_ready(item):self.message.set('아래에서 1번방향·2번방향 배정 코어를 먼저 선택하세요.');return 'break'
        item['checked']=not item['checked'];self.render_row(iid);self.update_summary();return 'break'

    def select_all(self,checked):
        for iid,item in self.items.items():
            item['checked']=bool(checked and self.pair_ready(item));self.render_row(iid)
        self.update_summary()

    def view_active_route(self):
        if not self.current_store():return
        item=self.items.get(self.active_item)
        if item and self.pair_ready(item):
            workflow.ConnectionRouteDialog(self,self.store,self.node_id,[(item['core_id'],item['left'],item['right'])])

    def confirm_active_pair(self):
        if not self.current_store():return
        item=self.items.get(self.active_item)
        if not item or not self.pair_ready(item):return
        if workflow.node_locked(self.store,self.node_id):self.update_summary();return
        pair=(item['core_id'],item['left'],item['right'])
        dialog=WaitingPairConfirmDialog(self,item['members'][item['left']],item['members'][item['right']])
        self.wait_window(dialog)
        if dialog.accepted:self.apply([pair],reviewed=True)

    def apply(self,pairs=None,reviewed=False):
        if not self.current_store():return
        if pairs is None:pairs=[(item['core_id'],item['left'],item['right']) for item in self.items.values() if item['checked'] and self.pair_ready(item)]
        if not pairs:messagebox.showinfo('연결대기확인','연결할 항목을 선택하세요.',parent=self);return
        if not reviewed:
            dialog=workflow.ConnectionRouteDialog(self,self.store,self.node_id,pairs,accept='경로 확인 완료 · 선택 연결')
            self.wait_window(dialog)
            if not dialog.accepted:return
        args=(self.node_id,pairs,self.revision)
        try:
            # Validate the exact reviewed pairs on a copy before the normal backup.
            workflow.bulk_trial(self.store,'connect_waiting_pairs',args)
            if workflow.state(self.store)['options']['bulk_backup'] and str(self.store.path)!=':memory:':
                path=self.store.path.parent/'backup'/f"{self.store.path.stem}_waiting_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.sqlite3"
                self.store.backup_to(path)
            count=self.store.connect_waiting_pairs(*args)
        except (ValueError,sqlite3.Error,OSError) as error:
            messagebox.showwarning('연결하지 않음',str(error),parent=self);self.reload();return
        self.parent.reload_all();self.parent.parent.refresh();self.reload()
        self.message.set(f'{count}건 연결·저장 완료. 남은 연결대기를 확인하세요.')
        self.parent.msg.set(f'연결대기 {count}건을 최종 확인 후 연결·저장했습니다.')

    def destroy(self):
        if self._closing:return
        self._closing=True;previous=self._previous_grab
        super().destroy()
        try:
            if previous is not None and previous.winfo_exists():previous.grab_set()
        except tk.TclError:pass


def node_summary_rows(store,node_id,choices):
    """Group equal identities for display only; retain every physical splice."""
    cids=[cid for _,cid in choices]
    ranks={cid:i for i,cid in enumerate(cids)}
    def slot_order(slot):return ranks.get(slot[0],len(cids)),slot[1]
    rows={cid:{r['core_index']:dict(r) for r in store.cores(cid)} for cid in cids}
    linked=set();parts=[];is_end=store.is_local_terminal(node_id)
    node=store.node(node_id)
    exceptions=(json.loads(node['extra_json'] or '{}').get('assignmentExceptions') or {}) if node else {}
    def members(slots):return [rows[cid][idx] for cid,idx in slots if idx in rows.get(cid,{})]
    for sp in store.conn.execute('SELECT * FROM splices WHERE node_id=? ORDER BY rowid',(node_id,)):
        slots=tuple(sorted(((sp['cable1_id'],sp['core1_index']),(sp['cable2_id'],sp['core2_index'])),key=slot_order))
        linked.update(slots)
        if members(slots):parts.append(('연결',slots))
    for cid in cids:
        for idx,core in rows[cid].items():
            flags=workflow.statuses(core)
            used=bool(str(core['core_id'] or '').strip() or str(core['detail'] or '').strip() or flags-{'','unknown'} or str(core['signal'] or '') not in ('','unknown'))
            if (cid,idx) not in linked and used:
                state='완료' if workflow.core_exception_complete(store,(cid,idx)) else '집계 제외' if workflow.core_connection_exempt(core) else '해지' if 'cancel' in flags else '끊김' if 'broken' in flags else '끝단' if is_end else '예외' if exceptions.get(f'{cid}::{idx}') else '임시코어' if workflow.hamche_temporary_exempt(node,core) else '배정필요'
                parts.append((state,((cid,idx),)))
    groups={}
    for number,(state,slots) in enumerate(parts):
        ids={str(r['core_id'] or '').strip() for r in members(slots)}
        identity=next(iter(ids)) if len(ids)==1 else ''
        # Empty/temporary identities are neutral, not evidence of a common core.
        # A conflicting actual pair stays together so its mismatch is visible.
        key=('id',identity) if identity and not identity.startswith('임시-') else ('part',number)
        groups.setdefault(key,[]).append((state,slots))
    field=workflow.field_slot_mode(store);result=[]
    def number_text(slot):
        cid,idx=slot;row=rows.get(cid,{}).get(idx,{})
        return str(row.get('label') or idx) if str(cid).startswith('PORT:') else str(idx)
    def location(slot):
        cid,idx=slot;label=next((label for label,owner in choices if owner==cid),cid)
        return label.replace('\n',' · ')+f' [{number_text(slot)}]'
    for grouped in groups.values():
        slots=tuple(sorted({slot for _,pair in grouped for slot in pair},key=slot_order))
        items=members(slots);core=items[0];states=[];connections=[];mismatch=False
        for state,pair in grouped:
            paired=members(pair)
            conflict=state=='연결' and (workflow.field_slot_pair_mismatch(paired) if field else
                len({r['core_id'] for r in paired})>1 or len({r['detail'] for r in paired})>1)
            mismatch=mismatch or conflict
            actual='완료' if all(workflow.core_exception_complete(store,s) for s in pair) else '연결 확인필요' if conflict else state
            states.append(actual)
            connections.append(actual+' · '+(' ↔ '.join(location(slot) for slot in pair)))
        state=' / '.join(dict.fromkeys(states))
        cells=[' · '.join(number_text((cid,idx)) for idx in sorted({idx for owner,idx in slots if owner==cid})) for cid in cids]
        ids=list(dict.fromkeys(str(r['core_id'] or '') for r in items))
        names=list(dict.fromkeys(str(r['detail'] or '') for r in items))
        annotations=' / '.join(dict.fromkeys(t for r in items if (t:=workflow.core_status_text(store,r))))
        # V168: one signal for the whole core (every position of its ID).
        signals=workflow.core_signal_summary_label(store,items)
        bases=[workflow.field_slot_tag(store,r,core_row_tag(r)) for r in items]
        tag='summary_mismatch' if mismatch else 'dangling' if '배정필요' in states and 'used' in bases else bases[0]
        if all(base=='cancel' for base in bases):tag='cancel'
        # V168: a core with signal ON that is still not connected here is a yellow row.
        if signals=='ON' and '배정필요' in states:tag='core_issue'
        result.append(dict(iid='slots:'+json.dumps(sorted(slots),ensure_ascii=False,separators=(',',':')),
            slots=slots,core=core,tag=tag,connection=' | '.join(connections),
            values=(' ↔ '.join(display_core_id(v) or '(ID 없음)' for v in ids),
                    ' / '.join(v or '(코어명 없음)' for v in names) if len(names)>1 else names[0],
                    *cells,state,annotations,signals)))
    return sorted(result,key=lambda r:(not bool(r['core']['core_id']) or str(r['core']['core_id']).startswith('임시-'),str(r['core']['core_id'] or ''),min(s[1] for s in r['slots'])))


def node_pair_groups(store,node_id):
    """V190: splices at one enclosure grouped by the two cables they join.

    Returns [{'key','a','b','a_label','b_label','pairs':[(num_a,num_b),...]}] in
    the enclosure's cable order. Display only; nothing is written."""
    node=store.node(node_id);order=[];labels={};seen={}
    if node and node['type'] in ('rn','sub'):
        cid='PORT:'+node_id;order.append(cid);labels[cid]='RN 내부' if node['type']=='rn' else '가입자 내부'
    for cable in store.node_cables(node_id):
        # V191: 방향 이름은 케이블ID가 아니라 그 방향(반대편) 함체·시설 이름.
        name=store.opposite_name(cable,node_id)
        seen[name]=seen.get(name,0)+1
        labels[cable['id']]=name+(f' ({seen[name]}번선)' if seen[name]>1 else '');order.append(cable['id'])
    rank={cid:i for i,cid in enumerate(order)}
    def number(cid,idx):
        if str(cid).startswith('PORT:'):
            row=store.core(cid,idx)
            if row and 'label' in row.keys() and str(row['label'] or '').strip():return str(row['label']).strip()
        return int(idx)
    groups={}
    for sp in store.conn.execute('SELECT * FROM splices WHERE node_id=? ORDER BY rowid',(node_id,)):
        a=(sp['cable1_id'],int(sp['core1_index']));b=(sp['cable2_id'],int(sp['core2_index']))
        if (rank.get(a[0],len(order)),a[0],a[1])>(rank.get(b[0],len(order)),b[0],b[1]):a,b=b,a
        key=(a[0],b[0])
        group=groups.setdefault(key,dict(key=key,a=a[0],b=b[0],a_label=labels.get(a[0],str(a[0])),b_label=labels.get(b[0],str(b[0])),pairs=[]))
        group['pairs'].append((number(*a),number(*b)))
    def sort_number(value):return (0,value,'') if isinstance(value,int) else (1,0,str(value))
    for group in groups.values():group['pairs'].sort(key=lambda p:(sort_number(p[0]),sort_number(p[1])))
    return sorted(groups.values(),key=lambda g:(rank.get(g['a'],len(order)),rank.get(g['b'],len(order)),g['a'],g['b']))


def node_pair_grid(groups,per_row=0,swapped=(),sort_bottom=()):
    """V190: two-line blocks (위 = A 방향, 아래 = 접속된 B 방향), a blank line
    between blocks. V191: per_row 0 (default) keeps one direction on one line.
    Returns a list of (group_index,cells); blank lines are (None,[])."""
    rows=[]
    for index,group in enumerate(groups):
        top,bottom=group['a_label'],group['b_label'];pairs=list(group['pairs'])
        if group['key'] in swapped:top,bottom=bottom,top;pairs=[(b,a) for a,b in pairs]
        # 기본은 위 줄 번호순, 「정렬 기준 바꾸기」를 누른 쌍은 아래 줄 번호순.
        first=1 if group['key'] in sort_bottom else 0
        pairs.sort(key=lambda p:tuple((0,v,'') if isinstance(v,int) else (1,0,str(v)) for v in (p[first],p[1-first])))
        size=int(per_row or 0) if int(per_row or 0)>0 else max(1,len(pairs))
        for start in range(0,len(pairs),size):
            chunk=pairs[start:start+size]
            if rows:rows.append((None,[]))
            rows.append((index,[f'{top} 방향',*[a for a,_ in chunk]]))
            rows.append((index,[f'{bottom} 방향',*[b for _,b in chunk]]))
    return rows


def node_pair_numbers_text(rows):
    """V192: numbers only (no 방향 name), comma joined, one line per row."""
    return '\n'.join(','.join(str(v) for v in cells[1:]) for _,cells in rows if len(cells)>1)


def node_pair_tsv(rows):
    """Tab separated text that pastes into Excel one value per cell."""
    return ''.join('\t'.join(str(v) for v in cells)+'\n' for _,cells in rows)


class NodeSummaryDialog(workflow.RememberedToplevel):
    """함체에서 보는 원본 V83식 코어내역 요약표.

    쿼리 결과를 한 번에 메모리로 가져와 표를 만들기 때문에 144C 여러 가닥이
    연결된 함체에서도 셀마다 DB를 다시 조회하지 않는다.
    """
    def __init__(self,parent,store,node_id):
        super().__init__(parent);self.parent=parent;self.store=store;self.node_id=node_id;self.row_slots={};self.row_values={};self.row_connections={}
        node=store.node(node_id);self.title(f'{node["name"]} · 함체 코어내역');self.geometry("1450x780")
        top=ttk.Frame(self,padding=8);top.pack(fill="x")
        ttk.Label(top,text='같은 코어ID는 한 행에 표시합니다. 실제 접속은 연결 구분에서 확인하세요. · 제목 클릭: ▲ → ▼ → 기본 순서').pack(side='left')
        ttk.Button(top,text="새로고침",command=self.reload).pack(side="right",padx=3)
        ttk.Button(top,text="전체 표 복사",command=self.copy_table).pack(side="right",padx=3)
        ttk.Button(top,text='코어 연결도',command=lambda:open_detail_dialog(self,self.store,'diagram',self.node_id)).pack(side='right',padx=3)
        ttk.Button(top,text='V2 보기 (두 줄 쌍)',command=lambda:NodePairSummaryDialog(self.parent,self.store,self.node_id)).pack(side='right',padx=3)
        box=ttk.Frame(self);box.pack(fill="both",expand=True,padx=8)
        style=ttk.Style(self);style.configure('NodeSummary.Treeview',rowheight=28);style.configure('NodeSummary.Treeview.Heading',padding=(5,7),font=('Malgun Gothic',9,'bold'))
        self.tree=workflow.SortableTreeview(box,show="headings",selectmode="browse",style='NodeSummary.Treeview')
        ys=ttk.Scrollbar(box,orient="vertical",command=self.tree.yview);xs=ttk.Scrollbar(box,orient="horizontal",command=self.tree.xview)
        self.tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set);self.tree.grid(row=0,column=0,sticky="nsew");ys.grid(row=0,column=1,sticky="ns");xs.grid(row=1,column=0,sticky="ew");box.rowconfigure(0,weight=1);box.columnconfigure(0,weight=1)
        self.tree.bind("<<TreeviewSelect>>",self.pick)
        self.connection_info=tk.StringVar(value='행을 선택하면 케이블별 코어번호와 실제 연결을 아래에 표시합니다.')
        ttk.Label(self,textvariable=self.connection_info,padding=(10,8),foreground='#1769aa',wraplength=1380).pack(fill='x')
        form=ttk.LabelFrame(self,text="선택한 코어 위치 수정",padding=8);form.pack(fill="x",padx=8,pady=8);self.vars=[tk.StringVar() for _ in range(5)]
        self._picked_iid=None;self._edit_slot=None;self._edit_slots=[]
        ttk.Label(form,text='수정 위치').grid(row=0,column=0,sticky='e')
        self.slot_choice=ttk.Combobox(form,state='readonly',width=65)
        self.slot_choice.grid(row=0,column=1,columnspan=7,sticky='w',padx=3,pady=(0,8))
        self.slot_choice.bind('<<ComboboxSelected>>',self.pick_slot)
        hint='신호 변경은 선택 위치와 이 함체의 실제 접속 상대에 반영됩니다.' if workflow.field_slot_mode(store) else '수정 위치를 선택하면 해당 코어의 현재 값을 불러옵니다.'
        ttk.Label(form,text=hint).grid(row=0,column=8,columnspan=4,sticky='w')
        for i,(label,var) in enumerate(zip(("코어ID","코어명","상태1","상태2","신호"),self.vars)):
            if i in (2,3):continue
            ttk.Label(form,text=label).grid(row=1,column=i*2,sticky="e",padx=2)
            if i<2:ttk.Entry(form,textvariable=var,width=20).grid(row=1,column=i*2+1,padx=3)
            else:ttk.Combobox(form,textvariable=var,values=SIGNAL_VALUES if i==4 else CORE_STATUS_VALUES,state="readonly",width=10).grid(row=1,column=i*2+1,padx=3)
        ttk.Button(form,text="상태",command=self.edit_annotations).grid(row=1,column=4,columnspan=4,padx=6)
        ttk.Button(form,text="선택 위치에 반영",command=self.apply).grid(row=1,column=10,padx=8)
        ttk.Button(form,text="배정필요 예외/해제",command=self.toggle_exception).grid(row=1,column=11,padx=3)
        self.reload()

    def _choices(self):
        pairs=[];seen={}
        for cable in self.store.node_cables(self.node_id):
            label=f"{clean_cable_id(cable['cable_id']) or '(ID 없음)'} / {cable['spec'] or str(cable['size'])+'C'}\n상대: {self.store.opposite_name(cable,self.node_id)}"
            seen[label]=seen.get(label,0)+1
            if seen[label]>1:label+=f' ({seen[label]}번선)'
            pairs.append((label,cable['id']))
        n=self.store.node(self.node_id)
        if n and n["type"] in ("rn","sub"):pairs=[("RN 내부 / 포트" if n["type"]=="rn" else "가입자 내부 / 포트","PORT:"+self.node_id)]+pairs
        return pairs

    def reload(self):
        selected=self.selected_slot();view=self.tree.yview()
        choices=self._choices();cids=[cid for _,cid in choices];safe=[f"c{i}" for i in range(len(cids))];columns=('id','detail',*safe,'state','s1','signal')
        self.tree.configure(columns=columns,displaycolumns=columns)
        labels=('코어ID','코어명',*[label for label,_ in choices],'연결 구분','상태','신호');widths=(170,260,*([185]*len(safe)),160,220,80)
        for col,label,width in zip(columns,labels,widths):self.tree.heading(col,text=label);self.tree.column(col,width=width,minwidth=width,anchor='w' if col in ('id','detail','s1') else 'center',stretch=col=='detail')
        entries=node_summary_rows(self.store,self.node_id,choices)
        self.tree.delete(*self.tree.get_children());self.row_slots.clear();self.row_values.clear();self.row_connections.clear()
        for entry in entries:
            iid=entry['iid']
            self.tree.insert('', 'end',iid=iid,values=entry['values'],tags=(entry['tag'],))
            self.row_slots[iid]=entry['slots'];self.row_values[iid]=entry['core'];self.row_connections[iid]=entry['connection']
        configure_core_tags(self.tree);self.tree.tag_configure('summary_mismatch',background='#fff3cd',foreground='#725500')
        self._picked_iid=next((iid for iid,slots in self.row_slots.items() if selected in slots),None)
        if self._picked_iid:
            self._set_edit_choices(self._picked_iid,selected)
            self.tree.selection_set(self._picked_iid);self.tree.focus(self._picked_iid)
            self.connection_info.set(self.row_connections[self._picked_iid])
        else:
            self._edit_slot=None;self._edit_slots=[];self.slot_choice.configure(values=());self.slot_choice.set('')
            for var in self.vars:var.set('')
            self.connection_info.set(f'전체 {len(entries)}행 · 케이블/포트 {len(cids)}열. 행을 선택하면 실제 연결을 확인할 수 있습니다.')
        if view:self.tree.yview_moveto(view[0])
        self._shared_rows_stamp=(self.store.data_revision(),self.store.conn.total_changes)

    def refresh_shared_rows(self):
        if 'row_slots' not in self.__dict__:return
        stamp=(self.store.data_revision(),self.store.conn.total_changes)
        if getattr(self,'_shared_rows_stamp',None)!=stamp:self.reload()

    def selected_slot(self):
        selection=self.tree.selection()
        slots=self.row_slots.get(selection[0],()) if selection else ()
        return self._edit_slot if self._edit_slot in slots else slots[0] if slots else None

    def _set_edit_choices(self,iid,preferred=None):
        self._edit_slots=list(self.row_slots[iid]);labels=dict((cid,label.replace('\n',' · ')) for label,cid in self._choices())
        values=[]
        for cid,idx in self._edit_slots:
            row=self.store.core(cid,idx)
            number=str(row['label'] or idx) if cid.startswith('PORT:') and row and 'label' in row.keys() else str(idx)
            values.append(f"{labels.get(cid,cid)} [{number}]")
        self.slot_choice.configure(values=values)
        index=self._edit_slots.index(preferred) if preferred in self._edit_slots else 0
        self.slot_choice.current(index);self._edit_slot=self._edit_slots[index]

    def pick(self,event=None):
        if not self.tree.selection():return
        iid=self.tree.selection()[0]
        if iid not in self.row_slots:return
        self.connection_info.set(self.row_connections[iid])
        if iid==self._picked_iid:return
        self._picked_iid=iid;self._set_edit_choices(iid);self.pick_slot()

    def pick_slot(self,event=None):
        index=self.slot_choice.current()
        if not 0<=index<len(self._edit_slots):return
        self._edit_slot=self._edit_slots[index];row=self.store.core(*self._edit_slot)
        if not row:return
        values=(display_core_id(row['core_id']),row['detail'],status_label(row['status1']),status_label(row['status2']),signal_label(row['signal']))
        for var,value in zip(self.vars,values):var.set(value)

    def apply(self):
        slot=self.selected_slot()
        if slot is None:messagebox.showinfo("선택 필요","수정할 코어 행과 위치를 선택하세요.",parent=self);return
        old=self.store.core(*slot)
        if not old:self.reload();return
        new_id=self.vars[0].get().strip()
        if new_id=="임시코어":new_id=str(old['core_id'] or '')
        if not confirm_temporary_identity(self,self.store,slot[0],[(slot[1],new_id)]):return
        signal=SIGNAL_FROM_LABEL.get(self.vars[4].get(),'')
        try:
            with self.store.action('함체 코어내역 수정'):
                if workflow.field_slot_mode(self.store):
                    # Only an intentional signal edit affects the actual local peer.
                    if signal!=old['signal']:workflow.field_signal_at_node(self.store,self.node_id,slot,signal)
                    self.store.update_core(*slot,[new_id,self.vars[1].get(),old['status1'],old['status2'],signal])
                else:self.store.update_core(*slot,[new_id,self.vars[1].get(),old['status1'],old['status2'],signal])
        except ValueError as e:messagebox.showerror("수정하지 않음",str(e),parent=self);return
        self.reload();self.parent.reload_all();self.parent.parent.refresh()

    def copy_table(self):
        columns=self.tree['columns'];output=io.StringIO();writer=csv.writer(output,delimiter='\t',lineterminator='\n')
        writer.writerow(self.tree.heading_text(c).replace('\n',' · ') for c in columns)
        writer.writerows(self.tree.item(i,'values') for i in self.tree.get_children())
        self.clipboard_clear();self.clipboard_append(output.getvalue());self.update()

    def edit_annotations(self):
        slot=self.selected_slot()
        if slot is None:return
        workflow.AnnotationDialog(self,self.store,slot,lambda:(self.reload(),self.parent.reload_all(),self.parent.parent.refresh()))

    def toggle_exception(self):
        slot=self.selected_slot()
        if slot is None:messagebox.showinfo("선택 필요","배정필요/예외 코어 위치를 선택하세요.",parent=self);return
        row=self.store.core(*slot)
        if not row:return
        if workflow.is_exception(row):messagebox.showinfo("완료 처리","아래 '상태' 버튼에서 예외코어 항목을 제거하면 실제 연결 상태로 다시 계산합니다.",parent=self);return
        if self.store.splice_for(self.node_id,*slot) or self.store.is_local_terminal(self.node_id) or workflow.statuses(row)&{'cancel','broken'}:
            messagebox.showinfo("예외 처리","선택 위치가 배정필요/예외 상태일 때 사용할 수 있습니다.",parent=self);return
        try:self.store.toggle_assignment_exception(self.node_id,*slot)
        except ValueError as e:messagebox.showerror("수정하지 않음",str(e),parent=self);return
        self.reload();self.parent.parent.refresh()


class NodePairSummaryDialog(workflow.RememberedToplevel):
    """V190 함체 코어내역 V2: 접속된 두 케이블을 두 줄 한 쌍으로 보여 주고
    Excel에 칸이 맞게 붙도록 탭 구분으로 복사한다. 보기 전용."""
    def __init__(self,parent,store,node_id):
        super().__init__(parent);self.parent=parent;self.store=store;self.node_id=node_id
        self.groups=[];self.grid_rows=[];self.row_group={};self.swapped=set();self.sort_bottom=set()
        node=store.node(node_id);self.title(f'{node["name"] if node else "함체"} · 함체 코어내역 V2');self.geometry('980x700')
        top=ttk.Frame(self,padding=8);top.pack(fill='x')
        ttk.Label(top,text='접속된 두 방향을 두 줄 한 쌍으로 표시합니다(방향 = 반대편 함체). 위 줄 번호와 바로 아래 번호가 이 함체에서 서로 접속된 코어입니다.',foreground='#1769aa').pack(side='left')
        tools=ttk.Frame(self,padding=(8,0,8,6));tools.pack(fill='x')
        self.copy_button=ttk.Button(tools,text='Excel용 전체 복사',style='Primary.TButton',command=self.copy_all);self.copy_button.pack(side='left')
        ttk.Button(tools,text='선택 행 숫자 복사 (1,2,3)',command=self.copy_numbers).pack(side='left',padx=(12,3))
        ttk.Button(tools,text='선택 쌍만 복사',command=self.copy_selected).pack(side='left',padx=3)
        ttk.Button(tools,text='선택 쌍 위·아래 바꾸기',command=self.swap_selected).pack(side='left',padx=(12,3))
        ttk.Button(tools,text='선택 쌍 정렬 기준 바꾸기',command=self.toggle_sort_selected).pack(side='left',padx=3)
        ttk.Button(tools,text='새로고침',command=self.reload).pack(side='right',padx=3)
        ttk.Button(tools,text='기존 함체 코어내역',command=lambda:NodeSummaryDialog(self.parent,self.store,self.node_id)).pack(side='right',padx=3)
        box=ttk.Frame(self);box.pack(fill='both',expand=True,padx=8)
        style=ttk.Style(self);style.configure('NodePair.Treeview',rowheight=26)
        self.tree=ttk.Treeview(box,show='headings',selectmode='extended',style='NodePair.Treeview')
        ys=ttk.Scrollbar(box,orient='vertical',command=self.tree.yview);xs=ttk.Scrollbar(box,orient='horizontal',command=self.tree.xview)
        self.tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set);self.tree.grid(row=0,column=0,sticky='nsew');ys.grid(row=0,column=1,sticky='ns');xs.grid(row=1,column=0,sticky='ew')
        box.rowconfigure(0,weight=1);box.columnconfigure(0,weight=1)
        self.tree.tag_configure('pair_top',background='#eef5ff');self.tree.tag_configure('pair_bottom',background='#ffffff')
        self.tree.tag_configure('pair_gap',background='#f4f4f4')
        self.tree.bind('<Control-c>',lambda e:self.copy_numbers())
        self.info=tk.StringVar();ttk.Label(self,textvariable=self.info,padding=(10,8),foreground='#555').pack(fill='x')
        self.reload()

    def reload(self):
        selected=self.selected_group_key()
        self.groups=node_pair_groups(self.store,self.node_id)
        self.grid_rows=node_pair_grid(self.groups,0,self.swapped,self.sort_bottom)
        count=max([len(cells)-1 for _,cells in self.grid_rows]+[1])
        columns=('dir',*[f'n{i}' for i in range(1,count+1)])
        self.tree.configure(columns=columns,displaycolumns=columns)
        self.tree.heading('dir',text='방향 (반대편 함체)');self.tree.column('dir',width=200,minwidth=140,anchor='w',stretch=False)
        for i in range(1,count+1):self.tree.heading(f'n{i}',text=str(i));self.tree.column(f'n{i}',width=70,minwidth=50,anchor='e',stretch=False)
        self.tree.delete(*self.tree.get_children());self.row_group.clear();top=True;pick=None
        for number,(group,cells) in enumerate(self.grid_rows):
            iid=f'r{number}'
            if group is None:self.tree.insert('','end',iid=iid,values=('',),tags=('pair_gap',));top=True;continue
            self.tree.insert('','end',iid=iid,values=tuple(cells),tags=('pair_top' if top else 'pair_bottom',));top=not top
            self.row_group[iid]=group
            if pick is None and self.groups[group]['key']==selected:pick=iid
        if pick:self.tree.selection_set(pick);self.tree.see(pick)
        total=sum(len(g['pairs']) for g in self.groups)
        self.info.set(f'접속 쌍 {len(self.groups)}개 · 접속 {total}개 · 한 방향은 한 줄로 표시. 「Excel용 전체 복사」 후 Excel 칸 하나를 클릭하고 Ctrl+V 하세요.' if self.groups else '이 함체에는 아직 접속된 코어가 없습니다.')
        self._shared_rows_stamp=(self.store.data_revision(),self.store.conn.total_changes)

    def refresh_shared_rows(self):
        stamp=(self.store.data_revision(),self.store.conn.total_changes)
        if getattr(self,'_shared_rows_stamp',None)!=stamp:self.reload()

    def selected_group_key(self):
        selection=self.tree.selection() if hasattr(self,'tree') else ()
        group=self.row_group.get(selection[0]) if selection else None
        return self.groups[group]['key'] if group is not None and group<len(self.groups) else None

    def copy_numbers(self):
        rows=[self.grid_rows[int(iid[1:])] for iid in self.tree.selection() if iid in self.row_group]
        text=node_pair_numbers_text(rows)
        if not text:messagebox.showinfo('선택 필요','숫자를 복사할 줄을 먼저 클릭하세요. Ctrl이나 Shift를 누르고 여러 줄을 고를 수 있습니다.',parent=self);return
        self._clip(text,f'선택한 {len(rows)}줄의 숫자를 복사했습니다(예: 1,2,3). 붙여넣으면 쉼표로 이어져 나옵니다.')

    def _clip(self,text,message):
        self.clipboard_clear();self.clipboard_append(text);self.update();self.info.set(message)

    def copy_all(self):
        if not self.grid_rows:messagebox.showinfo('복사할 내용 없음','이 함체에는 접속된 코어가 없습니다.',parent=self);return
        self._clip(node_pair_tsv(self.grid_rows),f'{len(self.groups)}개 접속 쌍을 복사했습니다. Excel 칸 하나를 클릭하고 Ctrl+V 하세요.')

    def copy_selected(self):
        key=self.selected_group_key()
        if key is None:messagebox.showinfo('선택 필요','복사할 쌍의 줄을 먼저 클릭하세요.',parent=self);return
        index=next(i for i,g in enumerate(self.groups) if g['key']==key)
        rows=[row for row in self.grid_rows if row[0]==index]
        self._clip(node_pair_tsv(rows),'선택한 쌍을 복사했습니다. Excel에서 Ctrl+V 하세요.')

    def swap_selected(self):
        key=self.selected_group_key()
        if key is None:messagebox.showinfo('선택 필요','위·아래를 바꿀 쌍의 줄을 먼저 클릭하세요.',parent=self);return
        self.swapped^={key};self.reload()

    def toggle_sort_selected(self):
        key=self.selected_group_key()
        if key is None:messagebox.showinfo('선택 필요','정렬 기준을 바꿀 쌍의 줄을 먼저 클릭하세요.',parent=self);return
        self.sort_bottom^={key};self.reload()


class BulkTableConnectDialog(workflow.RememberedToplevel):
    """Accept either cable columns alone or the original sheet's six leading fields."""
    def __init__(self,parent,store,node_id):
        super().__init__(parent);self.parent=parent;self.store=store;self.node_id=node_id;node=store.node(node_id)
        self.title(f'{node["name"] if node else "함체"} · Excel표 일괄연결');self.geometry("1100x720");self.transient(parent);self.grab_set()
        cables=[c for c in store.node_cables(node_id) if str(c["spec"] or "").strip()!="드랍"]
        has_port=bool(node and node["type"] in ("rn","sub"));self.col_count=max(3,min(8,len(cables)+(1 if has_port else 0)))
        self.row_count=max(80,min(1000,max((int(c["size"]) for c in cables),default=144)+1));self.max_columns=26
        self.data=[[""]*self.col_count for _ in range(self.row_count)];self.active_cell=(0,0);self.editor=None;self.editor_cell=None
        ttk.Label(self,text="Excel에서 범위를 그대로 복사한 뒤 A1을 클릭하고 Ctrl+V하세요.",padding=(10,10,10,2),foreground="#1769aa",font=("Malgun Gothic",10,"bold")).pack(fill="x")
        ttk.Label(self,text="1행 제목을 포함하세요. 원본표: 코어ID / 코어명 / 회선번호 / 회선명 / 가입자명 / 중요여부 / 케이블ID…\n뒤쪽 케이블 열에는 코어번호를 입력합니다. 임시코어에 ID·이름을 반영하며, 회선번호~중요여부는 참고용입니다.",padding=(10,2,10,5)).pack(fill="x")
        format_bar=ttk.Frame(self,padding=(10,0,10,5));format_bar.pack(fill='x')
        ttk.Label(format_bar,text='표 형식').pack(side='left');self.format_var=tk.StringVar(value='자동 판별')
        format_combo=ttk.Combobox(format_bar,textvariable=self.format_var,state='readonly',values=('자동 판별','원본표 (앞 6열 정보)','기존 케이블표'),width=27)
        format_combo.pack(side='left',padx=6);format_combo.bind('<<ComboboxSelected>>',lambda e:self._configure_columns())
        ttk.Label(format_bar,text='기존 케이블표도 사용 가능 · 원본표의 코어번호 한 칸은 정보만 입력',foreground='#666').pack(side='left',padx=8)
        tools=ttk.Frame(self,padding=(10,0,10,6));tools.pack(fill="x")
        ttk.Button(tools,text="Excel 전체표 붙여넣기 (A1)",command=self.paste_from_a1).pack(side="left")
        ttk.Button(tools,text="열 추가",command=self.add_column).pack(side="left",padx=(8,3));ttk.Button(tools,text="마지막 열 삭제",command=self.remove_column).pack(side="left",padx=3)
        ttk.Button(tools,text="행 10개 추가",command=self.add_rows).pack(side="left",padx=(8,3))
        ttk.Button(tools,text="표 전체 지우기",command=self.clear_all).pack(side="left",padx=8)
        ttk.Label(tools,text="제목 클릭: ▲ → ▼ → 기본 · 붙여넣기: 원래 행번호 기준",foreground="#666").pack(side="right")
        frame=ttk.Frame(self);frame.pack(fill="both",expand=True,padx=10)
        style=ttk.Style(self);style.configure("Excel.Treeview",rowheight=24)
        self.tree=workflow.SortableTreeview(frame,pinned_items=("1",),before_sort=self._commit_editor,editor_active=lambda:bool(self.editor),columns=self._column_ids(),show="tree headings",selectmode="browse",style="Excel.Treeview")
        ys=ttk.Scrollbar(frame,orient="vertical",command=self.tree.yview);xs=ttk.Scrollbar(frame,orient="horizontal",command=self.tree.xview);self.tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set)
        self.tree.grid(row=0,column=0,sticky="nsew");ys.grid(row=0,column=1,sticky="ns");xs.grid(row=1,column=0,sticky="ew");frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        self.tree.bind("<Button-1>",self.select_cell);self.tree.bind("<Double-Button-1>",self.begin_edit)
        self.tree.bind("<Control-v>",self.paste_excel);self.tree.bind("<Control-V>",self.paste_excel);self.tree.bind("<Shift-Insert>",self.paste_excel);self.tree.bind("<Delete>",self.clear_cell)
        # Windows에서 셀을 클릭해도 Treeview의 행 포커스만 바뀌고 키보드
        # 포커스가 표 밖에 남는 경우가 있다. 팝업 단계에서도 Ctrl+V를
        # 받아 같은 붙여넣기 함수로 보내면 A1 클릭 뒤 즉시 붙여넣을 수 있다.
        self.bind("<Control-v>",self.paste_excel);self.bind("<Control-V>",self.paste_excel);self.bind("<Shift-Insert>",self.paste_excel)
        output=ttk.LabelFrame(self,text='오류 목록 · 더블클릭하면 오류이유 전체 보기',padding=4);output.pack(fill='x',padx=10,pady=(5,0))
        self.output_tree=workflow.SortableTreeview(output,columns=('id','detail','reason'),show='headings',height=4)
        for key,label,width in (('id','코어ID',160),('detail','코어내역',220),('reason','오류이유',680)):
            self.output_tree.heading(key,text=label);self.output_tree.column(key,width=width,minwidth=50)
        out_scroll=ttk.Scrollbar(output,orient='vertical',command=self.output_tree.yview);self.output_tree.configure(yscrollcommand=out_scroll.set)
        self.output_tree.pack(side='left',fill='x',expand=True);out_scroll.pack(side='right',fill='y')
        workflow.style_error_table(self.output_tree);self.output_tree.bind('<Double-Button-1>',self.show_result)
        bottom=ttk.Frame(self,padding=10);bottom.pack(fill="x");ttk.Button(bottom,text="검사 후 연결·정보 입력",command=self.run).pack(side="right");ttk.Button(bottom,text="닫기",command=self.destroy).pack(side="right",padx=5)
        self.result=tk.StringVar(value="기존 연결도 임시코어 정보 입력 가능 · 서로 다른 실제 코어ID는 적용하지 않습니다.");self.result_label=ttk.Label(bottom,textvariable=self.result,foreground="#555",wraplength=660);self.result_label.pack(side="left")
        self._configure_columns();self.reload_grid();self.tree.selection_set("1");self.tree.focus("1")
        self.bind("<Control-Return>",lambda e:self.run());self.update_idletasks();self._center();self.tree.focus_force()

    def _center(self):
        workflow.center_popup(self,self.parent)

    def _column_name(self,index):
        name="";number=index+1
        while number:name=chr(65+(number-1)%26)+name;number=(number-1)//26
        return name

    def _column_ids(self):return tuple(f"c{i}" for i in range(self.col_count))

    def _source_format(self):
        choice=self.format_var.get()
        if choice!='자동 판별':return choice=='원본표 (앞 6열 정보)'
        header=[re.sub(r'[\s_]+','',str(x)).casefold() for x in self.data[0][:2]]
        return len(header)==2 and header[0] in ('코어id','coreid') and header[1] in ('코어명','코어내역','코어이름','corename','coredetail')

    def _configure_columns(self):
        self.tree.configure(columns=self._column_ids());self.tree.heading("#0",text="행");self.tree.column("#0",width=48,minwidth=48,stretch=False,anchor="center")
        fields=('코어ID','코어명','회선번호','회선명','가입자명','중요여부');source=self._source_format()
        for i,cid in enumerate(self._column_ids()):
            heading=self._column_name(i)+(f' · {fields[i]}' if source and i<6 else '')
            self.tree.heading(cid,text=heading);self.tree.column(cid,width=145,minwidth=90,stretch=True,anchor="center")
        self.tree.tag_configure("header",background="#dce9f9",foreground="#123b66",font=("Malgun Gothic",9,"bold"))

    def reload_grid(self):
        selected=self.active_cell;self.tree.delete(*self.tree.get_children())
        for row,values in enumerate(self.data,1):self.tree.insert("","end",iid=str(row),text=str(row),values=values,tags=("header",) if row==1 else ())
        iid=str(selected[0]+1)
        if self.tree.exists(iid):self.tree.selection_set(iid);self.tree.focus(iid);self.tree.see(iid)

    def select_cell(self,event):
        iid=self.tree.identify_row(event.y);column=self.tree.identify_column(event.x)
        if iid and column.startswith("#") and column!="#0":
            self.active_cell=(int(iid)-1,int(column[1:])-1);self.tree.selection_set(iid);self.tree.focus(iid);self.tree.focus_set()

    def begin_edit(self,event=None):
        if event is not None:self.select_cell(event)
        row,col=self.active_cell;iid=str(row+1);column=f"#{col+1}"
        if not self.tree.exists(iid):return "break"
        self.tree.see(iid);self.update_idletasks();box=self.tree.bbox(iid,column)
        if not box:return "break"
        if self.editor:self._commit_editor()
        x,y,w,h=box;self.editor=ttk.Entry(self.tree);self.editor_cell=(row,col);self.editor.insert(0,self.data[row][col]);self.editor.select_range(0,"end");self.editor.place(x=x,y=y,width=w,height=h);self.editor.focus_force()
        self.editor.bind("<Return>",lambda e:self._commit_editor(1,0));self.editor.bind("<Tab>",lambda e:self._commit_editor(0,1));self.editor.bind("<Escape>",self._cancel_editor);self.editor.bind("<FocusOut>",lambda e:self._commit_editor())
        self.editor.bind("<Control-v>",self.paste_excel);self.editor.bind("<Control-V>",self.paste_excel);self.editor.bind("<Shift-Insert>",self.paste_excel)
        return "break"

    def _commit_editor(self,move_row=0,move_col=0):
        if not self.editor:return "break"
        row,col=self.editor_cell or self.active_cell;value=self.editor.get().strip();editor=self.editor;self.editor=None;self.editor_cell=None;editor.destroy();self.data[row][col]=value;self.tree.item(str(row+1),values=self.data[row])
        if move_row or move_col:
            self.active_cell=(min(self.row_count-1,max(0,row+move_row)),min(self.col_count-1,max(0,col+move_col)));self.tree.selection_set(str(self.active_cell[0]+1));self.tree.see(str(self.active_cell[0]+1));self.after_idle(self.begin_edit)
        return "break"

    def _cancel_editor(self,event=None):
        if self.editor:editor=self.editor;self.editor=None;self.editor_cell=None;editor.destroy()
        return "break"

    def _grow_columns(self,needed):
        if needed>self.max_columns:raise ValueError(f"최대 {self.max_columns}열까지 붙여넣을 수 있습니다.")
        while self.col_count<needed:
            self.col_count+=1
            for row in self.data:row.append("")
        self._configure_columns()

    def _grow_rows(self,needed):
        if needed>1000:raise ValueError("최대 1000행까지 붙여넣을 수 있습니다.")
        while self.row_count<needed:self.data.append([""]*self.col_count);self.row_count+=1

    def paste_from_a1(self):
        if self.editor:self._commit_editor()
        self.active_cell=(0,0);return self.paste_excel()

    def paste_excel(self,event=None):
        try:raw=self.clipboard_get()
        except tk.TclError:messagebox.showinfo("Excel 붙여넣기","클립보드에 붙여넣을 표가 없습니다.",parent=self);return "break"
        if self.editor:
            start_cell=self.editor_cell or self.active_cell
            if "\t" not in raw and "\n" not in raw and "\r" not in raw:return None
            self._cancel_editor();self.active_cell=start_cell
        try:cells=list(csv.reader(io.StringIO(raw,newline=''),delimiter='\t',strict=True))
        except csv.Error as exc:messagebox.showerror('Excel 붙여넣기',f'표 형식을 읽지 못했습니다: {exc}',parent=self);return 'break'
        while cells and not any(cells[-1]):cells.pop()
        if not cells:return "break"
        start_row,start_col=self.active_cell
        self.tree.reset_sort()
        if start_col+max(len(row) for row in cells)>self.max_columns or start_row+len(cells)>1000:
            messagebox.showerror('붙여넣기 범위',f'최대 1000행 × {self.max_columns}열까지 가능합니다. 기존 표는 유지됩니다.',parent=self);return 'break'
        try:self._grow_columns(start_col+max(len(row) for row in cells));self._grow_rows(start_row+len(cells))
        except ValueError as e:messagebox.showerror("붙여넣기 범위",str(e),parent=self);return "break"
        if (start_row,start_col)==(0,0) and (len(cells)>1 or len(cells[0])>1):self.data=[[""]*self.col_count for _ in range(self.row_count)]
        for r,row in enumerate(cells,start_row):
            for offset,value in enumerate(row):self.data[r][start_col+offset]=value.strip()
        self.active_cell=(start_row,start_col);self._configure_columns();self.reload_grid();self.output_tree.delete(*self.output_tree.get_children())
        self.result_label.configure(foreground='#555')
        kind='원본표 · 앞 6열 정보 / G열부터 케이블' if self._source_format() else '기존 케이블표'
        self.result.set(f"{kind} · {len(cells)}행 × {max(len(row) for row in cells)}열 붙여넣음")
        return "break"

    def add_column(self):
        if self.col_count>=self.max_columns:return
        self._grow_columns(self.col_count+1);self.reload_grid()

    def add_rows(self):
        old=self.row_count
        try:self._grow_rows(self.row_count+10)
        except ValueError as e:messagebox.showinfo("행 추가",str(e),parent=self);return
        self.active_cell=(old,0);self.reload_grid();self.result.set(f"행을 10개 추가했습니다. 현재 {self.row_count}행입니다.")

    def remove_column(self):
        if self.col_count<=2:return
        if any(row[-1] for row in self.data) and not messagebox.askyesno("열 삭제","마지막 열에 입력된 값이 있습니다. 삭제할까요?",parent=self):return
        self.col_count-=1
        for row in self.data:row.pop()
        self.active_cell=(self.active_cell[0],min(self.active_cell[1],self.col_count-1));self._configure_columns();self.reload_grid()

    def clear_cell(self,event=None):
        row,col=self.active_cell;self.data[row][col]="";self.tree.item(str(row+1),values=self.data[row]);return "break"

    def clear_all(self):
        if any(any(row) for row in self.data) and not messagebox.askyesno("표 지우기","입력한 표 전체를 지울까요?",parent=self):return
        self.data=[[""]*self.col_count for _ in range(self.row_count)];self.active_cell=(0,0);self._configure_columns();self.reload_grid();self.output_tree.delete(*self.output_tree.get_children());self.result.set("표를 지웠습니다.");self.result_label.configure(foreground='#555')

    def _port_id(self,header):
        node=self.store.node(self.node_id);value=str(header or "").strip().replace(" ","").casefold()
        if node and node["type"]=="rn" and value in ("rn내부","rn내부포트","rn포트"):return "PORT:"+self.node_id
        if node and node["type"]=="sub" and value in ("가입자내부","가입자내부포트","가입자포트"):return "PORT:"+self.node_id
        return None

    def _slot(self,cid,value):
        raw=str(value or "").strip()
        if str(cid).startswith("PORT:"):
            ports=self.store.cores(cid);by_label={str(r["label"] or "").strip().casefold():r["core_index"] for r in ports}
            try:index=int(raw)
            except ValueError:index=by_label.get(raw.casefold(),0)
            if index<1 or index>len(ports):raise ValueError(f"내부 포트 '{raw}'를 찾지 못했습니다.")
            return cid,index
        cable=self.store.cable(cid)
        try:index=int(raw)
        except ValueError:raise ValueError(f"'{raw}'은 코어번호가 아닙니다.")
        if not cable or index<1 or index>int(cable["size"]):raise ValueError(f"{index}번이 케이블 규격 범위를 벗어났습니다.")
        return cid,index

    def run(self):
        if self.editor:self._commit_editor()
        self.output_tree.delete(*self.output_tree.get_children());self.last_report=None;self.result.set('검사 중…');self.result_label.configure(foreground='#555')
        source=self._source_format();method,args,errors=self.parse_table(source)
        self.report_identities=self.collect_report_identities(source)
        if not args[1]:
            if errors:
                report=self.report_results([],errors);self.show_report(report,'입력 오류 / 미적용')
                previous_grab=self.grab_current();dialog=workflow.BulkSummaryDialog(self,report,'입력 오류 / 미적용');self.wait_window(dialog)
                try:
                    if previous_grab and previous_grab.winfo_exists():previous_grab.grab_set()
                except tk.TclError:pass
            else:
                self.result.set('검사할 입력 행이 없습니다.')
                messagebox.showinfo('Excel표 입력','1행 제목과 케이블별 코어번호를 A1부터 붙여넣으세요.',parent=self)
            return
        results=workflow.run_bulk(self,self.store,method,args,errors,reporter=self.report_results)
        if results is None:
            if self.last_report:self.show_report(self.last_report,'검사 결과 / 미적용')
            else:self.result.set('검사 또는 적용이 완료되지 않았습니다.')
            return
        report=self.report_results(results,errors);self.show_report(report,'적용 완료')
        self.parent.reload_all();self.parent.parent.refresh()

    def collect_report_identities(self,source):
        offset=6 if source else 0;resolved=[];identities={}
        for header in self.data[0][offset:]:
            cid=self._port_id(header)
            if not cid and str(header).strip():
                cable,error=self.store.resolve_node_cable(self.node_id,header)
                if cable and not error:cid=cable['id']
            resolved.append(cid)
        for row_no,cells in enumerate(self.data[1:],2):
            if not any(str(x).strip() for x in cells):continue
            core_id=str(cells[0]).strip() if source else '';detail=str(cells[1]).strip() if source else ''
            if not core_id or not detail:
                ids={};details={}
                for cid,value in zip(resolved,cells[offset:]):
                    if not cid or not str(value).strip():continue
                    try:slot=self._slot(cid,value)
                    except ValueError:continue
                    current=self.store.core(*slot)
                    if current:
                        if current['core_id']:ids[display_core_id(current['core_id'])]=None
                        if current['detail']:details[str(current['detail'])]=None
                core_id=core_id or ' / '.join(ids);detail=detail or ' / '.join(details)
            identities[row_no]=(display_core_id(normalize_core_id_input(core_id)),detail)
        return identities

    def report_results(self,results,external_errors=()):
        errors={};normal=set()
        def row_key(label):
            match=re.match(r'(\d+)(?:행|\b)',str(label));number=int(match.group(1)) if match else 0
            return number if number>1 else str(label)
        def add_error(label,reason):
            key=row_key(label);entry=errors.setdefault(key,{})
            entry[str(reason)]=None
        for label,ok,message in results:
            if ok:normal.add(row_key(label))
            else:add_error(label,f'{label}: {message}')
        for error in external_errors:add_error(error,error)
        rows=[]
        for key,reasons in errors.items():
            core_id,detail=self.report_identities.get(key,('',''))
            rows.append((core_id,detail,'\n'.join(reasons)))
        report={'normal':len(normal-set(errors)),'errors':len(rows),'rows':rows}
        self.last_report=report;self.show_report(report,'검사 결과 / 아직 적용 전');return report

    def show_report(self,report,status):
        self.result.set(f"정상 {report['normal']}건 · 오류 {report['errors']}건 · {status}")
        self.result_label.configure(foreground='#c62828' if report['errors'] else '#1769aa')
        self.output_tree.delete(*self.output_tree.get_children())
        for row in report['rows']:self.output_tree.insert('','end',values=row,tags=('error',))

    def parse_table(self,source):
        headers=self.data[0];offset=6 if source else 0;resolved=[];errors=[];seen={}
        method='bulk_connect_source_rows' if source else 'bulk_connect_pairs'
        if source and len(headers)<7:return method,(self.node_id,[]),['원본표는 앞 6개 정보열 다음 G열부터 실제 케이블ID가 필요합니다.']
        for column,header in enumerate(headers[offset:],offset+1):
            if not str(header).strip():resolved.append(None);continue
            cid=self._port_id(header)
            if not cid:
                cable,error=self.store.resolve_node_cable(self.node_id,header);cid=cable["id"] if cable else None
                if error:errors.append(f"1행 {self._column_name(column-1)}열 '{header}': {error}")
                elif cable and str(cable["spec"] or "").strip()=="드랍":errors.append(f"1행 {self._column_name(column-1)}열 '{header}': 드랍 케이블은 함체 코어 일괄연결 대상이 아닙니다.");cid=None
            if cid and cid in seen:errors.append(f"1행 {self._column_name(column-1)}열: {self._column_name(seen[cid]-1)}열과 같은 케이블입니다.")
            if cid:seen[cid]=column
            resolved.append(cid)
        if errors:return method,(self.node_id,[]),errors
        pairs=[]
        for row_no,cells in enumerate(self.data[1:],2):
            slots=[];row_errors=[]
            for column,value in enumerate(cells[offset:],offset+1):
                if not str(value).strip():continue
                cid=resolved[column-offset-1]
                if not cid:row_errors.append(f"{self._column_name(column-1)}열은 1행의 케이블ID가 비어 있습니다.");continue
                try:slots.append(self._slot(cid,value))
                except ValueError as e:row_errors.append(f"{self._column_name(column-1)}열: {e}")
            if row_errors:errors.extend([f"{row_no}행: {x}" for x in row_errors]);continue
            if not slots:
                if source and any(str(x).strip() for x in cells[:2]):errors.append(f'{row_no}행: 코어ID/코어명은 있지만 케이블의 코어번호가 없습니다.')
                continue
            if len(slots) not in ((1,2) if source else (2,)):errors.append(f"{row_no}행: 코어번호가 {len(slots)}개입니다. 연결할 두 칸만 입력하세요.");continue
            if source:pairs.append({'row':row_no,'slots':slots,'core_id':cells[0],'detail':cells[1]})
            else:pairs.append((row_no,slots[0],slots[1]))
        return method,(self.node_id,pairs),errors

    def show_result(self,event=None):
        if not self.output_tree.selection():return
        values=self.output_tree.item(self.output_tree.selection()[0],'values')
        messagebox.showinfo('오류 내용',f'코어ID: {values[0]}\n코어내역: {values[1]}\n\n{values[2]}',parent=self)

    def _show_errors(self,errors):
        messagebox.showwarning("Excel표 일괄연결 확인필요","\n".join(errors[:100])+(f"\n외 {len(errors)-100}건" if len(errors)>100 else ""),parent=self)


class PortConfigDialog(workflow.RememberedToplevel):
    def __init__(self,parent,store,node_id,on_saved):
        super().__init__(parent);self.store=store;self.node_id=node_id;self.on_saved=on_saved
        n=store.node(node_id);self.node_type=n["type"];self.title("RN 규격" if self.node_type=="rn" else "가입자 포트")
        self.resizable(False,False);frame=ttk.Frame(self,padding=15);frame.pack()
        extra=json.loads(n["extra_json"] or "{}")
        spec=extra.get("rnSpec" if self.node_type=="rn" else "subSpec") or ({"mp":4,"sp":0,"p":4} if self.node_type=="rn" else {"p":4})
        self.vars={}
        keys=("mp","sp","p") if self.node_type=="rn" else ("p",)
        for i,key in enumerate(keys):
            ttk.Label(frame,text=key.upper()+" 개수").grid(row=i,column=0,sticky="w",pady=4)
            self.vars[key]=tk.IntVar(value=int(spec.get(key,0)));ttk.Spinbox(frame,from_=0,to=999,textvariable=self.vars[key],width=10).grid(row=i,column=1,pady=4)
        ttk.Button(frame,text="저장",command=self.save).grid(row=len(keys),column=0,columnspan=2,sticky="ew",pady=(10,0))

    def save(self):
        spec={k:max(0,int(v.get())) for k,v in self.vars.items()};self.store.ensure_ports(self.node_id,spec);self.on_saved();self.destroy()


class BulkConnectDialog(workflow.RememberedToplevel):
    """각 케이블 열에 코어 번호를 줄별로 넣어 같은 행의 두 코어를 연결한다."""
    def __init__(self, parent, store, node_id):
        super().__init__(parent); self.parent=parent; self.store=store; self.node_id=node_id
        self.title("Excel표 일괄연결 · 케이블별 입력칸"); self.geometry("1050x650"); self.transient(parent);self.grab_set()
        ttk.Label(self,text="위에서 케이블을 고른 뒤, Excel의 번호 열을 케이블별 입력칸에 각각 붙여넣으세요. 같은 가로줄의 두 번호가 연결됩니다.",padding=(8,8,8,2),foreground="#1769aa").pack(fill="x")
        ttk.Label(self,text="RN내부는 IN, MP1 같은 포트명도 입력할 수 있습니다. 케이블 칸은 아래 버튼으로 추가·삭제할 수 있습니다.",padding=(8,2,8,8)).pack(fill="x")
        self.columns_frame=ttk.Frame(self,padding=8);self.columns_frame.pack(fill="both",expand=True)
        controls=ttk.Frame(self,padding=8);controls.pack(fill="x")
        ttk.Button(controls,text="케이블 열 추가",command=self.add_column).pack(side="left")
        ttk.Button(controls,text="마지막 열 삭제",command=self.remove_column).pack(side="left",padx=5)
        ttk.Button(controls,text="검사 후 일괄연결",command=self.run).pack(side="right")
        self.result=tk.Text(self,height=8);self.result.pack(fill="x",padx=8,pady=(0,8))
        cables=[c for c in store.node_cables(node_id) if str(c["spec"] or "").strip()!="드랍"]
        allowed={c["id"] for c in cables};self.options={label:cid for label,cid in store.node_cable_choices(node_id) if cid in allowed}
        node=store.node(node_id)
        if node and node["type"] in ("rn","sub"):
            self.options={"RN내부 포트" if node["type"]=="rn" else "가입자내부 포트":"PORT:"+node_id,**self.options}
        self.cols=[]
        for _ in range(min(3,max(2,len(cables)))):self.add_column()
        self.update_idletasks();self._center()

    def _center(self):
        workflow.center_popup(self,self.parent)

    def add_column(self):
        if len(self.cols)>=8:return
        frame=ttk.LabelFrame(self.columns_frame,text=f"케이블 {len(self.cols)+1}",padding=6)
        frame.pack(side="left",fill="both",expand=True,padx=4)
        values=list(self.options);var=tk.StringVar(value=values[min(len(self.cols),len(values)-1)] if values else "")
        ttk.Label(frame,text="케이블 선택").pack(anchor="w")
        ttk.Combobox(frame,textvariable=var,values=values,state="readonly",width=28).pack(fill="x",pady=(0,4))
        text=tk.Text(frame,width=16,height=25);text.pack(fill="both",expand=True,pady=5)
        self.cols.append((frame,var,text))

    def remove_column(self):
        if len(self.cols)<=2:return
        frame,_,_=self.cols.pop();frame.destroy()

    def run(self):
        columns=[]
        for _,var,text in self.cols:
            if not var.get() or var.get() not in self.options:continue
            vals=[x.strip() for x in text.get("1.0","end-1c").splitlines()]
            columns.append((self.options[var.get()],vals,var.get()))
        max_rows=max((len(v) for _,v,_ in columns),default=0);ok=0;messages=[];pairs=[]
        for row in range(max_rows):
            slots=[]
            for cid,vals,label in columns:
                raw=vals[row] if row<len(vals) else ""
                if not raw:continue
                if str(cid).startswith("PORT:"):
                    port_rows=self.store.cores(cid);by_label={str(x["label"]).casefold():x["core_index"] for x in port_rows}
                    try:idx=int(raw)
                    except ValueError:idx=by_label.get(raw.casefold(),0)
                    if idx<1 or idx>len(port_rows):messages.append(f"{row+1}행: {label}의 포트 '{raw}'를 찾지 못했습니다.");continue
                else:
                    try:idx=int(raw)
                    except ValueError:messages.append(f"{row+1}행: '{raw}'는 코어번호가 아닙니다.");continue
                    cable=self.store.cable(cid)
                    if idx<1 or idx>cable["size"]:messages.append(f"{row+1}행: {label}의 {idx}번이 범위를 벗어났습니다.");continue
                slots.append((cid,idx))
            if len(slots)==0:continue
            if len(slots)!=2:messages.append(f"{row+1}행: 연결할 번호가 {len(slots)}개입니다. 정확히 2개를 입력하세요.");continue
            pairs.append((row+1,slots[0],slots[1]))
        result=workflow.run_bulk(self,self.store,'bulk_connect_pairs',(self.node_id,pairs),messages)
        if result is None:return
        for label,success,msg in result:
            if success:ok+=1
            else:messages.append(f"{label}행: {msg}")
        self.result.delete("1.0","end");self.result.insert("end",f"완료 {ok}건\n")
        self.result.insert("end","\n".join(messages) if messages else "오류 없음")
        self.parent.reload_all();self.parent.parent.refresh()


class SurveyDialog(workflow.RememberedToplevel):
    def __init__(self,parent,store):
        super().__init__(parent);self.parent=parent;self.store=store
        self.title("함체별 조사자료 입력");self.geometry("1100x760")
        top=ttk.Frame(self,padding=8);top.pack(fill="x")
        ttk.Label(top,text="조사 함체").pack(side="left")
        nodes=[n for n in store.nodes() if n["type"] in ("hamche","rn")]
        self.node_map={f'{NODE_LABELS.get(n["type"],n["type"])} · {n["name"]}':n["id"] for n in nodes}
        self.node_var=tk.StringVar(value=next(iter(self.node_map),""))
        cb=ttk.Combobox(top,textvariable=self.node_var,values=list(self.node_map),state="readonly",width=35);cb.pack(side="left",padx=6);cb.bind("<<ComboboxSelected>>",lambda e:self.load_saved())
        ttk.Button(top,text="저장된 조사자료 불러오기",command=self.load_saved).pack(side="left",padx=3)
        ttk.Button(top,text="오류코어확인",command=self.show_errors).pack(side="right",padx=3)
        ttk.Label(self,text="첫 줄: 케이블ID 또는 연결 함체명 / 다음 줄부터: 같은 행에 연결할 코어번호 2개\n엑셀에서 표 전체를 복사해 아래에 붙여넣을 수 있습니다.",padding=(8,2),foreground="#1769aa").pack(fill="x")
        self.text=tk.Text(self,height=25,wrap="none",font=("Consolas",11));self.text.pack(fill="both",expand=True,padx=8,pady=5)
        bottom=ttk.Frame(self,padding=8);bottom.pack(fill="x")
        self.replace=tk.BooleanVar(value=True);ttk.Checkbutton(bottom,text="이 함체의 기존 조사자료 교체",variable=self.replace).pack(side="left")
        ttk.Button(bottom,text="조사자료만 저장",command=lambda:self.save(False)).pack(side="right",padx=3)
        ttk.Button(bottom,text="저장하고 정상행 코어연결",command=lambda:self.save(True)).pack(side="right",padx=3)
        self.result=tk.Text(self,height=8);self.result.pack(fill="x",padx=8,pady=(0,8))

    def current_node(self):return self.node_map.get(self.node_var.get())

    def load_saved(self):
        nid=self.current_node()
        if not nid:return
        rows=self.store.conn.execute("SELECT * FROM survey_rows WHERE node_id=? ORDER BY created_at,rowid",(nid,)).fetchall()
        cables=[]
        for r in rows:
            for cid in (r["left_cable"],r["right_cable"]):
                c=self.store.cable(cid)
                if c:
                    name=clean_cable_id(c["cable_id"]) or self.store.opposite_name(c,nid)
                    if (cid,name) not in cables:cables.append((cid,name))
        if not cables:self.text.delete("1.0","end");return
        lines=["\t".join(name for _,name in cables)]
        for r in rows:
            vals=[""]*len(cables)
            for cid,idx in ((r["left_cable"],r["left_index"]),(r["right_cable"],r["right_index"])):
                for pos,(stored,_) in enumerate(cables):
                    if stored==cid:vals[pos]=str(idx)
            lines.append("\t".join(vals))
        self.text.delete("1.0","end");self.text.insert("1.0","\n".join(lines))

    def parse(self):
        nid=self.current_node();raw=self.text.get("1.0","end-1c").replace("\r","")
        lines=[x for x in raw.splitlines() if x.strip()]
        if not nid:return [],["조사 함체를 선택하세요."]
        if len(lines)<2:return [],["첫 줄의 케이블명과 그 아래 코어번호를 입력하세요."]
        headers=[x.strip() for x in lines[0].split("\t")]
        if len([x for x in headers if x])<2:return [],["첫 줄에는 케이블을 2개 이상 입력하세요. 엑셀 표는 탭으로 구분됩니다."]
        resolved=[];errors=[]
        for col,h in enumerate(headers,1):
            if not h:resolved.append(None);continue
            c,msg=self.store.resolve_node_cable(nid,h);resolved.append(c["id"] if c else None)
            if msg:errors.append(f"제목 {col}열: {msg}")
        result=[]
        for row_no,line in enumerate(lines[1:],2):
            vals=line.split("\t");vals+=['']*(len(headers)-len(vals));slots=[];row_errors=[]
            for col,raw_value in enumerate(vals[:len(headers)]):
                value=raw_value.strip()
                if not value:continue
                for one in [x.strip() for x in value.replace(",","/").split("/") if x.strip()]:
                    try:idx=int(one)
                    except ValueError:row_errors.append(f"{col+1}열 '{one}'은 코어번호가 아닙니다.");continue
                    cid=resolved[col]
                    if not cid:row_errors.append(f"{col+1}열 케이블을 찾지 못해 {idx}번을 연결할 수 없습니다.");continue
                    cable=self.store.cable(cid)
                    if idx<1 or idx>cable["size"]:row_errors.append(f"{col+1}열 {idx}번은 {cable['spec']} 범위를 벗어납니다.");continue
                    slots.append((cid,idx))
            if row_errors:errors.extend([f"{row_no}행: {x}" for x in row_errors])
            if len(slots)==2:result.append((row_no,slots[0],slots[1],""))
            elif slots:result.append((row_no,None,None,f"한 줄에 코어가 {len(slots)}개입니다. 정확히 2개가 필요합니다."))
        return result,errors

    def save(self,apply_connections):
        nid=self.current_node();rows,errors=self.parse()
        if not nid:return
        saved=0;connected=0;now=datetime.now().isoformat(timespec="seconds");pairs=[]
        with self.store.action("조사자료 저장"):
            if self.replace.get():self.store.conn.execute("DELETE FROM survey_rows WHERE node_id=?",(nid,))
            for row_no,a,b,error in rows:
                rid="SR-"+uuid.uuid4().hex
                if error:
                    self.store.conn.execute("INSERT INTO survey_rows VALUES(?,?,?,?,?,?,?,?,?)",(rid,nid,"",0,"",0,1,f"{row_no}행: {error}",now));continue
                self.store.conn.execute("INSERT INTO survey_rows VALUES(?,?,?,?,?,?,?,?,?)",(rid,nid,a[0],a[1],b[0],b[1],0,"",now));saved+=1
                if apply_connections:pairs.append((row_no,a,b))
            if pairs:
                for label,success,msg in self.store.bulk_connect_pairs(nid,pairs):
                    if success:connected+=1
                    else:errors.append(f"{label}행: {msg}")
        self.result.delete("1.0","end");self.result.insert("end",f"조사자료 {saved}건 저장, 코어연결 {connected}건\n")
        self.result.insert("end","\n".join(errors[:100]) if errors else "오류 없음")

    def show_errors(self):
        SurveyErrorsDialog(self,self.store,self.current_node())


def owning_app(widget):
    while widget is not None:
        if isinstance(widget,App):return widget
        widget=getattr(widget,'master',None)
    return None


def open_detail_dialog(parent,store,kind,item_id):
    """Reuse a live editor without resetting its selected core or unsaved text."""
    app=owning_app(parent) or parent
    windows=app.__dict__.setdefault('_detail_windows',{})
    key=(id(store),getattr(store,'_view_generation',0),kind,str(item_id))
    existing=windows.get(key)
    if existing is not None:
        try:
            if existing.winfo_exists():
                workflow.navigation_link(parent,existing);existing.deiconify();existing.lift()
                focus=existing.focus_lastfor();(focus or existing).focus_set()
                return existing
        except tk.TclError:pass
        windows.pop(key,None)
    node=store.node(item_id) if kind=='node' else None
    if kind in ('cable','diagram') or (node and node['type']=='hamche'):
        for previous_key,previous in list(windows.items()):
            if previous_key[2]!=kind:continue
            if workflow.navigation_top(parent) is not None:continue
            if kind=='node' and getattr(previous,'node_type',None)!='hamche':continue
            try:
                if not previous.winfo_exists():windows.pop(previous_key,None);continue
                if not previous.close_for_switch():
                    previous.deiconify();previous.lift();return previous
            except tk.TclError:
                if previous.winfo_exists():raise
                windows.pop(previous_key,None)
    if kind=='cable':window=CableDialog(app,store,cable_id=item_id)
    elif kind=='diagram':window=workflow.NodeConnectionDiagramDialog(app,store,item_id)
    elif kind=='node':window=NodeDialog(parent,store,item_id)
    else:window=NodePropertiesDialog(parent,store,item_id)
    workflow.navigation_link(parent,window)
    windows[key]=window
    def remove(event):
        if event.widget is window and windows.get(key) is window:windows.pop(key,None)
    window.bind('<Destroy>',remove,add='+')
    return window


class ConnectionListDialog(workflow.RememberedToplevel):
    CAUSE_FILTERS={'전체':None,'미접속':'unconnected','경로 분리':'split','끝점 조건 미충족':'endpoints',
                   '중복·분기 접속':'branch','코어ID 충돌·빈 코어 접속':'identity',
                   '신호 불일치':'signal','OK·미완료':'ok_incomplete',
                   '오류 상태·신호':'marked','RN 포트 연결 오류':'port','잘못된 접속정보':'invalid'}
    def __init__(self,parent,store,mode='error',node_id=None,cable_id=None):
        super().__init__(parent);self.parent=parent;self.store=store;self.mode=mode;self.node_id=node_id;self.cable_id=cable_id
        self.field_incomplete=mode=='incomplete' and workflow.field_slot_mode(store)
        self.title('미완료코어 목록' if mode=='incomplete' else '오류코어확인');self.geometry('1150x820' if mode=='incomplete' else '1150x780')
        self._error_trace_job=None;self._error_trace_key=None;self._error_trace_view={}
        self.previous_grab=self.grab_current()
        if self.previous_grab:self.transient(parent);self.grab_set()
        self.bind('<Destroy>',self.restore_grab,add='+')
        self.summary=tk.StringVar();ttk.Label(self,textvariable=self.summary,padding=10,foreground='#7b1fa2',wraplength=1050).pack(fill='x')
        self.cause_filter=tk.StringVar(value='전체')
        if mode=='incomplete':
            filters=ttk.Frame(self,padding=(8,0,8,7));filters.pack(fill='x')
            ttk.Label(filters,text='미완료 원인').pack(side='left',padx=(0,6))
            combo=ttk.Combobox(filters,textvariable=self.cause_filter,values=tuple(self.CAUSE_FILTERS),state='readonly',width=29)
            combo.pack(side='left');combo.bind('<<ComboboxSelected>>',lambda e:self.reload())
            ttk.Label(filters,text='전체를 고르면 모든 원인을 다시 표시합니다.',foreground='#415a77').pack(side='left',padx=10)
        tools=ttk.Frame(self,padding=(8,0));tools.pack(fill='x')
        ttk.Button(tools,text='새로고침',command=self.reload).pack(side='left')
        self.in_cable=isinstance(parent,CableDialog)
        if mode=='incomplete':
            ttk.Button(tools,text='해당 코어 보기' if self.in_cable else '도면 위치로 이동',command=self.navigate).pack(side='left',padx=5)
            if not self.in_cable:ttk.Button(tools,text='선택 코어 열기',command=lambda:self.navigate(open_core=True)).pack(side='left',padx=5)
            ttk.Button(tools,text='도면 강조 해제',command=self.clear_error_trace).pack(side='left',padx=5)
            ttk.Button(tools,text='예외로 빼기 (신호 유지)',command=self.mark_exception).pack(side='left',padx=5)
            self.map_allocation_button=ttk.Button(tools,text='도면에서 코어배정',command=self.open_map_allocation,style='Primary.TButton');self.map_allocation_button.pack(side='left',padx=5)
            ttk.Label(tools,text='클릭: 경로 표시 · 더블클릭: 위치 이동 · 도면에서 코어배정: 후도면에서 바로 배정',foreground='#415a77').pack(side='left',padx=8)
        else:
            ttk.Button(tools,text='선택 코어 추적',command=self.queue_error_trace).pack(side='left',padx=5)
            ttk.Button(tools,text='도면 강조 해제',command=self.clear_error_trace).pack(side='left',padx=5)
            ttk.Button(tools,text='예외로 빼기 (신호 유지)',command=self.mark_exception).pack(side='left',padx=5)
            ttk.Label(tools,text='코어 선택: 경로 그림·깜빡임 · 도면 클릭: 도면을 앞으로 · 예외: 일부만 그린 코어를 목록에서 뺌',foreground='#415a77').pack(side='left',padx=8)
        frame=ttk.Frame(self);frame.pack(fill='both',expand=True,padx=8,pady=8)
        columns=[('core','코어ID',180),('detail','코어내역',230),('reason','확인할 내용',610)]
        if self.field_incomplete:columns=[('core','경로의 코어ID',180),('state','내역 판정',105),('cable','대표 케이블ID',130),('num','코어번호',70),('signal','경로 신호',100),('count','구간 수',70),('reason','미완료 사유',400)]
        self.tree=workflow.SortableTreeview(frame,columns=tuple(key for key,_,_ in columns),show='headings',selectmode='browse')
        for key,label,width in columns:
            self.tree.heading(key,text=label);self.tree.column(key,width=width,minwidth=80)
        self.tree.grid(row=0,column=0,sticky='nsew');frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        self.tree.tag_configure('ok_pending',foreground='#b45309');self.tree.tag_configure('not_ok',foreground='#c62828')
        sy=ttk.Scrollbar(frame,orient='vertical',command=self.tree.yview);sy.grid(row=0,column=1,sticky='ns')
        sx=ttk.Scrollbar(frame,orient='horizontal',command=self.tree.xview);sx.grid(row=1,column=0,sticky='ew');self.tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        activate=self.navigate if mode=='incomplete' else self.queue_error_trace
        self.tree.bind('<Double-Button-1>',activate);self.tree.bind('<Return>',activate)
        if mode=='incomplete':
            detail_frame=ttk.LabelFrame(self,text='선택 코어 전체 내용',padding=6);detail_frame.pack(fill='x',padx=8,pady=(0,8))
            line=ttk.Frame(detail_frame);line.pack(fill='x',pady=(0,5))
            ttk.Label(line,text='이동할 위치').pack(side='left',padx=(0,6))
            self.target_var=tk.StringVar();self.target_options={}
            self.target_combo=ttk.Combobox(line,textvariable=self.target_var,state='readonly',width=90);self.target_combo.pack(side='left',fill='x',expand=True)
            text_frame=ttk.Frame(detail_frame);text_frame.pack(fill='x')
            self.details_text=tk.Text(text_frame,height=4,wrap='word',state='disabled',font=('Malgun Gothic',9))
            scroll=ttk.Scrollbar(text_frame,orient='vertical',command=self.details_text.yview);self.details_text.configure(yscrollcommand=scroll.set)
            self.details_text.pack(side='left',fill='x',expand=True);scroll.pack(side='right',fill='y')
            self.tree.bind('<<TreeviewSelect>>',self.update_selection_details)
            if self.field_incomplete:
                table_frame=ttk.LabelFrame(self,text='선택 경로의 케이블별 내역 · 행을 클릭하면 코어명 전체 표시',padding=4);table_frame.pack(fill='both',expand=True,padx=8,pady=(0,6))
                table_frame.rowconfigure(0,weight=1);table_frame.columnconfigure(0,weight=1)
                cols=('cable','num','core','signal','match','location')
                self.segment_tree=workflow.SortableTreeview(table_frame,columns=cols,show='headings',height=5)
                for col,label,width in zip(cols,('케이블ID / 내부포트','코어번호','실제 코어ID','신호','ID 비교','함체 구간'),(150,75,170,90,90,410)):
                    self.segment_tree.heading(col,text=label);self.segment_tree.column(col,width=width)
                self.segment_tree.tag_configure('mismatch',foreground='#c62828',background='#ffebee')
                self.segment_tree.grid(row=0,column=0,sticky='nsew')
                sy=ttk.Scrollbar(table_frame,orient='vertical',command=self.segment_tree.yview);sy.grid(row=0,column=1,sticky='ns')
                sx=ttk.Scrollbar(table_frame,orient='horizontal',command=self.segment_tree.xview);sx.grid(row=1,column=0,sticky='ew');self.segment_tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
                self.segment_tree.bind('<<TreeviewSelect>>',self.show_segment_detail)
                self.segment_rows={}
        self.trace_summary=tk.StringVar(value='코어를 클릭하면 연결 경로와 도면의 코어번호를 표시합니다.')
        ttk.Label(self,textvariable=self.trace_summary,padding=(10,0,10,5),foreground='#415a77').pack(fill='x')
        diagram_frame=ttk.LabelFrame(self,text='선택 코어 연결 경로',padding=4);diagram_frame.pack(fill='both',expand=True,padx=8,pady=(0,8))
        diagram_frame.rowconfigure(0,weight=1);diagram_frame.columnconfigure(0,weight=1)
        self.diagram=tk.Canvas(diagram_frame,bg='#ffffff',height=220 if mode=='incomplete' else 260,highlightthickness=0);self.diagram.grid(row=0,column=0,sticky='nsew')
        dx=ttk.Scrollbar(diagram_frame,orient='horizontal',command=self.diagram.xview);dy=ttk.Scrollbar(diagram_frame,orient='vertical',command=self.diagram.yview)
        dx.grid(row=1,column=0,sticky='ew');dy.grid(row=0,column=1,sticky='ns');self.diagram.configure(xscrollcommand=dx.set,yscrollcommand=dy.set)
        self.tree.bind('<<TreeviewSelect>>',self.queue_error_trace,add='+')
        self.tree.bind('<ButtonRelease-1>',self.queue_error_trace,add='+')
        self.reload()

    def restore_grab(self,event):
        if event.widget is not self:return
        self.clear_error_trace(redraw=False)
        try:
            if self.previous_grab and self.previous_grab.winfo_exists():self.previous_grab.grab_set()
        except tk.TclError:pass

    def reload(self):
        selection=self.tree.selection();selected_id=None
        if selection and selection[0].isdigit():
            previous=getattr(self,'entries',());index=int(selection[0])
            if index<len(previous):selected_id=previous[index]['core_id']
        if self.mode=='incomplete':
            all_entries=workflow.field_incomplete_entries(self.store) if self.field_incomplete else self.store.incomplete_core_groups(self.cable_id)
            if self.field_incomplete and self.cable_id:all_entries=[e for e in all_entries if any(m['slot'][0]==self.cable_id for m in e['members'])]
            selector=getattr(self,'cause_filter',None);choice=selector.get() if selector else '전체';cause=self.CAUSE_FILTERS.get(choice)
            self.entries=[e for e in all_entries if cause is None or cause in e.get('causes',())]
            ids={e.get('key',('id',e['core_id'])) for e in self.entries};total_ids={e.get('key',('id',e['core_id'])) for e in all_entries}
            scope='이 케이블' if self.cable_id else '현재 도면 전체'
            self.summary.set(f'{scope} · 원인: {choice} · 표시 코어ID {len(ids)}/{len(total_ids)}개\n코어를 클릭하면 아래 경로 그림과 도면의 주황색 케이블·코어번호를 표시합니다. 같은 코어ID의 끊어진 구간도 함께 확인합니다.')
            if self.field_incomplete:self.summary.set(f'{scope} · 원인: {choice} · 미완료 경로 {len(self.entries)}/{len(all_entries)}개\n한 경로를 한 줄로 표시합니다. OK여도 끝-끝 미연결이면 남습니다. 선택하면 아래 표에서 케이블별 ID·신호와 긴 코어명을 확인합니다.')
        else:
            self.entries=self.store.error_core_groups(self.node_id)
            self.summary.set(f"오류코어 {len(self.entries)}개\n오류 상태이거나 한 함체에 같은 ID가 3개 이상 있는 코어를 표시합니다. 코어를 선택하면 코어추적과 같은 경로 그림 및 도면 깜빡임으로 확인할 수 있습니다.")
        self.tree.delete(*self.tree.get_children())
        for i,entry in enumerate(self.entries):
            location,core,reason=entry['row']
            if self.mode=='incomplete':
                labels=' '.join(f'[{label}]' for label,cause in self.CAUSE_FILTERS.items() if cause and cause in entry.get('causes',()))
                if labels:reason=labels+' '+reason
            values=(display_core_id(entry['core_id']) or '(코어ID 없음)',entry.get('detail',''),reason)
            if self.field_incomplete:
                slot=entry['slot'];cable=self.store.cable(slot[0]);name=clean_cable_id(cable['cable_id']) if cable else '내부포트'
                values=(entry['id_summary'],entry['state'],name,slot[1],entry['signal'],entry['count'],entry['short_reason'])
            self.tree.insert('','end',iid=str(i),values=values,tags=('ok_pending' if entry.get('state')=='OK · 미완료' else 'not_ok' if self.field_incomplete else '',))
            if selected_id==entry['core_id']:self.tree.selection_set(str(i))
        if not self.entries:
            values=('',)*(len(self.tree['columns'])-1)+('현재 해당하는 코어가 없습니다.',)
            self.tree.insert('','end',iid='empty',values=values)
        if self.mode=='incomplete':self.update_selection_details()
        if self.tree.selection():self.queue_error_trace()
        else:self.clear_error_trace()

    def mark_exception(self):
        """V167: 예외코어 for the selected core; it leaves 미완료/오류 lists, signal and splices stay."""
        selection=self.tree.selection();iid=selection[0] if selection else ''
        if not iid.isdigit() or int(iid)>=len(self.entries):
            messagebox.showinfo('예외로 빼기','예외로 뺄 코어를 먼저 선택하세요.',parent=self);return
        entry=self.entries[int(iid)];slots=[m['slot'] for m in entry.get('members') or () if m.get('slot')]
        if entry.get('slot'):slots.insert(0,entry['slot'])
        slots=[tuple(s) for s in slots if self.store.core(*s)]
        ids=[cid for cid in dict.fromkeys(str(self.store.core(*s)['core_id'] or '').strip() for s in slots) if cid]
        if not ids:
            messagebox.showinfo('예외로 빼기','코어ID(또는 임시코어)가 있는 코어만 예외로 뺄 수 있습니다.',parent=self);return
        names=', '.join(display_core_id(cid) for cid in ids)
        if not messagebox.askyesno('예외로 빼기',f'{names}\n\n이 코어를 예외코어로 지정해 미완료코어·오류코어 목록에서 뺄까요?\n신호(ON 등)와 접속은 그대로 둡니다.\n해제: 코어확인/작업목록 → 예외코어 → 예외 해제 (또는 Ctrl+Z)',parent=self):return
        try:changed=self.store.set_cores_exception(slots,True)
        except (ValueError,sqlite3.Error) as error:messagebox.showerror('예외로 빼기',str(error),parent=self);return
        app=owning_app(self)
        if app is not None:
            app.refresh();app.status.set(f'예외코어 지정 {len(changed)}개 · {names}')
        self.reload()

    def queue_error_trace(self,event=None):
        if self._error_trace_job is not None:
            try:self.after_cancel(self._error_trace_job)
            except tk.TclError:pass
        self._error_trace_job=self.after_idle(self.trace_selected_error)
        return 'break'

    def trace_selected_error(self):
        self._error_trace_job=None;selection=self.tree.selection();iid=selection[0] if selection else ''
        app=owning_app(self)
        if app is None or app.store is not self.store or not iid.isdigit() or int(iid)>=len(self.entries):
            self.clear_error_trace();return
        entry=self.entries[int(iid)];core_id=entry['core_id'];slot=entry.get('slot') if self.field_incomplete else None
        key=(getattr(self.store,'_view_generation',0),self.store.data_revision(),core_id,slot)
        if self._error_trace_key==key and getattr(app,'highlight_owner',None) is self:return
        context=self.store.trace_context();trace=self.store.trace_core_paths(core_id,context,slot=slot)
        if not trace['rows']:
            self.clear_error_trace();self.trace_summary.set('보존 중인 내역입니다. 선택 코어 열기로 함체의 보존내역을 확인하세요.' if any(m.get('pending_identity') for m in self.entries[int(iid)].get('members',[])) else '현재 도면에서 해당 코어를 찾지 못했습니다. 목록을 새로고침하세요.');return
        view=connection_trace_view(self.store,[trace]);draw_trace_diagram(self.diagram,view)
        self._error_trace_key=key;self._error_trace_view=view
        app.start_highlight_blink(view['cable_colors'],owner=self,core_labels=core_path_number_labels(trace['rows']),core_rows=trace['rows'],core_slots=[slot] if slot else None)
        self.trace_summary.set(view['summary']+' · 도면의 미접속 함체 안내에서 양쪽 번호를 확인하세요.')
        if self.field_incomplete:
            self.segment_tree.delete(*self.segment_tree.get_children());self.segment_rows={}
            for row in trace['rows']:
                position=(row['cable_id'],int(row['core_index']));cable=context['cables'].get(position[0]);check=trace['checks'].get(position,{})
                name=clean_cable_id(cable['cable_id']) if cable else '내부포트'
                item=str(len(self.segment_rows));self.segment_rows[item]=row
                self.segment_tree.insert('','end',iid=item,values=(name,position[1],display_core_id(row['core_id']),signal_label(row['signal']),check.get('identity',''),check.get('location','')),tags=('mismatch' if check.get('mismatch') else '',))
        label='미완료코어' if self.mode=='incomplete' else '오류코어'
        app.status.set(f"{display_core_id(core_id)} {label} 경로 · 케이블 {len(view['highlight'])}개 · 코어번호 표시")

    def clear_error_trace(self,redraw=True):
        if getattr(self,'_error_trace_job',None) is not None:
            try:self.after_cancel(self._error_trace_job)
            except tk.TclError:pass
        self._error_trace_job=None;self._error_trace_key=None;self._error_trace_view={}
        app=owning_app(self)
        if app is not None and getattr(app,'highlight_owner',None) is self:app.stop_highlight_blink(clear=True)
        if redraw and hasattr(self,'diagram'):
            draw_trace_diagram(self.diagram,{})
            self.trace_summary.set('코어를 클릭하면 연결 경로와 도면의 코어번호를 표시합니다.')
            if hasattr(self,'segment_tree'):self.segment_tree.delete(*self.segment_tree.get_children());self.segment_rows={}

    def show_segment_detail(self,event=None):
        selected=self.segment_tree.selection();row=self.segment_rows.get(selected[0]) if selected else None
        if row is None:return
        position=(row['cable_id'],int(row['core_index']));text=self.store._slot_title(*position)+'\n코어ID: '+display_core_id(row['core_id'])+'\n코어명: '+str(row.get('detail') or '(없음)')+'\n신호: '+signal_label(row.get('signal'))
        self.details_text.configure(state='normal');self.details_text.delete('1.0','end');self.details_text.insert('1.0',text);self.details_text.configure(state='disabled')
        for label,item in self.target_options.items():
            if item.get('slot')==position:self.target_var.set(label);break

    def update_selection_details(self,event=None):
        if not hasattr(self,'details_text'):return
        selection=self.tree.selection();iid=selection[0] if selection else ''
        entry=self.entries[int(iid)] if iid.isdigit() and int(iid)<len(self.entries) else None
        members=entry.get('members',()) if entry else ()
        self.target_options={f'{i+1}. {item["row"][0]} · {item["row"][1]}':item for i,item in enumerate(members)}
        self.target_combo.configure(values=tuple(self.target_options));self.target_var.set(next(iter(self.target_options),''))
        text=''
        if entry:
            text=f'코어ID: {display_core_id(entry["core_id"])}\n코어내역: {entry.get("detail") or ""}\n'
            text+='\n'.join(f'{i+1}. {reason}' for i,reason in enumerate(entry.get('reason_items') or (entry['row'][2],)))
        self.details_text.configure(state='normal');self.details_text.delete('1.0','end');self.details_text.insert('1.0',text);self.details_text.configure(state='disabled')

    def navigate(self,event=None,open_core=False):
        if not self.tree.selection():return 'break'
        iid=self.tree.selection()[0]
        if not iid.isdigit() or int(iid)>=len(self.entries):return 'break'
        entry=self.entries[int(iid)]
        if entry.get('members'):
            options=getattr(self,'target_options',{});selector=getattr(self,'target_var',None)
            selected=options.get(selector.get()) if selector else None
            entry=selected if selected in entry['members'] else entry['members'][0]
        app=owning_app(self)
        if app is None:return 'break'
        if app.store is not self.store:
            messagebox.showinfo('작업 변경','현재 도면의 목록을 다시 열어주세요.',parent=self);return 'break'
        if entry.get('pending_identity'):
            workflow.FieldArchiveDialog(self,self.store,entry['nodes'][0]);return 'break'
        if not self.store.issue_position(entry):
            messagebox.showinfo('이동할 위치 없음','해당 시설이나 케이블이 현재 도면에 없습니다.\n'+entry['row'][2],parent=self);return 'break'
        slot=entry.get('slot')
        if self.in_cable and slot and slot[0]==self.parent.cable_key:
            parent=self.parent;self.destroy();parent.reload_status(slot[1]);parent.focus_core(slot[1]);return 'break'
        self.destroy();app.reveal_issue(entry,open_core=open_core);return 'break'


    def allocation_sources(self):
        """Saved slots of the selected incomplete path; the chosen location is tried first."""
        selection=self.tree.selection();iid=selection[0] if selection else ''
        if not iid.isdigit() or int(iid)>=len(self.entries):return []
        entry=self.entries[int(iid)];members=list(entry.get('members') or ())
        options=getattr(self,'target_options',{});selector=getattr(self,'target_var',None)
        chosen=options.get(selector.get()) if selector else None
        ordered=([chosen] if chosen in members else [])+([entry] if entry.get('slot') else [])+members
        sources=[]
        for item in ordered:
            slot=item.get('slot')
            if slot and tuple(slot) not in sources:sources.append((str(slot[0]),int(slot[1])))
        return sources

    def open_map_allocation(self):
        # The incomplete list acts as the allocation editor: it hides while the
        # map panel is open and comes back (reloaded) when the panel closes.
        app=owning_app(self)
        if app is None:return
        try:
            if app.store is not self.store:raise ValueError('열린 도면이 바뀌었습니다. 미완료 목록을 다시 여세요.')
            workflow.AfterPlanner(app).require_after()
            sources=self.allocation_sources()
            if not sources:raise ValueError('배정할 미완료 코어를 먼저 선택하세요.')
            panel=getattr(app,'_map_allocation_panel',None)
            if panel is not None and panel.winfo_exists():
                if panel.service.source in sources:self.withdraw();panel.deiconify();panel.lift();panel.matrix.focus_set();return panel
                if not panel.close_requested():return
            existing=getattr(app,'_manual_allocation_window',None)
            if existing is not None and existing.winfo_exists():existing.destroy()
            first_error=None
            for source in sources:
                try:return workflow.MapCoreAllocationPanel(app,source,editor=self)
                except ValueError as error:first_error=first_error or error
            raise first_error
        except (ValueError,sqlite3.Error,OSError) as error:messagebox.showwarning('도면에서 코어배정',str(error),parent=self)

    _core_trace_enabled=True
    def clear_core_trace(self):self.clear_error_trace(redraw=False)
    def queue_core_trace(self):
        if self.tree.selection():self.queue_error_trace()
    def focus_core(self,index):
        selection=self.tree.selection()
        if selection:self.tree.see(selection[0])
    def allocation_return(self):self.reload()


class SurveyErrorsDialog(ConnectionListDialog):
    def __init__(self,parent,store,node_id=None):super().__init__(parent,store,'error',node_id=node_id)


class IncompleteCoresDialog(ConnectionListDialog):
    def __init__(self,parent,store,cable_id=None):super().__init__(parent,store,'incomplete',cable_id=cable_id)


class TraceDialog(workflow.RememberedToplevel):
    def __init__(self,parent,store):
        super().__init__(parent);self.parent=parent;self.store=store;self.title("코어추적 · 경로 그림");self.geometry("1250x820")
        self._trace_closed=False
        self.protocol("WM_DELETE_WINDOW",self.close)
        self.bind("<Destroy>",self.on_destroy,add="+")
        top=ttk.Frame(self,padding=8);top.pack(fill="x");ttk.Label(top,text="코어ID(쉼표로 여러 개)").pack(side="left")
        self.q=tk.StringVar();entry=ttk.Entry(top,textvariable=self.q,width=42);entry.pack(side="left",padx=5);entry.focus_set()
        ttk.Button(top,text="추적",command=self.run).pack(side="left");ttk.Button(top,text="계속 깜빡임 재시작",command=self.blink_again).pack(side="left",padx=5);ttk.Button(top,text="도면 강조 해제",command=self.clear).pack(side="left",padx=5)
        self.summary=tk.StringVar(value="임시코어1, 임시코어2 또는 일반 코어ID를 입력하세요. 쉼표로 여러 개 추적 가능 · 실제 접속 구간마다 색상이 다르며 겹침은 진분홍색입니다.");ttk.Label(self,textvariable=self.summary,padding=(10,0,10,6),foreground="#415a77",wraplength=1200).pack(fill="x")
        ttk.Label(self,text=workflow.trace_basis(store)+' · ID 검색은 분리된 배치도 각각 표시합니다. 빨간 안내 테두리: ID·신호 등 오류.',padding=(10,0,10,6),wraplength=1200).pack(fill='x')
        diagram_frame=ttk.LabelFrame(self,text="연결 경로 그림",padding=4);diagram_frame.pack(fill="both",expand=True,padx=8,pady=(0,5));diagram_frame.rowconfigure(0,weight=1);diagram_frame.columnconfigure(0,weight=1)
        self.diagram=tk.Canvas(diagram_frame,bg="#ffffff",height=330,highlightthickness=0);self.diagram.grid(row=0,column=0,sticky="nsew")
        dx=ttk.Scrollbar(diagram_frame,orient="horizontal",command=self.diagram.xview);dy=ttk.Scrollbar(diagram_frame,orient="vertical",command=self.diagram.yview);dx.grid(row=1,column=0,sticky="ew");dy.grid(row=0,column=1,sticky="ns");self.diagram.configure(xscrollcommand=dx.set,yscrollcommand=dy.set)
        frame=ttk.Frame(self);frame.pack(fill='both',expand=True,padx=8,pady=(0,8));frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        columns=('id','group','section','cable','num','detail','signal','identity','connected')
        self.tree=workflow.SortableTreeview(frame,columns=columns,show='headings')
        for c,l,w in zip(columns,('실제 코어ID','경로','구간','케이블','번호','코어내역','신호','ID 비교','양쪽 접속'),(140,60,250,145,55,200,75,90,350)):self.tree.heading(c,text=l);self.tree.column(c,width=w)
        self.tree.tag_configure('mismatch',foreground='#c62828',background='#ffebee');self.tree.tag_configure('pending',foreground='#b45309')
        self.tree.grid(row=0,column=0,sticky='nsew')
        sy=ttk.Scrollbar(frame,orient='vertical',command=self.tree.yview);sy.grid(row=0,column=1,sticky='ns')
        sx=ttk.Scrollbar(frame,orient='horizontal',command=self.tree.xview);sx.grid(row=1,column=0,sticky='ew');self.tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        self.bind("<Return>",lambda e:self.run());self.last_highlight={}

    def run(self):
        self._clear_parent_highlight()
        core_ids=parse_core_ids(self.q.get());self.tree.delete(*self.tree.get_children());draw_trace_diagram(self.diagram,{});self.last_highlight={};self.summary.set("추적할 코어ID를 입력하세요.")
        if not core_ids:return
        context=self.store.trace_context();traces=[];missing=[]
        for core_id in core_ids:
            trace=self.store.trace_core_paths(core_id,context)
            if trace["rows"]:traces.append(trace)
            else:missing.append(core_id)
        if not traces:
            messagebox.showinfo("추적 결과","입력한 코어ID를 찾지 못했습니다.\n"+", ".join(display_core_id(value) for value in missing),parent=self);return
        combined=connection_trace_view(self.store,traces)
        for trace in traces:
            slot_group={slot:group["number"] for slot,group in combined["segments"]["by_slot"].items()}
            for row in trace["rows"]:
                cid,idx=row["cable_id"],int(row["core_index"]);gi=slot_group.get((cid,idx),1)
                c=self.store.cable(cid);core=self.store.core(cid,idx)
                if not core:continue
                if not c and str(cid).startswith("PORT:"):
                    n=self.store.node(str(cid).split(":",1)[1]);section=n["name"] if n else "내부포트";cable_name="내부포트"+(f'({core["label"]})' if "label" in core.keys() else "")
                elif c:
                    a=self.store.node(c["n1id"]);b=self.store.node(c["n2id"]);section=f'{a["name"]} ↔ {b["name"]}';cable_name=(c["spec"] or f'{c["size"]}C')+(f'({c["cable_id"]})' if c["cable_id"] else '')
                else:continue
                connected="접속" if self.store.conn.execute("SELECT 1 FROM splices WHERE (cable1_id=? AND core1_index=?) OR (cable2_id=? AND core2_index=?)",(cid,idx,cid,idx)).fetchone() else "끝점"
                check=trace.get('checks',{}).get((cid,idx),{})
                self.tree.insert('','end',values=(display_core_id(core['core_id']),gi,section,cable_name,idx,core['detail'],signal_label(core['signal']),check.get('identity','일치'),check.get('connection',connected)),tags=('mismatch' if check.get('mismatch') else 'pending' if '미접속' in check.get('connection','') else '',))
        draw_trace_diagram(self.diagram,combined);self.last_highlight=dict(combined["cable_colors"]);self.parent.start_highlight_blink(self.last_highlight,owner=self,core_labels=core_path_number_labels([r for t in traces for r in t['rows']]),core_rows=[r for t in traces for r in t['rows']])
        legend=" · ".join(f'{display_core_id(core_id)}={color}' for core_id,color in combined["core_colors"].items())
        missing_text=(" · 찾지 못함: "+", ".join(display_core_id(value) for value in missing)) if missing else ""
        issue_count=sum(len(trace["issues"]) for trace in traces);path_count=sum(len(trace["groups"]) for trace in traces)
        details='\n'.join(display_core_id(t['core_id'])+' · '+t['summary'] for t in traces if t.get('summary'))
        self.summary.set((details+'\n' if details else '')+combined['summary']+f' · 확인필요 {issue_count}건{missing_text}')

    def blink_again(self):
        if self.last_highlight:self.run()

    def _clear_parent_highlight(self):
        try:
            self.parent.stop_highlight_blink(clear=True)
        except (AttributeError,tk.TclError):pass

    def clear(self):
        self._clear_parent_highlight()
        try:self.parent.status.set("코어추적 강조를 해제했습니다.")
        except (AttributeError,tk.TclError):pass

    def close(self):
        if self._trace_closed:return
        self._clear_parent_highlight();self._trace_closed=True;self.destroy()

    def on_destroy(self,event):
        # 우측 위 X뿐 아니라 메인 Esc 처리로 닫혀도 강조가 남지 않게 한다.
        if event.widget is self and not self._trace_closed:
            self._trace_closed=True;self._clear_parent_highlight()


class CableTraceDialog(workflow.RememberedToplevel):
    def __init__(self,parent,store):
        super().__init__(parent);self.parent=parent;self.store=store;self.title("케이블추적 · 전체 코어내역 / 개별 경로");self.geometry("1480x880");self._closed=False;self.results=[];self.all_highlight=set();self.trace_by_item={};self.overview_text=""
        self.protocol("WM_DELETE_WINDOW",self.close);self.bind("<Destroy>",self.on_destroy,add="+")
        cables=store.cables();bases=[]
        for cable in cables:
            a=store.node(cable["n1id"]);b=store.node(cable["n2id"]);cid=clean_cable_id(cable["cable_id"]);base=f'{a["name"] if a else "?"} ↔ {b["name"] if b else "?"} · {cable["spec"] or str(cable["size"])+"C"}'+(f' · {cid}' if cid else '');bases.append(base)
        counts={base:bases.count(base) for base in set(bases)};seen={};self.mapping={}
        for cable,base in zip(cables,bases):
            seen[base]=seen.get(base,0)+1;label=base+(f' · {seen[base]}번선' if counts[base]>1 else '');self.mapping[label]=cable["id"]
        selected_cable=next((key for key in getattr(parent,"selected",set()) if store.cable(key)),None);default=next((label for label,cid in self.mapping.items() if cid==selected_cable),next(iter(self.mapping),""))
        top=ttk.Frame(self,padding=8);top.pack(fill="x");ttk.Label(top,text="추적할 케이블").pack(side="left");self.choice=tk.StringVar(value=default)
        ttk.Combobox(top,textvariable=self.choice,values=list(self.mapping),state="readonly",width=72).pack(side="left",padx=5)
        ttk.Button(top,text="전체 코어내역·전체추적",command=self.run).pack(side="left");ttk.Button(top,text="선택 코어 추적",command=self.trace_selected).pack(side="left",padx=5)
        self.summary=tk.StringVar(value="전체 코어내역을 확인하고 행을 클릭하면 해당 코어만 따로 추적합니다.");ttk.Label(self,textvariable=self.summary,padding=(10,0,10,6),foreground="#415a77").pack(fill="x")
        columns=("num","id","detail","s1","s2","signal","result","route","issue")
        tree_frame=ttk.Frame(self);tree_frame.pack(fill="both",expand=True,padx=8,pady=(0,5));tree_frame.rowconfigure(0,weight=1);tree_frame.columnconfigure(0,weight=1)
        self.tree=workflow.SortableTreeview(tree_frame,columns=columns,displaycolumns=tuple(c for c in columns if c!="s2"),show="headings",selectmode="browse",height=14)
        labels=("번호","코어ID","코어내역","상태","상태2","신호","추적결과","전체 경로","확인내용")
        widths=(55,125,165,75,75,65,80,470,300)
        for col,label,width in zip(columns,labels,widths):self.tree.heading(col,text=label);self.tree.column(col,width=width)
        self.tree.tag_configure("확인필요",background="#fff3e0",foreground="#b71c1c");self.tree.tag_configure("정상",background="#e8f5e9",foreground="#1b5e20")
        self.tree.tag_configure("빈 코어",background="#fafafa",foreground="#777777")
        self.tree.grid(row=0,column=0,sticky="nsew");tree_y=ttk.Scrollbar(tree_frame,orient="vertical",command=self.tree.yview);tree_x=ttk.Scrollbar(tree_frame,orient="horizontal",command=self.tree.xview);tree_y.grid(row=0,column=1,sticky="ns");tree_x.grid(row=1,column=0,sticky="ew");self.tree.configure(yscrollcommand=tree_y.set,xscrollcommand=tree_x.set);self.tree.bind("<<TreeviewSelect>>",self.trace_selected);self.tree.bind("<Double-Button-1>",self.trace_selected)
        diagram_frame=ttk.LabelFrame(self,text="전체/선택 코어 연결 경로",padding=4);diagram_frame.pack(fill="both",expand=True,padx=8,pady=(0,8));diagram_frame.rowconfigure(0,weight=1);diagram_frame.columnconfigure(0,weight=1)
        self.diagram=tk.Canvas(diagram_frame,bg="#ffffff",height=300,highlightthickness=0);self.diagram.grid(row=0,column=0,sticky="nsew")
        sx=ttk.Scrollbar(diagram_frame,orient="horizontal",command=self.diagram.xview);sy=ttk.Scrollbar(diagram_frame,orient="vertical",command=self.diagram.yview);sx.grid(row=1,column=0,sticky="ew");sy.grid(row=0,column=1,sticky="ns");self.diagram.configure(xscrollcommand=sx.set,yscrollcommand=sy.set)
        if default:self.after_idle(self.run)

    def run(self):
        cable_id=self.mapping.get(self.choice.get());self.tree.delete(*self.tree.get_children());self.results=[];self.all_highlight=set();self.trace_by_item={};draw_trace_diagram(self.diagram,{})
        if not cable_id:return
        rows=list(self.store.cores(cable_id));used_rows=[row for row in rows if str(row["core_id"] or "").strip()]
        context=self.store.trace_context();traces={};normal=0
        for row in used_rows:
            core_id=str(row["core_id"] or "").strip()
            key=(core_id,int(row['core_index'])) if workflow.field_slot_mode(self.store) else core_id
            if key not in traces:
                trace=self.store.trace_core_paths(core_id,context,slot=(cable_id,int(row['core_index'])));traces[key]=trace;self.results.append(trace);normal+=bool(trace["complete"])
        for row in rows:
            idx=int(row["core_index"]);core_id=str(row["core_id"] or "").strip();trace=traces.get((core_id,idx) if workflow.field_slot_mode(self.store) else core_id)
            if trace:
                result="정상" if trace["complete"] else "확인필요";route=trace_path_text(trace);issue=" / ".join(trace["issues"][:3]) or "-";tag=result
            else:result="빈 코어";route="";issue="";tag="빈 코어"
            iid=str(idx);self.tree.insert("","end",iid=iid,values=(idx,display_core_id(core_id),row["detail"] or "",workflow.core_status_text(self.store,row) if core_id else "","",signal_label(row["signal"]) if core_id else "",result,route,issue),tags=(tag,))
            if trace:self.trace_by_item[iid]=trace
        for trace in self.results:self.all_highlight.update(trace.get("highlight") or ())
        usage=self.store.cable_usage(cable_id);unique=len(self.results)
        self.overview_text=f'전체 {usage["total"]}코어 · 사용 {usage["used"]}코어 · 사용율 {usage["rate"]:.1f}% · 고유 코어ID {unique}개 · 정상 {normal}개 · 확인필요 {unique-normal}개'
        self.show_overview()

    def selected_trace(self):
        if not self.tree.selection():return None
        return self.trace_by_item.get(self.tree.selection()[0])

    def trace_selected(self,event=None):
        trace=self.selected_trace()
        if not trace:
            if self.tree.selection():
                self.parent.stop_highlight_blink(clear=True);draw_trace_diagram(self.diagram,{});self.summary.set(self.overview_text+" · 선택한 번호는 빈 코어라 추적 경로가 없습니다.")
            return
        draw_trace_diagram(self.diagram,trace);self.parent.start_highlight_blink(trace["highlight"])
        self.summary.set(f'선택 코어 {display_core_id(trace["core_id"])} · '+(trace.get('summary') or ("연결 정상" if trace["complete"] else f'확인필요 {len(trace["issues"])}건'))+f' · 경로 케이블 {len(trace["highlight"])}개 계속 깜빡임')

    def show_overview(self):
        cable_id=self.mapping.get(self.choice.get())
        for item in self.tree.selection():self.tree.selection_remove(item)
        self.diagram.delete("all");self.diagram.create_text(24,32,anchor="w",text="전체 코어내역은 위 표에서 확인할 수 있습니다.",fill="#1769aa",font=("Malgun Gothic",12,"bold"));self.diagram.create_text(24,65,anchor="w",text="코어 행을 클릭하면 해당 코어 경로만 그림으로 표시하고 도면에서 따로 깜빡입니다.",fill="#555555",font=("Malgun Gothic",10));self.diagram.configure(scrollregion=(0,0,1000,150))
        self.summary.set(self.overview_text+f' · 전체 경로 케이블 {len(self.all_highlight)}개 계속 깜빡임')
        if self.all_highlight or cable_id:self.parent.start_highlight_blink(self.all_highlight or {cable_id})

    def close(self):
        if self._closed:return
        self._closed=True;self.parent.stop_highlight_blink(clear=True);self.destroy()

    def on_destroy(self,event):
        if event.widget is self and not self._closed:
            self._closed=True
            try:self.parent.stop_highlight_blink(clear=True)
            except (AttributeError,tk.TclError):pass


class OverviewEndCoresDialog(workflow.RememberedToplevel):
    """V201: read-only list of the clicked cable's cores that end at one facility."""
    def __init__(self,parent,store,model,info):
        super().__init__(parent,position_family='OverviewEndCores');self.parent=parent;self.store=store
        cable=store.cable(model['cable_id']);label=(cable['cable_id'] or cable['spec'] or '케이블') if cable else '케이블'
        self.title(f'{label} → {info["name"]} 도착 코어');self.geometry('980x520')
        head=f'{label} 케이블 코어 중 {info["name"]}에 {info["arrive"]}코어 도착'+(f' · 미접속 {info["stop"]}코어' if info['stop'] else '')
        ttk.Label(self,text=head,padding=(10,8),font=('Malgun Gothic',11,'bold'),foreground='#1565c0').pack(fill='x')
        frame=ttk.Frame(self);frame.pack(fill='both',expand=True,padx=8);frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        columns=('number','core_id','detail','signal','state','end')
        self.tree=workflow.SortableTreeview(frame,columns=columns,show='headings')
        for c,l,w in zip(columns,('번호','코어ID','코어내역','신호','상태','도착 위치'),(60,170,280,80,70,300)):self.tree.heading(c,text=l);self.tree.column(c,width=w,anchor='center' if c in ('number','signal','state') else 'w')
        self.tree.tag_configure('stop',foreground='#c62828',background='#fff1f2')
        self.rows=[(c['number'],display_core_id(c['core_id']),c['detail'],signal_label(c['signal']),c['state'],c['end']) for c in info['cores']]
        for i,(row,core) in enumerate(zip(self.rows,info['cores'])):self.tree.insert('','end',iid=str(i),values=row,tags=('stop',) if core['state']=='미접속' else ())
        self.tree.grid(row=0,column=0,sticky='nsew');sy=ttk.Scrollbar(frame,orient='vertical',command=self.tree.yview);sy.grid(row=0,column=1,sticky='ns');self.tree.configure(yscrollcommand=sy.set)
        bar=ttk.Frame(self,padding=8);bar.pack(fill='x')
        ttk.Button(bar,text='목록 복사 (Excel)',command=self.copy_rows).pack(side='left')
        ttk.Button(bar,text='닫기',command=self.destroy).pack(side='right')
        self.bind('<Escape>',lambda e:self.destroy())

    def copy_rows(self):
        text='\n'.join('\t'.join(map(str,r)) for r in [('번호','코어ID','코어내역','신호','상태','도착 위치')]+self.rows)
        self.clipboard_clear();self.clipboard_append(text)


class CommonCoresDialog(workflow.RememberedToplevel):
    """V203: two cables picked (Ctrl+click) -> cores used in both, each cable's number side by side."""
    COLUMNS=('core_id','a_number','a_detail','b_number','b_detail','same')
    def __init__(self,parent,store,cable_a,cable_b):
        super().__init__(parent,position_family='CommonCores');self.parent=parent;self.store=store
        self.geometry('1060x540');self.head=tk.StringVar();self.summary=tk.StringVar()
        ttk.Label(self,textvariable=self.head,padding=(10,8,10,0),font=('Malgun Gothic',11,'bold'),foreground='#1565c0').pack(fill='x')
        ttk.Label(self,textvariable=self.summary,padding=(10,2,10,6)).pack(fill='x')
        frame=ttk.Frame(self);frame.pack(fill='both',expand=True,padx=8);frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        self.tree=workflow.SortableTreeview(frame,columns=self.COLUMNS,show='headings')
        for c,w in zip(self.COLUMNS,(180,80,280,80,280,70)):self.tree.column(c,width=w,anchor='center' if c in ('a_number','b_number','same') else 'w')
        self.tree.grid(row=0,column=0,sticky='nsew');sy=ttk.Scrollbar(frame,orient='vertical',command=self.tree.yview);sy.grid(row=0,column=1,sticky='ns');self.tree.configure(yscrollcommand=sy.set)
        bar=ttk.Frame(self,padding=8);bar.pack(fill='x')
        ttk.Button(bar,text='목록 복사 (Excel)',command=self.copy_rows).pack(side='left')
        ttk.Button(bar,text='A·B 바꾸기',command=self.swap).pack(side='left',padx=6)
        ttk.Label(bar,text='도면에서 Ctrl+클릭으로 케이블 2개를 고르면 이 창이 바뀝니다.',foreground='#64748b').pack(side='left',padx=8)
        ttk.Button(bar,text='닫기',command=self.destroy).pack(side='right')
        self.bind('<Escape>',lambda e:self.destroy())
        self.show(cable_a,cable_b)

    def show(self,cable_a,cable_b):
        model=self.model=workflow.cable_common_cores(self.store,cable_a,cable_b)
        a='A '+model['label_a'];b='B '+model['label_b']
        self.title(f'겹치는 코어 · {model["label_a"]} ↔ {model["label_b"]}')
        self.head.set(f'A: {model["label_a"]}   ↔   B: {model["label_b"]}');self.summary.set(model['summary'])
        self.headings=('코어ID','A 번호','A 코어내역','B 번호','B 코어내역','같은 번호')
        for c,l in zip(self.COLUMNS,self.headings):self.tree.heading(c,text=l)
        self.tree.delete(*self.tree.get_children())
        self.rows=[(display_core_id(r['core_id']),r['a_number'],r['a_detail'],r['b_number'],r['b_detail'],'O' if r['a_number']==r['b_number'] else '') for r in model['rows']]
        for i,row in enumerate(self.rows):self.tree.insert('','end',iid=str(i),values=row)
        if not self.rows:self.tree.insert('','end',iid='empty',values=('겹치는 코어가 없습니다.','','','','',''))

    def swap(self):self.show(self.model['cable_b'],self.model['cable_a'])

    def copy_rows(self):
        m=self.model;head=('코어ID',f'A 번호 ({m["label_a"]})','A 코어내역',f'B 번호 ({m["label_b"]})','B 코어내역','같은 번호')
        text='\n'.join('\t'.join(map(str,r)) for r in [head]+self.rows)
        self.clipboard_clear();self.clipboard_append(text)
        self.summary.set(m['summary']+f' · {len(self.rows)}줄 복사됨 (Excel에 붙여넣기)')


class CoreInfoDialog(workflow.RememberedToplevel):
    def __init__(self,parent,store):
        super().__init__(parent);self.store=store;self.title("코어정보 일괄입력");self.geometry("950x720")
        cables=store.cables();self.mapping={f'{store.node(c["n1id"])["name"]} ↔ {store.node(c["n2id"])["name"]} · {c["spec"]}'+(f' · {c["cable_id"]}' if c["cable_id"] else ''):c["id"] for c in cables}
        top=ttk.Frame(self,padding=8);top.pack(fill="x");ttk.Label(top,text="입력 기준").pack(side="left")
        self.choice=tk.StringVar(value=next(iter(self.mapping),"전체 입력"));self.combo=ttk.Combobox(top,textvariable=self.choice,values=list(self.mapping)+["전체 입력"],state="readonly",width=55);self.combo.pack(side="left",padx=5)
        ttk.Button(top,text="선택 케이블 기존정보 불러오기",command=self.load).pack(side="left")
        ttk.Label(self,text="선택 케이블: 번호<TAB>코어ID<TAB>코어명\n전체 입력: 케이블ID 또는 연결구간<TAB>번호<TAB>코어ID<TAB>코어명",padding=8,foreground="#1769aa").pack(fill="x")
        self.text=tk.Text(self,font=("Consolas",11),wrap="none");self.text.pack(fill="both",expand=True,padx=8)
        ttk.Button(self,text="검사 후 저장·연동",command=self.save).pack(anchor="e",padx=8,pady=8)
        self.result=tk.Text(self,height=8);self.result.pack(fill="x",padx=8,pady=(0,8))

    def load(self):
        cid=self.mapping.get(self.choice.get())
        if not cid:return
        lines=[f'{r["core_index"]}\t{r["core_id"]}\t{r["detail"]}' for r in self.store.cores(cid)]
        self.text.delete("1.0","end");self.text.insert("1.0","\n".join(lines))

    def global_cable(self,text):
        wanted=clean_cable_id(text).casefold();found=[]
        for c in self.store.cables():
            a=self.store.node(c["n1id"]);b=self.store.node(c["n2id"]);section=f'{a["name"]}-{b["name"]}'.casefold()
            if wanted and wanted in {clean_cable_id(c["cable_id"]).casefold(),section,f'{b["name"]}-{a["name"]}'.casefold()}:found.append(c)
        return found[0] if len(found)==1 else None,len(found)

    def save(self):
        fixed=self.mapping.get(self.choice.get());lines=self.text.get("1.0","end-1c").splitlines();todo=[];errors=[]
        for line_no,line in enumerate(lines,1):
            if not line.strip():continue
            cols=[x.strip() for x in line.split("\t")]
            try:
                if fixed:
                    if len(cols)<2:raise ValueError("번호와 코어ID가 필요합니다.")
                    cid=fixed;idx=int(cols[0]);core_id=cols[1];detail=cols[2] if len(cols)>2 else ""
                else:
                    if len(cols)<3:raise ValueError("케이블, 번호, 코어ID가 필요합니다.")
                    c,count=self.global_cable(cols[0])
                    if not c:raise ValueError("케이블을 찾지 못했습니다." if count==0 else f"같은 케이블ID가 {count}개입니다.")
                    cid=c["id"];idx=int(cols[1]);core_id=cols[2];detail=cols[3] if len(cols)>3 else ""
                cable=self.store.cable(cid)
                if idx<1 or idx>cable["size"]:raise ValueError(f"{idx}번은 {cable['spec']} 범위 밖입니다.")
                todo.append((line_no,cid,idx,core_id,detail))
            except Exception as e:errors.append(f"{line_no}행: {e}")
        saved=0
        with self.store.action("코어정보 일괄입력"):
            for line_no,cid,idx,core_id,detail in todo:
                old=self.store.core(cid,idx)
                try:self.store.update_core(cid,idx,[core_id,detail,old["status1"],old["status2"],old["signal"]]);saved+=1
                except ValueError as e:errors.append(f"{line_no}행 {idx}번: {e}")
        self.result.delete("1.0","end");self.result.insert("end",f"저장 {saved}건\n"+("\n".join(errors[:100]) if errors else "오류 없음"))


class QuickAssignDialog(workflow.RememberedToplevel):
    def __init__(self,parent,store):
        super().__init__(parent);self.parent=parent;self.store=store;self.title("빠른 코어배정");self.geometry("1050x700")
        top=ttk.Frame(self,padding=8);top.pack(fill="x");self.core_id=tk.StringVar();self.detail=tk.StringVar();self.index=tk.IntVar(value=1)
        ttk.Label(top,text="코어ID").pack(side="left");ttk.Entry(top,textvariable=self.core_id,width=22).pack(side="left",padx=4);ttk.Label(top,text="코어명").pack(side="left");ttk.Entry(top,textvariable=self.detail,width=30).pack(side="left",padx=4)
        body=ttk.Panedwindow(self,orient="horizontal");body.pack(fill="both",expand=True,padx=8)
        left=ttk.LabelFrame(body,text="도면 케이블",padding=5);right=ttk.LabelFrame(body,text="배정할 케이블/번호",padding=5);body.add(left,weight=1);body.add(right,weight=1)
        self.available=workflow.SortableTreeview(left,columns=("section","cable","size"),show="headings",selectmode="browse")
        for c,l,w in zip(("section","cable","size"),("구간","케이블ID","규격"),(280,130,70)):self.available.heading(c,text=l);self.available.column(c,width=w)
        self.cable_map={}
        for c in store.cables():
            if str(c["spec"] or "").strip()=="드랍":continue
            a=store.node(c["n1id"]);b=store.node(c["n2id"]);self.cable_map[c["id"]]=c;self.available.insert("","end",iid=c["id"],values=(f'{a["name"]} ↔ {b["name"]}',c["cable_id"] or "-",c["spec"]))
        self.available.pack(fill="both",expand=True)
        addbar=ttk.Frame(left);addbar.pack(fill="x",pady=5);ttk.Label(addbar,text="코어번호").pack(side="left");ttk.Spinbox(addbar,from_=1,to=288,textvariable=self.index,width=8).pack(side="left",padx=4);ttk.Button(addbar,text="선택 추가",command=self.add).pack(side="left")
        self.chosen=workflow.SortableTreeview(right,columns=("section","cable","num"),show="headings")
        for c,l,w in zip(("section","cable","num"),("구간","케이블","번호"),(280,130,60)):self.chosen.heading(c,text=l);self.chosen.column(c,width=w)
        self.chosen.pack(fill="both",expand=True);ttk.Button(right,text="선택 목록삭제",command=self.remove).pack(anchor="e",pady=5)
        bottom=ttk.Frame(self,padding=8);bottom.pack(fill="x");ttk.Button(bottom,text="선택 저장/자동연결",command=self.save).pack(side="right");self.msg=tk.StringVar(value="경로를 이루는 케이블과 사용할 코어번호를 차례로 추가하세요.");ttk.Label(bottom,textvariable=self.msg,foreground="#1769aa").pack(side="left")
        self.selected=[]

    def add(self):
        if not self.available.selection():return
        cid=self.available.selection()[0];c=self.cable_map[cid];idx=int(self.index.get())
        if idx<1 or idx>c["size"]:messagebox.showerror("번호 오류",f"{c['spec']}에는 {idx}번이 없습니다.",parent=self);return
        if (cid,idx) in self.selected:return
        vals=self.available.item(cid,"values");self.selected.append((cid,idx));self.chosen.insert("","end",iid=f"{cid}:{idx}",values=(vals[0],vals[1],idx))
    def remove(self):
        for iid in self.chosen.selection():
            cid,idx=iid.rsplit(":",1);self.selected=[x for x in self.selected if x!=(cid,int(idx))];self.chosen.delete(iid)
    def save(self):
        core_id=self.core_id.get().strip()
        if not core_id or not self.selected:messagebox.showinfo("입력 필요","코어ID와 배정할 케이블을 입력하세요.",parent=self);return
        result=workflow.run_bulk(self,self.store,'quick_assign_many',(self.selected,core_id,self.detail.get().strip()))
        if result is None:return
        saved,connected,errors=result
        self.parent.refresh();self.msg.set(f"배정 {saved}건 · 자동접속 {connected}건 · 확인필요 {len(errors)}건")
        if errors:messagebox.showwarning("확인필요","\n".join(errors[:100]),parent=self)


class AllCoreDialog(workflow.RememberedToplevel):
    def __init__(self,parent,store):
        super().__init__(parent);self.parent=parent;self.store=store;self._rows_stamp=None;self._rows=[]
        self._generation=getattr(store,'_view_generation',0)
        self.title("전체 코어내역 / 일괄수정");self.geometry("1250x760");self.minsize(900,520)
        top=ttk.Frame(self,padding=8);top.pack(fill="x")
        ttk.Label(top,text='검색').pack(side='left')
        self.search=tk.StringVar();e=ttk.Entry(top,textvariable=self.search,width=28);e.pack(side="left",padx=(4,12));e.bind("<KeyRelease>",lambda x:self.reload())
        self.status_filter=tk.StringVar(value='상태 전체');self.signal_filter=tk.StringVar(value='신호 전체')
        ttk.Label(top,text='상태').pack(side='left')
        self.status_combo=ttk.Combobox(top,textvariable=self.status_filter,state='readonly',width=16)
        self.status_combo.pack(side='left',padx=(4,12));self.status_combo.bind('<<ComboboxSelected>>',lambda e:self.reload())
        ttk.Label(top,text='신호').pack(side='left')
        combo=ttk.Combobox(top,textvariable=self.signal_filter,values=('신호 전체',)+SIGNAL_VALUES,state='readonly',width=10)
        combo.pack(side='left',padx=(4,8));combo.bind('<<ComboboxSelected>>',lambda e:self.reload())
        ttk.Button(top,text='필터 초기화',command=self.reset_filters).pack(side='left',padx=4)
        ttk.Button(top,text="새로고침",command=self.reload).pack(side="left",padx=4)
        self.summary=tk.StringVar();ttk.Label(self,textvariable=self.summary,padding=(10,0,10,5)).pack(anchor='w')
        cols=("id","detail","s1","s2","signal","count","route")
        table=ttk.Frame(self);table.pack(fill='both',expand=True,padx=8)
        self.tree=workflow.SortableTreeview(table,columns=cols,show="headings",selectmode="browse")
        for c,l,w in zip(cols,("코어ID","코어명","상태","상태2","신호","위치수","경로"),(150,220,240,0,75,60,430)):self.tree.heading(c,text=l);self.tree.column(c,width=w)
        self.tree.configure(displaycolumns=("id","detail","s1","signal","count","route"))
        y=ttk.Scrollbar(table,orient='vertical',command=self.tree.yview);x=ttk.Scrollbar(table,orient='horizontal',command=self.tree.xview)
        self.tree.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        self.tree.grid(row=0,column=0,sticky='nsew');y.grid(row=0,column=1,sticky='ns');x.grid(row=1,column=0,sticky='ew')
        table.rowconfigure(0,weight=1);table.columnconfigure(0,weight=1)
        self.tree.bind("<<TreeviewSelect>>",self.pick);self.tree.bind('<Button-3>',self.context_menu)
        form=ttk.Frame(self,padding=8);form.pack(fill="x");self.vars=[tk.StringVar() for _ in range(5)]
        for i,(lab,var) in enumerate(zip(("코어ID","코어명","상태1","상태2","신호"),self.vars)):
            if i in (2,3):continue
            ttk.Label(form,text=lab).grid(row=0,column=i*2,sticky="e",padx=2)
            if i<2:ttk.Entry(form,textvariable=var,width=18).grid(row=0,column=i*2+1,padx=3)
            else:ttk.Combobox(form,textvariable=var,values=SIGNAL_VALUES,state="readonly",width=10).grid(row=0,column=i*2+1,padx=3)
        ttk.Button(form,text="상태 변경",command=self.edit_annotations).grid(row=0,column=4,columnspan=4,padx=6)
        ttk.Button(form,text="선택 코어 전체 반영",command=self.apply).grid(row=0,column=10,padx=8)
        self.bind('<Escape>',lambda e:self.destroy());self.reload()

    def current_store(self):
        if self.parent.store is self.store and getattr(self.store,'_view_generation',0)==self._generation:return True
        messagebox.showwarning('다시 열기','작업 도면이 변경되었습니다. 전체코어내역을 다시 열어 주세요.',parent=self)
        return False

    def reload(self,selected_id=None):
        if not self.current_store():return
        selected=selected_id or next(iter(self.tree.selection()),None);scroll=self.tree.yview()
        stamp=(getattr(self.store,'_view_generation',0),self.store.data_revision(),self.store.conn.total_changes)
        if stamp!=self._rows_stamp:
            self._rows=[];choices=list(workflow.STATUS_NAMES.values())
            for row in self.store.core_analysis():
                row=workflow.annotate(self.store,row)
                labels=list(dict.fromkeys(row['annotation_labels']+workflow.phase_names(self.store,row)))
                if 'unknown' in (row['status1'],row['status2']) and '확인필요' not in labels:labels.append('확인필요')
                row['_labels']=set(labels);row['_status_text']=workflow.core_status_text(self.store,row)
                row['_signal_text']=signal_label(row['signal'])
                row['_search']=(row['core_id']+' '+str(row['detail'] or '')+' '+row['route']+' '+row['_status_text']).casefold()
                self._rows.append(row);choices.extend(labels)
            value=workflow.state(self.store)
            choices.extend(p['name'] for p in value['phases']);choices.extend(value.get('annotation_catalog',[]))
            choices.extend([self.status_filter.get()])
            self.status_combo.configure(values=tuple(dict.fromkeys(['상태 전체','상태 없음']+choices)))
            self._rows_stamp=(getattr(self.store,'_view_generation',0),self.store.data_revision(),self.store.conn.total_changes)
        q=self.search.get().strip().casefold();status=self.status_filter.get();signal=self.signal_filter.get()
        self.tree.delete(*self.tree.get_children());count=0
        for row in self._rows:
            if q and q not in row['_search']:continue
            if status=='상태 없음':
                if row['_labels']:continue
            elif status!='상태 전체' and status not in row['_labels']:continue
            if signal!='신호 전체' and signal!=row['_signal_text']:continue
            self.tree.insert("","end",iid=row['core_id'],values=(row['core_id'],row['detail'],row['_status_text'],"",row['_signal_text'],row['count'],row['route']),tags=(workflow.field_slot_tag(self.store,row,core_row_tag(row)),core_signal_tag(row)));count+=1
        configure_core_tags(self.tree)
        if selected and self.tree.exists(selected):self.tree.selection_set(selected);self.tree.focus(selected)
        if scroll:self.tree.yview_moveto(scroll[0])
        self.pick();self.summary.set(f'표시 {count}개 / 전체 {len(self._rows)}개 · 코어 행을 오른쪽 클릭하면 상태·신호를 변경합니다. 같은 코어ID에 공통 적용됩니다.')

    def refresh_shared_rows(self):
        if 'tree' not in self.__dict__ or getattr(self.store,'_view_generation',0)!=self._generation:return
        stamp=(self.store.data_revision(),self.store.conn.total_changes)
        if getattr(self,'_shared_rows_stamp',None)==stamp:return
        self._shared_rows_stamp=stamp;self._rows_stamp=None
        # Update displayed status without triggering selection events that replace form drafts.
        for row in self.store.core_analysis():
            iid=row['core_id']
            if not self.tree.exists(iid):continue
            values=list(self.tree.item(iid,'values'));values[1]=row['detail'];values[2]=workflow.core_status_text(self.store,row);values[4]=signal_label(row['signal'])
            self.tree.item(iid,values=values,tags=(workflow.field_slot_tag(self.store,row,core_row_tag(row)),core_signal_tag(row)))

    def reset_filters(self):
        self.search.set('');self.status_filter.set('상태 전체');self.signal_filter.set('신호 전체');self.reload()

    def pick(self,e=None):
        selected=self.tree.selection()
        values=self.tree.item(selected[0],"values")[:5] if selected else ('',)*5
        for var,value in zip(self.vars,values):var.set(value)

    def context_menu(self,event):
        row_id=self.tree.identify_row(event.y)
        if not row_id:return 'break'
        self.tree.selection_set(row_id);self.tree.focus(row_id);self.tree.focus_set();self.pick()
        previous=getattr(self,'_context_menu',None)
        if previous is not None:previous.destroy()
        menu=tk.Menu(self,tearoff=False);self._context_menu=menu
        menu.add_command(label='상태 변경…',command=lambda:self.edit_annotations(row_id))
        signal_menu=tk.Menu(menu,tearoff=False)
        for label in SIGNAL_VALUES:
            signal_menu.add_command(label=label,command=lambda value=label:self.change_signal(row_id,SIGNAL_FROM_LABEL[value]))
        menu.add_cascade(label='신호 변경',menu=signal_menu)
        try:menu.tk_popup(event.x_root,event.y_root)
        finally:menu.grab_release()
        return 'break'

    def after_change(self,selected_id=None):
        self.parent.refresh();self.reload(selected_id)

    def change_signal(self,core_id,signal):
        if not self.current_store():return
        if workflow.field_slot_mode(self.store):
            rows=self.store.all_core_rows(core_id)
            if not rows:return
            first=rows[0];dialog=workflow.FieldSlotEditorDialog(self,self.store,slot=(first['cable_id'],int(first['core_index'])))
            dialog.signal.set(signal_label(signal));dialog.summary.set('신호는 케이블 번호별로 변경합니다. 변경할 번호를 선택하고 「선택 슬롯 신호 적용」을 누르세요.')
            return
        try:self.store.set_core_signal(core_id,signal)
        except ValueError as error:messagebox.showerror('신호 변경',str(error),parent=self);return
        self.after_change(core_id)

    def apply(self):
        if not self.tree.selection() or not self.current_store():return
        old=self.tree.selection()[0];rows=self.store.all_core_rows(old)
        if not rows:self.reload();return
        row=rows[0];new_id=self.vars[0].get().strip()
        try:self.store.rename_core_group(old,new_id,self.vars[1].get(),row["status1"],row["status2"],SIGNAL_FROM_LABEL.get(self.vars[4].get(),""))
        except ValueError as e:messagebox.showerror("수정하지 않음",str(e),parent=self);return
        self.after_change(new_id)

    def edit_annotations(self,core_id=None):
        if not self.current_store():return
        core_id=core_id or next(iter(self.tree.selection()),None)
        if not core_id:return
        rows=self.store.all_core_rows(core_id)
        if not rows:self.reload();return
        row=rows[0]
        workflow.AnnotationDialog(self,self.store,(row["cable_id"],row["core_index"]),lambda:self.after_change(core_id))


class BeforeDrawingCheckDialog(workflow.RememberedToplevel):
    FILTERS=("전체","오류","경고")
    def __init__(self,parent,store):
        super().__init__(parent);self.parent=parent;self.store=store;self.title("전 도면 완성도 점검");self.geometry("1320x850");self.minsize(900,600)
        self._trace_job=None;self._trace_key=None;self._trace_view={}
        self.bind('<Destroy>',self.cleanup_trace,add='+')
        heading=tk.Frame(self,bg="#e3f2fd",highlightbackground="#90caf9",highlightthickness=1);heading.pack(fill="x",padx=8,pady=(8,4))
        tk.Label(heading,text="전 도면 완성도 점검",font=("Malgun Gothic",13,"bold"),fg="#0d47a1",bg="#e3f2fd").pack(side="left",padx=12,pady=9)
        tk.Label(heading,text="후 도면 작성 전에 고쳐야 할 연결·입력 문제를 모아 봅니다.",fg="#315b7d",bg="#e3f2fd").pack(side="left",padx=6)
        top=ttk.Frame(self,padding=(8,4));top.pack(fill="x")
        ttk.Label(top,text="표시").pack(side="left");self.filter=tk.StringVar(value="전체")
        combo=ttk.Combobox(top,textvariable=self.filter,values=self.FILTERS,state="readonly",width=11);combo.pack(side="left",padx=(4,12));combo.bind("<<ComboboxSelected>>",lambda e:self.show_rows())
        self.summary=tk.StringVar();ttk.Label(top,textvariable=self.summary,font=("Malgun Gothic",10,"bold")).pack(side="left")
        ttk.Button(top,text="새로고침",command=self.reload).pack(side="right",padx=3)
        ttk.Button(top,text="CSV 저장",command=self.csv_save).pack(side="right",padx=3)
        ttk.Button(top,text="선택 위치 열기",command=self.open_selected).pack(side="right",padx=3)
        ttk.Button(top,text="도면 강조 해제",command=self.clear_trace).pack(side="right",padx=3)
        self.info=tk.StringVar();ttk.Label(self,textvariable=self.info,padding=(10,2,10,7),foreground="#415a77",wraplength=1260,justify="left").pack(fill="x")
        table_frame=ttk.Frame(self);table_frame.pack(fill="both",expand=True,padx=8,pady=(0,8))
        table_frame.rowconfigure(0,weight=1);table_frame.columnconfigure(0,weight=1)
        cols=("level","category","location","core_id","message")
        self.tree=workflow.SortableTreeview(table_frame,columns=cols,show="headings",selectmode="browse",height=11)
        for col,label,width in zip(cols,("등급","구분","위치","코어ID","확인내용"),(75,110,270,180,600)):
            self.tree.heading(col,text=label);self.tree.column(col,width=width,minwidth=60,stretch=col in ("location","message"))
        self.tree.tag_configure("오류",background="#ffebee",foreground="#b71c1c")
        self.tree.tag_configure("경고",background="#fff8e1",foreground="#6d4c00")
        self.tree.grid(row=0,column=0,sticky="nsew")
        sy=ttk.Scrollbar(table_frame,orient="vertical",command=self.tree.yview);sy.grid(row=0,column=1,sticky="ns")
        sx=ttk.Scrollbar(table_frame,orient="horizontal",command=self.tree.xview);sx.grid(row=1,column=0,sticky="ew")
        self.tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        self.tree.bind('<<TreeviewSelect>>',self.queue_trace);self.tree.bind('<ButtonRelease-1>',self.queue_trace,add='+')
        self.tree.bind('<Return>',self.queue_trace);self.tree.bind("<Double-Button-1>",self.queue_trace)
        details=ttk.LabelFrame(self,text='선택 코어의 모든 점검 사유',padding=5);details.pack(fill='x',padx=8,pady=(0,8))
        text_frame=ttk.Frame(details);text_frame.pack(fill='x')
        self.issue_details=tk.Text(text_frame,height=4,wrap='word',state='disabled',font=('Malgun Gothic',9))
        scroll=ttk.Scrollbar(text_frame,orient='vertical',command=self.issue_details.yview);self.issue_details.configure(yscrollcommand=scroll.set)
        self.issue_details.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
        locations=ttk.Frame(details);locations.pack(fill='x',pady=(4,0))
        ttk.Label(locations,text='열 위치').pack(side='left',padx=(0,5))
        self.issue_location=ttk.Combobox(locations,state='readonly',width=90);self.issue_location.pack(side='left',fill='x',expand=True)
        ttk.Button(locations,text='위치 열기',command=self.open_selected).pack(side='left',padx=(5,0))
        self._detail_group=None
        self.trace_summary=tk.StringVar(value='코어ID를 클릭하면 아래에 연결 경로를 표시합니다. 도면 강조색: 주황색')
        ttk.Label(self,textvariable=self.trace_summary,padding=(10,0,10,5),foreground='#415a77',wraplength=1260).pack(fill='x')
        diagram_frame=ttk.LabelFrame(self,text='선택 코어 연결 경로 · 함체 / 케이블 / 코어번호',padding=4)
        diagram_frame.pack(fill='both',expand=True,padx=8,pady=(0,8));diagram_frame.rowconfigure(0,weight=1);diagram_frame.columnconfigure(0,weight=1)
        self.diagram=tk.Canvas(diagram_frame,bg='#ffffff',height=230,highlightthickness=0);self.diagram.grid(row=0,column=0,sticky='nsew')
        dx=ttk.Scrollbar(diagram_frame,orient='horizontal',command=self.diagram.xview);dx.grid(row=1,column=0,sticky='ew')
        dy=ttk.Scrollbar(diagram_frame,orient='vertical',command=self.diagram.yview);dy.grid(row=0,column=1,sticky='ns')
        self.diagram.configure(xscrollcommand=dx.set,yscrollcommand=dy.set)
        self.rows=[];self.visible=[];self.reload()

    def reload(self):
        self.rows=workflow.completion_check_groups(self.store.before_drawing_check_rows());work=self.store.work_required_cores()
        actual=sum(bool(str(row.get("core_id") or "").strip()) and not str(row.get("core_id") or "").startswith("임시-") for row in work)
        self.info.set("필수 코어 연결 완료율 "+workflow.completion_rate_text(self.store.drawing_connection_progress())+f" · 작업필요코어 {len(work)}개 중 실제 코어ID 확인 {actual}개. 같은 코어ID는 한 행으로 묶으며 오류·경고가 함께 있으면 오류로 분류합니다. 클릭하면 모든 점검 사유와 전체 경로를 표시합니다. 사유별로 열 위치를 선택할 수 있습니다. 코어ID 없는 시설·케이블 문제는 별도 행으로 표시합니다.")
        self.show_rows()

    def show_rows(self):
        self.clear_trace();self.show_issue_details(None)
        errors=sum(row["level"]=="오류" for row in self.rows);warnings=sum(row["level"]=="경고" for row in self.rows)
        if not errors and not warnings:self.summary.set("오류 0 · 경고 0 · 현재 점검항목 정상")
        else:self.summary.set(f"전체 {len(self.rows)}행 · 코어ID {sum(bool(r.get('core_id')) for r in self.rows)}개 · 오류 {errors} · 경고 {warnings}")
        self.tree.delete(*self.tree.get_children());self.visible=[];chosen=self.filter.get()
        for row in self.rows:
            if chosen!="전체" and row["level"]!=chosen:continue
            iid=str(len(self.visible));self.visible.append(row)
            values=list(self.row_values(row));values[-1]=values[-1].replace('\n\n',' | ').replace('\n',' · ')
            self.tree.insert("","end",iid=iid,values=values,tags=(row["level"],))

    @staticmethod
    def row_values(row):
        core_id=display_core_id(row.get('core_id')) or ('(코어ID 없음)' if row.get('core_index',"")!="" else '—')
        return row["level"],row["category"],row["location"],core_id,row["message"]

    def selected_row(self):
        if not self.tree.selection():return None
        try:return self.visible[int(self.tree.selection()[0])]
        except (ValueError,IndexError):return None

    def show_issue_details(self,row):
        if row is self._detail_group and row is not None:return
        self._detail_group=row
        items=row.get('_check_items',(row,)) if row else ()
        self.issue_location.configure(values=tuple(f"{i}. [{r['level']} · {r['category']}] {r['location']}" for i,r in enumerate(items,1)))
        if items:self.issue_location.current(0)
        else:self.issue_location.set('')
        self.issue_details.configure(state='normal',foreground='#b71c1c' if row and row['level']=='오류' else '#6d4c00')
        self.issue_details.delete('1.0','end')
        self.issue_details.insert('1.0',row['message'] if row else '코어ID를 선택하면 관련 점검 사유를 모두 표시합니다.')
        self.issue_details.configure(state='disabled');self.issue_details.yview_moveto(0)

    def queue_trace(self,event=None):
        if self._trace_job is not None:self.after_cancel(self._trace_job)
        self._trace_job=self.after_idle(self.trace_selected)
        return 'break'

    def trace_selected(self):
        self._trace_job=None;row=self.selected_row();self.show_issue_details(row);app=owning_app(self)
        if app is None or app.store is not self.store:
            self.clear_trace();return
        core_id=str(row.get('core_id') or '').strip() if row else ''
        if not core_id:
            self.clear_trace()
            if row:self.trace_summary.set('이 항목에는 코어ID가 없습니다. 확인내용과 선택 위치 열기에서 입력 상태를 확인하세요.')
            return
        key=(getattr(self.store,'_view_generation',0),self.store.data_revision(),core_id)
        if self._trace_key==key and getattr(app,'highlight_owner',None) is self:return
        trace=self.store.trace_core_paths(core_id)
        if not trace['rows']:
            self.clear_trace();self.trace_summary.set('현재 도면에서 해당 코어ID를 찾지 못했습니다. 새로고침 후 확인하세요.');return
        view=connection_trace_view(self.store,[trace]);draw_trace_diagram(self.diagram,view)
        self.diagram.xview_moveto(0);self.diagram.yview_moveto(0)
        self._trace_key=key;self._trace_view=view
        app.start_highlight_blink(view['cable_colors'],owner=self,core_labels=core_path_number_labels(trace['rows']),core_rows=trace['rows'])
        self.trace_summary.set(f"코어ID {display_core_id(core_id)} · "+view['summary'])

    def clear_trace(self,redraw=True):
        if self._trace_job is not None:
            try:self.after_cancel(self._trace_job)
            except tk.TclError:pass
        self._trace_job=None;self._trace_key=None;self._trace_view={}
        app=owning_app(self)
        if app is not None and getattr(app,'highlight_owner',None) is self:app.stop_highlight_blink(clear=True)
        if redraw:
            draw_trace_diagram(self.diagram,{})
            self.trace_summary.set('코어ID를 클릭하면 아래에 연결 경로를 표시합니다. 도면 강조색: 주황색')

    def cleanup_trace(self,event):
        if event.widget is self:self.clear_trace(redraw=False)

    def open_selected(self,event=None):
        row=self.selected_row()
        if not row:return
        self.show_issue_details(row)
        items=row.get('_check_items',(row,));index=self.issue_location.current()
        row=items[index] if 0<=index<len(items) else items[0]
        cable_id=row.get("cable_id");node_id=row.get("node_id");core_id=str(row.get("core_id") or "").strip()
        if row['category'].startswith('현장 ') and node_id and self.store.node(node_id):
            workflow.FieldSurveyDialog(self,self.store,node_id);return
        if cable_id and not str(cable_id).startswith("PORT:") and self.store.cable(cable_id):open_detail_dialog(self.parent,self.store,'cable',cable_id);return
        if node_id and self.store.node(node_id):open_detail_dialog(self.parent,self.store,'properties',node_id);return
        if core_id:
            window=TraceDialog(self.parent,self.store);workflow.navigation_link(self,window);window.q.set(core_id);window.run();return
        messagebox.showinfo("점검 위치",f'{row["location"]}\n\n{row["message"]}',parent=self)

    def csv_save(self):
        path=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="전도면_완성도_점검.csv",parent=self)
        if not path:return
        with open(path,"w",newline="",encoding="utf-8-sig") as file:
            writer=csv.writer(file);writer.writerow(("등급","구분","위치","코어ID","확인내용"))
            for row in self.rows:writer.writerow(self.row_values(row))
        messagebox.showinfo("저장 완료",path,parent=self)


class CoreCheckDialog(workflow.RememberedToplevel):
    CATEGORIES={"작업필요코어(전체)":"work","전체코어":"all","신호있음":"on","신호없음":"off","신호확인필요":"unknown","신호예외":"signal_exception","신호섞임":"signal_mixed","배정필요":"need","미완료코어":"incomplete","완료코어":"complete","경로오류":"patherror","끊어진 중복경로":"disconnected","내역없음":"noinfo","해지코어":"cancel","끊김코어":"broken","오류코어":"error","예외코어":"exception"}
    def __init__(self,parent,store):
        super().__init__(parent);self.parent=parent;self.store=store;self.title("코어확인 / 작업목록");self.geometry("1250x760")
        self._generation=getattr(store,'_view_generation',0);self._edit_core=None;self._edit_preview=None;self._name_original='';self.row_meta={}
        self.categories={"작업필요코어(전체)":"work"}
        if parent.scenario_kind()=="after":self.categories["코어연결필요"]="work_connection"
        self.categories.update(self.CATEGORIES);default=next(iter(self.categories))
        top=ttk.Frame(self,padding=8);top.pack(fill="x");self.kind=tk.StringVar(value=default);cb=ttk.Combobox(top,textvariable=self.kind,values=list(self.categories),state="readonly",width=25);cb.pack(side="left");cb.bind("<<ComboboxSelected>>",lambda e:(self.forget_route_choice(),self.reload()))
        self.count=tk.StringVar();ttk.Label(top,textvariable=self.count).pack(side="left",padx=12);ttk.Button(top,text="인쇄 미리보기",command=self.print_view).pack(side="right",padx=3);ttk.Button(top,text="CSV 저장",command=self.csv_save).pack(side="right")
        ttk.Button(top,text='새로고침',command=self.refresh_list).pack(side='right',padx=3)
        ttk.Button(top,text='도면 강조 해제',command=self.clear_route).pack(side='right',padx=3)
        ttk.Button(top,text='예외 해제',command=lambda:self.set_exception(False)).pack(side='right',padx=3)
        ttk.Button(top,text='예외로 빼기',command=lambda:self.set_exception(True)).pack(side='right',padx=3)
        self.work_basis=tk.StringVar()
        ttk.Label(self,textvariable=self.work_basis,padding=(8,0,8,4),wraplength=1100,foreground="#415a77").pack(fill="x")
        self._route_job=None;self._route_key=None
        self.route_info=tk.StringVar(value='코어를 클릭하면 도면에 경로가 깜빡이며 표시됩니다.')
        ttk.Label(self,textvariable=self.route_info,padding=(8,0,8,4),wraplength=1100,foreground="#1769aa").pack(fill="x")
        self.bind('<Destroy>',self.cleanup_route,add='+')
        cols=("method","signal","id","detail","category","note","route")
        table=ttk.Frame(self);table.pack(fill='both',expand=True,padx=8,pady=8);table.rowconfigure(0,weight=1);table.columnconfigure(0,weight=1)
        self.tree=workflow.SortableTreeview(table,columns=cols,show="headings",selectmode='browse')
        for c,l,w in zip(cols,("작업방법","신호","코어ID","코어명","구분","확인내용","경로"),(90,70,140,180,100,220,420)):self.tree.heading(c,text=l);self.tree.column(c,width=w)
        self.tree.grid(row=0,column=0,sticky='nsew')
        sy=ttk.Scrollbar(table,orient='vertical',command=self.tree.yview);sy.grid(row=0,column=1,sticky='ns')
        sx=ttk.Scrollbar(table,orient='horizontal',command=self.tree.xview);sx.grid(row=1,column=0,sticky='ew');self.tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        form=ttk.Frame(self,padding=8);form.pack(fill='x');form.columnconfigure(2,weight=1)
        self.selected_core=tk.StringVar(value='코어 선택');ttk.Label(form,textvariable=self.selected_core,width=25).grid(row=0,column=0,sticky='w')
        ttk.Label(form,text='코어명').grid(row=0,column=1,padx=4)
        self.name_var=tk.StringVar();self.name_entry=ttk.Entry(form,textvariable=self.name_var);self.name_entry.grid(row=0,column=2,sticky='ew',padx=4)
        self.name_entry.bind('<Return>',self.apply_name)
        self.name_button=ttk.Button(form,text='같은 ID 코어명 전체 반영',command=self.apply_name);self.name_button.grid(row=0,column=3,padx=4)
        self.name_scope=tk.StringVar(value='행 선택 후 코어명을 수정하세요.');ttk.Label(form,textvariable=self.name_scope,wraplength=1100).grid(row=1,column=0,columnspan=4,sticky='w',pady=(4,0))
        ttk.Label(form,text='작업 임시코어 신호: 현장 끝단 케이블 기준 · 일반 코어 목록: 현재 도면 같은 ID 전체 기준',foreground='#1769aa').grid(row=2,column=0,columnspan=4,sticky='w',pady=(4,0))
        self.copy_actions=workflow.CoreWorklistCopy(self)
        self.tree.bind('<<TreeviewSelect>>',self.on_select);self.tree.bind('<Double-Button-1>',self.double_click);self.rows=[];self.reload()
        # V169: every click on a row shows its path, even when the row was already selected.
        self.tree.bind('<ButtonRelease-1>',self.click_route,add='+')

    def on_select(self,event=None):
        self.pick_name(event);self.queue_route()

    def forget_route_choice(self):
        self._route_key=None;self._route_choice=None

    def click_route(self,event=None):
        if event is not None and not self.tree.identify_row(event.y):return
        self.forget_route_choice();self.queue_route()

    def queue_route(self):
        if self._route_job is not None:
            try:self.after_cancel(self._route_job)
            except tk.TclError:pass
        self._route_job=self.after_idle(self.show_route)

    def show_route(self):
        """Single click: blink the selected core's saved route on the main drawing."""
        self._route_job=None;app=owning_app(self.parent)
        if app is None or not self.current_store():return
        selected=self.tree.selection();core_id,slot=self.row_meta.get(selected[0],('',None)) if selected else ('',None)
        core_id=str(core_id or '').strip()
        if not selected:return
        if not core_id and not slot:
            self.clear_route();self.route_info.set('이 행은 코어ID가 없어 경로를 표시할 수 없습니다.');return
        key=(getattr(self.store,'_view_generation',0),self.store.data_revision(),core_id,slot)
        if self._route_key==key and getattr(app,'highlight_owner',None) is self:return
        # A list reload reselects the same row; never take the map back from another window.
        if self.__dict__.get('_route_choice')==(core_id,slot) and getattr(app,'highlight_owner',None) is not self:return
        if core_id:
            trace=self.store.trace_core_paths(core_id,slot=slot)
            if not trace['rows'] and not slot:
                self.clear_route();self.route_info.set('현재 도면에서 이 코어의 경로를 찾지 못했습니다. 새로고침 후 확인하세요.');return
            rows=trace['rows'];view=connection_trace_view(self.store,[trace]) if rows else {'cable_colors':{slot[0]:'#ff7a00'}}
            app.start_highlight_blink(view['cable_colors'],owner=self,core_labels=core_path_number_labels(rows),core_rows=rows,core_slots=[slot] if slot else None)
        else:app.start_highlight_blink({slot[0]:'#ff7a00'},owner=self,core_slots=[slot])
        self._route_key=key;self._route_choice=(core_id,slot)
        model=getattr(app,'highlight_connection_model',{}) or {}
        self.route_info.set(f"{display_core_id(core_id) if core_id else '선택 코어'} 경로 표시 중 · 케이블 {len(app.highlight_cables)}개"+(' · '+model['summary'] if model.get('summary') else '')+' · 도면 오른쪽 위 안내에서 색별 코어ID·케이블 확인')

    def clear_route(self):
        if self._route_job is not None:
            try:self.after_cancel(self._route_job)
            except tk.TclError:pass
        self._route_job=None;self._route_key=None;self._route_choice=None
        app=owning_app(self.parent)
        if app is not None and getattr(app,'highlight_owner',None) is self:app.stop_highlight_blink(clear=True)
        try:self.route_info.set('코어를 클릭하면 도면에 경로가 깜빡이며 표시됩니다.')
        except tk.TclError:pass

    def cleanup_route(self,event):
        if event.widget is self:
            if self._route_job is not None:
                try:self.after_cancel(self._route_job)
                except tk.TclError:pass
            self._route_job=None
            app=owning_app(self.parent)
            if app is not None and getattr(app,'highlight_owner',None) is self:app.stop_highlight_blink(clear=True)

    def current_store(self):
        return self.parent.store is self.store and getattr(self.store,'_view_generation',0)==self._generation

    def add_row(self,values,core_id,slot=None,fallback_signal='',field_signal=False):
        info=workflow.core_check_info(self.store,core_id,slot,fallback_signal);values=list(values);values[1]=signal_label(fallback_signal) if field_signal else info['label']
        if info['current']:values[3]=' / '.join(name for name in info['names'] if name)
        if info['warning']:values[5]=(str(values[5])+' · ' if values[5] and values[5]!='-' else '')+info['warning']
        self.rows.append(tuple(values));self._row_keys.append((str(core_id or '').strip(),tuple(slot) if slot else None))

    def render_rows(self):
        self.copy_actions.clear()
        self.tree.delete(*self.tree.get_children());self.row_meta={}
        for index,(values,key) in enumerate(zip(self.rows,self._row_keys)):
            iid='row'+str(index);self.row_meta[iid]=key;self.tree.insert('','end',iid=iid,values=values)
            if key==self._selected_key:self.tree.selection_set(iid);self.tree.focus(iid)
        if self._scroll:self.tree.yview_moveto(self._scroll[0])
        self._rows_stamp=(self.store.data_revision(),self.store.conn.total_changes);self.pick_name()

    def pick_name(self,event=None):
        if not self.current_store():self.name_button.configure(state='disabled');return
        selected=self.tree.selection();key=self.row_meta.get(selected[0]) if selected else None
        self.name_button.configure(state='disabled')
        if not key or not key[0]:self.name_scope.set('코어ID가 있는 행을 선택하면 현재 도면의 같은 ID 이름을 전체 수정할 수 있습니다.');return
        cid=key[0]
        if self._edit_core==cid and self.name_var.get()!=self._name_original:
            self.name_button.configure(state='normal' if self._edit_preview else 'disabled');return
        self._edit_core=cid;self.selected_core.set('코어ID: '+display_core_id(cid));self._edit_preview=None
        names=workflow.core_id_overview(self.store).get(cid,{}).get('names',[])
        self._name_original=next((name for name in names if name),'');self.name_var.set(self._name_original)
        try:self._edit_preview=self.store.preview_core_name(cid)
        except ValueError as error:self.name_scope.set(str(error));return
        self.name_button.configure(state='normal')
        self.name_scope.set(f"현재 도면의 같은 ID {len(self._edit_preview['positions'])}개 위치 전체 반영 · 케이블·RN 내부포트 포함"+(' · 서로 다른 코어명을 입력한 이름으로 통일합니다.' if len(names)>1 else ''))

    def apply_name(self,event=None):
        if not self.current_store():messagebox.showwarning('다시 열기','작업 도면이 변경되었습니다. 코어확인 목록을 다시 열어 주세요.',parent=self);return 'break'
        self.pick_name()
        selected=self.tree.selection();key=self.row_meta.get(selected[0]) if selected else None
        if not key or key[0]!=self._edit_core or not self._edit_preview:return 'break'
        try:changed=self.store.commit_core_name(self._edit_preview,self.name_var.get())
        except (ValueError,sqlite3.Error,OSError) as error:messagebox.showerror('코어명 변경',str(error),parent=self);return 'break'
        self._name_original=self.name_var.get();self.parent.refresh();self.reload()
        self.name_scope.set(f'같은 ID 코어명 {changed}곳 반영 완료 · Ctrl+Z로 전체 실행취소' if changed else '이미 같은 코어명입니다.')
        return 'break'

    def set_exception(self,enabled):
        """V167: 예외코어 on/off for the selected row; signal and splices stay."""
        if not self.current_store():messagebox.showwarning('다시 열기','작업 도면이 변경되었습니다. 코어확인 목록을 다시 열어 주세요.',parent=self);return
        selected=self.tree.selection();core_id,slot=self.row_meta.get(selected[0],('',None)) if selected else ('',None)
        core_id=str(core_id or '').strip()
        if not core_id and slot and self.store.core(*slot):core_id=str(self.store.core(*slot)['core_id'] or '').strip()
        title='예외로 빼기' if enabled else '예외 해제'
        if not core_id or core_id.startswith('('):messagebox.showinfo(title,'코어ID(또는 임시코어)가 있는 행을 선택하세요.',parent=self);return
        slots=[slot] if slot and str(self.store.core(*slot)['core_id'] or '').strip()==core_id else self.store.core_id_slots([core_id])
        try:changed=self.store.set_cores_exception(slots,enabled)
        except (ValueError,sqlite3.Error) as error:messagebox.showerror(title,str(error),parent=self);return
        if not changed:messagebox.showinfo(title,f'{display_core_id(core_id)}: 이미 '+('예외코어입니다.' if enabled else '예외코어가 아닙니다.'),parent=self);return
        self.parent.refresh();self.reload()
        self.route_info.set(f'{display_core_id(core_id)} '+('예외코어로 지정 · 미완료·오류 목록에서 빠짐 · 신호 그대로' if enabled else '예외 해제 · 실제 연결 상태로 다시 계산')+' · Ctrl+Z로 실행취소')

    def double_click(self,event):
        if self.tree.identify_column(event.x)=='#4' and self.tree.identify_row(event.y):
            self.tree.selection_set(self.tree.identify_row(event.y));self.pick_name();self.name_entry.focus_set();self.name_entry.selection_range(0,'end');return 'break'
        self.trace_selected(event)

    def refresh_shared_rows(self):
        if self.current_store() and getattr(self,'_rows_stamp',None)!=(self.store.data_revision(),self.store.conn.total_changes):self.reload()

    def refresh_list(self):
        # Explicit reread renews the reviewed scope without discarding typed text.
        cid=self._edit_core;draft=self.name_var.get();dirty=draft!=self._name_original
        self._edit_core=None;self.reload()
        if dirty and self._edit_core==cid:self.name_var.set(draft)

    def reload(self):
        if not self.current_store():return
        selected=self.tree.selection();self._selected_key=self.row_meta.get(selected[0]) if selected else None;self._scroll=self.tree.yview()
        key=self.categories[self.kind.get()];self.rows=[];self._row_keys=[]
        self.work_basis.set('작업대상: 실제 코어ID 또는 현장 끝단 케이블 신호 ON 임시코어 · 현장반영·후도면만 비교 (임시도면 제외) · 절단 포함 → 절단절체 / 절단 없이 철거·선번·접속 변경 → 코어절체 · 전체 목록은 완료 코어도 유지')
        work_report=self.parent.work_report();checked=work_report['rows']
        methods={r.get("core_id"):r.get("method","") for r in checked if r.get("core_id")}
        if key in ("work","work_connection"):
            for row in checked:
                if key=="work_connection" and (row.get("handled_missing") or row.get("complete") or row.get("result")=="완료" or (row.get('excluded') and not row.get('pending'))):continue
                before=" / ".join(row.get("source_routes") or [])
                note=row.get("note") or "후 도면에서 끝단까지 연결을 완료해야 합니다."
                route=row.get("current_route") or ("현장반영: "+before if before else "-")
                slots=list(row.get('source_slots') or ());slot=slots[0] if not row.get('core_id') and len(slots)==1 else None
                self.add_row((row.get("method") or "-","",row.get("core_id") or "(코어ID 없음)",row.get("detail") or "",row.get("result","확인필요"),f'{row.get("result","확인필요")} · {note}',route),row.get('core_id'),slot,row.get('signal'),bool(row.get('field_endpoints')))
            self.render_rows()
            cut=sum(r[0]=="절단절체" for r in self.rows);transfer=sum(r[0]=="코어절체" for r in self.rows)
            other=len(self.rows)-cut-transfer
            self.count.set(f"총 {len(self.rows)}개 · 절단절체 {cut} · 코어절체 {transfer}"+(f" · 구분없음(-) {other}" if other else ''))
            if work_report.get("kind")=="gis":self.work_basis.set("임시도면은 작업대상 판정에서 제외합니다. 현장반영 또는 후도면에서 작업목록을 확인하세요.")
            elif work_report.get("missing_before"):self.work_basis.set("저장된 현장반영 도면이 없어 작업대상·절체 변경을 비교할 수 없습니다.")
            return
        if key in ('all','complete'):
            report=self.store.drawing_connection_progress()
            for row in report['rows']:
                if key=='complete' and not row['complete']:continue
                first=self.store.core(*row['slots'][0]) if row['slots'] else {}
                route=' → '.join(self.store._slot_title(*slot) for slot in row['slots'])
                self.add_row((methods.get(row['core_id']) or '-','',display_core_id(row['core_id']) or '(코어ID 없음)',row['detail'],'완료' if row.get('exception_complete') else '연결완료' if row['complete'] else '미완료코어',row['reason'] or row['basis'],route),row['core_id'],row['slots'][0] if row['slots'] else None,(first or {}).get('signal',''))
            self.render_rows()
            self.count.set(f"필수 전체코어 {report['total']}개 · 집계 제외 {report['excluded']}개 · 완료율 "+workflow.completion_rate_text(report));return
        if key in ('incomplete','error'):
            grouped={}
            entries_to_show=self.store.incomplete_core_entries() if key=='incomplete' else self.store.error_core_summary()['entries']
            label='미완료코어' if key=='incomplete' else '오류코어'
            for entry in entries_to_show:grouped.setdefault(entry.get('key',('id',entry['core_id'])),[]).append(entry)
            for _,entries in grouped.items():
                core_id=entries[0]['core_id']
                reasons=' / '.join(dict.fromkeys(e['row'][2] for e in entries));route=' → '.join(e['row'][0] for e in entries)
                self.add_row((methods.get(core_id) or '-','',display_core_id(core_id),entries[0].get('detail',''),label,reasons,route),core_id,entries[0].get('slot'))
            self.render_rows()
            self.count.set(f'{label} {len(self.rows)}개');return
        if key=='signal_mixed':
            # V166: only cores whose entered signals differ (ON with OFF ...); 미입력 is neutral.
            for entry in workflow.signal_mixed_cores(self.store):
                route=' / '.join(self.store._slot_title(*slot)+' '+workflow.ROUTE_SIGNAL_SHORT.get(code,code) for slot,code in entry['slots'])
                self.add_row((methods.get(entry['core_id']) or '-','',display_core_id(entry['core_id']),entry['detail'],'신호섞임',entry['text'],route),entry['core_id'])
            self.render_rows()
            self.count.set(f"신호 섞인 코어 {len(self.rows)}개 · 행을 누르면 도면에 경로 표시");return
        all_rows=self.store.core_analysis()
        for r in all_rows:
            include= key=="all" or (key=="work" and r["work"]) or bool(r.get(key))
            if key in ('on','off','unknown','signal_exception'):
                info=workflow.core_check_info(self.store,r['core_id'],fallback_signal=r['signal'])
                include=info['signal']==('exception' if key=='signal_exception' else key)
            if not include:continue
            notes=[]
            if r["need"]:notes.append("일반 함체에서 반대편 배정 필요")
            if r["incomplete"]:notes.append("경로 미완료")
            if r["patherror"]:notes.append(f'끝점 {r["endpoints"]}개')
            if r["disconnected"]:notes.append(f'서로 끊어진 경로 {r["components"]}개')
            category=self.kind.get() if key!="all" else ("예외코어" if r.get("exception") else r["work"] or ("오류" if notes else "정상"))
            self.add_row((methods.get(r["core_id"]) or "-","",r["core_id"],r["detail"],category," / ".join(notes) or "-",r["route"]),r['core_id'],fallback_signal=r['signal'])
        self.render_rows()
        self.count.set(f"총 {len(self.rows)}개")

    def csv_save(self):
        path=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile=f'{self.kind.get()}_목록.csv')
        if not path:return
        with open(path,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f);w.writerow(("작업방법","신호","코어ID","코어명","구분","확인내용","경로"));w.writerows(self.rows)
        messagebox.showinfo("저장 완료",path,parent=self)

    def trace_selected(self,e=None):
        if not self.tree.selection():return
        core_id=self.row_meta.get(self.tree.selection()[0],('',None))[0]
        if not core_id or core_id.startswith("("):
            messagebox.showinfo("코어 추적","추적할 코어ID 또는 임시코어 번호가 필요합니다.",parent=self);return
        w=TraceDialog(self.parent,self.store);workflow.navigation_link(self,w);w.q.set(core_id);w.run()

    def print_view(self):
        folder=app_dir()/"print";folder.mkdir(exist_ok=True);path=folder/(self.kind.get()+"_인쇄.html")
        heads=("작업방법","신호","코어ID","코어명","구분","확인내용","경로")
        table='<table><thead><tr>'+''.join(f'<th>{html.escape(x)}</th>' for x in heads)+'</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{html.escape(str(x or ""))}</td>' for x in row)+'</tr>' for row in self.rows)+'</tbody></table>'
        doc=f'<!doctype html><meta charset="utf-8"><title>{html.escape(self.kind.get())}</title><style>@page{{size:A3 landscape;margin:10mm}}body{{font-family:Malgun Gothic}}table{{border-collapse:collapse;width:100%;font-size:10pt}}th,td{{border:1px solid #777;padding:4px}}th{{background:#e8eef8}}</style><h2>{html.escape(self.kind.get())} - {len(self.rows)}개</h2>'+table
        path.write_text(doc,encoding="utf-8");webbrowser.open(path.as_uri())


class WorkRequiredDialog(workflow.RememberedToplevel):
    FILTERS=("전체","확인필요","완료","작업필요","미완료","누락","끊김","예외 처리","해지","오류","입력누락","폐지 예정","이번 작업 제외","폐지 잔존","제외 재확인","현장반영 도면변경")
    def __init__(self,parent,store):
        super().__init__(parent);self.parent=parent;self.store=store;self.title("작업필요코어 진행표");self.geometry("1420x800");self.minsize(980,580)
        top=ttk.Frame(self,padding=8);top.pack(fill="x")
        ttk.Label(top,text="표시").pack(side="left");self.filter=tk.StringVar(value="확인필요" if parent.scenario_kind()=="after" else "전체")
        combo=ttk.Combobox(top,textvariable=self.filter,values=self.FILTERS,state="readonly",width=13);combo.pack(side="left",padx=(4,12));combo.bind("<<ComboboxSelected>>",lambda e:self.show_rows())
        self.summary=tk.StringVar();ttk.Label(top,textvariable=self.summary,font=("Malgun Gothic",10,"bold")).pack(side="left")
        ttk.Button(top,text="새로고침",command=self.reload).pack(side="right",padx=3)
        ttk.Button(top,text="CSV 저장",command=self.csv_save).pack(side="right",padx=3)
        ttk.Button(top,text="선택 위치 열기",command=self.open_selected).pack(side="right",padx=3)
        ttk.Button(top,text="선택 코어 추적",command=self.trace_selected).pack(side="right",padx=3)
        actions=ttk.Frame(self,padding=(8,0,8,6));actions.pack(fill='x')
        for title,command in (("연결 필요로 복구",lambda:self.set_disposition('연결 필요')),("폐지 예정",lambda:self.set_disposition('폐지 예정')),("이번 작업 제외",lambda:self.set_disposition('이번 작업 제외')),("끝단 변경 승인",self.approve_endpoints),("현장반영 도면 변경 확인",self.review_changes),("점검 결과 기록",self.record_check),("작업 검사 옵션",self.open_options),("처리 이력",self.show_audit)):
            ttk.Button(actions,text=title,command=command).pack(side='left',padx=2)
        progress=ttk.Frame(self,padding=(10,0,10,5));progress.pack(fill="x")
        self.progress_value=tk.DoubleVar(value=0);self.progress_text=tk.StringVar()
        ttk.Progressbar(progress,variable=self.progress_value,maximum=100,length=300).pack(side="left")
        ttk.Label(progress,textvariable=self.progress_text,font=("Malgun Gothic",10,"bold")).pack(side="left",padx=10)
        self.info=tk.StringVar();ttk.Label(self,textvariable=self.info,padding=(10,2,10,7),foreground="#415a77",wraplength=1350,justify="left").pack(fill="x")
        cols=("result","method","signal","id","detail","before","after","note")
        self.tree=workflow.SortableTreeview(self,columns=cols,show="headings",selectmode="extended")
        labels=("결과","작업방법","신호","코어ID","코어명","현장반영 도면 작업대상 구간 / 번호","후 도면 경로","확인내용")
        widths=(85,90,70,140,170,310,360,390)
        for c,label,width in zip(cols,labels,widths):self.tree.heading(c,text=label);self.tree.column(c,width=width,minwidth=55,stretch=c in ("before","after","note"))
        self.tree.tag_configure("완료",background="#e8f5e9",foreground="#1b5e20")
        self.tree.tag_configure("작업필요",background="#e3f2fd",foreground="#0d47a1")
        self.tree.tag_configure("미완료",background="#fff8e1",foreground="#6d4c00")
        self.tree.tag_configure("누락",background="#ffebee",foreground="#b71c1c")
        self.tree.tag_configure("오류",background="#f3e5f5",foreground="#6a1b9a")
        self.tree.tag_configure("입력누락",background="#fce4ec",foreground="#ad1457")
        self.tree.tag_configure("예외 처리",background="#e8f5e9",foreground="#1b5e20")
        for label in ("끊김","해지"):self.tree.tag_configure(label,background="#eeeeee",foreground="#616161")
        self.tree.pack(fill="both",expand=True,padx=8,pady=(0,8));self.tree.bind("<Double-Button-1>",self.trace_selected)
        self.rows=[];self.visible=[];self.reload()

    def reload(self):
        report=self.parent.work_report();rows=report['rows']
        self.info.set(f"대상: 실제 코어ID 또는 현장 끝단 케이블 신호 ON 임시코어 · {report['review']} · 현장반영 도면 반영 확인 {report['pending']}건 · 다중 선택: Ctrl/Shift · 폐지/제외는 원본 코어를 삭제하지 않습니다. 제외 정보가 바뀌면 다시 확인해야 합니다.")
        if report.get('missing_before'):self.info.set('저장된 현장반영 도면이 없습니다. 현장반영 도면에서 Ctrl+S로 저장하세요.')
        self.rows=sorted(rows,key=lambda r:({"현장반영 도면변경":0,"제외 재확인":1,"폐지 잔존":2,"입력누락":3,"오류":4,"누락":5,"미완료":6,"작업필요":7,"완료":8}.get(r.get("result"),9),str(r.get("core_id") or "")))
        self.show_rows()

    def chosen_rows(self):return [self.visible[int(i)] for i in self.tree.selection()]

    def set_disposition(self,kind):
        rows=self.chosen_rows()
        if not rows:messagebox.showinfo('코어 선택','처리할 코어를 먼저 선택하세요.',parent=self);return
        reason=simpledialog.askstring(kind,'사유를 입력하세요. (복구 시 선택 사항)',parent=self)
        if reason is None:return
        try:workflow.Workflow(self.parent).disposition(rows,kind,reason)
        except ValueError as exc:messagebox.showwarning('사유 필요',str(exc),parent=self);return
        self.parent.refresh();self.reload()

    def approve_endpoints(self):
        rows=[r for r in self.chosen_rows() if r.get('endpoint_changed')]
        if not rows:messagebox.showinfo('끝단 변경 승인','끝단 변경이 표시된 후도면 코어를 선택하세요.',parent=self);return
        reason=simpledialog.askstring('끝단 변경 승인','RN/끝단을 변경한 사유를 입력하세요. 다른 오류는 승인되지 않습니다.',parent=self)
        if not reason:return
        workflow.Workflow(self.parent).approve(rows,reason);self.parent.refresh();self.reload()

    def review_changes(self):workflow.preview_changes(self.parent,self);self.reload()
    def record_check(self):
        if self.parent.scenario_kind()!='after':messagebox.showinfo('완료 점검','후도면에서 기록하세요.',parent=self);return
        workflow.Workflow(self.parent).record();self.parent.refresh();self.reload()
    def open_options(self):
        window=workflow.OptionsDialog(self.parent);workflow.navigation_link(self,window);self.wait_window(window);self.reload()
    def show_audit(self):
        rows=[(a['time'],a['action']) for a in workflow.state(self.store)['audit']]
        workflow.TableDialog(self,'작업 처리 이력 (최근 500건)',('일시','작업 내용'),rows)

    def include(self,result):
        chosen=self.filter.get()
        if chosen=="전체":return True
        if chosen=="확인필요":return result not in ("완료","폐지 예정","이번 작업 제외","끊김","예외 처리","해지")
        if chosen=="완료":return result in ("완료","예외 처리")
        return result==chosen

    def show_rows(self):
        counts={name:0 for name in self.FILTERS[2:]}
        for row in self.rows:counts[row.get("result","")]=counts.get(row.get("result",""),0)+1
        excluded=sum(bool(r.get('excluded')) for r in self.rows)
        completed=sum(bool(r.get('complete')) and not r.get('excluded') for r in self.rows)
        self.summary.set(f'전체 {len(self.rows)} · 연결대상 {len(self.rows)-excluded} · 연결대상 제외 {excluded} · 완료 {completed} (예외 처리 {counts.get("예외 처리",0)})')
        if self.parent.scenario_kind()=="after":
            total=len(self.rows)-excluded;done=completed;rate=done*100.0/total if total else 0.0
            self.progress_value.set(rate);self.progress_text.set(f"절체 작업 확인율 {rate:.1f}% ({done}/{total})" if total else "후 도면 작업필요코어 없음")
        else:
            total=len(self.rows)-excluded;ready=sum(row.get("result")=="작업필요" for row in self.rows);rate=ready*100.0/total if total else 0.0
            self.progress_value.set(rate);self.progress_text.set(f"현장반영 도면 작업대상 확인율 {rate:.1f}% ({ready}/{total})" if total else "현장반영 도면 작업필요코어 없음")
        self.tree.delete(*self.tree.get_children());self.visible=[]
        for row in self.rows:
            result=row.get("result","")
            if not self.include(result):continue
            values=(result,row.get("method",""),signal_label(row.get("signal","")),row.get("core_id","") or "(코어ID 없음)",row.get("detail","") or ""," / ".join(row.get("source_routes") or []),row.get("current_route","") or "",row.get("note","") or "")
            iid=str(len(self.visible));self.visible.append(row);self.tree.insert("","end",iid=iid,values=values,tags=(result,))

    def selected_row(self):
        if not self.tree.selection():return None
        try:return self.visible[int(self.tree.selection()[0])]
        except (ValueError,IndexError):return None

    def trace_selected(self,event=None):
        row=self.selected_row();core_id=str(row.get("core_id") or "").strip() if row else ""
        if not core_id:
            messagebox.showinfo("코어 추적","추적할 코어ID 또는 임시코어 번호가 필요합니다.",parent=self);return
        window=TraceDialog(self.parent,self.store);workflow.navigation_link(self,window);window.q.set(core_id);window.run()

    def open_selected(self):
        row=self.selected_row()
        if not row:return
        for cable_id,index in row.get("source_slots") or ():
            if not str(cable_id).startswith("PORT:") and self.store.cable(cable_id):
                open_detail_dialog(self.parent,self.store,'cable',cable_id);return
        core_id=str(row.get("core_id") or "").strip()
        if core_id:self.trace_selected();return
        messagebox.showinfo("선택 위치","현재 도면에서 바로 열 수 있는 케이블 위치가 없습니다. 현장반영 도면 작업대상 구간을 확인하세요.",parent=self)

    def csv_save(self):
        path=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="작업필요코어_진행표.csv",parent=self)
        if not path:return
        heads=("결과","작업방법","신호","코어ID","코어명","현장반영 도면 작업대상 구간 / 번호","후 도면 경로","확인내용")
        with open(path,"w",newline="",encoding="utf-8-sig") as file:
            writer=csv.writer(file);writer.writerow(heads)
            for row in self.rows:
                writer.writerow((row.get("result",""),row.get("method",""),signal_label(row.get("signal","")),row.get("core_id","") or "(코어ID 없음)",row.get("detail","") or ""," / ".join(row.get("source_routes") or []),row.get("current_route","") or "",row.get("note","") or ""))
        messagebox.showinfo("저장 완료",path,parent=self)


class HistoryDialog(workflow.RememberedToplevel):
    def __init__(self,app):
        super().__init__(app);self.app=app;self.store=app.store;self.generation=getattr(self.store,'_view_generation',0)
        self.previous_grab=self.grab_current();self.title('수정 이력 · 원하는 시점으로 돌아가기');self.geometry('1190x760');self.minsize(900,560);self.transient(app);self.grab_set()
        top=ttk.Frame(self,padding=10);top.pack(fill='x');self.summary=tk.StringVar()
        ttk.Label(top,textvariable=self.summary,font=('Malgun Gothic',10,'bold')).pack(side='left')
        ttk.Button(top,text='새로고침',command=self.reload).pack(side='right')
        ttk.Label(self,text='현재 전/후 도면에 저장된 최근 100개 작업입니다. 저장 전 수정표 입력은 해당 창에서 Ctrl+Z로 되돌립니다.',padding=(10,0)).pack(fill='x')
        frame=ttk.Frame(self,padding=10);frame.pack(fill='both',expand=True)
        self.tree=workflow.SortableTreeview(frame,columns=('order','time','label','state','count'),show='headings',selectmode='browse',height=12)
        for key,label,width in (('order','순서',60),('time','시간',175),('label','수정한 작업',540),('state','현재 상태',135),('count','변경 항목 수',100)):
            self.tree.heading(key,text=label);self.tree.column(key,width=width,minwidth=50)
        bar=ttk.Scrollbar(frame,command=self.tree.yview);self.tree.configure(yscrollcommand=bar.set);self.tree.pack(side='left',fill='both',expand=True);bar.pack(side='right',fill='y')
        self.tree.tag_configure('current',background='#fff2b2');self.tree.tag_configure('undone',foreground='#777777')
        self.tree.bind('<<TreeviewSelect>>',self.show_selection)
        ttk.Label(self,text='선택한 작업의 변경 내용',padding=(10,0)).pack(anchor='w')
        box=ttk.Frame(self,padding=(10,4));box.pack(fill='both',expand=True)
        self.details=tk.Text(box,height=10,wrap='word');scroll=ttk.Scrollbar(box,command=self.details.yview);self.details.configure(yscrollcommand=scroll.set,state='disabled')
        self.details.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
        self.restore_info=tk.StringVar();ttk.Label(self,textvariable=self.restore_info,padding=(10,5),foreground='#174b83').pack(fill='x')
        controls=ttk.Frame(self,padding=10);controls.pack(fill='x')
        ttk.Button(controls,text='선택 작업 직전으로',command=lambda:self.restore(before=True)).pack(side='left',padx=4)
        ttk.Button(controls,text='선택 작업 직후로',command=self.restore).pack(side='left',padx=4)
        ttk.Button(controls,text='닫기',command=self.destroy).pack(side='right')
        ttk.Label(self,text='시점 복원 전에 자동 백업합니다. 되돌린 뒤 새로 수정하면 기존 다시실행 목록은 지워집니다.',padding=(10,0,10,10),foreground='#8a4b08').pack(fill='x')
        self.bind('<Escape>',lambda e:self.destroy());self.reload()

    def valid(self):
        if self.app.store is not self.store or self.generation!=getattr(self.store,'_view_generation',0):
            raise ValueError('열린 도면이 변경됐습니다. 수정 이력 창을 닫고 다시 여세요.')

    def reload(self):
        try:self.valid()
        except ValueError as error:self.summary.set(str(error));return
        selected=self.tree.selection();self.rows=self.store.history_rows();self.revision=self.store.data_revision();self.by_id={r['id']:r for r in self.rows}
        active=[r for r in self.rows if not r['undone']];self.current_id=active[-1]['id'] if active else None
        self.tree.delete(*self.tree.get_children())
        for index in range(len(self.rows)-1,-1,-1):
            r=self.rows[index];current=r['id']==self.current_id
            self.tree.insert('','end',iid=r['id'],values=(index+1,r['created_at'].replace('T',' '),r['label'],'현재 시점' if current else '되돌린 작업' if r['undone'] else '적용된 작업',r['event_count']),tags=('current',) if current else ('undone',) if r['undone'] else ())
        kind='전' if self.app.scenario_kind()=='before' else '후'
        self.summary.set(f"현재 {kind}도면 · 보관 이력 {len(self.rows)}개 · 적용 {len(active)}개 · 다시실행 가능 {len(self.rows)-len(active)}개")
        target=selected[0] if selected and selected[0] in self.by_id else self.current_id or (self.rows[-1]['id'] if self.rows else None)
        if target:self.tree.selection_set(target);self.tree.see(target)
        self.show_selection()

    def show_selection(self,event=None):
        selected=self.tree.selection();text='저장된 수정 이력이 없습니다.'
        if selected:
            gid=selected[0];r=self.by_id.get(gid)
            if not r:return
            text=f"{r['created_at']} · {r['label']}\n\n"
            labels={'nodes':'시설','cables':'케이블','cores':'코어','ports':'포트','splices':'접속','survey_rows':'선번 입력','workflow_state':'작업계획·설정','core_annotations':'코어 상태·메모'}
            fields={'core_id':'코어ID','detail':'코어명','status1':'상태1','status2':'상태2','signal':'신호','name':'이름','size':'용량','spec':'규격','status':'상태','label':'포트명','memo':'메모','labels':'상태 표시','x':'가로 위치','y':'세로 위치','extra_json':'시설·케이블 설정','value':'작업계획·설정'}
            events=self.store.conn.execute('SELECT * FROM history_events WHERE group_id=? ORDER BY seq LIMIT 250',(gid,)).fetchall()
            for e in events:
                old=json.loads(e['old_json']) if e['old_json'] else {};new=json.loads(e['new_json']) if e['new_json'] else {};row=new or old;table=e['table_name']
                target=row.get('name') or row.get('core_id') or row.get('cable_id') or ''
                if table in ('cores','ports'):target=f"{row.get('core_index',row.get('port_index'))}번 · {display_core_id(row.get('core_id',''))}"
                if table=='splices':target=f"{row['cable1_id']}/{row['core1_index']}번 ↔ {row['cable2_id']}/{row['core2_index']}번"
                text+=f"[{labels.get(table,table)} {dict(insert='추가',update='수정',delete='삭제')[e['op']]} {target}\n"
                changed=[key for key in fields if key in old or key in new]
                for key in changed:
                    if old.get(key)==new.get(key):continue
                    left=str(old.get(key) or '(빈칸)');right=str(new.get(key) or '(빈칸)')
                    if key in ('extra_json','value'):text+=f"  {fields[key]} 변경\n"
                    else:text+=f"  {fields[key]}: {left[:400]} → {right[:400]}\n"
                text+='\n'
            if r['event_count']>250:text+=f"표시하지 않은 변경 항목 {r['event_count']-250}개가 있습니다. 시점 복원은 해당 작업 전체에 적용됩니다.\n"
            try:
                before=self.store.history_restore_plan(gid,True,self.revision);after=self.store.history_restore_plan(gid,False,self.revision)
                fmt=lambda p:f"{'실행취소' if p['direction']=='undo' else '다시실행'} {len(p['steps'])}개" if p['steps'] else '이미 현재 시점'
                self.restore_info.set('직전으로: '+fmt(before)+'  /  직후로: '+fmt(after))
            except ValueError as error:self.restore_info.set(str(error))
        else:self.restore_info.set('')
        self.details.configure(state='normal');self.details.delete('1.0','end');self.details.insert('1.0',text);self.details.configure(state='disabled')

    def restore(self,before=False):
        try:
            self.valid()
            if self.app.pending_drag:raise ValueError('시설 이동을 먼저 마치세요.')
            if not self.tree.selection():raise ValueError('돌아갈 작업을 선택하세요.')
            gid=self.tree.selection()[0];plan=self.store.history_restore_plan(gid,before,self.revision)
            if not plan['steps']:self.restore_info.set('이미 선택한 시점입니다.');return
            row=self.by_id[gid];when='직전' if before else '직후';direction='되돌립니다' if plan['direction']=='undo' else '다시 적용합니다'
            question=f"{row['created_at']} · {row['label']}\n이 작업 {when}으로 이동하여 {len(plan['steps'])}개 작업을 {direction}.\n\n복원 직전 자동 백업합니다. 열려 있는 도면 편집창은 닫히며, 그 창의 저장 전 입력은 버려집니다.\n선택한 시점으로 돌아갈까요?"
            if not messagebox.askyesno('선택 시점 복원',question,parent=self):return
            result=self.store.restore_history(gid,before,self.revision);self.generation=getattr(self.store,'_view_generation',0)
            for window in list(self.app.winfo_children()):
                if window is self or not isinstance(window,tk.Toplevel):continue
                if getattr(window,'store',None) is self.store or isinstance(window,workflow.AfterPlanDialog):window.destroy()
            self.app.selected.clear();self.app.refresh();self.reload();self.app.status.set(f"수정 이력 {len(plan['steps'])}개 {when} 시점 복원 완료")
            self.restore_info.set('선택한 시점으로 복원했습니다. 확인 후 Ctrl+S로 저장하세요.\n백업: '+str(result['backup'] or ''))
        except (ValueError,sqlite3.Error,OSError) as error:messagebox.showwarning('시점 복원 안 됨',str(error),parent=self)

    def destroy(self):
        previous=getattr(self,'previous_grab',None);super().destroy()
        try:
            if previous and previous.winfo_exists():previous.grab_set()
        except tk.TclError:pass


class ProjectDialog(workflow.RememberedToplevel):
    def __init__(self,app):
        super().__init__(app);self.app=app;self.title("작업관리");self.geometry("650x520")
        ttk.Label(self,text="작업마다 별도의 SQLite 파일로 저장됩니다.",padding=8).pack(fill="x")
        self.tree=workflow.SortableTreeview(self,columns=("name","current","modified"),show="headings",selectmode="browse")
        for c,l,w in zip(("name","current","modified"),("작업명","현재","수정일"),(320,70,180)):self.tree.heading(c,text=l);self.tree.column(c,width=w)
        self.tree.pack(fill="both",expand=True,padx=8)
        bar=ttk.Frame(self,padding=8);bar.pack(fill="x")
        buttons=(("열기",self.open),("새 작업",self.new),("현재 작업 복사",self.copy),("외부 작업 열기",self.open_external),("다른 위치로 복사",self.copy_external),("이름변경",self.rename),("삭제",self.delete))
        for i,(text,fn) in enumerate(buttons):ttk.Button(bar,text=text,command=fn).grid(row=i//4,column=i%4,padx=3,pady=3,sticky="ew")
        for i in range(4):bar.columnconfigure(i,weight=1)
        self.reload()

    def folder(self):
        p=app_dir()/"data"/"projects";p.mkdir(parents=True,exist_ok=True);return p
    def files(self):
        files=[app_dir()/"data"/"telecom_core.sqlite3"]+sorted(self.folder().glob("*.sqlite3"));current=self.app.store.path
        if current.exists() and all(p.resolve()!=current.resolve() for p in files):files.insert(0,current)
        return files
    def reload(self):
        self.tree.delete(*self.tree.get_children());current=self.app.store.path.resolve();self.paths={}
        for i,p in enumerate(self.files()):
            if not p.exists():continue
            label="기본 작업" if p.name=="telecom_core.sqlite3" and p.parent.name=="data" else p.stem
            iid=str(i);self.paths[iid]=p;self.tree.insert("","end",iid=iid,values=(label,"사용중" if p.resolve()==current else "",datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")))
    def selected_path(self):
        if not self.tree.selection():return None
        return self.paths.get(self.tree.selection()[0])
    def safe_name(self):
        name=simpledialog.askstring("작업명","작업 이름을 입력하세요.",parent=self)
        if not name:return None
        name="".join(c for c in name.strip() if c not in '\\/:*?"<>|')
        return name or None
    def open(self):
        p=self.selected_path()
        if p:self.app.switch_project(p);self.reload()
    def new(self):
        name=self.safe_name()
        if not name:return
        p=self.folder()/(name+".sqlite3")
        if p.exists():messagebox.showerror("새 작업", "같은 이름의 작업이 있습니다.",parent=self);return
        Store(p).close();self.app.switch_project(p);self.reload()
    def copy(self):
        name=self.safe_name()
        if not name:return
        p=self.folder()/(name+".sqlite3")
        if p.exists():messagebox.showerror("작업 복사","같은 이름의 작업이 있습니다.",parent=self);return
        self.app.store.backup_to(p);self.reload()
    def open_external(self):
        p=filedialog.askopenfilename(filetypes=[("SQLite 작업파일","*.sqlite3"),("모든 파일","*.*")])
        if not p:return
        test=sqlite3.connect(p)
        try:
            ok=test.execute("PRAGMA integrity_check").fetchone()[0]=="ok"
            tables={r[0] for r in test.execute("SELECT name FROM sqlite_master WHERE type='table'")};ok=ok and {"nodes","cables","cores","splices"}.issubset(tables)
        except Exception:ok=False
        test.close()
        if not ok:messagebox.showerror("작업 열기","정상적인 SQLite 작업파일이 아닙니다.",parent=self);return
        self.app.switch_project(Path(p));self.reload()
    def copy_external(self):
        p=filedialog.asksaveasfilename(defaultextension=".sqlite3",filetypes=[("SQLite 작업파일","*.sqlite3")],initialfile=self.app.store.path.name)
        if not p:return
        if Path(p).resolve()==self.app.store.path.resolve():messagebox.showinfo("작업 복사","현재 사용 중인 파일과 같은 위치입니다.",parent=self);return
        self.app.store.backup_to(p);messagebox.showinfo("작업 복사","현재 작업을 선택한 위치에 복사했습니다.",parent=self)
    def rename(self):
        p=self.selected_path()
        if not p or p.resolve()==self.app.store.path.resolve():messagebox.showinfo("이름변경","사용 중인 작업은 다른 작업을 연 뒤 변경하세요.",parent=self);return
        name=self.safe_name()
        if not name:return
        dest=self.folder()/(name+".sqlite3")
        if dest.exists():messagebox.showerror("이름변경","같은 이름이 있습니다.",parent=self);return
        p.rename(dest);self.reload()
    def delete(self):
        p=self.selected_path()
        if not p or p.resolve()==self.app.store.path.resolve():messagebox.showinfo("삭제","현재 사용 중인 작업은 삭제할 수 없습니다.",parent=self);return
        if messagebox.askyesno("작업 삭제",f'{p.stem} 작업을 삭제할까요?',parent=self):p.unlink();self.reload()


class ScenarioDialog(workflow.RememberedToplevel):
    def __init__(self,app):
        super().__init__(app);self.app=app;self.title("임시도면 / 현장반영 / 후도면 관리");self.geometry("800x580")
        ttk.Label(self,text="임시도면 원본과 현장반영 전도면, 후도면을 따로 보관합니다. 기존 현장반영 도면은 다시 들어가도 유지됩니다.",padding=12).pack(fill="x")
        grid=ttk.Frame(self,padding=10);grid.pack(fill="x")
        buttons=(("현재 단계 저장",lambda:self.save(self.app.scenario_kind())),("도면 새 창으로 열기",lambda:workflow.open_reference_drawing(self.app)),("임시도면 → 현장반영 새로 복사",self.copy_field),("현장반영 → 후도면 생성",self.copy_after),("현장반영/후도면 차이 확인",self.compare),("현장반영 변경 확인 / 작업목록 반영",self.sync_common),("현재 단계 삭제 · 이전 단계로",self.clear),("단계 삭제 되돌리기",self.restore_deleted),("미입력 임시도면 연결 정리",self.separate_field))
        for i,(text,fn) in enumerate(buttons):ttk.Button(grid,text=text,command=fn,width=30).grid(row=i//2,column=i%2,padx=5,pady=5,sticky="ew")
        new_windows=ttk.LabelFrame(self,text="각 도면을 다른 모니터에서 보기",padding=8);new_windows.pack(fill="x",padx=15,pady=(0,4))
        self.reference_buttons={}
        for kind,label in (("gis","임시도면 새 창"),("before","현장도면 새 창"),("after","후도면 새 창")):
            button=ttk.Button(new_windows,text=label,command=lambda k=kind:workflow.open_reference_drawing(self.app,k))
            button.pack(side="left",fill="x",expand=True,padx=3);self.reference_buttons[kind]=button
        self.info=tk.Text(self,height=8);self.info.pack(fill="both",expand=True,padx=10,pady=10);self.refresh_info()
    def separate_field(self):
        try:
            if self.app.scenario_kind()!='before':raise ValueError('현장반영 도면으로 전환한 뒤 사용하세요.')
            if workflow.field_slot_mode(self.app.store):raise ValueError('이미 임시도면 참고 선번과 현장 실제 연결이 분리된 도면입니다.')
            dialog=workflow.FieldConnectionSeparationDialog(self);self.wait_window(dialog);self.refresh_info()
        except (ValueError,sqlite3.Error,OSError) as error:messagebox.showinfo('임시도면 연결 정리',str(error),parent=self)
    def folder(self):
        return self.app.scenario_folder()
    def path(self,kind):return self.app.scenario_path(kind)
    def save(self,kind):
        self.app.save_current_drawing(silent=True);self.refresh_info()
    def copy_field(self):
        if (self.path('before').exists() or self.app.scenario_kind()=='before') and not messagebox.askyesno('현장반영 새로 복사','기존 현장반영 도면을 백업하고 새로 시작할까요? 임시도면의 코어ID·코어명·신호와 기존 접속 선번을 함께 복사합니다. 현장 조사자료는 비우고, 기존 선번부터 검사합니다.',parent=self):return
        try:loaded=self.app.copy_gis_to_field(replace=True)
        except Exception as error:
            messagebox.showerror('현장반영 새로 복사 실패',str(error),parent=self);return
        self.refresh_info()
        if loaded:messagebox.showinfo('현장반영 초기화 완료',self.app.status.get()+'\n\n현재 화면이 새 현장반영 도면으로 전환됐습니다.\n임시도면의 기존 접속 선번과 코어내역이 적용됐습니다. 조사자료 없이도 현재 연결로 검사하며, 현장 선번 적용 후 다시 계산합니다.',parent=self)
    def copy_after(self):
        if not self.app.field_ready_for_after():return
        if not self.path("before").exists():messagebox.showinfo("전/후","먼저 (전)을 저장하세요.",parent=self);return
        exists=self.path("after").exists()
        title="후 도면 다시 생성" if exists else "후 도면 최초 생성"
        question=("기존 후 도면을 백업하고 다시 생성할까요?" if exists else "현재 전 도면으로 후 도면을 생성할까요?")+"\n현장반영에서 하나로 확인된 코어ID·내역을 실제 연결 경로 전체에 입력합니다."
        if not messagebox.askyesno(title,question,parent=self):return
        if self.app.scenario_kind()!="before":
            messagebox.showinfo("전도면 전환","전도면으로 전환한 뒤 생성하세요.",parent=self);return
        self.app.manual_backup(silent=True)
        if exists:
            old=self.path("after");archive=self.folder()/("after_previous_"+datetime.now().strftime("%Y%m%d_%H%M%S_%f")+".sqlite3");shutil.copy2(old,archive)
        try:
            workflow.Workflow(self.app).prepare_after();self.app.save_current_drawing(silent=True)
            report=workflow.after_identity_copy(type(self.app.store),self.path('before'),self.path('after'))
        except (ValueError,sqlite3.Error,OSError) as error:
            messagebox.showerror('후도면 생성 실패',str(error),parent=self);return
        self.refresh_info();self.app.status.set(workflow.after_identity_copy_summary(report))
        messagebox.showinfo('후도면 생성 완료',workflow.after_identity_copy_summary(report),parent=self)
    def load(self,kind):
        if self.app.load_scenario(kind):self.refresh_info()
    def counts(self,path):
        c=sqlite3.connect(path)
        try:return tuple(c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("nodes","cables","cores","splices"))
        finally:c.close()
    def compare(self):
        if not self.path("before").exists() or not self.path("after").exists():messagebox.showinfo("비교","전과 후를 모두 저장하세요.",parent=self);return
        a=self.counts(self.path("before"));b=self.counts(self.path("after"));labels=("시설","케이블","코어","접속")
        self.info.delete("1.0","end");self.info.insert("end","전/후 수량 비교\n\n"+"\n".join(f"{l}: 전 {x} / 후 {y} / 증감 {y-x:+d}" for l,x,y in zip(labels,a,b)))
    def sync_common(self):
        workflow.preview_changes(self.app,self);self.refresh_info()

    def clear(self):
        dialog=workflow.open_stage_delete(self.app,self)
        if dialog is not None:self.wait_window(dialog)
        self.refresh_info()
    def restore_deleted(self):
        workflow.restore_stage_delete(self.app,self)
        self.refresh_info()
    def refresh_info(self):
        self.info.delete("1.0","end")
        active=workflow.SCENARIO_LABELS[self.app.scenario_kind()]
        self.info.insert("end",f"현재 화면: ({active}) 도면\n\n")
        if workflow.field_slot_mode(self.app.store):
            count=self.app.store.conn.execute('SELECT COUNT(*) FROM splices').fetchone()[0]
            self.info.insert('end',f'현장 선번 새 작성 방식 · 현재 접속 연결 {count}건\n코어ID·코어명·신호는 케이블 번호별로 보존됩니다.\n\n')
        for kind,label in workflow.SCENARIO_LABELS.items():
            p=self.path(kind);self.info.insert("end",f"({label}): "+(datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S") if p.exists() else "저장값 없음")+"\n")


class SubscriberKindDialog(workflow.RememberedToplevel):
    def __init__(self,parent):
        super().__init__(parent);self.title('가입자 종류 선택');self.transient(parent);self.resizable(False,False);self.result=None
        ttk.Label(self,text='만들 종류를 클릭하세요.',padding=12).pack()
        row=ttk.Frame(self,padding=(12,0,12,8));row.pack()
        for label,kind in SUBSCRIBER_TYPES.items():
            card=ttk.Frame(row,padding=5);card.pack(side='left',padx=4)
            preview=tk.Canvas(card,width=105,height=86,bg='#f6f8fc',highlightthickness=1,highlightbackground='#d1d9e6',cursor='hand2');preview.pack()
            visual=node_visual({'type':'sub','status':'기설','color':'','name':'','extra_json':json.dumps({'subscriberKind':kind})})
            subscriber_symbol(preview,52,43,visual,.85)
            if visual['text']:preview.create_text(52,43,text=visual['text'],fill=visual['text_fill'],font=('Arial',-29,'bold'))
            preview.bind('<Button-1>',lambda e,k=kind:self.choose(k))
            ttk.Button(card,text=label,width=13,command=lambda k=kind:self.choose(k)).pack(pady=(6,0))
        ttk.Label(self,text='스페이스/Enter: 가입자 · Esc: 취소',padding=(8,0,8,8)).pack()
        ttk.Button(self,text='취소',command=self.destroy).pack(pady=(0,10))
        self.bind('<space>',lambda e:self.choose('subscriber'));self.bind('<Return>',lambda e:self.choose('subscriber'));self.bind('<Escape>',lambda e:self.destroy())
        self.update_idletasks();workflow.center_popup(self,parent);self.grab_set();self.focus_set()
    def choose(self,kind):self.result=kind;self.destroy();return 'break'


class NodePropertiesDialog(workflow.RememberedToplevel):
    def __init__(self,parent,store,node_id):
        super().__init__(parent);self.parent=parent;self.store=store;self.node_id=node_id;self.title("시설 속성");self.resizable(False,False)
        self._generation=getattr(store,'_view_generation',0)
        n=store.node(node_id);f=ttk.Frame(self,padding=15);f.pack();self.name=tk.StringVar(value=n["name"]);self.status=tk.StringVar(value=n["status"] or "기설");self.color=tk.StringVar(value=n["color"] or "자동")
        self.terminal=tk.BooleanVar(value=workflow.terminal_marked(n))
        self.subscriber_type=tk.StringVar(value=next(k for k,v in SUBSCRIBER_TYPES.items() if v==subscriber_kind(n)))
        for i,(lab,var,values) in enumerate((("이름",self.name,None),("상태",self.status,STATUS_VALUES),("색상",self.color,("자동","파란색","빨간색","초록색","분홍색")))):
            ttk.Label(f,text=lab).grid(row=i,column=0,sticky="w",pady=4)
            (ttk.Entry(f,textvariable=var,width=30) if values is None else ttk.Combobox(f,textvariable=var,values=values,state="readonly",width=27)).grid(row=i,column=1,pady=4)
        if n['type'] in ('hamche','sub','rn'):
            ttk.Checkbutton(f,text='말단으로 처리',variable=self.terminal).grid(row=3,column=0,columnspan=2,sticky='w',pady=4)
        if n["type"]=="hamche":
            spec,identifier=hamche_details(n);self.hamche_spec=tk.StringVar(value=spec);self.hamche_id=tk.StringVar(value=identifier)
            for row,(label,var) in enumerate((('함체규격',self.hamche_spec),('함체ID',self.hamche_id)),4):
                ttk.Label(f,text=label).grid(row=row,column=0,sticky='w',pady=4)
                entry=ttk.Entry(f,textvariable=var,width=30);entry.grid(row=row,column=1,pady=4)
                entry.bind('<Control-a>',lambda e,w=entry:select_entry_text(w))
                if var is self.hamche_spec:entry.bind('<FocusOut>',lambda e:self.hamche_spec.set(normalize_hamche_spec(self.hamche_spec.get())))
        if n['type']=='rn':
            identifier,computer_no=rn_details(n)
            self.rn_id=tk.StringVar(value=identifier);self.rn_computer=tk.StringVar(value=computer_no)
            for row,(label,var) in enumerate((('RN ID',self.rn_id),('전산화번호',self.rn_computer)),4):
                ttk.Label(f,text=label).grid(row=row,column=0,sticky='w',pady=4)
                entry=ttk.Entry(f,textvariable=var,width=30);entry.grid(row=row,column=1,pady=4)
                entry.bind('<Control-a>',lambda e,w=entry:select_entry_text(w))
        if n['type']=='sub':
            ttk.Label(f,text='종류').grid(row=4,column=0,sticky='w',pady=4)
            ttk.Combobox(f,textvariable=self.subscriber_type,values=tuple(SUBSCRIBER_TYPES),state='readonly',width=27).grid(row=4,column=1,pady=4)
        ttk.Button(f,text="저장",command=self.save).grid(row={'hamche':6,'rn':6,'sub':5}.get(n['type'],4),column=0,columnspan=2,sticky="ew",pady=8)
        self.bind('<Escape>',lambda e:self.destroy())
        for entry in f.winfo_children():
            if isinstance(entry,ttk.Entry) and not isinstance(entry,ttk.Combobox):entry.bind('<Control-a>',lambda e,w=entry:select_entry_text(w))
        self.refresh_lock_state();self.bind('<FocusIn>',lambda e:self.refresh_lock_state(),add='+')
    def refresh_lock_state(self):
        app=owning_app(self)
        if app and (app.store is not self.store or getattr(self.store,'_view_generation',0)!=self._generation):return
        workflow.set_controls_locked(self,workflow.node_locked(self.store,self.node_id))
    def save(self):
        if workflow.node_locked(self.store,self.node_id):return
        if not self.name.get().strip():return
        with self.store.action("시설 속성 변경"):
            n=self.store.node(self.node_id);extra=json.loads(n["extra_json"] or "{}");extra["rn_terminal_v128" if n["type"]=="rn" else "terminal"]=bool(self.terminal.get())
            self.store.conn.execute("UPDATE nodes SET status=?,color=?,extra_json=? WHERE id=?",(self.status.get(),"" if self.color.get()=="자동" else self.color.get(),json.dumps(extra,ensure_ascii=False),self.node_id))
            hamche=(self.hamche_spec.get(),self.hamche_id.get()) if n['type']=='hamche' else None
            rn=(self.rn_id.get(),self.rn_computer.get()) if n['type']=='rn' else None
            self.store.set_node_details(self.node_id,self.name.get(),hamche=hamche,rn=rn)
            if n['type']=='sub':self.store.set_subscriber_kind(self.node_id,SUBSCRIBER_TYPES[self.subscriber_type.get()])
        self.parent.refresh();self.destroy()


class StartupProjectDialog(workflow.RememberedToplevel):
    """Prevent an old remembered SQLite project from opening without explanation."""
    def __init__(self,app):
        super().__init__(app);self.app=app;self.title("시작할 작업 확인");self.resizable(False,False);self.transient(app);self.grab_set()
        path=app.store.path;modified=datetime.fromtimestamp(path.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S") if path.exists() else "-"
        nodes=len(app.store.nodes());cables=len(app.store.cables())
        frame=ttk.Frame(self,padding=18);frame.pack(fill="both",expand=True)
        ttk.Label(frame,text="이전에 사용하던 작업 데이터가 있습니다.",font=("Malgun Gothic",12,"bold")).pack(anchor="w")
        ttk.Label(frame,text=f"작업명: {path.stem}\n마지막 수정: {modified}\n시설 {nodes}개 · 케이블 {cables}개",padding=(0,10),justify="left").pack(anchor="w")
        ttk.Label(frame,text="원하지 않는 데이터라면 새 빈 작업을 선택하세요. 기존 데이터는 삭제되지 않습니다.",foreground="#1769aa").pack(anchor="w",pady=(0,14))
        buttons=ttk.Frame(frame);buttons.pack(fill="x")
        ttk.Button(buttons,text="마지막 작업 계속",command=self.continue_last).pack(side="left",expand=True,fill="x",padx=(0,5))
        ttk.Button(buttons,text="새 빈 작업",command=self.new_blank).pack(side="left",expand=True,fill="x",padx=5)
        ttk.Button(buttons,text="다른 작업 선택",command=self.choose_other).pack(side="left",expand=True,fill="x",padx=(5,0))
        self.protocol("WM_DELETE_WINDOW",self.continue_last);self.update_idletasks()
        self.geometry("620x210");workflow.center_popup(self,app)

    def continue_last(self):
        self.grab_release();self.destroy();self.app.status.set(f"마지막 작업 계속: {self.app.store.path.stem}")

    def new_blank(self):
        folder=app_dir()/"data"/"projects";folder.mkdir(parents=True,exist_ok=True);stamp=datetime.now().strftime("%Y%m%d_%H%M%S");path=folder/f"새작업_{stamp}.sqlite3";number=2
        while path.exists():path=folder/f"새작업_{stamp}_{number}.sqlite3";number+=1
        Store(path).close();self.grab_release();self.destroy();self.app.switch_project(path);self.app.status.set(f"새 빈 작업 시작: {path.stem}")

    def choose_other(self):
        self.grab_release();self.destroy();self.app.after_idle(lambda:ProjectDialog(self.app))


class HelpDialog(workflow.RememberedToplevel):
    def __init__(self,parent):
        super().__init__(parent);self.title("사용법 / 색상 범례 / 단축키");self.geometry("900x720")
        text=tk.Text(self,wrap="word",font=("Malgun Gothic",10),padx=16,pady=14)
        y=ttk.Scrollbar(self,orient="vertical",command=text.yview);text.configure(yscrollcommand=y.set)
        text.pack(side="left",fill="both",expand=True);y.pack(side="right",fill="y")
        guide="""[처음 사용하는 순서]
1. 함체/RN/가입자 만들기 버튼을 누르고 도면을 한 번 클릭하면 자동 이름으로 생성된 뒤 대기모드로 돌아갑니다.
2. 케이블 만들기 → 첫 시설 → 두 번째 시설 순으로 클릭합니다.
3. 화면 가운데의 작은 생성창에 함께 보이는 상태·규격을 고르고 Space 또는 저장을 누릅니다. 창이 뜨자마자 Space를 눌러도 됩니다.
4. 함체를 더블클릭하고 양쪽 케이블을 고른 뒤 코어를 하나씩 선택해 연결합니다.
5. 기존 데이터가 있으면 시작 확인창에서 마지막 작업, 새 빈 작업, 다른 작업 중 하나를 고릅니다.

[함체 코어 연결]
• 창 위쪽에서 함체명/RN명을 바로 변경하고 Enter 또는 이름 저장
• 한쪽에서 고른 케이블은 반대쪽 선택목록에서 제외
• 양쪽 빈 코어 선택 후 Space: 임시코어로 연결
• 현장반영 신호: 케이블 번호별 저장. 함체에서 바꾸면 그 함체의 직접 접속 상대 번호까지만 함께 변경
• 연결대기확인: 양쪽 함체 방향·케이블ID·코어번호를 확인하고 체크 후 최종 연결
• 연결대기 후보가 여러 개면 확인 창 아래에서 왼쪽·오른쪽 배정 코어를 직접 선택
• 새 임시 연결은 임시코어1, 임시코어2처럼 순번으로 표시
• 한쪽에 실제 코어ID가 있으면 반대쪽 임시/빈 코어에 실제 ID 전파
• 서로 다른 실제 코어ID는 연결하지 않고 오류번호 표시
• ID 전파 뒤 관련 함체에 같은 실제 ID의 미접속 대상이 정확히 2개면 실제 접속도 자동 생성
• 기존 데이터도 함체/RN을 열 때 현재 시설의 같은 ID 미접속 쌍 자동보정
• 코어 하나 선택 후 Delete 또는 코어삭제: 확인창 뒤 최근 클릭한 한쪽만 삭제
• Excel표 일괄연결: Excel 범위를 복사해 A1부터 통째로 붙여넣기
• Excel 검사 결과창: Space로 저장·적용, Esc로 취소 (전체 적용 보류 시 Space는 닫기)
• 표의 1행은 케이블ID, 2행부터는 해당 열의 코어번호이며 같은 행의 정확히 두 코어를 연결
• 열 추가·삭제, 행 10개 추가, 셀 더블클릭 개별 수정, 빈칸을 포함한 표 붙여넣기 지원
• 사용 코어 같은 번호 중접: 코어ID/내역이 있는 번호만 연결하고 빈 코어는 제외
• 전체 번호 100% 중접: 공통 규격 전체를 연결하고 빈 번호는 임시코어 생성
• 번호 범위 직결: 시작·끝 번호(예: 6~30)를 입력하면 그 번호만 같은 번호끼리 연결

[케이블 코어 입력]
• 케이블 더블클릭: 규격·상태·ID와 1~전체 코어를 편집
• 편집창이 열리면 케이블ID 입력칸에 커서와 기존 ID 선택
• 케이블ID 입력·변경 후 Space: 저장 버튼과 동일하게 바로 저장
• 함체 우클릭: 메뉴 맨 위에서 함체 잠금 / 잠금 해제
• 함체: 이름·규격·ID를 위쪽 저장 버튼 하나로 저장 (숫자 규격 12 → 12C)
• RN: RN명·RN ID·전산화번호를 각각 입력 후 저장
• 가입자: 창을 열면 이름 자동 선택 → Ctrl+V 붙여넣기 → Space 저장
• LOT NO.: 케이블 편집창에서 입력 후 저장
• 보기설정: 케이블 LOT 표시 선택. 예: 144C =123=
• LOT 칸의 Space는 공백 입력
• 케이블 상태를 신설로 바꾸면 NEW1·NEW2 순서로 ID 자동발급, 자동 NEW 케이블을 기설로 되돌리면 ID 비움
• 코어번호 클릭 후 Excel의 코어ID+코어내역 두 열 Ctrl+V: 선택 번호부터 즉시 입력
• 셀을 더블클릭해 입력 커서가 열린 상태에서도 Excel 여러 행·열 Ctrl+V 가능
• 여러 줄 붙여넣기: 코어ID[TAB]코어내역 형식
• 코어ID를 비우면 현재 케이블의 해당 번호와 그 번호의 접속만 해제되며 반대편 코어정보는 유지
• 코어표에서 한 번호 선택 후 Delete 또는 선택 코어삭제: 확인창 뒤 그 번호의 전체 코어정보 삭제
• 코어순서 바꾸기: 선택 번호와 입력 번호의 정보·연결 위치 교환
• 케이블ID 1828633/72C 입력 시 /72C는 자동 제외

[오류코어확인]
• 상태 변경에서 예외코어를 추가하면 완료로 집계하며 예외·미완료·미배정 목록에서 제외합니다. 제거하면 실제 연결 상태로 다시 계산합니다.
• 메인 조사입력·코어정보입력 버튼은 제거됨
• 오류가 있으면 오류코어확인 버튼이 빨간색으로 바뀌고 건수를 표시
• 상태 오류, 서로 다른 코어ID 접속, 기존 조사자료 불일치·중복을 한 표에서 확인

[색상 범례]
• 흰색: 코어ID·내역이 없는 기본 빈 코어
• 분홍: 코어ID가 있지만 현재 함체에서 아직 연결되지 않아 배정이 필요한 코어
• 코어ID 없는 빈 코어의 상태·신호는 빈칸으로 표시
• 행 글자색: 신호 ON 빨강 · 신호 OFF 검정 · 신호 미선택 파랑 · 오류 보라
• 보라: 오류코어  • 회색: 해지  • 빨강: 끊김
• 노란 이름 배경: 함체 잠금 / 양쪽 함체가 잠긴 케이블 자동 잠금
• 깜빡이는 케이블: 코어/케이블 추적 결과
• 코어추적은 쉼표로 여러 코어ID를 입력할 수 있고 함체→케이블(코어번호)→함체 그림과 오류 위치를 표시
• 여러 코어 추적 시 코어별 경로는 다른 색, 둘 이상의 코어가 함께 지나는 케이블은 검정색으로 표시
• 케이블추적의 전체 코어내역은 빈 번호까지 ID·내역·상태·신호·경로를 전부 표시하고 전체 경로를 깜빡임
• 전체 코어내역에서 한 행을 클릭하면 해당 코어 경로만 따로 그림과 깜빡임으로 표시
• 추적창이 열려 있는 동안 계속 깜빡이며 창을 닫거나 강조 해제를 누르면 자동 해제

[도면 이동과 단축키]
• 함체/RN 오른쪽 클릭: 기설/신설/철거 상태 변경
• 케이블 오른쪽 클릭: 기설/신설/철거/절단 상태 변경 (신설 긴 대시 - - -·철거 ×·절단 ★)
• 케이블 규격 아래: 미배정코어·미완료코어 수량, 실제 ID 없이 끝-끝 연결된 임시 경로는 끝단 케이블에만 연결완료임시코어 수량 표시
• 미배정코어·미완료코어 표시를 더블클릭하면 그 케이블의 어떤 번호가 왜 미완료인지 목록이 열립니다. 같은 임시코어 구간은 함체에서 자동으로 이어지고, 직접 연결 해제한 곳 등은 함체 우클릭 「같은 코어ID 끝 이어 연결」로 잇습니다.
• 새 시설은 기존 시설 도형과 겹치는 위치에 생성되지 않음
• 시설 이동 후 다른 시설과 겹치면 이동을 취소하고 겹친 시설명을 안내
• 가입자 오른쪽 클릭: 파란/빨강/초록/분홍 색상 변경
• 케이블 하나 클릭: 왼쪽 위에 전체코어수·사용코어수·사용율 표시
• 연결이 끊긴 구간의 케이블에만 보라색 오류 수량 표시, 케이블 클릭 시 왼쪽 위 셋째 줄에 번호·시설·원인 표시
• 왼쪽 위 작업필요코어: 전 도면은 전체 수량, 후 도면은 전체·완료·완료율 표시
• Ctrl+A: 시설 전체 선택 → 드래그해서 전체 이동
• 시설/케이블 하나 선택 후 Shift+클릭: 기존 선택을 유지하며 추가 다중선택
• 시설 드래그: 40단위 격자를 한 칸씩 이동
• 팝업 입력 중 Ctrl+A/Delete/Ctrl+Z 등은 팝업 안에서만 작동하고 메인 도면에는 전달되지 않음
• Ctrl+Z / Ctrl+Y: 실제 값이 바뀐 행동 한 단계씩 실행취소 / 다시실행
• Ctrl+S: 현재 전/후 도면 저장  • Delete: 선택 삭제  • Esc: 열린 팝업 닫기/선택·이동 모드
• 빈 곳 왼쪽 드래그: 화면 이동  • Shift+빈 곳 드래그: 영역 선택
• 마우스 휠: 확대/축소  • 오른쪽 버튼 드래그: 화면 이동

[V18 기능 및 화면 구성]
• 작업 검사 옵션: 검사 기준·전도면 편집 잠금·일괄 미리보기/충돌/백업 설정
• 작업필요코어 진행표: 폐지 예정·이번 작업 제외·연결 필요 복구, 끝단 변경 승인, 전도면 변경 확인
• 점검 결과 기록: 검사 시점 보관, 변경 후 재점검 필요 표시
• 케이블/함체의 상태: 여러 항목과 메모 추가, 항목 ×로 개별 삭제, 적용 시 저장
• 맨 위 1 임시도면작성 → 2 전도면작성(현장반영) → 3 완성도점검 → 4 후도면작성 → 5 후도면 작업실 순서로 사용
• 전체 도구 펼치기: 코어추적·검색·배정·점검 도구 열기/접기
• 파일·출력: JSON·백업·데이터점검·SVG/A0 출력·화면맞춤·사용법
• 왼쪽 위 작업코어 현황: 절단·철거 케이블과 철거 함체·RN에 연결된 코어의 연결 완료율 · 「도면현황」 버튼으로 신호 코어 전체 기준 전환 · 접기/펼치기 가능
• 오른쪽 아래 미니맵: 원하는 위치를 클릭하거나 주황색 화면 사각형을 잡고 끌어서 이동
• 도면 표시 설정: 격자·케이블ID·오류 배지 표시와 라벨 겹침 자동 조정을 켜고 끔
• 케이블 라벨은 기본적으로 곡선 정중앙에 표시하며, 겹치면 이동 후 가는 선으로 케이블과 연결
• 표시 설정은 다음 실행에도 유지되며, 숨긴 코어 정보나 오류 데이터는 삭제되지 않음

[저장과 안전]
• 입력 내용은 현재 SQLite 작업파일에 즉시 저장됩니다.
• 작업관리에서 새 작업, 복사, 외부 작업파일 열기를 할 수 있습니다.
• 기본값은 전 도면이며 단일 전환 버튼은 현재 도면의 반대쪽만 표시
• 최초 후 도면 전환 시 생성 여부를 확인한 뒤 현재 전 도면을 그대로 복사해 후 도면 생성
• 전도면 완성도 점검: 후 도면 작성 전 연결·입력·임시코어·겹침 문제를 오류/경고로 확인
• 작업필요코어 진행표: 현장반영·후도면만 비교하여 절체 대상을 판정합니다. 임시도면 및 과거 작업대상 기록은 제외합니다.
• 후 도면의 코어확인 첫 항목 '코어연결필요'에서 미완료·누락·오류·입력누락 코어만 바로 확인
• 완료 기준: 서로 다른 시설의 끝단↔끝단, 끝단↔RN 내부, RN 내부↔RN 내부 (실제 접속 필요)
• V83 JSON은 가져오기/내보내기로 교환합니다.
• 데이터점검은 잘못된 연결 찌꺼기를 검사하고, 정리 전 자동백업합니다.
"""
        text.insert("1.0",guide);text.configure(state="disabled")


class DisplaySettingsDialog(workflow.RememberedToplevel):
    def __init__(self,parent):
        super().__init__(parent);self.parent=parent;self.title("보기설정");self.resizable(False,False);self.transient(parent);self.grab_set()
        frame=ttk.Frame(self,padding=18);frame.pack(fill="both",expand=True)
        ttk.Label(frame,text="화면 표시만 바뀝니다. 코어·접속 데이터는 지워지지 않습니다.",foreground="#1565c0").pack(anchor="w",pady=(0,12))
        self.values={}
        for group,keys in DISPLAY_GROUPS:
            section=ttk.LabelFrame(frame,text=group,padding=(10,5));section.pack(fill='x',pady=4)
            for key in keys:
                var=tk.BooleanVar(value=parent.display_options.get(key,DISPLAY_DEFAULTS[key]));self.values[key]=var
                ttk.Checkbutton(section,text=DISPLAY_LABELS[key],variable=var).pack(anchor="w",pady=2)
        ttk.Label(frame,text="격자: 화면 전용 / 나머지 설정: SVG·인쇄에도 적용\n배지를 숨겨도 현황판의 오류·진행률 점검은 유지됩니다.").pack(anchor="w",pady=10)
        buttons=ttk.Frame(frame);buttons.pack(fill="x",pady=(8,0))
        ttk.Button(buttons,text="기본값",command=lambda:[v.set(DISPLAY_DEFAULTS[k]) for k,v in self.values.items()]).pack(side="left")
        ttk.Button(buttons,text="적용",command=self.apply).pack(side="right",padx=4)
        ttk.Button(buttons,text="취소",command=self.destroy).pack(side="right")
        self.bind("<Escape>",lambda e:self.destroy());self.update_idletasks()
        workflow.center_popup(self,parent)
    def apply(self):
        options={key:var.get() for key,var in self.values.items()}
        try:save_display_options(self.parent.display_options_path,options)
        except OSError as error:messagebox.showerror("설정 저장 실패",str(error),parent=self);return
        self.parent.display_options=options;self.parent.refresh();self.destroy()



class App(tk.Tk):
    def __init__(self):
        super().__init__();workflow.install_monitor_dialogs(self);self.title(APP_TITLE);self.geometry("1450x900");self.minsize(1000,650)
        data=app_dir()/"data";data.mkdir(exist_ok=True);db_path=data/"telecom_core.sqlite3";marker=data/"current_project.txt"
        if marker.exists():
            try:
                remembered=Path(marker.read_text(encoding="utf-8").strip())
                if remembered.exists():db_path=remembered
            except Exception:pass
        self.store=Store(db_path)
        self.initialize_scenario()
        self.scenario_saved_revision=self.store.data_revision()
        backup=app_dir()/"backup"/f'{db_path.stem}_{datetime.now().strftime("%Y%m%d")}.sqlite3'
        if not backup.exists() and (data/"telecom_core.sqlite3").exists():self.store.backup_to(backup)
        self.mode="select";self.selected=set();self.drag_anchor=None;self.box_start=None;self.box_item=None;self.cable_start=None;self.item_to_node={};self.item_to_cable={}
        self.left_pan=None;self.left_pan_moved=False;self.left_pan_cursor=''
        self.highlight_cables=set();self.highlight_cable_colors={};self.highlight_blink_on=True;self.highlight_blink_job=None;self.cable_line_items={};self.cable_base_styles={};self.refresh_job=None;self.pending_drag=None;self.view_scale=1.0;self.preview_positions={};self.right_press=None;self.right_dragged=False
        self.highlight_core_labels={};self._highlight_label_items=[];self._highlight_hint_items=[];self._highlight_glow_items={}
        self.highlight_connection_model={};self._highlight_seeds=();self._highlight_stamp=None
        self.work_progress_cache_key=None;self.work_progress_cache_value=None;self.error_core_cache_key=None;self.error_core_cache_value=0;self.error_core_button=None
        self.advanced_tools_visible=False;self.dashboard_expanded=True;self.minimap_visible=False;self.minimap_transform=None;self.minimap_view_item=None
        self.display_options_path=data/"display_options.json";self.display_options=read_display_options(self.display_options_path)
        self.minimap_drag_anchor=None;self.minimap_update_job=None;self.label_fonts={}
        self.make_ui();self.update_title();self.refresh();self.protocol("WM_DELETE_WINDOW",self.on_close)
        if AUTO_HTML_ON_START and self.work_view_start_enabled():self.after(1200 if isinstance(globals().get('LOGIN_WEB'),dict) else 2500,self.auto_open_work_view)
        elif AUTO_HTML_ON_START:self.after(500,lambda:self.login_page_message('로그인 완료. 「시작할 때 HTML 작업도면 열기」가 꺼져 있어 기존 화면에서 계속합니다.'))
        if not globals().get("_CLOUD_ACTIVE") and (self.store.nodes() or self.store.cables()):self.after(180,lambda:StartupProjectDialog(self))

    def open_update_settings(self):
        launcher=globals().get("_CLOUD_ROOT_HOME",app_dir())/"telecom_updater.py"
        if getattr(sys,"frozen",False):
            messagebox.showinfo("업데이트 설정","자동 업데이트는 실행.bat으로 실행하는 버전에서 사용할 수 있습니다.",parent=self);return
        if not launcher.is_file():
            messagebox.showwarning("업데이트 설정","기존 실행.bat 폴더에 telecom_updater.py를 함께 넣어 주세요.",parent=self);return
        subprocess.Popen([sys.executable,str(launcher),"--settings"],cwd=str(launcher.parent))

    def report_callback_exception(self,exc,value,tb):
        if str(value).startswith('함체 잠금:'):
            self.pending_drag=None;self.drag_anchor=None
            messagebox.showwarning('함체 잠금',str(value),parent=self);self.refresh();return
        text="".join(traceback.format_exception(exc,value,tb));log=app_dir()/"error.log";log.write_text(text,encoding="utf-8")
        # V145: 이미 닫힌 창·그림판에 늦게 도착한 동작(종료 중 깜빡임/다시그리기)은 기록만 하고 오류창은 띄우지 않는다.
        if stale_widget_error(self,value):return
        messagebox.showerror("프로그램 오류",f"오류 내용을 error.log에 저장했습니다.\n\n{value}",parent=self)

    def make_ui(self):
        workflow.install_desktop_theme(self)
        self.metrics_details_visible=False
        header_frame=tk.Frame(self,bg="#14243d");header_frame.pack(fill="x");self.desktop_header=header_frame
        title_row=tk.Frame(header_frame,bg="#14243d");title_row.pack(fill='x',padx=16,pady=(12,8))
        actions=tk.Frame(title_row,bg='#14243d');actions.pack(side='right')
        self.scenario_badge=tk.Label(actions,text="현재 도면",font=("Malgun Gothic",9,"bold"),fg="#ffffff",bg="#315eac",padx=12,pady=7)
        self.scenario_badge.pack(side='left',padx=(8,10))
        self.reference_windows_button=ttk.Button(actions,text='도면 새 창',command=lambda:workflow.open_reference_drawing(self),style='Header.TButton');self.reference_windows_button.pack(side='left',padx=3)
        self.html_view_button=ttk.Button(actions,text='HTML 화면',command=self.open_html_view,style='Header.TButton');self.html_view_button.pack(side='left',padx=3)
        self.work_view_button=ttk.Button(actions,text='작업도면 전·중·후',command=self.open_work_view,style='Header.TButton');self.work_view_button.pack(side='left',padx=3)
        ttk.Button(actions,text='저장  Ctrl+S',command=self.save_current_drawing,style='Header.TButton').pack(side='left',padx=3)
        self.scenario_switch_button=tk.Button(actions,text="후도면 전환",command=self.toggle_scenario,font=("Malgun Gothic",9,"bold"),fg="#e1eaf7",bg="#294468",activebackground="#355980",activeforeground='#ffffff',relief="flat",padx=11,pady=7,cursor="hand2")
        self.scenario_switch_button.pack(side='left',padx=3)
        self.all_lock_button=tk.Button(actions,text='🔓',command=self.toggle_all_locks,font=('Segoe UI Symbol',16),width=3,fg='#dce6f5',bg='#294468',relief='flat',cursor='hand2',takefocus=True)
        self.desktop_lock_images={flag:workflow.desktop_lock_image(self,flag) for flag in (False,True)}
        self.all_lock_button.configure(image=self.desktop_lock_images[False],compound='none',width=30,height=30)
        self.all_lock_button.pack(side='left',padx=(6,0))
        workflow.Tooltip(self.all_lock_button,'현재 도면의 전체 함체 잠금 / 해제 · 다시 누르면 전환 · 조회와 복사는 유지')
        mark=tk.Canvas(title_row,width=36,height=38,bg='#14243d',highlightthickness=0);mark.pack(side='left',padx=(0,11))
        mark.create_line(8,10,26,28,fill='#7ba7f2',width=2);mark.create_line(8,28,26,10,fill='#7ba7f2',width=2)
        for x,y in ((8,10),(26,10),(8,28),(26,28)):mark.create_oval(x-4,y-4,x+4,y+4,fill='#14243d',outline='#cfdef8',width=2)
        title_text=tk.Frame(title_row,bg='#14243d');title_text.pack(side='left',fill='x',expand=True)
        tk.Label(title_text,text="통신 코어 도면",font=("Malgun Gothic",15,"bold"),fg="#ffffff",bg="#14243d",anchor='w').pack(fill='x')
        self.project_heading=tk.Label(title_text,text='도면 작업실',font=('Malgun Gothic',8),fg='#a7bbd7',bg='#14243d',anchor='w')
        self.project_heading.pack(fill='x')
        stages=tk.Frame(header_frame,bg="#14243d");stages.pack(fill='x',padx=16,pady=(0,12))
        self.workflow_buttons={}
        for i,(key,text,command) in enumerate((("gis","1   임시도면",self.workflow_gis),("before","2   현장반영",self.workflow_before),("check","3   완성도 점검",self.open_before_drawing_check),("after","4   후도면",self.workflow_after),("complete","5   후도면 작업실",lambda:workflow.AfterPlanDialog(self)))):
            button=tk.Button(stages,text=text,command=command,font=("Malgun Gothic",9,"bold"),relief="flat",bd=0,padx=8,pady=7,cursor="hand2",takefocus=True)
            button.grid(row=0,column=i,sticky='ew',padx=(0,5) if i<4 else 0);stages.columnconfigure(i,weight=1,uniform='stage');self.workflow_buttons[key]=button

        self.drawing_toolbar_frame=ttk.Frame(self);self.drawing_toolbar_frame.pack(fill='x')
        bar=workflow.FlowToolbar(self.drawing_toolbar_frame);self.drawing_toolbar=bar;self.mode_buttons={}
        self.drawing_tools=workflow.DrawingTools(self,bar,self.drawing_tool_catalog(),app_dir()/'data'/'drawing_tools.json')
        bar.pack(side='left',fill='x',expand=True)
        file_menu=tk.Menu(self,tearoff=False);self.file_menu=file_menu
        for label,command in (("JSON 가져오기",self.import_json),("JSON 내보내기",self.export_json),("백업",self.manual_backup),("백업 복구",self.restore_backup),("데이터점검",self.check_data),("SVG 저장",self.export_svg),("A0 인쇄 미리보기",self.print_preview),("HTML 화면으로 보기",self.open_html_view),("작업도면 전·중·후 (HTML)",self.open_work_view),("화면 맞춤",self.fit_view),("작업 검사 옵션",lambda:workflow.OptionsDialog(self)),("업데이트 설정",self.open_update_settings),("사용법/범례",lambda:HelpDialog(self))):
            file_menu.add_command(label=label,command=command)
        self.work_view_start_var=tk.BooleanVar(value=self.work_view_start_enabled())
        file_menu.add_checkbutton(label='시작할 때 HTML 작업도면 열기',variable=self.work_view_start_var,command=lambda:self.set_work_view_start(self.work_view_start_var.get()))
        self.status=tk.StringVar(value='도면에서 시설을 선택하거나 새 시설을 추가하세요.')
        statusbar=ttk.Frame(self,padding=(14,6));statusbar.pack(side='bottom',fill='x');self.desktop_statusbar=statusbar
        ttk.Label(statusbar,text='Ctrl+S 저장   ·   Ctrl+F 찾기   ·   Esc 선택',style='Muted.TLabel').pack(side='right',padx=(10,0))
        ttk.Label(statusbar,textvariable=self.status,style='Muted.TLabel',anchor='w').pack(side='left',fill='x',expand=True)

        self.advanced_tools_frame=ttk.Frame(self)
        workflowbar=workflow.FlowToolbar(self.advanced_tools_frame);workflowbar.pack(fill='x')
        for text,command in [('도면 새 창',lambda:workflow.open_reference_drawing(self)),('후도면 작업실',lambda:workflow.AfterPlanDialog(self)),('작업차수 / 구간',lambda:workflow.PhaseDialog(self)),('전도면 정보 반영',lambda:workflow.sync_metadata(self,interactive=True)),('상태·메모 검색',lambda:workflow.StatusSearchDialog(self))]:workflowbar.add(ttk.Button(workflowbar,text=text,command=command))
        bar2=ttk.LabelFrame(self.advanced_tools_frame,text="코어·검사 도구",padding=5);bar2.pack(fill="x",padx=4,pady=(0,4))
        core_buttons=(("전체 선번 연결도",lambda:workflow.open_core_layout(self)),("코어추적",lambda:TraceDialog(self,self.store)),("케이블추적",lambda:CableTraceDialog(self,self.store)),("코어확인/작업목록",lambda:CoreCheckDialog(self,self.store)),("전도면 완성도 점검",self.open_before_drawing_check),("작업필요코어 진행표",lambda:WorkRequiredDialog(self,self.store)),("오류코어확인",lambda:SurveyErrorsDialog(self,self.store)),("전체코어내역",lambda:AllCoreDialog(self,self.store)),("같은 코어ID 한꺼번에 잇기",lambda:workflow.open_same_id_join(self)),("도면 밖 연결 목록",lambda:workflow.open_offmap_links(self,self.store)),("도면 강조 해제",self.clear_highlight))
        for i,(text,fn) in enumerate(core_buttons):
            if text=="오류코어확인":
                button=tk.Button(bar2,text=text,command=fn,width=17,relief="raised",bd=1,font=("Malgun Gothic",9),bg="#f0f0f0",fg="#111111",activebackground="#e2e2e2")
                self.error_core_button=button
            else:button=ttk.Button(bar2,text=text,command=fn,width=19)
            button.grid(row=i//6,column=i%6,padx=2,pady=2,sticky="ew")
        for column in range(6):bar2.columnconfigure(column,weight=1)

        canvas_frame=ttk.Frame(self);self.canvas_frame=canvas_frame;canvas_frame.pack(fill="both",expand=True);canvas_frame.rowconfigure(0,weight=1);canvas_frame.columnconfigure(0,weight=1)
        self.canvas=tk.Canvas(canvas_frame,bg="#f5f7fb",highlightthickness=0);self.canvas.grid(row=0,column=0,sticky="nsew")
        vbar=ttk.Scrollbar(canvas_frame,orient="vertical",command=self.canvas_yview);hbar=ttk.Scrollbar(canvas_frame,orient="horizontal",command=self.canvas_xview)
        vbar.grid(row=0,column=1,sticky="ns");hbar.grid(row=1,column=0,sticky="ew")
        self.canvas.configure(xscrollcommand=lambda a,b:self.canvas_scrolled(hbar,a,b),yscrollcommand=lambda a,b:self.canvas_scrolled(vbar,a,b))
        self.canvas.bind("<Configure>",lambda e:self.schedule_minimap_viewport())
        self.dashboard_frame=tk.Frame(canvas_frame,bg="#ffffff",highlightbackground="#dbe3ed",highlightthickness=1);self.dashboard_frame.place(x=18,y=18,anchor="nw")
        dash_header=tk.Frame(self.dashboard_frame,bg="#ffffff");dash_header.pack(fill="x")
        # V200: 작업코어현황 (절단·철거 케이블, 철거 함체·RN의 코어) is the default; 도면현황 stays one click away.
        self.dashboard_mode=getattr(self,'dashboard_mode','work')
        self.dashboard_title_label=tk.Label(dash_header,text="작업코어 현황",font=("Malgun Gothic",11,"bold"),fg="#192b46",bg="#ffffff",padx=14,pady=12);self.dashboard_title_label.pack(side="left")
        self.dashboard_mode_button=tk.Button(dash_header,text="도면현황",command=self.toggle_dashboard_mode,font=("Malgun Gothic",8),fg="#315eac",bg="#ffffff",activebackground="#edf3fc",activeforeground="#315eac",relief="flat",padx=7,pady=3);self.dashboard_mode_button.pack(side="right",padx=3,pady=3)
        self.minimap_toggle_button=tk.Button(dash_header,text="미니맵 보기",command=self.toggle_minimap,font=("Malgun Gothic",8),fg="#64748b",bg="#ffffff",activebackground="#edf3fc",activeforeground="#315eac",relief="flat",padx=7,pady=3);self.minimap_toggle_button.pack(side="right",padx=3,pady=3)
        self.dashboard_toggle_button=tk.Button(dash_header,text="접기 ▲",command=self.toggle_dashboard,font=("Malgun Gothic",8),fg="#64748b",bg="#ffffff",activebackground="#edf3fc",activeforeground="#315eac",relief="flat",padx=7,pady=3);self.dashboard_toggle_button.pack(side="right",padx=3,pady=3)
        self.metrics_frame=tk.Frame(self.dashboard_frame,bg="#ffffff");self.metrics_frame.pack(fill="both")
        self.cable_usage_label=tk.Label(self.metrics_frame,text="",justify="left",anchor="w",font=("Malgun Gothic",9,"bold"),fg="#0d47a1",bg="#ffffff",padx=14,pady=10,wraplength=300)
        self.work_progress_label=tk.Frame(self.metrics_frame,bg="#ffffff",padx=14,pady=8)
        self.work_progress_label.pack(fill="x")
        metric_style=dict(justify='left',anchor='w',font=('Malgun Gothic',9),bg='#ffffff',padx=0,pady=0,borderwidth=0)
        self.work_progress_text=tk.Label(self.work_progress_label,text='',**metric_style);self.work_progress_text.pack(fill='x',pady=(0,8));self.work_progress_text.configure(wraplength=300)
        self.work_progress_counts=tk.Frame(self.work_progress_label,bg='#fff8e1');self.work_progress_counts.pack(fill='x')
        self.work_progress_completed=tk.Label(self.work_progress_counts,text='',**metric_style);self.work_progress_completed.pack(side='left')
        self.work_progress_incomplete=tk.Label(self.work_progress_counts,text='',**metric_style);self.work_progress_incomplete.pack(side='left')
        self.work_progress_rate=tk.Label(self.work_progress_label,text='',**metric_style);self.work_progress_rate.pack(fill='x',pady=(6,8));self.work_progress_rate.configure(font=('Malgun Gothic',22,'bold'))
        self.completion_bar=ttk.Progressbar(self.work_progress_label,maximum=100,style='Completion.Horizontal.TProgressbar');self.completion_bar.pack(fill='x',pady=(0,10))
        self.metrics_details_button=ttk.Button(self.work_progress_label,text='상세 기준 펼치기 ▾',command=self.toggle_metric_details,style='Tool.TButton');self.metrics_details_button.pack(fill='x',pady=(0,4))
        self.work_progress_note=tk.Label(self.work_progress_label,text='같은 코어ID는 1개 · 전·후도면 필수 코어 기준 적용',fg='#000000',**metric_style)
        self.work_progress_task=tk.Frame(self.work_progress_label,bg='#fff8e1')
        self.work_progress_task_count=tk.Label(self.work_progress_task,text='',**metric_style);self.work_progress_task_count.pack(side='top',anchor='w')
        self.work_progress_task_note=tk.Label(self.work_progress_task,text='작업완료율은 후 도면에서 확인',fg='#000000',**metric_style);self.work_progress_task_note.pack(side='top',anchor='w')
        self.work_progress_footer=tk.Label(self.work_progress_label,text='',**metric_style);self.work_progress_footer.pack(fill='x')
        ttk.Button(self.metrics_frame,text='미완료 목록 바로 열기',command=lambda:IncompleteCoresDialog(self,self.store)).pack(fill='x',padx=14,pady=5)
        ttk.Button(self.metrics_frame,text='완료율 대상·제외 기준 보기',command=lambda:workflow.CompletionTargetsDialog(self,self.store)).pack(fill='x',padx=14,pady=(0,12))
        self.error_summary_label=tk.Label(self.metrics_frame,text="오류코어 0개",justify="left",anchor="w",font=("Malgun Gothic",9),fg="#1b5e20",bg="#f1f8e9",padx=14,pady=10,cursor="hand2")
        self.error_summary_label.pack(fill="x");self.error_summary_label.bind("<Button-1>",lambda e:SurveyErrorsDialog(self,self.store))

        self.minimap_frame=tk.Frame(canvas_frame,bg="#ffffff",highlightbackground="#7f8da3",highlightthickness=1)
        mini_head=tk.Frame(self.minimap_frame,bg="#26354d");mini_head.pack(fill="x")
        tk.Label(mini_head,text="미니맵 · 클릭 이동 / 주황 상자 드래그",font=("Malgun Gothic",8,"bold"),fg="#ffffff",bg="#26354d",padx=8,pady=4).pack(side="left")
        self.minimap=tk.Canvas(self.minimap_frame,width=250,height=155,bg="#fbfcfe",highlightthickness=0,cursor="hand2");self.minimap.pack()
        self.minimap.bind("<Button-1>",self.minimap_press);self.minimap.bind("<B1-Motion>",self.minimap_drag);self.minimap.bind("<ButtonRelease-1>",self.minimap_release)
        if self.minimap_visible:self.minimap_frame.place(relx=1.0,rely=1.0,x=-18,y=-18,anchor="se")
        self.canvas.bind("<Button-1>",self.click);self.canvas.bind("<B1-Motion>",self.drag);self.canvas.bind("<ButtonRelease-1>",self.drop)
        self.canvas.bind("<Double-Button-1>",self.double_click);self.canvas.bind("<ButtonPress-3>",self.pan_start);self.canvas.bind("<B3-Motion>",self.pan_move);self.canvas.bind("<ButtonRelease-3>",self.pan_end)
        for sequence in ('<Control-a>','<Control-A>'):
            self.canvas.bind(sequence,self.select_all);self.bind(sequence,self.select_all)
        self.bind("<Delete>",lambda e:self.delete_selected());self.bind_all("<Escape>",self.escape_action)
        for sequence in ('<Control-z>','<Control-Z>'):self.bind_all(sequence,self.route_undo)
        for sequence in ('<Control-y>','<Control-Y>'):self.bind_all(sequence,self.route_redo)
        for sequence in ('<Control-s>','<Control-S>'):self.bind_all(sequence,self.save_current_drawing)
        for sequence in ('<Control-f>','<Control-F>'):self.bind_all(sequence,self.open_find)
        self.bind("<F1>",lambda e:HelpDialog(self))
        self.bind("<Alt-Key-1>",lambda e:self.set_mode("hamche"));self.bind("<Alt-Key-2>",lambda e:self.set_mode("rn"));self.bind("<Alt-Key-3>",lambda e:self.set_mode("sub"));self.bind("<Alt-Key-grave>",lambda e:self.set_mode("cable"))
        self.canvas.bind("<MouseWheel>",self.zoom)

    def drawing_tool_catalog(self):
        rows=[]
        for label,mode,shortcut in (('선택/이동','select','Esc'),('함체 만들기','hamche','Alt+1'),('RN 만들기','rn','Alt+2'),('가입자 만들기','sub','Alt+3'),('케이블 만들기','cable','Alt+`')):
            rows.append(dict(id='mode_'+mode,label=label,group='만들기·편집',command=lambda m=mode:self.set_mode(m),mode=mode,tip=label+' · '+shortcut,default=True))
        for key,label,command in (('properties','선택 속성',self.open_properties),('delete','선택 삭제',self.delete_selected),('undo','실행취소',self.undo),('redo','다시실행',self.redo),('history','수정 이력',self.open_history)):
            rows.append(dict(id=key,label=label,group='만들기·편집',command=command,default=True))
        groups=(('관리·보기',(
            ('projects','작업관리',lambda:self.cloud.projects() if getattr(self,'cloud',None) else ProjectDialog(self)),
            ('scenarios','전/후관리',lambda:ScenarioDialog(self)),('find','찾기 Ctrl+F',self.open_find),
            ('display','보기설정',lambda:DisplaySettingsDialog(self)),('reference_drawing','도면 새 창',lambda:workflow.open_reference_drawing(self)),('field_slots','현장 전체내역·확정',self.open_field_slots),
            ('field_identity','현장 코어내역 반영',lambda:workflow.sync_after_identities(self)),
            ('files','파일·출력 ▾',lambda:workflow.desktop_popup_menu(self.drawing_tools.buttons['files'],self.file_menu)),
            ('all_tools','전체 도구 펼치기 ▾',self.toggle_advanced_tools))),
            ('작업 도구',(
            ('after_plan','후도면 작업실',lambda:workflow.AfterPlanDialog(self)),('stage_delete','현재 단계 삭제 · 이전 단계로',lambda:workflow.open_stage_delete(self)),('stage_restore','단계 삭제 되돌리기',lambda:workflow.restore_stage_delete(self)),('phases','작업차수 / 구간',lambda:workflow.PhaseDialog(self)),
            ('sync_metadata','전도면 정보 반영',lambda:workflow.sync_metadata(self,interactive=True)),('status_search','상태·메모 검색',lambda:workflow.StatusSearchDialog(self)))),
            ('코어·검사',(
            ('core_trace','코어추적',lambda:TraceDialog(self,self.store)),('cable_trace','케이블추적',lambda:CableTraceDialog(self,self.store)),
            ('core_layout','전체 선번 연결도',lambda:workflow.open_core_layout(self)),('core_worklist','코어확인/작업목록',lambda:CoreCheckDialog(self,self.store)),('before_check','전도면 완성도 점검',self.open_before_drawing_check),
            ('work_progress','작업필요코어 진행표',lambda:WorkRequiredDialog(self,self.store)),('core_errors','오류코어확인',lambda:SurveyErrorsDialog(self,self.store)),
            ('all_cores','전체코어내역',lambda:AllCoreDialog(self,self.store)),('clear_highlight','도면 강조 해제',self.clear_highlight))),
            ('파일·출력',(
            ('import_json','JSON 가져오기',self.import_json),('export_json','JSON 내보내기',self.export_json),('backup','백업',self.manual_backup),
            ('restore_backup','백업 복구',self.restore_backup),('check_data','데이터점검',self.check_data),('export_svg','SVG 저장',self.export_svg),
            ('print','A0 인쇄 미리보기',self.print_preview),('html_view','HTML 화면으로 보기',self.open_html_view),('work_view','작업도면 전·중·후 (HTML)',self.open_work_view),('fit','화면 맞춤',self.fit_view),('options','작업 검사 옵션',lambda:workflow.OptionsDialog(self)),
            ('update','업데이트 설정',self.open_update_settings),('help','사용법/범례',lambda:HelpDialog(self)))))
        for group,items in groups:
            for key,label,command in items:rows.append(dict(id=key,label=label,group=group,command=command))
        return rows

    def workflow_before(self):
        if self.scenario_kind()=="before":self.set_mode("select");self.status.set("2단계 · 기존 저장 선번으로 연결 검사 · 현장 선번 적용 후 다시 계산")
        else:self.load_scenario("before")

    def open_field_slots(self):
        if not workflow.field_slot_mode(self.store):
            messagebox.showinfo('현장 전체내역','임시도면에서 새로 생성한 현장반영 도면에서 사용할 수 있습니다.\n기존 현장반영 도면은 유지됩니다. 새로 시작하려면 임시도면 단계의 전/후관리 → 임시도면 → 현장반영 새로 복사를 사용하세요.',parent=self);return
        workflow.FieldSlotEditorDialog(self,self.store)

    def workflow_gis(self):
        if self.scenario_kind()=="gis":self.set_mode("select");self.status.set("1단계 · 임시도면 작성 중 · 오류가 있어도 2단계로 복사할 수 있습니다.")
        else:self.load_scenario("gis")

    def workflow_after(self):
        if self.scenario_kind()=="after":self.set_mode("select");self.status.set("4단계 · 후도면 작성 중")
        else:self.load_scenario("after")

    def update_workflow_stage(self):
        if not hasattr(self,"workflow_buttons"):return
        kind=self.scenario_kind()
        for key,button in self.workflow_buttons.items():
            active=key==kind
            bg='#ffffff' if active else '#233957'
            fg=workflow.STAGE_WINDOW_COLORS[kind] if active else '#c4d3e8'
            button.configure(bg=bg,fg=fg,activebackground=bg if active else "#314c72",activeforeground=fg)

    def toggle_advanced_tools(self):
        self.advanced_tools_visible=not self.advanced_tools_visible
        if self.advanced_tools_visible:
            self.advanced_tools_frame.pack(fill="x",before=self.canvas_frame)
        else:
            self.advanced_tools_frame.pack_forget()
        self.drawing_tools.sync()

    def toggle_dashboard(self):
        self.dashboard_expanded=not self.dashboard_expanded
        if self.dashboard_expanded:
            self.metrics_frame.pack(fill="both");self.dashboard_toggle_button.configure(text="접기 ▲")
        else:
            self.metrics_frame.pack_forget();self.dashboard_toggle_button.configure(text="펼치기 ▼")
        self.dashboard_frame.lift()

    def set_dashboard_mode(self,mode):
        self.dashboard_mode='drawing' if mode=='drawing' else 'work'
        work=self.dashboard_mode=='work'
        self.dashboard_title_label.configure(text='작업코어 현황' if work else '도면 현황')
        self.dashboard_mode_button.configure(text='도면현황' if work else '작업코어')
        self.refresh_metrics()

    def toggle_dashboard_mode(self):
        self.set_dashboard_mode('drawing' if getattr(self,'dashboard_mode','work')=='work' else 'work')

    def toggle_metric_details(self):
        self.metrics_details_visible=not self.metrics_details_visible
        self.metrics_details_button.configure(text='상세 기준 접기 ▴' if self.metrics_details_visible else '상세 기준 펼치기 ▾')
        self.work_progress_footer.pack(fill='x');self.refresh_metrics()

    def toggle_minimap(self):
        self.minimap_drag_anchor=None
        self.minimap_visible=not self.minimap_visible
        if self.minimap_visible:
            self.minimap_frame.place(relx=1.0,rely=1.0,x=-18,y=-18,anchor="se");self.minimap_toggle_button.configure(text="미니맵 숨기기");self.refresh_minimap()
        else:
            self.minimap_frame.place_forget();self.minimap_toggle_button.configure(text="미니맵 보기")

    def canvas_xview(self,*args):
        self.canvas.xview(*args)

    def canvas_yview(self,*args):
        self.canvas.yview(*args)

    def canvas_scrolled(self,scrollbar,first,last):
        scrollbar.set(first,last);self.schedule_minimap_viewport()

    def schedule_minimap_viewport(self):
        if self.minimap_update_job is None:
            def update():
                self.minimap_update_job=None;self.refresh_minimap_viewport()
            self.minimap_update_job=self.after_idle(update)

    def set_mode(self,mode):
        panel=getattr(self,'_map_allocation_panel',None)
        if panel is not None and panel.winfo_exists() and not panel.close_requested():return
        self.cancel_left_pan()
        self.mode=mode;self.cable_start=None;self.cable_end_move=None
        drag=self.__dict__.pop('cable_end_drag',None)
        if drag and drag['line'] is not None:self.canvas.delete(drag['line'])
        names={"select":"선택/이동 · 빈 곳 드래그: 화면 이동 · Shift+드래그: 영역 선택","hamche":"함체 생성","rn":"RN 생성","sub":"가입자 생성","cable":"케이블 생성: 첫 시설을 클릭하세요"}
        self.status.set(names[mode])
        for key,button in getattr(self,'mode_buttons',{}).items():button.configure(style='Active.Tool.TButton' if key==mode else 'Tool.TButton')

    def next_node_name(self,node_type,subscriber_type='subscriber'):
        base=next((k for k,v in SUBSCRIBER_TYPES.items() if v==subscriber_type),'가입자') if node_type=='sub' else {"hamche":"함체","rn":"RN"}.get(node_type,"시설");used={str(n["name"] or "") for n in self.store.nodes()};number=1
        while f"{base}{number}" in used:number+=1
        return f"{base}{number}"

    def overlapping_node(self,x,y,node_type):
        new_w,new_h=node_half_size(node_type)
        for node in self.store.nodes():
            old_w,old_h=node_half_size(node['type'])
            if abs(float(node["x"])-x)<new_w+old_w+12 and abs(float(node["y"])-y)<new_h+old_h+12:return node
        return None

    def movement_overlap(self,final_positions):
        moving=set(final_positions);stationary=[node for node in self.store.nodes() if node["id"] not in moving]
        for nid,(x,y) in final_positions.items():
            moved=self.store.node(nid)
            if not moved:continue
            moved_w,moved_h=node_half_size(moved['type'])
            for other in stationary:
                other_w,other_h=node_half_size(other['type'])
                if abs(float(other["x"])-x)<moved_w+other_w+12 and abs(float(other["y"])-y)<moved_h+other_h+12:return moved,other
        return None

    def update_title(self):
        kind=self.scenario_kind();label=workflow.SCENARIO_LABELS[kind]
        name=self.cloud.entry()["name"] if getattr(self,"cloud",None) and self.cloud.current else self.store.path.stem
        self.title(f"{APP_TITLE} · {name} · [{label}]")
        workflow.apply_stage_window_chrome(self,kind,False)
        if hasattr(self,"scenario_badge"):
            color=workflow.STAGE_WINDOW_COLORS[kind]
            self.scenario_badge.configure(text=label+" · 편집 중",bg=color)
        if hasattr(self,"scenario_switch_button"):
            self.scenario_switch_button.configure(text={"gis":"현장반영 전환","before":"후도면 전환","after":"현장반영 전환"}[kind])
        if hasattr(self,'project_heading'):self.project_heading.configure(text=name)
        self.update_workflow_stage()
        for window in self.winfo_children():
            if isinstance(window,(ScenarioDialog,workflow.ReferenceDrawingChooser)):
                workflow.apply_stage_window_chrome(window,kind,False)

    def scenario_folder(self):
        folder=app_dir()/"scenarios"/self.store.path.stem;folder.mkdir(parents=True,exist_ok=True);return folder

    def scenario_path(self,kind):
        return self.scenario_folder()/(kind+".sqlite3")

    def scenario_kind(self):
        try:row=self.store.conn.execute("SELECT value FROM meta WHERE key='active_scenario'").fetchone()
        except sqlite3.Error:return "before"
        value=str(row[0] or "") if row else ""
        return value if value in workflow.SCENARIO_LABELS else ("before" if self.store.nodes() else "gis")

    def initialize_scenario(self):
        if not self.store.conn.execute("SELECT 1 FROM meta WHERE key='active_scenario'").fetchone():
            self.store.conn.execute("INSERT INTO meta VALUES('active_scenario',?)",(self.scenario_kind(),));self.store.conn.commit()
        workflow.after_auto_activate(self.store);workflow.temporary_auto_activate(self.store)

    def set_scenario_kind(self,kind):
        value=kind if kind in workflow.SCENARIO_LABELS else "gis"
        self.store.conn.execute("INSERT INTO meta(key,value) VALUES('active_scenario',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(value,))
        self.store.conn.commit();workflow.after_auto_activate(self.store);workflow.temporary_auto_activate(self.store);self.update_title()

    def scenario_dirty(self):
        return self.store.data_revision()!=self.scenario_saved_revision

    def save_current_snapshot(self):
        """Commit local drawing/snapshot; caller owns confirmation and cloud receipt."""
        if self.store.conn.hold_commit or self.store._history_depth:raise ValueError('다른 변경을 처리 중입니다. 잠시 후 다시 저장하세요.')
        if self.__dict__.get('pending_drag'):raise ValueError('시설 이동을 마친 뒤 다시 저장하세요.')
        kind=self.scenario_kind();workflow.phase_refresh_references(self)
        self.store.conn.commit();path=self.scenario_path(kind);self.store.backup_to(path);self.mark_snapshot_kind(path,kind)
        self.scenario_saved_revision=self.store.data_revision();label=workflow.SCENARIO_LABELS[kind]
        self.status.set(f'현재 ({label}) PC 도면 저장 완료 · '+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

    def save_current_drawing(self,event=None,silent=False):
        if self.__dict__.get('_saving_now'):
            dialog=self.__dict__.get('_save_dialog')
            if dialog is not None and dialog.winfo_exists():dialog.lift()
            return 'break'
        popup_parent=self
        if event is not None:
            try:popup_parent=event.widget.winfo_toplevel()
            except (AttributeError,tk.TclError):pass
        self._saving_now=True
        try:
            if silent:
                self.save_current_snapshot()
                if getattr(self,'cloud',None):self.after_idle(self.cloud.sync_now)
            else:
                self._save_dialog=workflow.DrawingSaveDialog(popup_parent,self)
                self.wait_window(self._save_dialog)
        finally:
            self._save_dialog=None;self._saving_now=False
        return 'break'

    def mark_snapshot_kind(self,path,kind):
        conn=sqlite3.connect(path)
        try:
            conn.execute("INSERT INTO meta(key,value) VALUES('active_scenario',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(kind,))
            conn.commit()
        finally:conn.close()

    def toggle_scenario(self):
        return self.load_scenario("after" if self.scenario_kind()=="before" else "before")

    def field_ready_for_after(self):
        if self.scenario_kind()!='before':
            messagebox.showinfo('현장반영 단계','2단계 전도면(현장반영)에서 기존 또는 현장 선번의 연결 상태와 완성도를 점검한 뒤 후도면을 작성하세요.',parent=self);return False
        if any(row['level']=='오류' for row in self.store.before_drawing_check_rows()):
            BeforeDrawingCheckDialog(self,self.store);self.status.set('코어연결 미완료·조사자료 불일치와 완성도 점검 오류를 해결한 뒤 후도면을 작성하세요.');return False
        return True

    def copy_gis_to_field(self,replace=False):
        current=self.scenario_kind();path=self.scenario_path('before');source=self.scenario_path('gis')
        if path.exists() and not replace:return self.load_scenario('before')
        if current!='gis' and not source.exists():
            messagebox.showinfo('임시도면 원본 없음','저장된 임시도면 원본이 없습니다. 1단계 임시도면을 확인하고 저장한 뒤 새로 복사하세요. 현재 현장반영 도면은 유지됩니다.',parent=self);return False
        # Save/archive the old working drawing before replacing before.sqlite3.
        # A normal same-phase switch would reject the reload, or a later dirty
        # save could overwrite the newly copied snapshot with the old field.
        self.save_current_drawing(silent=True)
        if path.exists():shutil.copy2(path,self.scenario_folder()/('before_previous_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite3'))
        workflow.field_slot_copy(source,path)
        self.activate_scenario_snapshot('before',path)
        self.save_current_drawing(silent=True)
        count=self.store.conn.execute('SELECT COUNT(*) FROM splices').fetchone()[0]
        surveys=len(workflow.field_records(self.store))
        expected=len((workflow.field_reference(self.store) or {}).get('snapshot',{}).get('splices',[]))
        if count!=expected or surveys or not workflow.field_slot_mode(self.store):raise ValueError('새 현장반영 도면의 초기화 결과를 확인하지 못했습니다. 백업본은 보관되어 있습니다.')
        self.status.set(f'현장반영 초기화 완료 · 기존 접속 선번 {count}건 적용 · 현장 조사 {surveys}건 · 기존 선번으로 연결 검사')
        return True

    def activate_scenario_snapshot(self,kind,path):
        """Activate an already chosen snapshot, including an explicit same-phase recopy."""
        common=workflow.state(self.store)
        self.manual_backup(silent=True);self.replace_current_from(path);self.set_scenario_kind(kind)
        target=workflow.state(self.store);common['field_surveys']=target.get('field_surveys',{})
        for field_key in ('field_slot_moves','field_slot_confirmations'):
            common[field_key]=target.get(field_key,[])
        workflow.write_state(self.store,common,'전/후 공통 작업정책 유지',history=False)
        self.work_progress_cache_key=None;self._work_report_key=None;self.refresh()
        self.scenario_saved_revision=self.store.data_revision()
        return common

    def load_scenario(self,kind):
        if kind not in workflow.SCENARIO_LABELS:return False
        label=workflow.SCENARIO_LABELS[kind];path=self.scenario_path(kind);current=self.scenario_kind();identity_report=None
        if current==kind:
            messagebox.showinfo("전/후 도면",f"이미 ({label}) 도면을 사용 중입니다.",parent=self);return False
        if kind=='after' and current!='after' and not self.field_ready_for_after():return False
        if kind=='before' and current=='gis' and not path.exists():
            return self.copy_gis_to_field()
        if kind=='gis' and not path.exists():
            if current=='before':self.save_current_drawing(silent=True)
            source=self.scenario_path('before')
            if not source.exists():
                messagebox.showinfo('임시도면 원본 없음','임시도면으로 보관할 전도면이 없습니다. 먼저 전도면을 불러오세요.',parent=self);return False
            shutil.copy2(source,path);self.mark_snapshot_kind(path,'gis')
        if kind=="after" and current=="before" and not path.exists():
            if not messagebox.askyesno("후 도면 최초 생성","후 도면이 아직 없습니다.\n현장반영에서 하나로 확인된 코어ID·내역을 실제 연결 경로 전체에 입력하여 후 도면을 생성할까요?",parent=self):return False
            try:
                workflow.Workflow(self).prepare_after()
                self.save_current_drawing(silent=True);before_path=self.scenario_path('before')
                identity_report=workflow.after_identity_copy(type(self.store),before_path,path)
            except (ValueError,sqlite3.Error,OSError) as error:
                messagebox.showerror('후도면 생성 실패',str(error),parent=self);return False
        if not path.exists():
            messagebox.showinfo("전/후 도면",f"({label}) 저장값이 없습니다.\n전/후관리에서 먼저 저장하거나 생성하세요.",parent=self);return False
        current_label=workflow.SCENARIO_LABELS[current]
        if self.scenario_dirty():
            choice=messagebox.askyesnocancel("수정사항 저장",f"현재 ({current_label}) 도면에 수정사항이 있습니다.\n\n예: 저장하고 ({label}) 도면으로 전환\n아니오: 저장하지 않고 전환\n취소: 현재 도면 계속 사용",parent=self)
            if choice is None:return False
            if choice:self.save_current_drawing(silent=True)
        common=self.activate_scenario_snapshot(kind,path)
        if kind=='after' and common['options'].get('sync_metadata',True):
            plan=workflow.metadata_plan(self);workflow.sync_metadata(self,interactive=any(p['conflict'] for p in plan))
        self.status.set(workflow.after_identity_copy_summary(identity_report) if identity_report else f"현재 도면: {label} · 전환 완료")
        if kind=='after' and common['options']['notify_before'] and workflow.Workflow(self).changes():
            messagebox.showinfo('현장반영 변경 확인','작업필요코어 진행표의 현장반영 도면 변경 확인에서 추가·삭제·변경 사항을 확인하고 반영하세요. 후도면 연결은 자동 수정하지 않습니다.',parent=self)
        return True

    def work_report(self):
        before_path=self.scenario_path('before');stamp=before_path.stat().st_mtime_ns if before_path.exists() else 0
        key=(str(self.store.path.resolve()),self.scenario_kind(),self.store.data_revision(),self.store.conn.total_changes,getattr(self.store,'_view_generation',0),stamp)
        if getattr(self,'_work_report_key',None)!=key:
            self._work_report_value=workflow.Workflow(self).report();self._work_report_key=key
        return self._work_report_value

    def work_progress(self):
        """데이터가 바뀐 경우에만 작업필요코어 완료율을 다시 계산한다."""
        kind=self.scenario_kind();revision=self.store.data_revision();before_path=self.scenario_path("before")
        before_stamp=before_path.stat().st_mtime_ns if before_path.exists() else 0
        key=(str(self.store.path.resolve()),kind,revision,before_stamp)
        if key==self.work_progress_cache_key and self.work_progress_cache_value is not None:return self.work_progress_cache_value
        report=self.work_report();value={k:report[k] for k in ('kind','total','done','rate','missing_before','excluded','pending','review')}
        self.work_progress_cache_key=key;self.work_progress_cache_value=value;return value

    def refresh_metrics(self):
        cable_ids=[key for key in self.selected if key in self.cable_line_items]
        if len(cable_ids)==1:
            cable=self.store.cable(cable_ids[0]);usage=self.store.cable_usage(cable_ids[0]);name=clean_cable_id(cable["cable_id"]) or (cable["spec"] or f'{cable["size"]}C')
            warning=self.store.cable_core_warning_summary().get(cable_ids[0],{})
            error_text=f"오류코어 {warning.get('marked_error_total',0)}개"
            self.cable_usage_label.configure(text=f"케이블 사용율 · {name}\n전체코어수 {usage['total']} / 사용코어수 {usage['used']} / 사용율 {usage['rate']:.1f}%\n{error_text}")
            if not self.cable_usage_label.winfo_manager():self.cable_usage_label.pack(fill="x",before=self.work_progress_label)
        elif self.cable_usage_label.winfo_manager():self.cable_usage_label.pack_forget()
        progress=self.work_progress();overall=self.store.drawing_connection_progress()
        label={'gis':'임시도면','before':'전도면(현장반영)','after':'후도면'}[overall['kind']]
        if getattr(self,'dashboard_mode','work')=='work':return self.refresh_work_core_metrics(label)
        rate=workflow.completion_rate_text(overall)
        text=f"필수 코어 연결 완료율 · {label}"
        incomplete=overall['total']-overall['done']
        fg='#16734b' if overall['rate']==100.0 else '#192b46';bg='#ffffff'
        self.work_progress_label.configure(bg=bg);self.work_progress_text.configure(text=text,fg=fg,bg=bg)
        self.work_progress_counts.configure(bg=bg)
        self.work_progress_completed.configure(text=f"전체 {overall['total']} / 연결완료 {overall['done']} / ",fg=fg,bg=bg)
        self.work_progress_incomplete.configure(text=f"미완료 {incomplete}",fg='#c62828' if incomplete>0 else fg,bg=bg)
        self.work_progress_rate.configure(text=rate,fg=fg,bg=bg)
        self.completion_bar.configure(value=overall['rate'] or 0,style='Complete.Horizontal.TProgressbar' if overall['rate']==100.0 else 'Completion.Horizontal.TProgressbar')
        criteria='필수: 신호 있음 또는 실제 코어ID'+(' 또는 해지예상' if overall['kind']=='after' else '')
        excluded=' / '.join(f'{name} {count}' for name,count in overall['excluded_counts'].items()) or '없음'
        self.work_progress_note.configure(text=criteria+('\n기준: 기존 저장 선번 · 조사자료가 있으면 해당 선번 재검사' if overall['kind']=='before' else '')+'\nOFF·신호 ON 아닌 끊김은 집계 제외 / 예외는 완료\n같은 코어ID는 1개 · 집계 제외 '+str(overall['excluded'])+'개 ('+excluded+')',fg='#64748b',bg=bg,wraplength=300)
        self.work_progress_footer.pack(fill='x')
        self.work_progress_note.pack(fill='x',before=self.work_progress_footer)
        self.work_progress_task.configure(bg=bg);self.work_progress_task_count.configure(text=f"절체 작업대상 {progress['total']}개 · ",fg=fg,bg=bg)
        task_note=('별도 작업 확인율 '+('-' if progress['rate'] is None else f"{progress['rate']:.1f}%")) if progress['kind']=='after' else '후도면에서 절체 작업 확인'
        self.work_progress_task_note.configure(text=task_note,fg='#000000',bg=bg);self.work_progress_task.pack(fill='x',before=self.work_progress_footer)
        self.work_progress_footer.configure(text='목표: 현장반영 100% → 후도면 100%',fg='#64748b',bg=bg,wraplength=300)
        if not self.metrics_details_visible:
            for widget in (self.work_progress_note,self.work_progress_task,self.work_progress_footer):widget.pack_forget()
        errors=self.store.error_core_summary()
        error_text=f"오류코어 {errors['core_count']}개"
        self.error_summary_label.configure(text=error_text,fg="#7b1fa2" if errors['total'] else "#1b5e20",bg="#f3e5f5" if errors['total'] else "#f1f8e9")
        self.dashboard_frame.lift()

    def refresh_work_core_metrics(self,label):
        """V202 작업코어현황 = the 코어확인/작업목록 「작업필요코어(전체)」 rows (same count)."""
        work=workflow.work_core_list_report(self.store,self.work_report())
        incomplete=work['total']-work['done'];bg='#ffffff'
        fg='#16734b' if work['rate']==100.0 else '#192b46'
        self.work_progress_label.configure(bg=bg);self.work_progress_counts.configure(bg=bg)
        self.work_progress_text.configure(text=f"작업코어 {work['all']}개 · 연결 완료율 · {label}",fg=fg,bg=bg)
        if work['kind']=='gis' or work['missing_before'] or not work['all']:
            message='임시도면은 작업코어 판정 제외' if work['kind']=='gis' else '저장된 현장반영 도면 없음' if work['missing_before'] else '절단·철거 표시된 케이블·함체·RN 없음'
            self.work_progress_completed.configure(text=message,fg='#64748b',bg=bg)
            self.work_progress_incomplete.configure(text='',fg=fg,bg=bg)
        else:
            self.work_progress_completed.configure(text=f"연결대상 {work['total']} / 연결완료 {work['done']} / ",fg=fg,bg=bg)
            self.work_progress_incomplete.configure(text=f"미완료 {incomplete}",fg='#c62828' if incomplete>0 else fg,bg=bg)
        self.work_progress_rate.configure(text=workflow.completion_rate_text(work),fg=fg,bg=bg)
        self.completion_bar.configure(value=work['rate'] or 0,style='Complete.Horizontal.TProgressbar' if work['rate']==100.0 else 'Completion.Horizontal.TProgressbar')
        excluded=' / '.join(f'{name} {count}' for name,count in work['excluded_counts'].items()) or '없음'
        self.work_progress_note.configure(text=f"작업코어 = 코어확인/작업목록 「작업필요코어(전체)」 {work['all']}개 (절단절체 {work['cut']} · 코어절체 {work['transfer']})"
            +'\n절단·철거 케이블, 철거 함체·RN에 연결된 코어 · 같은 코어ID는 1개\n연결검사 제외 '+str(work['excluded'])+'개 ('+excluded+')',fg='#64748b',bg=bg,wraplength=300)
        self.work_progress_footer.configure(text='도면 전체 기준은 위 「도면현황」 버튼',fg='#64748b',bg=bg,wraplength=300)
        self.work_progress_task.pack_forget()
        self.work_progress_footer.pack(fill='x');self.work_progress_note.pack(fill='x',before=self.work_progress_footer)
        if not self.metrics_details_visible:
            for widget in (self.work_progress_note,self.work_progress_footer):widget.pack_forget()
        errors=self.store.error_core_summary()
        self.error_summary_label.configure(text=f"오류코어 {errors['core_count']}개",fg="#7b1fa2" if errors['total'] else "#1b5e20",bg="#f3e5f5" if errors['total'] else "#f1f8e9")
        self.dashboard_frame.lift()

    def error_core_count(self):
        return self.store.error_core_summary()['total']

    def refresh_error_core_button(self):
        if not self.error_core_button:return
        count=self.error_core_count()
        if count:
            self.error_core_button.configure(text=f"오류코어확인 ({count}개)",bg="#d32f2f",fg="#ffffff",activebackground="#b71c1c",activeforeground="#ffffff",font=("Malgun Gothic",9,"bold"))
        else:
            self.error_core_button.configure(text="오류코어확인",bg="#f0f0f0",fg="#111111",activebackground="#e2e2e2",activeforeground="#111111",font=("Malgun Gothic",9))
        self.drawing_tools.sync(error_count=count)

    def hamche_label_layout(self,nodes,scale=1,preview=False,reveal_selected=False):
        size=max(9,round(12*scale))
        if size not in self.label_fonts:self.label_fonts[size]=tkfont.Font(root=self,family='Malgun Gothic',size=-size,weight='bold')
        font=self.label_fonts[size];height=font.metrics('linespace')+6;result=[]
        warnings=self.store.node_warning_summary()
        for node in nodes.values():
            text=hamche_detail_text(node,self.display_options,selected=reveal_selected and node['id'] in self.selected)
            if not text:continue
            x,y=self.preview_positions.get(node['id'],(node['x'],node['y'])) if preview else (node['x'],node['y'])
            width=font.measure(text)+14;cx=max(width/2+4,x*scale)
            cy=(y-48)*scale-max(11*scale,10)-height/2-4
            if cy-height/2<4:
                badges=node_display_badges(self.store,node,warnings.get(node['id'],{}),self.display_options)
                bottom=48+24*(len(badges)-1)+10 if badges else 38
                cy=y*scale+bottom*scale+height/2+4
            result.append({'id':node['id'],'text':text,'x':cx,'y':cy,'width':width,'height':height,'font':font,
                           'bounds':(cx-width/2,cy-height/2,cx+width/2,cy+height/2),'border':status_color(node['status'])})
        return result

    def cable_label_layout(self,nodes,cables,warnings,scale=1,preview=False,hamche_layout=None,reveal_selected=False):
        options=self.display_options
        try:phase_tags=workflow.cable_phase_tags(self.store)
        except Exception:phase_tags={}
        size=max(10,round(13*scale));small=max(9,round(11*scale))
        for pixels in (size,small):
            if pixels not in self.label_fonts:self.label_fonts[pixels]=tkfont.Font(root=self,family="Malgun Gothic",size=-pixels,weight="bold")
        font=self.label_fonts[size];badge_font=self.label_fonts[small]
        def pos(n):return self.preview_positions.get(n["id"],(n["x"],n["y"])) if preview else (n["x"],n["y"])
        occupancy=LabelOccupancy(max(80,160*scale))
        node_warnings=self.store.node_warning_summary()
        for node in nodes.values():
            x,y=pos(node);x*=scale;y*=scale
            half=max((60 if node["type"]=="sub" else 40)*scale,font.measure(str(node["name"] or ""))/2+6)
            badges=node_display_badges(self.store,node,node_warnings.get(node['id'],{}),options)
            for badge,fill,ink in badges:
                half=max(half,font.measure(badge)/2+6)
            bottom=max(62,62+24*(len(badges)-1)) if badges else 40
            occupancy.add((x-half,y-max(65*scale,48*scale+10),x+half,y+max(bottom*scale,20)))
        if hamche_layout is None:hamche_layout=self.hamche_label_layout(nodes,scale,preview)
        for entry in hamche_layout:
            x1,y1,x2,y2=entry['bounds'];occupancy.add((x1-4,y1-4,x2+4,y2+4))
        groups={}
        for cable in cables:groups.setdefault(tuple(sorted((cable["n1id"],cable["n2id"]))),[]).append(cable)
        markers=LabelOccupancy(max(80,160*scale))
        # Cut stars keep their existing protection. Removal crosses are placed
        # after labels, so an X can never push cable text away from its midpoint.
        for pair,group in groups.items():
            a,b=nodes.get(pair[0]),nodes.get(pair[1])
            if not a or not b:continue
            ax,ay=pos(a);bx,by=pos(b);dx=bx-ax;dy=by-ay;length=max(1,math.hypot(dx,dy))
            for i,cable in enumerate(group):
                if cable['status']!='절단':continue
                path=parallel_cable_path(ax*scale,ay*scale,bx*scale,by*scale,i,len(group),scale)
                radius=max(7,12*scale)+5
                for x,y in cable_path_even_points(path,150*scale):
                    box=(x-radius,y-radius,x+radius,y+radius);markers.add(box);occupancy.add(box)
        result=[]
        for pair,group in groups.items():
            a,b=nodes.get(pair[0]),nodes.get(pair[1])
            if not a or not b:continue
            ax,ay=pos(a);bx,by=pos(b);dx=bx-ax;dy=by-ay;length=max(1,math.hypot(dx,dy))
            for i,cable in enumerate(group):
                path=parallel_cable_path(ax*scale,ay*scale,bx*scale,by*scale,i,len(group),scale)
                count=len(group);outer_side=0
                if count<=1:anchor=cable_path_point(path,.5)
                elif i in (0,count-1):
                    # V205: the two outside cables carry their label just outside the bundle.
                    outer_side=-1 if i==0 else 1;anchor=cable_path_point(path,.5)
                else:
                    inner=count-2;k=i-1;anchor=cable_path_point(path,.5 if inner==1 else .35+.3*k/(inner-1))
                label=cable_label_text(cable,options,selected=reveal_selected and cable["id"] in self.selected)
                phase_tag=phase_tags.get(str(cable["id"]))
                if phase_tag:label+=' ['+'·'.join(workflow.work_phase_short(n) for n in phase_tag)+']'
                auto_locked=workflow.cable_endpoints_locked(cable,nodes)
                if auto_locked:label='🔒 '+label
                parts=[{"text":label,"width":font.measure(label)+22,"height":font.metrics("linespace")+8,"font":font,"fill":"#ffeb3b" if auto_locked else "#ffffff","ink":"#222222","border":status_color(cable["status"])}]
                warning=warnings.get(cable["id"],{})
                if options["badges"]:
                    u=warning.get("unassigned",0);n=warning.get("incomplete_badge",warning.get("incomplete",0))
                    badges=[]
                    pending=([f"미배정코어 {u}"] if u and options.get("cable_unassigned",True) else [])+([f"미완료코어 {n}"] if n and options.get("cable_incomplete",True) else [])
                    if pending:badges.append((" · ".join(pending),"#fff1f2","#c62828","#ef9a9a"))
                    t=warning.get("temporary_complete",0)
                    if t and options.get("cable_temporary",True):badges.append((f"연결완료임시코어 {t}","#e3f2fd","#1565c0","#90caf9"))
                    marked=warning.get('marked_error',0)
                    if marked:badges.append((f"오류코어 {marked}","#f3e5f5","#7b1fa2","#ce93d8"))
                    for text,fill,ink,border in badges:parts.append({"text":text,"width":badge_font.measure(text)+14,"height":badge_font.metrics("linespace")+6,"font":badge_font,"fill":fill,"ink":ink,"border":border})
                width=max(p["width"] for p in parts);height=sum(p["height"] for p in parts)+4*(len(parts)-1)
                if outer_side:
                    px,py=-dy/length*outer_side,dx/length*outer_side
                    clear=max(10,12*scale)+abs(px)*width/2+abs(py)*height/2
                    center=(anchor[0]+px*clear,anchor[1]+py*clear)
                    anchor=(center[0],center[1]-(height-parts[0]["height"])/2)
                # Anchor the first row at the cable midpoint; reserve the entire badge group.
                cx,cy=anchor[0],anchor[1]+(height-parts[0]["height"])/2
                protected=not markers.free((cx-width/2-4,cy-height/2-4,cx+width/2+4,cy+height/2+4))
                cx,cy=occupancy.place(cx,cy,width,height,options["auto_labels"] or protected)
                top=cy-height/2
                for part in parts:part["x"]=cx;part["y"]=top+part["height"]/2;top+=part["height"]+4
                result.append({"id":cable["id"],"anchor":anchor,"parts":parts,"bounds":(cx-width/2,cy-height/2,cx+width/2,cy+height/2)})
        return result

    def render_cable_labels(self,layout):
        for entry in layout:
            cid=entry["id"];parts=entry["parts"];first=parts[0];tags=("cable",cid,"cable_label")
            ax,ay=entry["anchor"]
            if math.hypot(first["x"]-ax,first["y"]-ay)>1:
                item=self.canvas.create_line(ax,ay,first["x"],first["y"],fill="#64748b",dash=(3,3),tags=tags);self.item_to_cable[item]=cid
            for i,part in enumerate(parts):
                x,y=part["x"],part["y"];w=part["width"];h=part["height"]
                group_tags=tags+(("warning_badge",)+(("incomplete_badge",) if part["text"].startswith(("미배정코어","미완료코어")) else ()) if i else ())
                box=self.canvas.create_rectangle(x-w/2,y-h/2,x+w/2,y+h/2,fill=part["fill"],outline=part["border"],width=1.5,tags=group_tags)
                text=self.canvas.create_text(x,y,text=part["text"],font=part["font"],fill="#006b2c" if i==0 and cid in self.selected else part["ink"],tags=group_tags)
                self.item_to_cable[box]=cid;self.item_to_cable[text]=cid

    def schedule_auto_splice_notice(self):
        if not getattr(self.store,'pending_auto_splice_report',None) or getattr(self,'_auto_splice_notice_job',None):return
        store=self.store
        def show():
            self._auto_splice_notice_job=None
            if self.store is not store:return
            report=getattr(store,'pending_auto_splice_report',None);store.pending_auto_splice_report=None
            if not report:return
            self.status.set(f"동일번호 자동 중접 · 정상 {report['normal']}건 · 오류 {report['errors']}건")
            if report['errors']:
                focused=self.focus_get();parent=focused.winfo_toplevel() if focused else self
                previous_grab=self.grab_current()
                dialog=workflow.BulkSummaryDialog(parent,report,'정상 연결 완료 / 오류 연결 보류');self.wait_window(dialog)
                try:
                    if previous_grab is not None and previous_grab.winfo_exists():previous_grab.grab_set()
                except tk.TclError:pass
        self._auto_splice_notice_job=self.after_idle(show)

    def refresh(self):
        self.refresh_all_lock_button()
        scale=self.view_scale;existing_nodes=self.store.nodes();existing_cables=self.store.cables()
        self.close_stale_detail_dialogs(existing_nodes,existing_cables)
        windows=[w for w in self.winfo_children() if isinstance(w,tk.Toplevel)]
        while windows:
            window=windows.pop()
            windows.extend(w for w in window.winfo_children() if isinstance(w,tk.Toplevel))
            if hasattr(window,'gis_control') and window.gis_control.store is self.store:window.gis_control.refresh()
            if isinstance(window,(NodeDialog,CableDialog,NodePropertiesDialog)) and window.store is self.store:window.refresh_lock_state()
            if isinstance(window,(NodeDialog,CableDialog,NodeSummaryDialog,NodePairSummaryDialog,AllCoreDialog,CoreCheckDialog,workflow.NodeConnectionDiagramDialog,workflow.CoreLayoutDialog,workflow.RNIdentityDialog)) and window.store is self.store:window.refresh_shared_rows()
        self.refresh_connection_highlight()
        self.render_drawing_canvas(existing_nodes,existing_cables)
        self.apply_highlight_visuals();self.render_highlight_core_labels()
        self.refresh_metrics();self.refresh_error_core_button();self.refresh_minimap(existing_nodes,existing_cables);self.status.set(self.status.get() or f"시설 {len(existing_nodes)}개 · 케이블 {len(existing_cables)}개")
        self.schedule_auto_splice_notice()

    def render_drawing_canvas(self,existing_nodes=None,existing_cables=None):
        """Paint geometry/labels only; shared by the editor and read-only reference."""
        scale=self.view_scale
        existing_nodes=self.store.nodes() if existing_nodes is None else existing_nodes
        existing_cables=self.store.cables() if existing_cables is None else existing_cables
        self.canvas.delete("all");self.item_to_node.clear();self.item_to_cable.clear();self.cable_line_items.clear();self.cable_base_styles.clear();self.__dict__.setdefault('new_cable_ids',set()).clear()
        def node_pos(n):return self.preview_positions.get(n["id"],(n["x"],n["y"]))
        world_w=max(5200,int(max((node_pos(n)[0] for n in existing_nodes),default=0)+600));world_h=max(4200,int(max((node_pos(n)[1] for n in existing_nodes),default=0)+600));self.world_w,self.world_h=world_w,world_h;self.canvas.configure(scrollregion=(0,0,world_w*scale,world_h*scale))
        if self.display_options["grid"] and 40*scale>=12:
            for x in range(0,world_w+1,40):self.canvas.create_line(x*scale,0,x*scale,world_h*scale,fill="#e5e8ef",tags=("grid",))
            for y in range(0,world_h+1,40):self.canvas.create_line(0,y*scale,world_w*scale,y*scale,fill="#e5e8ef",tags=("grid",))
        nodes={r["id"]:r for r in existing_nodes};groups={};cable_warnings=self.store.cable_core_warning_summary()
        for c in existing_cables:groups.setdefault(tuple(sorted((c["n1id"],c["n2id"]))),[]).append(c)
        hamche_layout=self.hamche_label_layout(nodes,scale,preview=True,reveal_selected=True)
        self.current_label_layout=self.cable_label_layout(nodes,existing_cables,cable_warnings,scale,preview=True,hamche_layout=hamche_layout,reveal_selected=True)
        removal_obstacles=removal_mark_obstacles(self.current_label_layout+hamche_layout,nodes,scale,self.preview_positions) if any(c['status']=='철거' for c in existing_cables) else None
        self.render_complexity=len(nodes)+sum(len(x) for x in groups.values())
        for pair,cs in groups.items():
            for index,c in enumerate(cs):
                a,b=nodes.get(pair[0]),nodes.get(pair[1])
                if not a or not b:continue
                ap,bp=node_pos(a),node_pos(b);x1,y1,x2,y2=ap[0]*scale,ap[1]*scale,bp[0]*scale,bp[1]*scale
                path=parallel_cable_path(x1,y1,x2,y2,index,len(cs),scale);coords=cable_path_coords(path);smooth=cable_path_smooth(path)
                color="#d32f2f" if c["size"]<=12 else ("#1769aa" if c["size"]<=36 else ("#19703a" if c["size"]<=72 else ("#e24a9b" if c["size"]<=144 else "#795548")))
                cable_selected=c["id"] in self.selected
                if cable_selected:color="#00a843"
                base_color=color;base_width=7 if cable_selected else 4
                blink_highlight=c["id"] in self.highlight_cables and self.highlight_blink_on
                if blink_highlight:color=self.highlight_cable_colors.get(c["id"],"#ff7a00")
                dash,marker=cable_status_style(c["status"])
                check_mark=cable_check_mark(c) if self.display_options.get('cable_check_mark',True) else ''
                if check_mark:
                    # V164 user 'checked' colour: widest rim, so the yellow
                    # missing-info rim still shows inside it.
                    mark_rim=self.canvas.create_line(*coords,smooth=smooth,splinesteps=18,width=max(29,int(30*scale)),fill=CABLE_CHECK_MARKS[check_mark][1],tags=('cable',c['id'],'cable_check_mark'))
                    self.item_to_cable[mark_rim]=c['id']
                if self.display_options.get('cable_missing_info',True) and cable_missing_fields(c):
                    # A steady outer rim remains visible beneath selection and route pulses.
                    rim_width=max(19,int(20*scale))
                    rim=self.canvas.create_line(*coords,smooth=smooth,splinesteps=18,width=rim_width,fill='#facc15',tags=('cable',c['id'],'cable_missing_info'))
                    self.item_to_cable[rim]=c['id']
                if cable_selected:
                    glow_width=max(10,int(12*scale))
                    glow=self.canvas.create_line(*coords,smooth=smooth,splinesteps=18,width=glow_width,fill="#b9f6ca",dash=new_cable_dash(glow_width) if dash else None,tags=("cable",c["id"]));self.item_to_cable[glow]=c["id"]
                line_width=7 if blink_highlight else base_width
                line=self.canvas.create_line(*coords,smooth=smooth,splinesteps=18,width=line_width,fill=color,dash=new_cable_dash(line_width) if dash else None,tags=("cable",c["id"]))
                self.item_to_cable[line]=c["id"];self.cable_line_items[c["id"]]=line;self.cable_base_styles[c["id"]]=(base_color,base_width)
                if dash:self.__dict__.setdefault('new_cable_ids',set()).add(c["id"])
                if c["status"]=="철거":
                    half=max(5,9*scale)
                    for qx,qy in removal_mark_path_points(path,removal_obstacles,scale):
                        first=self.canvas.create_line(qx-half,qy-half,qx+half,qy+half,fill="#111111",width=max(2,int(3*scale)),tags=("cable",c["id"]));second=self.canvas.create_line(qx-half,qy+half,qx+half,qy-half,fill="#111111",width=max(2,int(3*scale)),tags=("cable",c["id"]));self.item_to_cable[first]=c["id"];self.item_to_cable[second]=c["id"]
                elif c["status"]=="절단":
                    for qx,qy in cable_path_even_points(path,150*scale):
                        mark=self.canvas.create_polygon(star_points(qx,qy,max(7,12*scale),max(3,5.5*scale)),fill="#ff1744",outline="#111111",width=max(1,int(2*scale)),tags=("cable",c["id"]));self.item_to_cable[mark]=c["id"]
        # V187: 「도면 밖 연결」 hint between the two marked enclosures.
        try:offmap_lines=workflow.offmap_map_lines(self.store)
        except (AttributeError,sqlite3.Error):offmap_lines=[]
        for na,nb,text,ok in offmap_lines:
            if na not in nodes or nb not in nodes:continue
            (ax,ay),(bx,by)=node_pos(nodes[na]),node_pos(nodes[nb]);ax,ay,bx,by=ax*scale,ay*scale,bx*scale,by*scale
            hint='#7c3aed' if ok else '#d00000'
            self.canvas.create_line(ax,ay,bx,by,fill=hint,width=max(2,int(3*scale)),dash=(4,6),tags=('offmap_link',))
            self.canvas.create_text((ax+bx)/2,(ay+by)/2-14*scale,text=text,fill=hint,font=("Malgun Gothic",max(7,int(9*scale)),"bold"),tags=('offmap_link',))
        # Raise selected cable geometry without changing parallel-curve order.
        # Facilities still paint over cable endpoints; selected labels go last.
        selected_cables=[c['id'] for c in existing_cables if c['id'] in self.selected]
        active=getattr(self,'_active_cable',None)
        if active in selected_cables:selected_cables.remove(active);selected_cables.append(active)
        for cid in selected_cables:self.canvas.tag_raise(cid)
        self.render_cable_labels(self.current_label_layout)
        all_labels=self.current_label_layout+hamche_layout
        if all_labels:
            self.world_w=max(self.world_w,math.ceil(max(e["bounds"][2] for e in all_labels)/scale)+100)
            self.world_h=max(self.world_h,math.ceil(max(e["bounds"][3] for e in all_labels)/scale)+100)
            self.canvas.configure(scrollregion=(0,0,self.world_w*scale,self.world_h*scale))
        warnings=self.store.node_warning_summary()
        for n in nodes.values():
            px,py=node_pos(n);x,y=px*scale,py*scale;selected=n["id"] in self.selected;visual=node_visual(n);items=[]
            wide=visual["shape"]=="wide";half_w,half_h=node_half_size(n['type']);rx=half_w*scale;ry=half_h*scale
            warning=visible_node_warning(warnings.get(n["id"]),self.display_options)
            if warning:
                warn_color="#ff1744" if warning.get('count') or warning.get('rn_in') or warning.get('duplicate_count') else '#1565c0'
                outer=self.canvas.create_rectangle(x-rx-7*scale,y-ry-7*scale,x+rx+7*scale,y+ry+7*scale,outline=warn_color,width=max(3,int(5*scale))) if wide else self.canvas.create_oval(x-rx-7*scale,y-ry-7*scale,x+rx+7*scale,y+ry+7*scale,outline=warn_color,width=max(3,int(5*scale)))
                items.append(outer)
            if selected:
                glow=self.canvas.create_rectangle(x-rx-8*scale,y-ry-8*scale,x+rx+8*scale,y+ry+8*scale,outline="#b9f6ca",width=max(3,int(6*scale))) if wide else self.canvas.create_oval(x-rx-8*scale,y-ry-8*scale,x+rx+8*scale,y+ry+8*scale,outline="#b9f6ca",width=max(3,int(6*scale)))
                ring=self.canvas.create_rectangle(x-rx-4*scale,y-ry-4*scale,x+rx+4*scale,y+ry+4*scale,outline="#00a843",width=max(2,int(3*scale))) if wide else self.canvas.create_oval(x-rx-4*scale,y-ry-4*scale,x+rx+4*scale,y+ry+4*scale,outline="#00a843",width=max(2,int(3*scale)))
                items.extend((glow,ring))
            if n['type']=='sub':
                parts=subscriber_symbol(self.canvas,x,y,visual,scale,('node',n['id']));items.extend(parts[:-1]);shape=parts[-1]
            elif wide:shape=self.canvas.create_rectangle(x-rx,y-ry,x+rx,y+ry,fill=visual["fill"],outline=visual["outline"],width=max(2,int(3*scale)),tags=("node",n["id"]))
            else:shape=self.canvas.create_oval(x-rx,y-ry,x+rx,y+ry,fill=visual["fill"],outline=visual["outline"],width=max(2,int(3*scale)),tags=("node",n["id"]))
            items.append(shape)
            if visual["shape"]=="circle_x":
                d=22*scale;items.extend((self.canvas.create_line(x-d,y-d,x+d,y+d,fill=visual["outline"],width=max(2,int(4*scale))),self.canvas.create_line(x-d,y+d,x+d,y-d,fill=visual["outline"],width=max(2,int(4*scale)))))
            if visual["text"]:
                font=('Arial',-max(8,round(visual['symbol_font']*scale)),'bold') if visual.get('symbol_font') else ("Malgun Gothic",max(7,int((11 if wide else 15)*scale)),"bold")
                items.append(self.canvas.create_text(x,y,text=visual["text"],font=font,fill=visual["text_fill"],tags=("node",n["id"])))
            if visual["label_above"]:
                name=str(n["name"] or "");label_w=max(56,min(180,len(name)*13+14))*scale;ly=y-48*scale
                name_ink,name_fill=node_name_colors(n)
                items.append(self.canvas.create_rectangle(x-label_w/2,ly-11*scale,x+label_w/2,ly+11*scale,fill=name_fill,outline=status_color(n["status"]),width=max(1,int(2*scale)),tags=("node",n["id"])))
                items.append(self.canvas.create_text(x,ly,text=name,font=("Malgun Gothic",max(7,int(9*scale)),"bold"),fill=name_ink,tags=("node",n["id"])))
            if n["status"]=="절단" and visual["shape"]!="circle_x":
                items.extend((self.canvas.create_line(x-rx*.75,y-ry*.7,x+rx*.75,y+ry*.7,fill="#ffffff",width=max(2,int(3*scale))),self.canvas.create_line(x-rx*.75,y+ry*.7,x+rx*.75,y-ry*.7,fill="#ffffff",width=max(2,int(3*scale)))))
            badges=node_display_badges(self.store,n,warnings.get(n['id'],{}),self.display_options)
            if badges:
                for badge_index,(badge,bc,fg) in enumerate(badges):
                    by=y+(48+24*badge_index)*scale;bw=max(70,len(badge)*11)*scale
                    items.append(self.canvas.create_rectangle(x-bw/2,by-10*scale,x+bw/2,by+10*scale,fill=bc,outline="#ffffff",width=1,tags=("node",n["id"])))
                    items.append(self.canvas.create_text(x,by,text=badge,font=("Malgun Gothic",max(7,int(8*scale)),"bold"),fill=fg,tags=("node",n["id"])))
            for item in items:self.item_to_node[item]=n["id"]
        for entry in hamche_layout:
            x,y,w,h=entry['x'],entry['y'],entry['width'],entry['height'];tags=('node',entry['id'],'hamche_details')
            box=self.canvas.create_rectangle(x-w/2,y-h/2,x+w/2,y+h/2,fill='#f1f7ff',outline=entry['border'],width=1,tags=tags)
            text=self.canvas.create_text(x,y,text=entry['text'],font=entry['font'],fill='#17365d',tags=tags)
            self.item_to_node[box]=entry['id'];self.item_to_node[text]=entry['id']
        for cid in selected_cables:
            for item in self.canvas.find_withtag(cid):
                if 'cable_label' in self.canvas.gettags(item):self.canvas.tag_raise(item)
        selected_nodes=[nid for nid in nodes if nid in self.selected]
        active=getattr(self,'_active_node',None)
        if active in selected_nodes:selected_nodes.remove(active);selected_nodes.append(active)
        for nid in selected_nodes:
            for item in self.canvas.find_all():
                if self.item_to_node.get(item)==nid:self.canvas.tag_raise(item)


    def close_stale_detail_dialogs(self,nodes,cables):
        windows=getattr(self,'_detail_windows',{})
        if not windows:return
        node_ids={str(n['id']) for n in nodes};cable_ids={str(c['id']) for c in cables}
        for key,window in list(windows.items()):
            owner,generation,kind,item_id=key
            if owner!=id(self.store) or generation!=getattr(self.store,'_view_generation',0) or item_id not in (cable_ids if kind=='cable' else node_ids):
                windows.pop(key,None)
                try:window.destroy()
                except tk.TclError:pass

    def refresh_minimap(self,nodes=None,cables=None):
        if not self.minimap_visible or not hasattr(self,"minimap"):return
        if self.pending_drag and self.minimap_transform:self.refresh_minimap_viewport();return
        if nodes is None:nodes={row["id"]:row for row in self.store.nodes()}
        elif not isinstance(nodes,dict):nodes={row["id"]:row for row in nodes}
        if cables is None:cables=list(self.store.cables())
        else:cables=list(cables)
        self.minimap.delete("all");self.minimap_view_item=None;self.minimap_drag_anchor=None
        width=max(1,int(self.minimap.cget("width")));height=max(1,int(self.minimap.cget("height")));pad=10
        if not nodes:
            self.minimap.create_text(width/2,height/2,text="도면이 비어 있습니다",fill="#7b8798",font=("Malgun Gothic",9));self.minimap_transform=None;return
        positions={nid:self.preview_positions.get(nid,(float(node["x"]),float(node["y"]))) for nid,node in nodes.items()}
        minx=min(pos[0] for pos in positions.values())-100;maxx=max(pos[0] for pos in positions.values())+100;miny=min(pos[1] for pos in positions.values())-100;maxy=max(pos[1] for pos in positions.values())+100
        factor=min((width-pad*2)/max(1,maxx-minx),(height-pad*2)/max(1,maxy-miny));self.minimap_transform=(minx,miny,factor,pad)
        def point(x,y):return pad+(x-minx)*factor,pad+(y-miny)*factor
        cable_step=max(1,math.ceil(len(cables)/1200))
        for cable in cables[::cable_step]:
            if cable["n1id"] not in positions or cable["n2id"] not in positions:continue
            x1,y1=point(*positions[cable["n1id"]]);x2,y2=point(*positions[cable["n2id"]])
            self.minimap.create_line(x1,y1,x2,y2,fill=status_color(cable["status"]),width=1)
        node_rows=list(nodes.values());node_step=max(1,math.ceil(len(node_rows)/1200))
        for node in node_rows[::node_step]:
            x,y=point(*positions[node["id"]]);visual=node_visual(node);fill=visual['fill'];selected=node['id'] in self.selected;outline='#00a843' if selected else visual['outline'] if visual['shape']=='info' else '#334155'
            if visual['shape'] in ('triangle','diamond'):self.minimap.create_polygon(subscriber_points(visual['shape'],x,y,4),fill=fill,outline=outline,width=2 if selected else 1)
            else:self.minimap.create_oval(x-3,y-3,x+3,y+3,fill=fill,outline=outline,width=2 if selected else 1)
        self.refresh_minimap_viewport()

    def refresh_minimap_viewport(self):
        if not self.minimap_visible or not self.minimap_transform or not hasattr(self,"canvas"):return
        minx,miny,factor,pad=self.minimap_transform
        left=self.canvas.canvasx(0)/self.view_scale;top=self.canvas.canvasy(0)/self.view_scale
        right=self.canvas.canvasx(max(1,self.canvas.winfo_width()))/self.view_scale;bottom=self.canvas.canvasy(max(1,self.canvas.winfo_height()))/self.view_scale
        x1=pad+(left-minx)*factor;y1=pad+(top-miny)*factor;x2=pad+(right-minx)*factor;y2=pad+(bottom-miny)*factor
        width=int(self.minimap.cget("width"));height=int(self.minimap.cget("height"));x1=max(1,min(width-1,x1));x2=max(1,min(width-1,x2));y1=max(1,min(height-1,y1));y2=max(1,min(height-1,y2))
        coords=(min(x1,x2),min(y1,y2),max(x1,x2),max(y1,y2))
        if self.minimap_view_item:self.minimap.coords(self.minimap_view_item,*coords)
        else:self.minimap_view_item=self.minimap.create_rectangle(*coords,outline="#ff6d00",fill="#ffcc80",stipple="gray12",width=2,tags=("viewport",))
        self.minimap.tag_raise("viewport")

    def minimap_press(self,event):
        if not self.minimap_transform:return "break"
        coords=self.minimap.coords(self.minimap_view_item) if self.minimap_view_item else []
        inside=len(coords)==4 and coords[0]-3<=event.x<=coords[2]+3 and coords[1]-3<=event.y<=coords[3]+3
        if not inside:self.minimap_click(event)
        # Record the grab point: pressing inside the box must not recenter/jump.
        self.minimap_drag_anchor=(event.x,event.y,self.canvas.canvasx(0),self.canvas.canvasy(0),self.minimap_transform[2],self.view_scale)
        self.minimap.configure(cursor="fleur")
        return "break"

    def minimap_drag(self,event):
        if not self.minimap_drag_anchor:return "break"
        x,y,left,top,factor,scale=self.minimap_drag_anchor
        total_w=max(1,self.world_w*scale);total_h=max(1,self.world_h*scale)
        left+=(event.x-x)/factor*scale;top+=(event.y-y)/factor*scale
        self.canvas.xview_moveto(max(0,min(max(0,total_w-self.canvas.winfo_width()),left))/total_w)
        self.canvas.yview_moveto(max(0,min(max(0,total_h-self.canvas.winfo_height()),top))/total_h)
        self.refresh_minimap_viewport()
        return "break"

    def minimap_release(self,event):
        self.minimap_drag_anchor=None;self.minimap.configure(cursor="hand2");return "break"

    def minimap_click(self,event):
        if not self.minimap_transform:return
        minx,miny,factor,pad=self.minimap_transform;world_x=minx+(event.x-pad)/factor;world_y=miny+(event.y-pad)/factor
        total_w=max(1,self.world_w*self.view_scale);total_h=max(1,self.world_h*self.view_scale)
        x_fraction=(world_x*self.view_scale-self.canvas.winfo_width()/2)/total_w;y_fraction=(world_y*self.view_scale-self.canvas.winfo_height()/2)/total_h
        self.canvas.xview_moveto(max(0,min(1,x_fraction)));self.canvas.yview_moveto(max(0,min(1,y_fraction)));self.refresh_minimap_viewport()

    def schedule_refresh(self):
        if self.refresh_job is None:
            def run():
                self.refresh_job=None
                if self.pending_drag:
                    orig,dx,dy=self.pending_drag
                    self.preview_positions={nid:(x+dx,y+dy) for nid,(x,y) in orig.items()}
                self.refresh()
            delay=33 if getattr(self,"render_complexity",0)<250 else 60
            self.refresh_job=self.after(delay,run)

    def target(self,event):
        x=self.canvas.canvasx(event.x);y=self.canvas.canvasy(event.y);ids=self.canvas.find_overlapping(x-3,y-3,x+3,y+3)
        for item in reversed(ids):
            if item in self.item_to_node:return "node",self.item_to_node[item]
            if item in self.item_to_cable:return "cable",self.item_to_cable[item]
        return None,None

    def click(self,e):
        self.lift()
        self.canvas.focus_set()
        self.cancel_left_pan()
        kind,key=self.target(e)
        panel=getattr(self,'_map_allocation_panel',None)
        if panel is not None and panel.winfo_exists():
            self.drag_anchor=None;self.pending_drag=None
            if kind=='cable':panel.run(lambda:panel.add_cable(key));return 'break'
            if kind=='node':
                if self.store.node(key)['type']=='rn':panel.run(lambda:panel.add_cable('PORT:'+key))
                else:panel.message.set('배정할 케이블 또는 RN을 클릭하세요.')
                return 'break'
            self.left_pan=(e.x,e.y);self.left_pan_moved=False;self.left_pan_cursor=self.canvas.cget('cursor');self.canvas.scan_mark(e.x,e.y)
            return 'break'
        if self.__dict__.get('cable_end_move'):
            self.drag_anchor=None;self.pending_drag=None
            if kind!='node':self.status.set('케이블 끝을 새로 붙일 시설(함체·RN·가입자)을 클릭하세요 · Esc 취소');return 'break'
            move=self.cable_end_move;self.cable_end_move=None;self.finish_cable_end_move(move,key);return 'break'
        if self.mode in NODE_TYPES.values():
            node_type=self.mode;name=self.next_node_name(node_type);wx=self.canvas.canvasx(e.x)/self.view_scale;wy=self.canvas.canvasy(e.y)/self.view_scale
            x,y=round(wx/40)*40,round(wy/40)*40;overlap=self.overlapping_node(x,y,node_type)
            if overlap:
                messagebox.showinfo("시설 위치 겹침",f'{overlap["name"]}과 겹치는 위치입니다.\n조금 떨어진 빈 격자를 선택하세요.',parent=self);return
            subscriber_type='subscriber'
            if node_type=='sub':
                dialog=SubscriberKindDialog(self);self.wait_window(dialog);self.set_mode('select')
                if dialog.result is None:self.status.set('가입자 생성 취소 · 선택/이동 대기');return
                subscriber_type=dialog.result;name=self.next_node_name(node_type,subscriber_type)
            self.store.add_node(name,x,y,node_type,subscriber_type);self.set_mode("select");self.selected.clear();self.refresh();self.status.set(f"{name} 생성 완료 · 선택/이동 대기")
            return
        if self.mode=="cable":
            if kind!="node":return
            if not self.cable_start:self.cable_start=key;self.status.set("두 번째 시설을 클릭하세요");return
            if key==self.cable_start:messagebox.showinfo("케이블","다른 시설을 선택하세요.");return
            CableDialog(self,self.store,create_nodes=(self.cable_start,key));self.cable_start=None;self.set_mode("select");return
        if kind=="node" and self.open_overview_end(key,e):
            self.drag_anchor=None;self.pending_drag=None;return 'break'
        if kind=="node":
            if e.state & 0x0004:self.selected.symmetric_difference_update({key})
            elif e.state & 0x0001:self.selected.add(key)
            elif key not in self.selected:self.selected={key}
            self.clear_cable_overview()
            if key not in self.selected:return
            self._active_node=key
            selected_nodes=[nid for nid in self.selected if self.store.node(nid)]
            self.drag_anchor=(self.canvas.canvasx(e.x)/self.view_scale,self.canvas.canvasy(e.y)/self.view_scale,{nid:(self.store.node(nid)["x"],self.store.node(nid)["y"]) for nid in selected_nodes});self.refresh()
        elif kind=="cable":
            if e.state & 0x0004:self.selected.symmetric_difference_update({key})
            elif e.state & 0x0001:self.selected.add(key)
            else:self.selected={key}
            self._active_cable=key
            # V199: a plain click shows where every core of this cable goes.
            if not e.state & 0x0005 and self.mode=='select':self.show_cable_overview(key)
            else:self.clear_cable_overview()
            self.refresh()
            # V203: Ctrl+click making exactly two cables -> list the cores both carry.
            if e.state & 0x0004 and self.mode=='select':self.open_common_cores()
            if not e.state & 0x0005 and self.mode=='select':self.begin_cable_end_drag(key,e)
        else:
            self.drag_anchor=None
            if e.state & 0x0001:
                self.selected.clear();self.refresh();x=self.canvas.canvasx(e.x);y=self.canvas.canvasy(e.y);self.box_start=(x,y);self.box_item=self.canvas.create_rectangle(x,y,x,y,outline="#1769aa",dash=(5,3),width=2)
            else:
                self.left_pan=(e.x,e.y);self.left_pan_moved=False;self.left_pan_cursor=self.canvas.cget('cursor');self.canvas.scan_mark(e.x,e.y)

    def cancel_left_pan(self):
        if self.__dict__.get('left_pan') is not None:
            self.canvas.configure(cursor=self.left_pan_cursor);self.left_pan=None;self.left_pan_moved=False

    def move_left_pan(self,e):
        if self.__dict__.get('left_pan') is None:return False
        if not self.left_pan_moved and math.hypot(e.x-self.left_pan[0],e.y-self.left_pan[1])>=5:
            self.left_pan_moved=True;self.canvas.configure(cursor='fleur')
        if self.left_pan_moved:
            self.canvas.scan_dragto(e.x,e.y,gain=1);self.schedule_minimap_viewport()
        return True

    def begin_cable_end_drag(self,cable_id,e):
        """Press on a cable, drag the end nearest the press point onto another facility."""
        cable=self.store.cable(cable_id)
        if not cable or cable['n1id']==cable['n2id']:return
        ends=[self.store.node(nid) for nid in (cable['n1id'],cable['n2id'])]
        if not all(ends):return
        wx=self.canvas.canvasx(e.x)/self.view_scale;wy=self.canvas.canvasy(e.y)/self.view_scale
        near,far=sorted(ends,key=lambda n:math.hypot(float(n['x'])-wx,float(n['y'])-wy))
        self.cable_end_drag=dict(cable=cable_id,node=near['id'],anchor=(float(far['x']),float(far['y'])),press=(e.x,e.y),
                                 moved=False,line=None,store=self.store,generation=getattr(self.store,'_view_generation',0))

    def drag_cable_end(self,e):
        move=self.__dict__.get('cable_end_drag')
        if not move:return False
        if not move['moved']:
            if math.hypot(e.x-move['press'][0],e.y-move['press'][1])<8:return True
            move['moved']=True;node=self.store.node(move['node'])
            self.status.set(f'{node["name"] if node else ""} 쪽 케이블 끝을 붙일 시설 위에 놓으세요 · 코어내역 유지 · 빈 곳에 놓으면 취소')
        x,y=self.canvas.canvasx(e.x),self.canvas.canvasy(e.y);ax,ay=(v*self.view_scale for v in move['anchor'])
        if move['line'] is None or not self.canvas.type(move['line']):move['line']=self.canvas.create_line(ax,ay,x,y,fill='#f97316',width=3,dash=(8,4),tags=('cable_end_drag',))
        else:self.canvas.coords(move['line'],ax,ay,x,y)
        self.canvas.tag_raise(move['line']);return True

    def end_cable_end_drag(self,e):
        move=self.__dict__.pop('cable_end_drag',None)
        if not move:return False
        if move['line'] is not None:self.canvas.delete(move['line'])
        if not move['moved']:return True
        kind,key=self.target(e)
        if kind!='node' or key==move['node']:self.status.set('케이블 끝 옮기기 취소 · 시설 위에 놓아야 옮겨집니다');return True
        self.finish_cable_end_move((move['cable'],move['node'],move['store'],move['generation']),key);return True

    def drag(self,e):
        if self.move_left_pan(e):return
        if self.drag_cable_end(e):return
        if self.box_start and self.box_item:
            x,y=self.canvas.canvasx(e.x),self.canvas.canvasy(e.y);self.canvas.coords(self.box_item,self.box_start[0],self.box_start[1],x,y);return
        if not self.drag_anchor or not self.selected:return
        ax,ay,orig=self.drag_anchor;dx=round((self.canvas.canvasx(e.x)/self.view_scale-ax)/40)*40;dy=round((self.canvas.canvasy(e.y)/self.view_scale-ay)/40)*40
        self.pending_drag=(orig,dx,dy)
        self.schedule_refresh()

    def drop(self,e):
        if self.end_cable_end_drag(e):return
        if self.move_left_pan(e):
            moved=self.left_pan_moved;self.cancel_left_pan()
            if not moved:self.clear_cable_overview()
            if not moved and self.selected:self.selected.clear();self.refresh()
            return
        if self.box_start:
            x1,y1=self.box_start;x2,y2=self.canvas.canvasx(e.x),self.canvas.canvasy(e.y);self.box_start=None
            ids=self.canvas.find_enclosed(min(x1,x2),min(y1,y2),max(x1,x2),max(y1,y2));self.selected={self.item_to_node[i] for i in ids if i in self.item_to_node};self.box_item=None;self.refresh();return
        if self.drag_anchor and self.pending_drag is None:
            self.drag_anchor=None;self.preview_positions={};return
        if self.drag_anchor:
            _,_,orig=self.drag_anchor
            ax,ay,_=self.drag_anchor;dx=round((self.canvas.canvasx(e.x)/self.view_scale-ax)/40)*40;dy=round((self.canvas.canvasy(e.y)/self.view_scale-ay)/40)*40;final={nid:(x+dx,y+dy) for nid,(x,y) in orig.items()}
            if final:
                anchor=next(iter(final));ox,oy=final[anchor];sx,sy=round(ox/40)*40-ox,round(oy/40)*40-oy;final={nid:(max(40,x+sx),max(40,y+sy)) for nid,(x,y) in final.items()}
            collision=self.movement_overlap(final) if any(final.get(nid)!=position for nid,position in orig.items()) else None
            if collision:
                moved,other=collision;self.drag_anchor=None;self.pending_drag=None;self.preview_positions={}
                if self.refresh_job is not None:self.after_cancel(self.refresh_job);self.refresh_job=None
                self.refresh();self.status.set(f'{moved["name"]} 이동 취소 · {other["name"]}과 겹침');messagebox.showwarning("시설 이동 겹침",f'{moved["name"]}을 놓은 위치가 {other["name"]}과 겹칩니다.\n이동을 취소했습니다.',parent=self);return
            with self.store.action("시설 이동"):
                for nid,(x,y) in final.items():self.store.update_node_pos(nid,x,y)
            self.drag_anchor=None;self.pending_drag=None;self.preview_positions={}
            if self.refresh_job is not None:self.after_cancel(self.refresh_job);self.refresh_job=None
            self.refresh()

    def double_click(self,e):
        kind,key=self.target(e)
        panel=getattr(self,'_map_allocation_panel',None)
        if panel is not None and panel.winfo_exists():
            if kind=='cable':panel.run(lambda:panel.add_cable(key))
            elif kind=='node' and self.store.node(key)['type']=='rn':panel.run(lambda:panel.add_cable('PORT:'+key))
            return 'break'
        if kind=="node" and self.overview_end_under_pointer(e):return 'break'
        if kind=="cable" and self.badge_under_pointer(e):
            # V180: double-click 「미완료코어 N」 → which numbers and why (that cable only).
            IncompleteCoresDialog(self,self.store,key);return 'break'
        if kind=="node":open_detail_dialog(self,self.store,'node',key)
        elif kind=="cable":open_detail_dialog(self,self.store,'cable',key)

    def overview_end_under_pointer(self,e):
        if e is None or not hasattr(e,'x') or not self.__dict__.get('_cable_overview'):return False
        x,y=self.canvas.canvasx(e.x),self.canvas.canvasy(e.y)
        return any('cable_overview_end' in self.canvas.gettags(item) for item in self.canvas.find_overlapping(x-1,y-1,x+1,y+1))

    def open_overview_end(self,node_id,e):
        """V201: click on 「N코어 도착」 → which cores of the clicked cable arrive there."""
        if not self.overview_end_under_pointer(e):return False
        model=self.highlight_connection_model.get('cable_overview') or {}
        info=next((x for x in model.get('ends',()) if x['node_id']==node_id),None)
        if not info:return False
        OverviewEndCoresDialog(self,self.store,model,info);return True

    def badge_under_pointer(self,e):
        if e is None or not hasattr(e,'x'):return False
        x,y=self.canvas.canvasx(e.x),self.canvas.canvasy(e.y)
        return any('incomplete_badge' in self.canvas.gettags(item) for item in self.canvas.find_overlapping(x-1,y-1,x+1,y+1))

    def reveal_issue(self,entry,open_core=False):
        target=self.store.issue_position(entry)
        if not target:return False
        key,x,y=target;self.cancel_left_pan();self.mode='select';self.cable_start=None
        self.selected={key};self.refresh();self.update_idletasks()
        for label in getattr(self,'current_label_layout',()):
            if label['id']==key:x,y=(v/self.view_scale for v in label['anchor']);break
        scale=self.view_scale;w=max(1,self.world_w*scale);h=max(1,self.world_h*scale)
        self.canvas.xview_moveto(max(0,min(w-self.canvas.winfo_width(),x*scale-self.canvas.winfo_width()/2))/w)
        self.canvas.yview_moveto(max(0,min(h-self.canvas.winfo_height(),y*scale-self.canvas.winfo_height()/2))/h)
        self.refresh_minimap_viewport();self.lift();self.canvas.focus_set()
        self.status.set('확인 위치 · '+entry['row'][0]+' · '+entry['row'][1])
        if open_core:
            slot=entry.get('slot')
            if slot and not str(slot[0]).startswith('PORT:'):
                window=open_detail_dialog(self,self.store,'cable',slot[0])
                if window.cable_key==slot[0]:window.focus_core(slot[1])
            else:
                window=open_detail_dialog(self,self.store,'node',key)
                if slot:
                    label=next((label for label,cid in window.by_label.items() if cid==slot[0]),None)
                    if label:
                        window.left_var.set(label);window.reload_all(slot[1])
                        if window.left_tree.exists(str(slot[1])):window.left_tree.see(str(slot[1]));window.left_tree.focus_set()
        return True

    def select_all(self,e=None):
        if e is not None:
            widget=getattr(e,'widget',None)
            try:
                if widget.winfo_toplevel() is not self:return
                if widget.winfo_class() in ('Entry','TEntry','Text','Spinbox','TSpinbox','TCombobox','Combobox'):return
            except (AttributeError,tk.TclError):return
        self.cancel_left_pan()
        nodes=self.store.nodes();cables=self.store.cables()
        self.selected={r['id'] for r in nodes}|{r['id'] for r in cables}
        if self.drag_anchor:
            ax,ay,_=self.drag_anchor;positions={n['id']:(n['x'],n['y']) for n in nodes};self.drag_anchor=(ax,ay,positions)
            if self.pending_drag:
                _,dx,dy=self.pending_drag;self.pending_drag=(positions,dx,dy)
        self.refresh();self.status.set(f'전체 선택 · 시설 {len(nodes)}개 · 케이블 {len(cables)}개 · 시설을 끌면 함께 이동합니다.');return 'break'

    def escape_action(self,event=None):
        widget=getattr(event,"widget",None)
        try:top=widget.winfo_toplevel() if widget else self.focus_get().winfo_toplevel()
        except (AttributeError,tk.TclError):top=self
        if top is not self and isinstance(top,tk.Toplevel):
            try:top.grab_release()
            except tk.TclError:pass
            top.destroy()
            self.after_idle(self.focus_force)
        else:self.set_mode("select")
        return "break"

    def shortcut_is_on_main(self,event):
        """팝업 입력 단축키와 메인 도면 실행취소를 확실히 분리한다."""
        widget=getattr(event,"widget",None)
        try:return widget.winfo_toplevel() is self
        except (AttributeError,tk.TclError):return True

    def route_undo(self,event=None):
        if not self.shortcut_is_on_main(event):return self.route_editor_history(event,False)
        return self.undo()

    def route_redo(self,event=None):
        if not self.shortcut_is_on_main(event):return self.route_editor_history(event,True)
        return self.redo()

    def route_editor_history(self,event,redo):
        try:window=event.widget.winfo_toplevel()
        except (AttributeError,tk.TclError):return 'break'
        if isinstance(window,CableDialog) and window.store is self.store:
            if window.notebook.select()==str(window.identity_tab):return window.undo_identity_input(redo=redo,saved_fallback=True)
            return self.change_history(redo=redo,editor=window)
        # Other text widgets retain their native editing shortcuts.
        return None

    def delete_selected(self):
        panel=getattr(self,'_map_allocation_panel',None)
        if panel is not None and panel.winfo_exists():panel.message.set('코어배정 중입니다. 빈 번호를 선택하거나 분배를 종료하세요.');return
        if not self.selected:return
        if not messagebox.askyesno("삭제 확인",f"선택한 항목 {len(self.selected)}개를 삭제할까요?",parent=self):return
        with self.store.action("선택 항목 삭제"):
            for key in list(self.selected):
                if self.store.node(key):
                    cable_ids=[r["id"] for r in self.store.node_cables(key)]
                    for cid in cable_ids:self.store.conn.execute("DELETE FROM splices WHERE cable1_id=? OR cable2_id=?",(cid,cid))
                    self.store.conn.execute("DELETE FROM nodes WHERE id=?",(key,))
                elif self.store.cable(key):
                    self.store.conn.execute("DELETE FROM splices WHERE cable1_id=? OR cable2_id=?",(key,key));self.store.conn.execute("DELETE FROM cables WHERE id=?",(key,))
        self.selected.clear();self.refresh()

    def change_history(self,redo=False,editor=None):
        try:
            if self.pending_drag:raise ValueError('시설 이동을 마친 뒤 실행취소하세요.')
            result=(self.store.redo if redo else self.store.undo)()
            self.selected.clear();self.refresh();self.status.set(result)
            if editor and editor.winfo_exists():
                if self.store.cable(editor.cable_key):editor.reload();editor.info.set(result)
                else:editor.destroy()
        except (ValueError,sqlite3.Error) as error:messagebox.showwarning('다시실행' if redo else '실행취소',str(error),parent=editor or self)
        return 'break'

    def undo(self):return self.change_history()
    def redo(self):return self.change_history(redo=True)
    def open_history(self):return HistoryDialog(self)

    def pan_start(self,e):
        self.cancel_left_pan()
        kind,key=self.target(e);self.right_press=(e.x,e.y,kind,key);self.right_dragged=False;self.canvas.scan_mark(e.x,e.y)

    def pan_move(self,e):
        if not self.right_press:return
        if not self.right_dragged and math.hypot(e.x-self.right_press[0],e.y-self.right_press[1])>=5:self.right_dragged=True
        if self.right_dragged:self.canvas.scan_dragto(e.x,e.y,gain=1);self.refresh_minimap_viewport()

    def pan_end(self,e):
        pressed=self.right_press;moved=self.right_dragged;self.right_press=None;self.right_dragged=False
        if moved:self.refresh_minimap_viewport();return
        if not pressed:return
        _,_,kind,key=pressed
        if kind not in ("node","cable") or not key:return
        if key not in self.selected:self.selected={key}
        self.refresh();self.show_status_menu(kind,key,e)

    def show_status_menu(self,kind,key,event):
        row=self.store.node(key) if kind=="node" else self.store.cable(key)
        if not row:return
        targets=[x for x in self.selected if (self.store.node(x) if kind=="node" else self.store.cable(x))]
        if not targets:targets=[key]
        title=((NODE_LABELS.get(row["type"],"시설")+" · "+row["name"]) if kind=="node" else ("케이블 · "+(clean_cable_id(row["cable_id"]) or (row["spec"] or f'{row["size"]}C'))))+(f" 외 {len(targets)-1}개" if len(targets)>1 else "")
        menu=tk.Menu(self,tearoff=False);menu.add_command(label=title,state="disabled");menu.add_separator()
        if kind=='node' and row['type'] in ('hamche','rn') and self.scenario_kind()=='before':
            workflow.add_survey_status_menu(menu,self,key)
        if kind=='node' and row['type']=='hamche':
            store=self.store;generation=getattr(store,'_view_generation',0);locked=workflow.node_locked(store,key)
            label=('이 함체' if len(targets)>1 else '함체')+(' 잠금 해제' if locked else ' 잠금')
            menu.add_command(label=label,foreground='#047857' if locked else '#be123c',
                             command=lambda:self.apply_context_lock(key,not locked,store,generation))
            menu.add_separator()
        sub_rows=[]
        if kind=="node":
            for item in targets:
                candidate=self.store.node(item)
                if candidate and candidate["type"]=="sub":sub_rows.append(candidate)
        if sub_rows:
            current={"blue":"파란색","red":"빨간색","green":"초록색","pink":"분홍색"}.get(str(sub_rows[0]["color"] or "").lower(),str(sub_rows[0]["color"] or "파란색"))
            for color in ("파란색","빨간색","초록색","분홍색"):
                menu.add_command(label=("✓ " if color==current else "   ")+color,command=lambda value=color:self.apply_context_color(targets,value))
        else:
            current=str(row["status"] or "기설");values=STATUS_VALUES if kind=="cable" else STATUS_VALUES[:3]
            for status in values:
                menu.add_command(label=("✓ " if status==current else "   ")+status,command=lambda value=status:self.apply_context_status(kind,targets,value))
        if kind=="node" and row['type'] in ('hamche','rn') and workflow.same_id_join_mode(self.store):
            # V176: join free ends that carry the same real core ID here (V180: also 임시코어 pieces, after drawings too).
            joins=workflow.field_same_id_pairs(self.store,node_ids={key},respect_exclusions=False)
            if joins:menu.add_separator();menu.add_command(label=f"같은 코어ID 끝 이어 연결 ({len(joins)}개)…",command=lambda:self.join_same_id_ends(key))
        if kind=="node":menu.add_separator();menu.add_command(label="이름/속성 수정…",command=lambda:open_detail_dialog(self,self.store,'properties',key))
        else:
            menu.add_separator();marks=tk.Menu(menu,tearoff=False);current_mark=cable_check_mark(row)
            for value,(name,color) in (('',('표시 없음','')),*CABLE_CHECK_MARKS.items()):
                marks.add_command(label=("✓ " if value==current_mark else "   ")+name,foreground=color or None,command=lambda value=value:self.apply_context_check_mark(targets,value))
            menu.add_cascade(label="확인 표시 (테두리색)",menu=marks);self._check_mark_menu=marks
            # V206: 작업차수 for the whole cable (every core inside follows it).
            phases=tk.Menu(menu,tearoff=False);current_phase=workflow.cable_phase_name(self.store,key)
            for name in ['']+workflow.work_phase_names(self.store):
                phases.add_command(label=("✓ " if name==current_phase else "   ")+(name or '차수 없음'),command=lambda value=name:self.apply_context_phase(targets,value))
            phases.add_separator();phases.add_command(label="작업차수 관리 (추가·이름 변경)…",command=lambda:workflow.PhaseDialog(self))
            menu.add_cascade(label="작업차수 (케이블 전체 코어)",menu=phases);self._phase_menu=phases
            if len(targets)==1:
                ends=tk.Menu(menu,tearoff=False)
                for nid in dict.fromkeys((row["n1id"],row["n2id"])):
                    end=self.store.node(nid)
                    if end:ends.add_command(label=f'{end["name"]} 쪽 끝 → 다른 시설로…',command=lambda nid=nid:self.start_cable_end_move(key,nid))
                menu.add_separator();menu.add_cascade(label="케이블 끝 옮기기 (코어내역 유지)",menu=ends);self._cable_end_menu=ends
            menu.add_separator();menu.add_command(label="이 케이블의 코어 경로 추적…",command=lambda:CableTraceDialog(self,self.store))
            if len(targets)==2:menu.add_command(label="두 케이블 겹치는 코어 보기…",command=lambda pair=tuple(targets):self.open_common_cores(pair))
        try:menu.tk_popup(event.x_root,event.y_root)
        finally:menu.grab_release()

    def selected_cable_pair(self):
        cables=[x for x in self.selected if not str(x).startswith('PORT:') and self.store.cable(x)]
        if len(cables)!=2:return None
        active=self.__dict__.get('_active_cable')
        return tuple(sorted(cables,key=lambda c:c==active))

    def open_common_cores(self,pair=None):
        """V203: show (or refresh) the window of cores shared by two selected cables."""
        pair=pair or self.selected_cable_pair()
        if not pair:return None
        dialog=self.__dict__.get('_common_cores_dialog')
        try:alive=dialog is not None and dialog.winfo_exists()
        except tk.TclError:alive=False
        if alive:dialog.store=self.store;dialog.show(*pair);dialog.lift()
        else:dialog=self._common_cores_dialog=CommonCoresDialog(self,self.store,*pair)
        self.status.set('두 케이블 '+dialog.model['summary'])
        return dialog

    def join_same_id_ends(self,node_id):
        """V176: confirm, then splice each same-ID free-end pair at this facility (one undo)."""
        store=self.store;node=store.node(node_id)
        joins=workflow.field_same_id_pairs(store,node_ids={node_id},respect_exclusions=False)
        if not node or not joins:self.status.set('이을 같은 코어ID 끝이 없습니다.');return
        lines=[f"{display_core_id(store.core(*a)['core_id'])} · {store._slot_title(*a)} ↔ {store._slot_title(*b)}" for _,a,b in joins]
        if not messagebox.askyesno('같은 코어ID 끝 이어 연결',f"{node['name']}에서 같은 코어ID 끝을 이어 연결할까요?\n\n"+'\n'.join(lines[:12])+(f"\n외 {len(lines)-12}개" if len(lines)>12 else '')+"\n\n코어명·신호·상태는 번호별로 그대로 둡니다.",parent=self):return
        try:
            with store.action('같은 코어ID 끝 이어 연결'):workflow.field_same_id_join_apply(store,joins)
        except ValueError as exc:messagebox.showerror('연결하지 않음',str(exc),parent=self);return
        self.refresh();self.status.set(f"{node['name']} · 같은 코어ID {len(joins)}개 이어 연결 완료 · Ctrl+Z로 되돌리기")

    def start_cable_end_move(self,cable_id,node_id):
        cable=self.store.cable(cable_id);node=self.store.node(node_id)
        if not cable or not node:return
        self.set_mode('select')
        if self.mode!='select':return
        self.selected={cable_id};self.refresh()
        self.cable_end_move=(cable_id,node_id,self.store,getattr(self.store,'_view_generation',0))
        self.status.set(f'{node["name"]} 쪽 끝을 새로 붙일 시설을 클릭하세요 · 코어ID·코어내역·신호 유지 · Esc 취소')

    def finish_cable_end_move(self,move,new_node_id):
        cable_id,old_node_id,store,generation=move
        if self.store is not store or getattr(store,'_view_generation',0)!=generation:
            messagebox.showwarning('케이블 끝 옮기기','도면이 바뀌었습니다. 케이블을 다시 우클릭하세요.',parent=self);return
        try:preview=store.cable_end_move_preview(cable_id,old_node_id,new_node_id)
        except ValueError as error:messagebox.showinfo('케이블 끝 옮기기',str(error),parent=self);self.status.set('케이블 끝 옮기기 취소');return
        cable=store.cable(cable_id);old=store.node(old_node_id);new=store.node(new_node_id);other=store.node(preview['other'])
        name=clean_cable_id(cable['cable_id']) or cable['spec'] or f"{cable['size']}C"
        text=(f'케이블 {name}\n{other["name"] if other else "-"} ↔ {old["name"]}  →  {other["name"] if other else "-"} ↔ {new["name"]}\n\n'
              f'코어 {cable["size"]}개의 코어ID·코어내역·신호·상태는 그대로 유지합니다 (내역 있는 코어 {preview["cores"]}개).\n'
              +(f'{old["name"]} 안의 이 케이블 접속 {preview["splices"]}건은 끊어집니다.\n' if preview['splices'] else '')
              +f'{new["name"]}에서는 새로 접속하세요.\n\n잘못 옮기면 「실행취소」로 되돌릴 수 있습니다. 옮길까요?')
        if not messagebox.askyesno('케이블 끝 옮기기',text,parent=self):self.status.set('케이블 끝 옮기기 취소');return
        try:store.move_cable_end(cable_id,old_node_id,new_node_id)
        except (ValueError,sqlite3.Error) as error:messagebox.showwarning('케이블 끝 옮기기',str(error),parent=self);return
        self.selected={cable_id};self.refresh()
        self.status.set(f'케이블 {name} 끝을 {old["name"]} → {new["name"]}로 옮겼습니다 · 코어내역 유지'+(f' · 접속 {preview["splices"]}건 해제' if preview['splices'] else '')+' · 실행취소 가능')

    def refresh_all_lock_button(self):
        if 'all_lock_button' not in self.__dict__:return
        all_locked=self.store.all_enclosures_locked()
        if hasattr(self,'desktop_lock_images'):self.all_lock_button.configure(image=self.desktop_lock_images[all_locked])
        self.all_lock_button.configure(text='🔒' if all_locked else '🔓',bg='#facc15' if all_locked else '#e2e8f0',state='disabled' if workflow.locked(self.store) or not any(n['type']=='hamche' for n in self.store.nodes()) else 'normal')

    def toggle_all_locks(self):
        try:
            locked=not self.store.all_enclosures_locked()
            count=self.store.set_all_enclosures_locked(locked)
            self.pending_drag=None;self.drag_anchor=None;self.preview_positions={}
            self.refresh();self.status.set(f'전체 함체 잠금'+(' 완료' if locked else ' 해제 완료')+f' · {count}개 변경')
        except (ValueError,sqlite3.Error) as error:messagebox.showwarning('전체 함체 잠금',str(error),parent=self)

    def apply_context_lock(self,node_id,locked,store,generation):
        if self.store is not store or getattr(store,'_view_generation',0)!=generation:
            messagebox.showwarning('함체 잠금','도면이 변경되었습니다. 함체를 다시 우클릭하세요.',parent=self);return
        try:store.set_node_locked(node_id,locked)
        except (ValueError,sqlite3.Error) as error:
            messagebox.showwarning('함체 잠금',str(error),parent=self);return
        self.refresh()
        for window in tuple(self.__dict__.get('_detail_windows',{}).values()):
            if isinstance(window,NodeDialog) and window.store is store and window.node_id==node_id and window.winfo_exists():window.refresh_lock_state()
        node=store.node(node_id)
        self.status.set(f'{node["name"]} · 함체 잠금'+(' 완료' if locked else ' 해제 완료'))

    def apply_context_status(self,kind,keys,status):
        count=self.store.set_nodes_status(keys,status) if kind=="node" else self.store.set_cables_status(keys,status)
        self.refresh();self.status.set(("시설" if kind=="node" else "케이블")+f" {count}개 상태를 {status}로 변경했습니다.")

    def apply_context_check_mark(self,keys,mark):
        try:count=self.store.set_cables_check_mark(keys,mark)
        except Exception as exc:messagebox.showerror("확인 표시",str(exc),parent=self);return
        name=CABLE_CHECK_MARKS[mark][0]+' 테두리' if mark else '표시 없음'
        self.refresh();self.status.set(f"케이블 {count}개 확인 표시를 {name}(으)로 바꿨습니다."+("" if not mark or self.display_options.get('cable_check_mark',True) else " (보기설정에서 표시가 꺼져 있습니다)"))

    def apply_context_phase(self,keys,name):
        try:count=workflow.set_cable_phase(self.store,keys,name)
        except Exception as exc:messagebox.showerror("작업차수",str(exc),parent=self);return
        self._work_report_key=None;self.refresh()
        self.status.set(f"케이블 {count}개를 {name or '차수 없음'}(으)로 지정했습니다. 안의 코어도 같은 차수로 표시됩니다." if name else f"케이블 {count}개의 작업차수를 지웠습니다.")

    def apply_context_color(self,keys,color):
        count=self.store.set_subscriber_colors(keys,color);self.refresh();self.status.set(f"가입자 {count}개 색상을 {color}으로 변경했습니다.")
    def zoom(self,e):
        old=self.view_scale;new=max(0.25,min(2.5,old*(1.12 if e.delta>0 else 0.89)))
        wx=self.canvas.canvasx(e.x)/old;wy=self.canvas.canvasy(e.y)/old;self.view_scale=new;self.refresh();self.update_idletasks()
        self.canvas.xview_moveto(max(0,(wx*new-e.x))/(self.world_w*new));self.canvas.yview_moveto(max(0,(wy*new-e.y))/(self.world_h*new))

    def fit_view(self):
        nodes=self.store.nodes()
        if not nodes:return
        minx=min(n["x"] for n in nodes)-100;maxx=max(n["x"] for n in nodes)+100;miny=min(n["y"] for n in nodes)-200;maxy=max(n["y"] for n in nodes)+100
        self.update_idletasks()
        available_width=self.canvas.winfo_width()
        if self.dashboard_frame.winfo_ismapped():available_width=max(300,available_width-self.dashboard_frame.winfo_width()-48)
        self.view_scale=max(0.25,min(2.0,min(available_width/max(1,maxx-minx),(self.canvas.winfo_height()-24)/max(1,maxy-miny))))
        self.refresh();self.update_idletasks();self.canvas.xview_moveto(max(0,minx*self.view_scale)/(self.world_w*self.view_scale));self.canvas.yview_moveto(max(0,miny*self.view_scale)/(self.world_h*self.view_scale))

    def trace_ids(self,core_ids):
        if not core_ids:return
        dialog=TraceDialog(self,self.store);dialog.q.set(','.join(core_ids));dialog.run()

    def open_find(self,event=None):
        parent=self
        if event is not None:
            try:parent=event.widget.winfo_toplevel()
            except (AttributeError,tk.TclError):pass
        if isinstance(parent,CableDialog) and parent.cable_key:return workflow.open_cable_find(parent)
        dialog=getattr(self,'find_dialog',None)
        if dialog is not None and dialog.winfo_exists():
            if dialog.current():dialog.focus_query();return 'break'
            dialog.destroy()
        parent=self.grab_current() or parent
        self.find_dialog=workflow.DrawingFindDialog(self,parent)
        return 'break'

    def search_cores(self):
        q=simpledialog.askstring("전체 코어 검색","코어ID 또는 코어내역 일부를 입력하세요.",parent=self)
        if q is None:return
        rows=self.store.conn.execute("""SELECT c.cable_id internal_id,c.core_index,c.core_id,c.detail,b.cable_id,b.size,b.spec,n1.name a,n2.name b
          FROM cores c JOIN cables b ON b.id=c.cable_id JOIN nodes n1 ON n1.id=b.n1id JOIN nodes n2 ON n2.id=b.n2id
          WHERE c.core_id LIKE ? OR c.detail LIKE ? ORDER BY n1.name,n2.name,c.core_index LIMIT 1000""",(f"%{q}%",f"%{q}%")).fetchall()
        w=workflow.RememberedToplevel(self,position_family='CoreSearchResults');w.title("전체 코어 검색 결과");w.geometry("900x600")
        t=workflow.SortableTreeview(w,columns=("section","cable","num","id","detail"),show="headings")
        for c,l,width in zip(("section","cable","num","id","detail"),("구간","케이블","번호","코어ID","코어내역"),(220,120,60,180,280)):t.heading(c,text=l);t.column(c,width=width)
        location_map={}
        for i,r in enumerate(rows):
            iid=str(i);location_map[iid]=r["internal_id"];t.insert("","end",iid=iid,values=(f'{r["a"]} ↔ {r["b"]}',(r["spec"] or f'{r["size"]}C')+(f'({r["cable_id"]})' if r["cable_id"] else ''),r["core_index"],r["core_id"],r["detail"]))
        def highlight(e=None):
            if t.selection():self.start_highlight_blink({location_map[t.selection()[0]]});self.status.set("코어 위치 케이블을 계속 깜빡이게 표시했습니다.")
        t.bind("<Double-Button-1>",highlight)
        t.pack(fill="both",expand=True)

    def clear_highlight(self):
        self.stop_highlight_blink(clear=True);self.status.set("코어·케이블 추적 강조를 해제했습니다.")

    def stop_highlight_blink(self,clear=False):
        self.highlight_owner=None
        if self.highlight_blink_job is not None:
            try:self.after_cancel(self.highlight_blink_job)
            except tk.TclError:pass
            self.highlight_blink_job=None
        self.highlight_blink_on=True
        if clear:
            self._cable_overview=None
            self.highlight_cables.clear();self.highlight_cable_colors.clear();self.highlight_core_labels={}
            self.highlight_connection_model={};self._highlight_seeds=();self._highlight_stamp=None
        self.apply_highlight_visuals();self.render_highlight_core_labels()

    def connection_highlight_stamp(self):
        return (id(self.store),getattr(self.store,'_view_generation',0),self.store.data_revision(),self.store.conn.total_changes)

    def show_cable_overview(self,cable_id):
        """V199: blink every core route of one cable; ends show how many cores arrive."""
        if not self.store.cable(cable_id):return
        if self.__dict__.get('_cable_overview')==cable_id and self.__dict__.get('highlight_owner')=='cable_overview':return
        if self.highlight_blink_job is not None:
            try:self.after_cancel(self.highlight_blink_job)
            except tk.TclError:pass
            self.highlight_blink_job=None
        self.highlight_owner='cable_overview';self._highlight_seeds=();self._highlight_stamp=None
        self.highlight_core_labels={};self.highlight_connection_model={}
        self._cable_overview=cable_id;self.refresh_connection_highlight(force=True)
        if not self.highlight_cables:
            self._cable_overview=None;self.highlight_owner=None;return
        self.highlight_blink_on=True;self.apply_highlight_visuals();self.render_highlight_core_labels()
        self.schedule_highlight_tick()

    def clear_cable_overview(self):
        if self.__dict__.get('_cable_overview') and self.__dict__.get('highlight_owner')=='cable_overview':
            self.stop_highlight_blink(clear=True)

    def schedule_highlight_tick(self):
        def tick():
            self.highlight_blink_job=None
            if not self.highlight_cables:return
            self.highlight_blink_on=not self.highlight_blink_on;self.apply_highlight_visuals();self.highlight_blink_job=self.after(330,tick)
        self.highlight_blink_job=self.after(330,tick)

    def refresh_connection_highlight(self,force=False):
        overview=self.__dict__.get('_cable_overview')
        if overview:
            stamp=self.connection_highlight_stamp();previous=self.__dict__.get('_highlight_stamp')
            if (previous and previous[:2]!=stamp[:2]) or not self.store.cable(overview):
                self.stop_highlight_blink(clear=True);return
            if not force and previous==stamp:return
            model=workflow.cable_route_overview(self.store,overview)
            self._highlight_stamp=stamp
            if not model['seed_count']:
                self.highlight_connection_model={};self.highlight_cable_colors={};self.highlight_cables=set()
                self.status.set(model['summary']);return
            self.highlight_connection_model=dict(cable_overview=model,summary=model['summary'])
            self.highlight_cable_colors=dict(model['colors']);self.highlight_core_labels={}
            self.highlight_cables=set(model['colors']);self.status.set(model['summary'])
            return
        if not self.__dict__.get('_highlight_seeds'):return
        stamp=self.connection_highlight_stamp();previous=self.__dict__.get('_highlight_stamp')
        if previous and previous[:2]!=stamp[:2]:
            self.stop_highlight_blink(clear=True);return
        if not force and previous==stamp:return
        model=workflow.core_connection_highlight(self.store,self._highlight_seeds)
        self.highlight_connection_model=model;self._highlight_stamp=stamp
        self.highlight_cable_colors=dict(model['colors']);self.highlight_core_labels=dict(model['labels'])
        self.highlight_cables=set(model['colors'])
        self.status.set(model['summary']+' · 미접속 함체 안내를 더블클릭해 연결을 확인하세요.')

    def render_highlight_core_labels(self):
        for tag in ('core_path_number','core_path_segment','core_path_glow','core_join_hint','core_path_port','core_path_junction'):self.canvas.delete(tag)
        for item in self.__dict__.get('_highlight_label_items',()):self.item_to_cable.pop(item,None)
        for item in self.__dict__.get('_highlight_hint_items',()):self.item_to_node.pop(item,None)
        self._highlight_label_items=[];self._highlight_hint_items=[];self._highlight_glow_items={}
        model=self.__dict__.get('highlight_connection_model',{});occupied={}
        render_route_legend(self,model)
        if not self.__dict__.get('highlight_core_labels') and not model.get('boundaries') and not model.get('port_labels') and not model.get('junctions') and not model.get('cable_overview'):return
        def cells(box):
            a,b,c,d=box
            return [(x,y) for x in range(int(a//240),int(c//240)+1) for y in range(int(b//180),int(d//180)+1)]
        def reserve(box):
            for cell in cells(box):occupied.setdefault(cell,[]).append(box)
        def overlaps(box):
            a,b,c,d=box
            return any(a<q[2]+8 and c>q[0]-8 and b<q[3]+8 and d>q[1]-8 for cell in cells(box) for q in occupied.get(cell,()))
        for entry in self.__dict__.get('current_label_layout',()):
            if entry.get('bounds'):reserve(entry['bounds'])
        nodes={r['id']:dict(r) for r in self.store.nodes()}
        for nid,node in nodes.items():
            nx,ny=self.preview_positions.get(nid,(node['x'],node['y']));nx*=self.view_scale;ny*=self.view_scale
            reserve((nx-42,ny-40,nx+42,ny+65))
        def label_at(x,y,label,color,tags,mapping,key,items,fill='#ffffff',text_color='#172033'):
            text=self.canvas.create_text(0,0,text=label,font=('Malgun Gothic',10,'bold'),fill=text_color,anchor='nw',width=245,tags=tags)
            a,b,c,d=self.canvas.bbox(text);w=c-a+10;h=d-b+8
            candidates=[]
            for ring in range(12):
                offset=20+ring*max(70,h+12)
                candidates.extend(((x-w/2,y-offset-h),(x-w/2,y+offset),(x+offset,y-h/2),(x-offset-w,y-h/2)))
            for px,py in candidates:
                px=max(8,px);py=max(8,py);bounds=(px,py,px+w,py+h)
                if not overlaps(bounds):break
            reserve(bounds);self.canvas.coords(text,px+5,py+4)
            box=self.canvas.create_rectangle(*bounds,fill=fill,outline=color,width=2,tags=tags)
            lx=max(px,min(x,px+w));ly=max(py,min(y,py+h))
            leader=self.canvas.create_line(x,y,lx,ly,fill=color,width=1,dash=(3,3),tags=tags)
            self.canvas.tag_lower(leader,box);self.canvas.tag_raise(text)
            for item in (text,box,leader):mapping[item]=key;items.append(item)
        signal_fills=workflow.route_cable_signal_fills(model)
        for cable_id,label in self.__dict__.get('highlight_core_labels',{}).items():
            if cable_id not in self.highlight_cables or cable_id not in self.cable_line_items:continue
            points=self.canvas.coords(self.cable_line_items[cable_id])
            if len(points)<4:continue
            x,y=cable_path_point(cable_path_points(points),.64)
            color=model.get('label_colors',{}).get(cable_id,self.highlight_cable_colors.get(cable_id,CORE_PATH_COLORS['left']))
            # Keep the saved cable geometry: one highlight stroke and a blinking
            # halo below it. Parallel permanent strokes obscured the original path.
            glow=self.canvas.create_line(*points,smooth=len(points)==6,splinesteps=18,fill='#fde6f4' if cable_id in model.get('overlaps',()) else '#fff0bf',width=15,state='normal' if self.highlight_blink_on else 'hidden',tags=('core_path_glow','cable',cable_id))
            self.canvas.tag_lower(glow,self.cable_line_items[cable_id])
            self.item_to_cable[glow]=cable_id;self._highlight_label_items.append(glow);self._highlight_glow_items[cable_id]=glow
            # Segment/ID details live in the route legend; the cable shows only its core numbers.
            label=model.get('short_labels',{}).get(cable_id) or label
            # V166: on a 섞임 path the label box is green (ON) / gray (OFF) / yellow (미입력).
            label_at(x,y,label,color,('core_path_number','cable',cable_id),self.item_to_cable,cable_id,self._highlight_label_items,fill=signal_fills.get(cable_id,'#ffffff'))
        # RN internal port where the traced core is assigned (IN, SP5 ...), drawn at the RN.
        for nid,info in model.get('port_labels',{}).items():
            node=nodes.get(nid)
            if not node:continue
            x,y=self.preview_positions.get(nid,(node['x'],node['y']));x*=self.view_scale;y*=self.view_scale
            tags=('core_path_port','node',nid)
            ring=self.canvas.create_oval(x-19,y-19,x+19,y+19,outline=info['color'],width=4,tags=tags)
            self.item_to_node[ring]=nid;self._highlight_hint_items.append(ring)
            label_at(x,y,info['text'],info['color'],tags,self.item_to_node,nid,self._highlight_hint_items,fill='#f3f8ff')
        # Shared cable (11·19번): at each end enclosure say which core continues where.
        for info in model.get('junctions',()):
            nid=info['node_id'];node=nodes.get(nid)
            if not node:continue
            x,y=self.preview_positions.get(nid,(node['x'],node['y']));x*=self.view_scale;y*=self.view_scale
            label_at(x,y,info['text'],info['color'],('core_path_junction','node',nid),self.item_to_node,nid,self._highlight_hint_items,fill='#fff0fa',text_color='#7a0058')
        # V199 cable click: only the number of cores that arrive at each end.
        for info in (model.get('cable_overview') or {}).get('ends',()):
            nid=info['node_id'];node=nodes.get(nid)
            if not node:continue
            x,y=self.preview_positions.get(nid,(node['x'],node['y']));x*=self.view_scale;y*=self.view_scale
            tags=('core_path_port','node',nid,'cable_overview_end')
            ring=self.canvas.create_oval(x-19,y-19,x+19,y+19,outline=info['color'],width=4,tags=tags)
            self.item_to_node[ring]=nid;self._highlight_hint_items.append(ring)
            label_at(x,y,info['text']+'\n(클릭: 코어 목록)',info['color'],tags,self.item_to_node,nid,self._highlight_hint_items,fill=info['fill'])
        for hint in model.get('boundaries',()):
            nid=hint['node_id'];node=nodes.get(nid)
            if not node:continue
            x,y=self.preview_positions.get(nid,(node['x'],node['y']));x*=self.view_scale;y*=self.view_scale
            tags=('core_join_hint','node',nid)
            ring=self.canvas.create_oval(x-21,y-21,x+21,y+21,outline=hint['color'],width=3,tags=tags)
            self.item_to_node[ring]=nid;self._highlight_hint_items.append(ring)
            label_at(x,y,hint['text'],hint['color'],tags,self.item_to_node,nid,self._highlight_hint_items,fill='#fffbea')
        bounds=self.canvas.bbox('all')
        if bounds:
            current=tuple(map(float,self.canvas.cget('scrollregion').split()))
            if len(current)==4:self.canvas.configure(scrollregion=(min(current[0],bounds[0]),min(current[1],bounds[1]),max(current[2],bounds[2]+20),max(current[3],bounds[3]+20)))

    def apply_highlight_visuals(self):
        """Blink the whole saved route between its highlight and base appearance."""
        blink_route_legend(self)
        for cable_id,item in list(self.cable_line_items.items()):
            base_color,base_width=self.cable_base_styles.get(cable_id,("#1769aa",4))
            active=cable_id in self.highlight_cables and self.highlight_blink_on
            color=self.highlight_cable_colors.get(cable_id,"#ff7a00") if active else base_color
            width=max(9,base_width+3) if active else base_width
            try:
                if cable_id in self.__dict__.get('new_cable_ids',()):self.canvas.itemconfigure(item,fill=color,width=width,dash=new_cable_dash(width))
                else:self.canvas.itemconfigure(item,fill=color,width=width)
                glow=self.__dict__.get('_highlight_glow_items',{}).get(cable_id)
                if glow:self.canvas.itemconfigure(glow,state='normal' if active else 'hidden')
            except tk.TclError:pass

    def start_highlight_blink(self,cable_ids,flashes=None,owner=None,core_labels=None,core_rows=None,core_slots=None):
        self.highlight_owner=owner;self._cable_overview=None
        if self.highlight_blink_job is not None:
            try:self.after_cancel(self.highlight_blink_job)
            except tk.TclError:pass
        if isinstance(cable_ids,dict):self.highlight_cable_colors={str(key):str(value) for key,value in cable_ids.items()}
        else:self.highlight_cable_colors={str(key):"#ff7a00" for key in cable_ids}
        self.highlight_core_labels=dict(core_labels or {});self.highlight_connection_model={};self._highlight_stamp=None
        self._highlight_seeds=tuple(core_slots if core_slots is not None else [(r['cable_id'],int(r['core_index'])) for r in (core_rows or ())])
        self.highlight_cables=set(self.highlight_cable_colors);self.refresh_connection_highlight(force=True)
        self.highlight_blink_on=True;self.apply_highlight_visuals();self.render_highlight_core_labels()
        self.schedule_highlight_tick()

    def check_data(self):
        checks=self.store.integrity_report();text="\n".join(("정상" if ok else "확인필요")+f" - {name}: {detail}" for name,ok,detail in checks)
        if all(x[1] for x in checks):messagebox.showinfo("데이터 점검",text,parent=self)
        elif messagebox.askyesno("데이터 점검",text+"\n\n잘못된 연결정보를 자동정리할까요? 먼저 자동백업합니다.",parent=self):
            self.manual_backup(silent=True);removed=self.store.repair_links();messagebox.showinfo("자동정리",f"연결정보 {removed}건을 정리했습니다.\n조사자료 원본은 삭제하지 않았습니다.",parent=self);self.refresh()

    def open_before_drawing_check(self):
        if self.scenario_kind()!="before":
            messagebox.showinfo("전 도면 완성도 점검","이 기능은 전 도면을 기준으로 검사합니다.\n위의 '2 전도면작성(현장반영)'을 눌러 현장반영 도면으로 이동한 뒤 실행하세요.",parent=self);return
        BeforeDrawingCheckDialog(self,self.store)

    def manual_backup(self,silent=False):
        path=app_dir()/"backup"/f'{self.store.path.stem}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.sqlite3';self.store.backup_to(path)
        if not silent:messagebox.showinfo("백업 완료",f"backup 폴더에 저장했습니다.\n{path.name}",parent=self)
        return path

    def restore_backup(self):
        path=filedialog.askopenfilename(initialdir=str(app_dir()/"backup"),filetypes=[("SQLite 백업","*.sqlite3"),("모든 파일","*.*")])
        if not path:return
        test=sqlite3.connect(path)
        try:result=test.execute("PRAGMA integrity_check").fetchone()[0]
        except Exception as e:messagebox.showerror("복구 실패",str(e),parent=self);test.close();return
        test.close()
        if result!="ok":messagebox.showerror("복구 실패",f"백업파일 점검 결과: {result}",parent=self);return
        if messagebox.askyesno("백업 복구","현재 작업을 따로 백업한 뒤 선택한 파일로 복구할까요?",parent=self):self.manual_backup(silent=True);self.replace_current_from(path);messagebox.showinfo("복구 완료","백업파일을 불러왔습니다.",parent=self)

    def open_properties(self):
        if len(self.selected)!=1:messagebox.showinfo("선택 속성","시설이나 케이블 하나를 먼저 선택하세요.",parent=self);return
        key=next(iter(self.selected))
        if self.store.node(key):open_detail_dialog(self,self.store,'properties',key)
        elif self.store.cable(key):open_detail_dialog(self,self.store,'cable',key)

    def auto_connect(self):
        result=workflow.run_bulk(self,self.store,'auto_connect_same_ids',())
        if result is None:return
        count,errors=result;self.refresh()
        text=f"자동접속 {count}건 완료"
        if errors:text+="\n\n연결하지 않은 항목:\n"+"\n".join(errors[:100])
        messagebox.showwarning("같은 코어ID 자동접속",text,parent=self) if errors else messagebox.showinfo("같은 코어ID 자동접속",text,parent=self)

    def switch_project(self,path):
        if getattr(self,"cloud",None) and not self.cloud.switching:return self.cloud.import_external(path)
        panel=getattr(self,'_map_allocation_panel',None)
        if panel is not None:panel.destroy(restore_editor=False)
        self._work_report_key=None
        if self.highlight_blink_job is not None:self.after_cancel(self.highlight_blink_job);self.highlight_blink_job=None
        self.store.conn.commit();self.store.backup_to(app_dir()/"backup"/f'{self.store.path.stem}_latest.sqlite3');self.store.close();self.store=Store(path);self.initialize_scenario();self.scenario_saved_revision=self.store.data_revision();(app_dir()/"data"/"current_project.txt").write_text(str(Path(path).resolve()),encoding="utf-8");self.selected.clear();self.highlight_cables.clear();self.highlight_cable_colors.clear();self.highlight_blink_on=True;self.preview_positions={};self.work_progress_cache_key=None;self.work_progress_cache_value=None;self.error_core_cache_key=None;self.error_core_cache_value=0;self.update_title();self.refresh();self.status.set(f"작업 열림: {Path(path).stem}")

    def replace_current_from(self,path):
        panel=getattr(self,'_map_allocation_panel',None)
        if panel is not None:panel.destroy(restore_editor=False)
        self._work_report_key=None
        if self.highlight_blink_job is not None:
            try:self.after_cancel(self.highlight_blink_job)
            except tk.TclError:pass
            self.highlight_blink_job=None
        self.store.conn.commit();source=sqlite3.connect(path)
        try:source.backup(self.store.conn)
        finally:source.close()
        self.store.create_schema();workflow.after_auto_activate(self.store);workflow.temporary_auto_activate(self.store);self.store._warning_cache=None;self.store._cable_warning_cache=None;self.store._trace_context_cache=None;self.store._trace_context_revision=None;self.scenario_saved_revision=self.store.data_revision();self.selected.clear();self.highlight_cables.clear();self.highlight_cable_colors.clear();self.work_progress_cache_key=None;self.work_progress_cache_value=None;self.error_core_cache_key=None;self.error_core_cache_value=0;self.update_title();self.refresh()

    def drawing_svg(self):
        nodes={n["id"]:n for n in self.store.nodes()};cables=self.store.cables()
        if nodes:
            minx=min(n["x"] for n in nodes.values())-100;miny=min(n["y"] for n in nodes.values())-100;maxx=max(n["x"] for n in nodes.values())+100;maxy=max(n["y"] for n in nodes.values())+100
        else:minx=miny=0;maxx=1200;maxy=800
        groups={};cable_warnings=self.store.cable_core_warning_summary()
        for c in cables:groups.setdefault(tuple(sorted((c["n1id"],c["n2id"]))),[]).append(c)
        hamche_layout=self.hamche_label_layout(nodes)
        label_layout=self.cable_label_layout(nodes,cables,cable_warnings,hamche_layout=hamche_layout)
        removal_obstacles=removal_mark_obstacles(label_layout+hamche_layout,nodes) if any(c['status']=='철거' for c in cables) else None
        for entry in label_layout+hamche_layout:
            x1,y1,x2,y2=entry["bounds"];minx=min(minx,x1-20);miny=min(miny,y1-20);maxx=max(maxx,x2+20);maxy=max(maxy,y2+20)
        parts=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{minx} {miny} {maxx-minx} {maxy-miny}" width="{maxx-minx}" height="{maxy-miny}">','<rect x="-10000" y="-10000" width="20000" height="20000" fill="white"/>']
        for pair,cs in groups.items():
            for i,c in enumerate(cs):
                a=nodes.get(pair[0]);b=nodes.get(pair[1])
                if not a or not b:continue
                path=parallel_cable_path(a["x"],a["y"],b["x"],b["y"],i,len(cs));d_path=cable_path_svg(path)
                color="#d32f2f" if c["size"]<=12 else ("#1769aa" if c["size"]<=36 else ("#19703a" if c["size"]<=72 else ("#e24a9b" if c["size"]<=144 else "#795548")))
                dash_pattern,marker=cable_status_style(c["status"]);dash=' stroke-dasharray="'+NEW_CABLE_SVG_DASH+'"' if dash_pattern else ''
                if self.display_options.get('cable_check_mark',True) and cable_check_mark(c):
                    parts.append(f'<path d="{d_path}" fill="none" stroke="{CABLE_CHECK_MARKS[cable_check_mark(c)][1]}" stroke-width="18" class="cable_check_mark"/>')
                if self.display_options.get('cable_missing_info',True) and cable_missing_fields(c):
                    parts.append(f'<path d="{d_path}" fill="none" stroke="#facc15" stroke-width="12" class="cable_missing_info"/>')
                parts.append(f'<path d="{d_path}" fill="none" stroke="{color}" stroke-width="4"{dash}/>')
                if c["status"]=="철거":
                    for qx,qy in removal_mark_path_points(path,removal_obstacles):
                        parts.append(f'<path d="M {qx-9} {qy-9} L {qx+9} {qy+9} M {qx-9} {qy+9} L {qx+9} {qy-9}" fill="none" stroke="#111111" stroke-width="3"/>')
                elif c["status"]=="절단":
                    for qx,qy in cable_path_even_points(path,150):
                        points=star_points(qx,qy,12,5.5);point_text=" ".join(f"{points[j]},{points[j+1]}" for j in range(0,len(points),2));parts.append(f'<polygon points="{point_text}" fill="#ff1744" stroke="#111111" stroke-width="2"/>')
        for entry in label_layout:
            ax,ay=entry["anchor"];first=entry["parts"][0]
            if math.hypot(first["x"]-ax,first["y"]-ay)>1:
                parts.append(f'<line x1="{ax}" y1="{ay}" x2="{first["x"]}" y2="{first["y"]}" stroke="#64748b" stroke-dasharray="3 3"/>')
            for part in entry["parts"]:
                x,y=part["x"],part["y"];w,h=part["width"],part["height"];size=abs(int(part["font"].cget("size")))
                parts.append(f'<rect x="{x-w/2}" y="{y-h/2}" width="{w}" height="{h}" fill="{part["fill"]}" stroke="{part["border"]}"/>')
                parts.append(f'<text x="{x}" y="{y}" dominant-baseline="central" text-anchor="middle" font-family="Malgun Gothic" font-size="{size}" font-weight="bold" fill="{part["ink"]}">{html.escape(part["text"])}</text>')
        warnings=self.store.node_warning_summary()
        for n in nodes.values():
            v=node_visual(n);x,y=n["x"],n["y"];warning=visible_node_warning(warnings.get(n["id"]),self.display_options)
            if warning:
                wc="#ff1744" if warning.get('count') or warning.get('rn_in') or warning.get('duplicate_count') else '#1565c0'
                if v["shape"]=="wide":parts.append(f'<rect x="{x-67}" y="{y-39}" width="134" height="78" fill="none" stroke="{wc}" stroke-width="5"/>')
                else:parts.append(f'<circle cx="{x}" cy="{y}" r="39" fill="none" stroke="{wc}" stroke-width="5"/>')
            if n['type']=='sub':parts.extend(subscriber_svg(x,y,v))
            elif v["shape"]=="wide":parts.append(f'<rect x="{x-60}" y="{y-32}" width="120" height="64" fill="{v["fill"]}" stroke="{v["outline"]}" stroke-width="3"/>')
            else:parts.append(f'<circle cx="{x}" cy="{y}" r="32" fill="{v["fill"]}" stroke="{v["outline"]}" stroke-width="3"/>')
            if v["shape"]=="circle_x":
                parts.append(f'<path d="M {x-22} {y-22} L {x+22} {y+22} M {x-22} {y+22} L {x+22} {y-22}" fill="none" stroke="{v["outline"]}" stroke-width="4"/>')
            if v.get('symbol_font'):parts.append(f'<text x="{x}" y="{y}" dominant-baseline="central" text-anchor="middle" font-family="Arial" font-size="{v["symbol_font"]}" font-weight="bold" fill="{v["text_fill"]}">{html.escape(v["text"])}</text>')
            elif v["text"]:parts.append(f'<text x="{x}" y="{y+5}" text-anchor="middle" font-family="Malgun Gothic" font-size="{12 if v["shape"]=="wide" else 18}" font-weight="bold" fill="{v["text_fill"]}">{html.escape(v["text"])}</text>')

            if v["label_above"]:
                name=str(n["name"] or "");lw=max(56,min(180,len(name)*13+14));name_ink,name_fill=node_name_colors(n)
                parts.append(f'<rect x="{x-lw/2}" y="{y-59}" width="{lw}" height="22" rx="5" fill="{name_fill}" stroke="{status_color(n["status"])}" stroke-width="2"/>');parts.append(f'<text x="{x}" y="{y-44}" text-anchor="middle" font-family="Malgun Gothic" font-size="11" font-weight="bold" fill="{name_ink}">{html.escape(name)}</text>')
            badges=node_display_badges(self.store,n,warnings.get(n['id'],{}),self.display_options)
            if badges:
                for badge_index,(badge,bc,fg) in enumerate(badges):
                    by=y+48+24*badge_index;bw=max(70,len(badge)*11)
                    parts.append(f'<rect x="{x-bw/2}" y="{by-10}" width="{bw}" height="20" rx="9" fill="{bc}" stroke="white"/>')
                    parts.append(f'<text x="{x}" y="{by+4}" text-anchor="middle" font-family="Malgun Gothic" font-size="10" font-weight="bold" fill="{fg}">{html.escape(badge)}</text>')
        for entry in hamche_layout:
            x,y,w,h=entry['x'],entry['y'],entry['width'],entry['height'];size=abs(int(entry['font'].cget('size')))
            parts.append(f'<rect x="{x-w/2}" y="{y-h/2}" width="{w}" height="{h}" fill="#f1f7ff" stroke="{entry["border"]}"/>')
            parts.append(f'<text x="{x}" y="{y}" dominant-baseline="central" text-anchor="middle" font-family="Malgun Gothic" font-size="{size}" font-weight="bold" fill="#17365d">{html.escape(entry["text"])}</text>')
        parts.append('</svg>');return "\n".join(parts)

    def html_view_scene(self):
        """V207: the drawing as plain data for the HTML view. Geometry, colours,
        marks, labels and badges come from the same helpers as drawing_svg()."""
        nodes={n["id"]:n for n in self.store.nodes()};cables=self.store.cables()
        if nodes:
            minx=min(n["x"] for n in nodes.values())-100;miny=min(n["y"] for n in nodes.values())-100;maxx=max(n["x"] for n in nodes.values())+100;maxy=max(n["y"] for n in nodes.values())+100
        else:minx=miny=0;maxx=1200;maxy=800
        groups={};cable_warnings=self.store.cable_core_warning_summary()
        for c in cables:groups.setdefault(tuple(sorted((c["n1id"],c["n2id"]))),[]).append(c)
        hamche_layout=self.hamche_label_layout(nodes)
        label_layout=self.cable_label_layout(nodes,cables,cable_warnings,hamche_layout=hamche_layout)
        removal_obstacles=removal_mark_obstacles(label_layout+hamche_layout,nodes) if any(c['status']=='철거' for c in cables) else None
        for entry in label_layout+hamche_layout:
            x1,y1,x2,y2=entry["bounds"];minx=min(minx,x1-20);miny=min(miny,y1-20);maxx=max(maxx,x2+20);maxy=max(maxy,y2+20)
        try:phase_tags=workflow.cable_phase_tags(self.store)
        except Exception:phase_tags={}
        status_names={'remove':'철거','cut':'절단'}
        scene_cables=[]
        for pair,cs in groups.items():
            for i,c in enumerate(cs):
                a=nodes.get(pair[0]);b=nodes.get(pair[1])
                if not a or not b:continue
                path=parallel_cable_path(a["x"],a["y"],b["x"],b["y"],i,len(cs))
                dash,marker=cable_status_style(c["status"]);marks=[]
                if c["status"]=="철거":marks=[('x',qx,qy) for qx,qy in removal_mark_path_points(path,removal_obstacles)]
                elif c["status"]=="절단":marks=[('star',qx,qy) for qx,qy in cable_path_even_points(path,150)]
                rims=[]
                if self.display_options.get('cable_check_mark',True) and cable_check_mark(c):rims.append((CABLE_CHECK_MARKS[cable_check_mark(c)][1],18))
                if self.display_options.get('cable_missing_info',True) and cable_missing_fields(c):rims.append(('#facc15',12))
                status=str(c["status"] or "기설");status=status_names.get(status,status)
                scene_cables.append(dict(id=str(c["id"]),a=str(c["n1id"]),b=str(c["n2id"]),d=cable_path_svg(path),mid=list(cable_path_point(path,.5)),
                    color=cable_size_color(c["size"]),dash=bool(dash),status=status,spec=str(c["spec"] or f'{c["size"]}C'),size=int(c["size"] or 0),
                    cable_id=clean_cable_id(c["cable_id"]),lot=cable_lot_no(c).strip(),marks=marks,rims=rims,
                    phases=[workflow.work_phase_short(n) for n in phase_tags.get(str(c["id"]),[])]))
        scene_labels=[]
        for entry in label_layout:
            parts=[dict(text=p["text"],x=p["x"],y=p["y"],w=p["width"],h=p["height"],fill=p["fill"],ink=p["ink"],border=p["border"],size=abs(int(p["font"].cget("size")))) for p in entry["parts"]]
            scene_labels.append(dict(id=str(entry["id"]),ax=entry["anchor"][0],ay=entry["anchor"][1],parts=parts))
        warnings=self.store.node_warning_summary();type_labels={'hamche':'함체','rn':'RN','sub':'가입자'};scene_nodes=[]
        for n in nodes.values():
            v=node_visual(n);warning=visible_node_warning(warnings.get(n["id"]),self.display_options);ring=''
            if warning:ring="#ff1744" if warning.get('count') or warning.get('rn_in') or warning.get('duplicate_count') else '#1565c0'
            poly=''
            if n['type']=='sub' and v['shape'] in ('triangle','diamond'):
                coords=subscriber_points(v['shape'],n["x"],n["y"]);poly=' '.join(f'{coords[i]},{coords[i+1]}' for i in range(0,len(coords),2))
            name_ink,name_fill=node_name_colors(n);status=str(n["status"] or "기설");status=status_names.get(status,status)
            badges=[list(b) for b in node_display_badges(self.store,n,warnings.get(n['id'],{}),self.display_options)]
            kind=next((k for k,val in SUBSCRIBER_TYPES.items() if val==subscriber_kind(n)),'가입자') if n['type']=='sub' else type_labels.get(n['type'],'시설')
            scene_nodes.append(dict(id=str(n["id"]),name=str(n["name"] or ""),type=str(n["type"] or "hamche"),type_label=kind,status=status,x=n["x"],y=n["y"],
                v=v,ring=ring,poly=poly,name_ink=name_ink,name_fill=name_fill,border=status_color(n["status"]),badges=badges,detail=hamche_detail_text(n,self.display_options,selected=True)))
        details=[dict(text=e['text'],x=e['x'],y=e['y'],w=e['width'],h=e['height'],border=e['border'],size=abs(int(e['font'].cget('size')))) for e in hamche_layout]
        return dict(nodes=scene_nodes,cables=scene_cables,labels=scene_labels,details=details,bounds=[minx,miny,maxx,maxy])

    def html_view_text(self):
        scene=self.html_view_scene()
        try:work=self.work_report()
        except Exception:work={}
        try:report=workflow.completion_report(self.store)
        except Exception:report={}
        scene['cores']=workflow.html_view_cores(self.store,work,report)
        scene['dashboard']=workflow.html_view_dashboard(self.store,work)
        kind=self.scenario_kind()
        name=self.cloud.entry()["name"] if getattr(self,"cloud",None) and self.cloud.current else self.store.path.stem
        meta=dict(name=name,kind=kind,stage_label={'gis':'임시도면','before':'현장반영','after':'후도면'}.get(kind,kind),
                  version=APP_VERSION_LABEL,created=datetime.now().strftime('%Y-%m-%d %H:%M'),stages=list(workflow.HTML_VIEW_STAGES))
        return workflow.html_view_document(scene,meta)

    def open_html_view(self):
        """V207: open the current drawing in the new HTML screen (read-only)."""
        try:
            folder=app_dir()/"print";folder.mkdir(exist_ok=True);path=folder/workflow.HTML_VIEW_FILE
            path.write_text(self.html_view_text(),encoding="utf-8")
        except Exception as error:
            messagebox.showerror("HTML 화면으로 보기","HTML 화면을 만들지 못했습니다.\n"+str(error),parent=self);return None
        webbrowser.open(path.as_uri());self.status.set("HTML 화면을 브라우저로 열었습니다 · 보기 전용 · "+str(path))
        return path

    def work_view_stores(self):
        """V208: (현장반영 store, 후도면 store or None, temporary stores to close).
        The open drawing is used live (unsaved edits included); the other one is
        read from its saved file into memory, so its file is never written."""
        kind=self.scenario_kind()
        if kind=='gis':raise ValueError('임시도면에서는 작업도면을 만들 수 없습니다.\n현장반영(전도면)으로 전환한 뒤 다시 여세요.')
        opened=[]
        def load(name):
            if name==kind:return self.store
            path=self.scenario_path(name)
            if not path.exists():return None
            trial=type(self.store)(':memory:');opened.append(trial)
            source=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)
            try:source.backup(trial.conn)
            finally:source.close()
            trial._view_generation=getattr(trial,'_view_generation',0)+1
            return trial
        try:
            before=load('before');after=load('after')
            if before is None:raise ValueError('저장된 현장반영(전도면)이 없습니다.\n현장반영 도면을 저장한 뒤 다시 여세요.')
        except Exception:
            for store in opened:store.close()
            raise
        return before,after,opened

    def work_view_scene(self):
        """V208: one 작업도면 from 현장반영 (작업전) + 후도면 (작업후)."""
        before,after,opened=self.work_view_stores()
        try:
            try:work=self.work_report()
            except Exception:work={}
            data=workflow.work_view_data(before,after,work);data['work']=workflow.work_view_work_rows(work)
            try:phase_tags=workflow.cable_phase_tags(after or before)
            except Exception:phase_tags={}
            locks={}
            for side,store in (('before',before),('after',after)):
                try:locks[side]=bool(store is not None and store.all_enclosures_locked())
                except Exception:locks[side]=False
        finally:
            for store in opened:store.close()
        type_labels={'hamche':'함체','rn':'RN','sub':'가입자'};nodes={};scene_nodes=[];pos={}
        layout=workflow.work_view_layout(self.store)
        for item in data['nodes']:
            n=item['row'];nodes[item['id']]=n;v=node_visual(n);poly=''
            pos[item['id']]=workflow.work_view_positions(item['rows'],layout.get(item['id']))
            if n['type']=='sub' and v['shape'] in ('triangle','diamond'):
                coords=subscriber_points(v['shape'],n['x'],n['y']);poly=' '.join(f'{coords[i]},{coords[i+1]}' for i in range(0,len(coords),2))
            name_ink,name_fill=node_name_colors(n)
            kind=next((k for k,val in SUBSCRIBER_TYPES.items() if val==subscriber_kind(n)),'가입자') if n['type']=='sub' else type_labels.get(n['type'],'시설')
            edit={k:(dict(name=str(r['name'] or ''),status=str(r['status'] or '기설'),locked=workflow.work_view_node_locked(r)) if r else None) for k,r in item['rows'].items()}
            scene_nodes.append(dict(id=item['id'],name=str(n['name'] or ''),type=str(n['type'] or 'hamche'),type_label=kind,role=item['role'],edit=edit,pos=pos[item['id']],moved=item['id'] in layout,
                                    x=n['x'],y=n['y'],v=v,poly=poly,name_ink=name_ink,name_fill=name_fill,border=status_color(n['status'])))
        points=[p for value in pos.values() for p in value.values()]
        if points:
            minx=min(p[0] for p in points)-120;miny=min(p[1] for p in points)-120;maxx=max(p[0] for p in points)+120;maxy=max(p[1] for p in points)+120
        else:minx=miny=0;maxx=1200;maxy=800
        groups={}
        for item in data['cables']:
            c=item['row']
            if str(c['n1id']) in nodes and str(c['n2id']) in nodes:groups.setdefault(tuple(sorted((str(c['n1id']),str(c['n2id'])))),[]).append(item)
        scene_cables=[]
        for pair,items in groups.items():
            a=nodes[pair[0]];b=nodes[pair[1]]
            for i,item in enumerate(items):
                c=item['row'];path=parallel_cable_path(a['x'],a['y'],b['x'],b['y'],i,len(items))
                geo={}
                for name in ('before','during','after'):
                    # V215: every view has its own facility positions, so its own cable lines.
                    pa=pos[pair[0]][name];pb=pos[pair[1]][name];vp=parallel_cable_path(pa[0],pa[1],pb[0],pb[1],i,len(items))
                    geo[name]=dict(d=cable_path_svg(vp),mid=list(cable_path_point(vp,.5)),lab=list(cable_path_point(vp,.5 if len(items)==1 else .3+.4*i/max(1,len(items)-1))),
                                   marks=[list(p) for p in cable_path_even_points(vp,150)] if item['role'] in workflow.WORK_VIEW_REMOVED else [])
                edit={k:(dict(status=str(r['status'] or '기설'),spec=str(r['spec'] or f"{r['size']}C"),cable_id=clean_cable_id(r['cable_id']),lot=cable_lot_no(r).strip()) if r else None) for k,r in item['rows'].items()}
                marks=[list(p) for p in cable_path_even_points(path,150)] if item['role'] in workflow.WORK_VIEW_REMOVED else []
                scene_cables.append(dict(id=item['id'],a=str(c['n1id']),b=str(c['n2id']),role=item['role'],in_before=item['in_before'],in_after=item['in_after'],edit=edit,d=cable_path_svg(path),
                    mid=list(cable_path_point(path,.5)),lab=list(cable_path_point(path,.5 if len(items)==1 else .3+.4*i/max(1,len(items)-1))),marks=marks,
                    spec=str(c['spec'] or f"{c['size']}C"),size=int(c['size'] or 0),cable_id=clean_cable_id(c['cable_id']),lot=cable_lot_no(c).strip(),
                    phases=[workflow.work_phase_short(n) for n in phase_tags.get(item['id'],[])],geo=geo,pi=[i,len(items)]))
        return dict(nodes=scene_nodes,cables=scene_cables,cores=data['cores'],issues=data['issues'],counts=data['counts'],splices=data.get('splices',{}),work=data.get('work',[]),
                    has_after=data['has_after'],bounds=[minx,miny,maxx,maxy],locks=locks,phase=workflow.work_view_phase_info(self.store),kind=self.scenario_kind())

    def work_view_text(self,live=None):
        scene=self.work_view_scene()
        name=self.cloud.entry()["name"] if getattr(self,"cloud",None) and self.cloud.current else self.store.path.stem
        meta=dict(name=name,kind=self.scenario_kind(),version=APP_VERSION_LABEL,created=datetime.now().strftime('%Y-%m-%d %H:%M'),
                  modes=list(workflow.WORK_VIEW_MODES))
        if live:meta.update(live=True,token=live,statuses=list(STATUS_VALUES),sizes=list(CABLE_SIZE_CHOICES))
        return workflow.work_view_document(scene,meta)

    def work_view_live_scene(self):
        scene=self.work_view_scene();scene['created']=datetime.now().strftime('%Y-%m-%d %H:%M:%S');scene['kind']=self.scenario_kind()
        return scene

    def work_view_backup(self,kind,path):
        """V209: one backup of a saved drawing before the HTML page first edits it."""
        done=self.__dict__.setdefault('_work_view_backups',set())
        if kind in done:return
        folder=self.scenario_folder()/'backup';folder.mkdir(parents=True,exist_ok=True)
        target=folder/(f'{kind}_before_html_edit_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite3')
        source=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True);dest=sqlite3.connect(target)
        try:source.backup(dest)
        finally:dest.close();source.close()
        done.add(kind)

    def work_view_flush(self):
        """V217: the deferred part of quick HTML edits (facility moves): redraw this
        window once, save the open drawing once, sync once."""
        pending=self.__dict__.get('_work_view_flush_id')
        if pending:
            try:self.after_cancel(pending)
            except tk.TclError:pass
        self._work_view_flush_id=None
        live=self.__dict__.pop('_work_view_flush_live',False);other=self.__dict__.pop('_work_view_flush_other',False)
        self.refresh()
        if live:
            try:self.save_current_drawing(silent=True)
            except Exception:pass
        if other and getattr(self,'cloud',None):self.after_idle(self.cloud.sync_now)

    def work_view_ensure_after(self):
        """V223: one drawing. 후도면 is no longer made by hand: the first edit in
        작업중·작업후 makes it from the open 현장반영, the same way the program does."""
        path=self.scenario_path('after')
        if path.exists():return None
        if self.scenario_kind()!='before':raise ValueError('현장반영(전도면)을 연 상태에서 다시 고치세요.')
        try:
            workflow.Workflow(self).prepare_after();self.save_current_drawing(silent=True)
            report=workflow.after_identity_copy(type(self.store),self.scenario_path('before'),path)
        except (sqlite3.Error,OSError) as error:raise ValueError('작업후 도면을 준비하지 못했습니다: '+str(error))
        self._work_view_after_made=workflow.after_identity_copy_summary(report)
        return report

    def work_view_side_store(self,side,kind):
        """V223: (store, temporary) for one file; None when the file is missing."""
        if side==kind:return self.store,False
        path=self.scenario_path(side)
        if not path.exists():return None,False
        self.work_view_backup(side,path);return type(self.store)(path),True

    def work_view_last_group(self,store,undone=0):
        row=store.conn.execute('SELECT id FROM history_groups WHERE undone=? ORDER BY rowid '+('DESC' if not undone else 'ASC')+' LIMIT 1',(undone,)).fetchone()
        return row[0] if row else ''

    def work_view_apply(self,view,label,action,light=False,mirror=None):
        """V210: run action(store) on the drawing a view edits. 작업전 edits the
        현장반영 drawing, 작업중·작업후 the 후도면, with the desktop Store methods
        (locks, rules, undo history). The open drawing is edited live and saved;
        the other one in its saved file, backed up once per session first.
        V223 (one drawing): mirror(other_store, other_side, result, store) then
        writes the same change into the other file (skipped when it has nothing
        to change); both are undone together from the page."""
        if view not in ('before','during','after'):raise ValueError('작업전·작업중·작업후 보기를 고르세요.')
        target='before' if view=='before' else 'after'
        kind=self.scenario_kind()
        if kind=='gis':raise ValueError('임시도면이 열려 있습니다. 현장반영이나 후도면으로 전환한 뒤 고치세요.')
        if self.store.conn.hold_commit or self.store._history_depth:raise ValueError('프로그램에서 다른 변경을 처리 중입니다. 잠시 후 다시 저장하세요.')
        if self.__dict__.get('pending_drag'):raise ValueError('프로그램에서 시설 이동을 마친 뒤 다시 저장하세요.')
        if target=='after' and not label.startswith('작업정책:'):self.work_view_ensure_after()
        live=target==kind;store,temporary=self.work_view_side_store(target,kind)
        if store is None:raise ValueError('저장된 현장반영 도면이 없습니다.' if target=='before' else '작업후 도면이 아직 없습니다.')
        wrote={target};note=''
        try:
            try:
                with store.action(label):result=action(store)
            except sqlite3.Error as error:raise ValueError('저장하지 못했습니다: '+str(error))
            store.conn.commit()
            if mirror:
                other='after' if target=='before' else 'before';first=self.work_view_last_group(store)
                other_store,other_temp=self.work_view_side_store(other,kind)
                if other_store is not None:
                    try:
                        try:
                            with other_store.action(label):mirror(other_store,other,result,store)
                            other_store.conn.commit();wrote.add(other)
                            pairs=self.__dict__.setdefault('_work_view_pairs',{})
                            pairs[(target,first)]=(other,self.work_view_last_group(other_store))
                        except workflow.WorkViewSkip:pass
                        except (ValueError,sqlite3.Error) as error:
                            note=f' · {workflow.SCENARIO_LABELS[other]}에는 반영 못 함: {error}'
                    finally:
                        if other_temp:other_store.close()
        finally:
            if temporary:store.close()
        self._work_report_key=None;self.work_progress_cache_key=None
        if isinstance(self.__dict__.get('selected'),set):self.selected={k for k in self.selected if self.store.node(k) or self.store.cable(k)}
        live_wrote=kind in wrote;other_wrote=bool(wrote-{kind})
        where=' · '.join(workflow.SCENARIO_LABELS[s] for s in ('before','after') if s in wrote)
        made=self.__dict__.pop('_work_view_after_made','')
        if made:note=' · '+made+note
        if light:
            # V217: moves come one after another; the page already shows them, so
            # skip rebuilding the whole page data and do the slow redraw / save /
            # sync once, a moment after the last move.
            self._work_view_flush_live=self.__dict__.get('_work_view_flush_live',False) or live_wrote
            self._work_view_flush_other=self.__dict__.get('_work_view_flush_other',False) or other_wrote
            pending=self.__dict__.get('_work_view_flush_id')
            if pending:
                try:self.after_cancel(pending)
                except tk.TclError:pass
            self._work_view_flush_id=self.after(1200,self.work_view_flush)
            self.status.set(f'HTML 작업도면에서 {where} 수정 · {label} · 저장됨')
            return dict(ok=True,where=where,result=result,note=note.strip(' ·'))
        if self.__dict__.get('_work_view_flush_id'):self.work_view_flush()
        self.refresh()
        if live_wrote:
            try:self.save_current_drawing(silent=True)
            except Exception:pass
        if other_wrote and getattr(self,'cloud',None):self.after_idle(self.cloud.sync_now)
        self.status.set(f'HTML 작업도면에서 {where} 수정 · {label} · 저장됨{note}')
        return dict(ok=True,where=where,result=result,note=note.strip(' ·'),scene=self.work_view_live_scene())

    def work_view_history(self,payload):
        """V218: Ctrl+Z / Ctrl+Y in the HTML page. 작업전 undoes the 현장반영
        drawing, 작업중·작업후 the 후도면 (same history as the program)."""
        view=str(payload.get('view') or '');redo=bool(payload.get('redo'))
        if view not in ('before','during','after'):raise ValueError('작업전·작업중·작업후 보기를 고르세요.')
        target='before' if view=='before' else 'after';kind=self.scenario_kind()
        if kind=='gis':raise ValueError('임시도면이 열려 있습니다.')
        if self.store.conn.hold_commit or self.store._history_depth or self.__dict__.get('pending_drag'):raise ValueError('프로그램에서 다른 작업을 처리 중입니다. 잠시 후 다시 누르세요.')
        if self.__dict__.get('_work_view_flush_id'):self.work_view_flush()
        live=target==kind;store=self.store
        if not live:
            path=self.scenario_path(target)
            if not path.exists():raise ValueError('후도면이 아직 없습니다.')
            self.work_view_backup(target,path);store=type(self.store)(path)
        other_live=False;other_wrote=False
        try:
            group=self.work_view_last_group(store,1 if redo else 0)
            try:result=(store.redo if redo else store.undo)()
            except sqlite3.Error as error:raise ValueError('되돌리지 못했습니다: '+str(error))
            # V223: an edit written to both files is undone / redone in both,
            # only while the other file's next step is that same edit.
            pair=self.__dict__.get('_work_view_pairs',{}).get((target,group)) if group else None
            if pair:
                other_store,other_temp=self.work_view_side_store(pair[0],kind)
                if other_store is not None:
                    try:
                        if self.work_view_last_group(other_store,1 if redo else 0)==pair[1]:
                            (other_store.redo if redo else other_store.undo)();other_wrote=True;other_live=not other_temp;result+=' · 작업전·작업후 함께'
                    except sqlite3.Error:pass
                    finally:
                        if other_temp:other_store.close()
        finally:
            if not live:store.close()
        self._work_report_key=None;self.work_progress_cache_key=None
        if isinstance(self.__dict__.get('selected'),set):self.selected={k for k in self.selected if self.store.node(k) or self.store.cable(k)}
        self.refresh()
        if live or other_live:
            try:self.save_current_drawing(silent=True)
            except Exception:pass
        if (not live or (other_wrote and not other_live)) and getattr(self,'cloud',None):self.after_idle(self.cloud.sync_now)
        where=workflow.SCENARIO_LABELS[target];self.status.set(f'HTML 작업도면 · {where} · {result}')
        return dict(ok=True,where=where,result=result,scene=self.work_view_live_scene())

    def work_view_edit_core(self,payload):
        """V209: one core slot. 작업전 -> 현장반영, 작업후 -> 후도면."""
        view=str(payload.get('view') or '')
        if view not in ('before','after'):raise ValueError('작업전 또는 작업후 칸을 고르세요.')
        cable=str(payload.get('cable') or '')
        try:number=int(payload.get('n'))
        except (TypeError,ValueError):raise ValueError('코어 번호가 올바르지 않습니다.')
        core_id=str(payload.get('id') or '').strip()[:120];detail=str(payload.get('detail') or '').strip()[:500]
        def action(store):
            old=store.core(cable,number)
            if not old:raise ValueError('그 케이블·코어 번호를 찾지 못했습니다. 화면을 새로 고치세요.')
            store.update_core(cable,number,[core_id,detail,old['status1'],old['status2'],old['signal']])
            return dict(old)
        def mirror(store,side,old,source):
            # V223: the other side follows only when its slot held the same 코어ID·내역.
            row=store.core(cable,number)
            if not workflow.work_view_slot_same(row,old,('core_id','detail')):raise workflow.WorkViewSkip('코어절체 칸')
            store.update_core(cable,number,[core_id,detail,row['status1'],row['status2'],row['signal']])
        done=self.work_view_apply(view,f'{number}번 코어 정보 변경',action,mirror=mirror);done['result']=number
        return done

    def work_view_edit(self,payload):
        """V210: cable / facility edits from the HTML 작업도면."""
        op=str(payload.get('op') or '');view=str(payload.get('view') or '')
        text=lambda key,limit=120:str(payload.get(key) or '').strip()[:limit]
        def number(key):
            try:return float(payload.get(key))
            except (TypeError,ValueError):raise ValueError('위치가 올바르지 않습니다.')
        def need_cable(store,key):
            cable=store.cable(key)
            if not cable:raise ValueError('이 케이블은 이 보기의 도면에 없습니다. 케이블이 있는 보기(작업전 또는 작업후)에서 고치세요.')
            return cable
        def need_node(store,key):
            node=store.node(key)
            if not node:raise ValueError('이 시설은 이 보기의 도면에 없습니다. 시설이 있는 보기에서 고치세요.')
            return node
        def spec_value(value):
            value=str(value or '').strip().upper().replace(' ','')
            if value in ('드랍','DROP'):return '드랍'
            if value.endswith('C'):value=value[:-1]
            if not value.isdigit() or not 1<=int(value)<=999:raise ValueError('규격은 12C처럼 숫자+C로 입력하세요.')
            return f'{int(value)}C'
        def status_value(value):
            value=str(value or '').strip() or '기설'
            if value not in STATUS_VALUES:raise ValueError('상태는 기설·신설·철거·절단 중에서 고르세요.')
            return value
        if op=='cable_info':
            key=text('cable');status=status_value(payload.get('status'));spec=spec_value(payload.get('spec'));name=clean_cable_id(text('cable_id'));lot=text('lot')
            def action(store):
                old=need_cable(store,key)
                if spec!=str(old['spec'] or ''):store.resize_cable(key,spec)
                if status!=str(old['status'] or '기설'):store.set_cable_status(key,status)
                if name!=clean_cable_id(old['cable_id']):store.conn.execute('UPDATE cables SET cable_id=? WHERE id=?',(name,key))
                if lot!=cable_lot_no(old).strip():store.set_cable_lot_no(key,lot)
                return key
            def mirror(store,side,result,source):
                # V223: one drawing: the same cable in the other file gets the same 이름·규격·상태·LOT.
                if not store.cable(key):raise workflow.WorkViewSkip('없음')
                action(store)
            return self.work_view_apply(view,'케이블 정보 변경',action,mirror=mirror)
        if op=='cable_add':
            a=text('a');b=text('b');status=status_value(payload.get('status'));spec=spec_value(payload.get('spec'))
            if a==b:raise ValueError('서로 다른 두 시설을 고르세요.')
            def action(store):
                need_node(store,a);need_node(store,b)
                return store.add_cable(a,b,text('cable_id'),spec,status,text('lot'))
            # V223: 신설 lives in 작업후 only; 기설·철거·절단 in both files with the same id.
            if status=='신설':return self.work_view_apply('after','케이블 만들기',action)
            return self.work_view_apply(view,'케이블 만들기',action,mirror=lambda store,side,cid,source:workflow.work_view_copy_rows(source,store,'cable',cid))
        if op=='node_add':
            name=text('name',60);kind=text('type') or 'hamche';x=number('x');y=number('y')
            if not name:raise ValueError('시설 이름을 입력하세요.')
            if kind not in ('hamche','rn','sub'):raise ValueError('시설 종류를 다시 고르세요.')
            def action(store):
                nid=store.add_node(name,max(40,round(x)),max(40,round(y)),kind)
                if view!='before':store.set_node_status(nid,'신설')
                return nid
            # V223: made in 작업전 = 기설 in both files; in 작업중·작업후 = 신설 in 작업후 only.
            mirror=(lambda store,side,nid,source:workflow.work_view_copy_rows(source,store,'node',nid)) if view=='before' else None
            return self.work_view_apply(view,'시설 만들기',action,mirror=mirror)
        if op=='core_signal':
            # V221: one number's 신호 (ON·OFF·예외·오류·확인필요), like the cable window's 신호 적용.
            if view not in ('before','after'):raise ValueError('작업전 또는 작업후 칸을 고르세요.')
            cable=text('cable');n=int(payload.get('n') or 0) if str(payload.get('n') or '').isdigit() else 0
            signal=str(payload.get('signal') or '')
            if signal not in SIGNAL_LABELS or signal=='unknown':raise ValueError('신호를 다시 고르세요.')
            if n<1:raise ValueError('코어 번호가 올바르지 않습니다.')
            if not payload.get('confirm'):
                # The page asks first when the new signal would mix signals on the connected path.
                target='before' if view=='before' else 'after';kind=self.scenario_kind()
                if target==kind:
                    try:warning=workflow.signal_mix_warning(self.store,[(cable,n)],signal)
                    except (ValueError,KeyError,sqlite3.Error):warning=''
                    if warning:return dict(ok=False,confirm=warning)
            def action(store):
                row=store.core(cable,n)
                if not row:raise ValueError('그 케이블·코어 번호를 찾지 못했습니다. 화면을 새로 고치세요.')
                if str(row['signal'] or '')==signal:return f'{n}번 신호 그대로'
                old=dict(row)
                if not str(row['core_id'] or '').strip():store.set_empty_core_signal((cable,n),signal)
                else:store.update_core(cable,n,[row['core_id'],row['detail'],row['status1'],row['status2'],signal])
                self._work_view_old_slot=old
                return f'{n}번 신호 {SIGNAL_LABELS[signal]}'
            def mirror(store,side,result,source):
                old=self.__dict__.pop('_work_view_old_slot',None);row=store.core(cable,n)
                if not workflow.work_view_slot_same(row,old,('core_id','detail','signal')):raise workflow.WorkViewSkip('다른 칸')
                if not str(row['core_id'] or '').strip():store.set_empty_core_signal((cable,n),signal)
                else:store.update_core(cable,n,[row['core_id'],row['detail'],row['status1'],row['status2'],signal])
            self._work_view_old_slot=None
            return self.work_view_apply(view,'코어 신호 변경',action,mirror=mirror)
        if op=='nodes_move':
            # V219: several facilities moved together (Shift+드래그 / Shift+클릭).
            items=payload.get('items');light=bool(payload.get('light'))
            if not isinstance(items,list) or not items:raise ValueError('옮길 시설이 없습니다.')
            if len(items)>2000:raise ValueError('한 번에 2000개까지 옮길 수 있습니다.')
            moves=[]
            for item in items:
                if not isinstance(item,dict):raise ValueError('옮길 시설을 다시 고르세요.')
                try:moves.append((str(item.get('node') or '')[:120],max(40,round(float(item.get('x')))),max(40,round(float(item.get('y'))))))
                except (TypeError,ValueError):raise ValueError('위치가 올바르지 않습니다.')
            def refuse_locked(store):
                names=[str(store.node(k)['name'] or k) for k,_,_ in moves if store.node(k) and workflow.node_locked(store,k)]
                if names:raise ValueError('잠긴 함체가 있어 옮기지 않았습니다: '+', '.join(names[:5])+(' 외' if len(names)>5 else ''))
            if view=='during':
                refuse_locked(self.store);live_view='before' if self.scenario_kind()=='before' else 'after'
                def layout(store):
                    value=workflow.state(store);places=value.setdefault('work_view_layout',{}).setdefault('during',{})
                    for k,x,y in moves:places[k]=[x,y]
                    workflow.write_state(store,value,'작업도면 배치');return len(moves)
                return self.work_view_apply(live_view,'작업정책: 작업중 배치',layout,light=light)
            def action(store):
                refuse_locked(store);count=0
                for k,x,y in moves:
                    if store.node(k):store.update_node_pos(k,x,y);count+=1
                if not count:raise ValueError('이 보기의 도면에 그 시설들이 없습니다.')
                return count
            return self.work_view_apply(view,'시설 여러 개 이동',action,light=light)
        if op=='node_info':
            key=text('node');name=text('name',60);status=status_value(payload.get('status'))
            def action(store):
                old=need_node(store,key)
                if name!=str(old['name'] or ''):store.set_node_details(key,name)
                if status!=str(old['status'] or '기설'):store.set_node_status(key,status)
                return key
            def mirror(store,side,result,source):
                if not store.node(key):raise workflow.WorkViewSkip('없음')
                action(store)
            return self.work_view_apply(view,'시설 정보 변경',action,mirror=mirror)
        if op=='node_move':
            key=text('node');x=max(40,round(number('x')));y=max(40,round(number('y')));reset=bool(payload.get('reset'));light=bool(payload.get('light')) and not reset
            if view=='during':
                # V215: 작업중 has its own layout (shared by both drawings like 작업차수,
                # so written to the open drawing). Unset = the 작업전 position.
                if workflow.node_locked(self.store,key):raise ValueError('잠긴 함체입니다. 잠금을 푼 뒤 옮기세요.')
                live_view='before' if self.scenario_kind()=='before' else 'after'
                return self.work_view_apply(live_view,'작업정책: 작업중 배치',lambda store:workflow.work_view_set_layout(store,'during',key,None if reset else (x,y)),light=light)
            def action(store):
                need_node(store,key)
                if workflow.node_locked(store,key):raise ValueError('잠긴 함체입니다. 잠금을 푼 뒤 옮기세요.')
                store.update_node_pos(key,x,y);return key
            return self.work_view_apply(view,'시설 이동',action,light=light)
        if op=='delete':
            key=text('id');what=text('kind')
            def action(store):
                if what=='node':
                    need_node(store,key)
                    for row in store.node_cables(key):store.conn.execute('DELETE FROM splices WHERE cable1_id=? OR cable2_id=?',(row['id'],row['id']))
                    store.conn.execute('DELETE FROM nodes WHERE id=?',(key,))
                elif what=='cable':
                    need_cable(store,key)
                    store.conn.execute('DELETE FROM splices WHERE cable1_id=? OR cable2_id=?',(key,key));store.conn.execute('DELETE FROM cables WHERE id=?',(key,))
                else:raise ValueError('지울 대상을 다시 고르세요.')
                return key
            def mirror(store,side,result,source):
                # V223: one drawing: deleting removes it from every view (both files).
                if not (store.node(key) if what=='node' else store.cable(key)):raise workflow.WorkViewSkip('없음')
                action(store)
            return self.work_view_apply(view,'선택 항목 삭제',action,mirror=mirror)
        def slot_number(key):
            try:value=int(payload.get(key))
            except (TypeError,ValueError):raise ValueError('코어 번호를 숫자로 입력하세요.')
            if value<1:raise ValueError('코어 번호는 1부터입니다.')
            return value
        def node_cable(store,node,cable):
            need_node(store,node);row=need_cable(store,cable)
            if node not in (row['n1id'],row['n2id']):raise ValueError('그 케이블은 이 시설에 붙어 있지 않습니다.')
            return row
        if op=='splice_add':
            node=text('node');a=(text('a_cable'),slot_number('a_n'));b=(text('b_cable'),slot_number('b_n'));temporary=bool(payload.get('temporary'))
            def action(store):
                node_cable(store,node,a[0]);node_cable(store,node,b[0])
                for slot in (a,b):
                    if not store.core(*slot):raise ValueError(f'{slot[1]}번 코어가 그 케이블에 없습니다.')
                return store.connect(node,a,b,temporary)
            return self.work_view_apply(view,'코어 연결',action)
        if op=='splice_del':
            node=text('node');cable=text('cable');n=slot_number('n')
            def action(store):
                need_node(store,node)
                if not store.disconnect(node,cable,n):raise ValueError('이 시설에서 그 코어의 연결을 찾지 못했습니다.')
                return f'{n}번 연결 해제'
            return self.work_view_apply(view,'코어 연결 해제',action)
        if op=='splice_range':
            node=text('node');left=text('left');right=text('right')
            if left==right:raise ValueError('서로 다른 두 케이블을 고르세요.')
            def action(store):
                node_cable(store,node,left);node_cable(store,node,right)
                count,errors=store.full_splice(node,left,right,start=payload.get('start'),end=payload.get('end'))
                return f'{count}개 직결'+(' · 건너뜀 '+'; '.join(errors[:5]) if errors else '')
            return self.work_view_apply(view,'번호 범위 직결',action)
        if op=='core_paste':
            cable=text('cable');start=slot_number('start');lines=payload.get('lines')
            if not isinstance(lines,list) or not lines:raise ValueError('붙여 넣을 내용이 없습니다.')
            if len(lines)>1000:raise ValueError('한 번에 1000줄까지 붙여 넣을 수 있습니다.')
            def action(store):
                need_cable(store,cable);saved=0;errors=[]
                for offset,line in enumerate(lines):
                    number=start+offset;line=line if isinstance(line,list) else [line]
                    core_id=str(line[0] if line else '').strip()[:120];detail=str(line[1] if len(line)>1 else '').strip()[:500]
                    old=store.core(cable,number)
                    if not old:errors.append(f'{number}번: 케이블 코어 수를 넘음');break
                    try:store.update_core(cable,number,[core_id,detail,old['status1'],old['status2'],old['signal']]);saved+=1;pasted[number]=(dict(old),core_id,detail)
                    except ValueError as error:errors.append(f'{number}번: {error}')
                if not saved:raise ValueError('저장한 줄이 없습니다. '+'; '.join(errors[:5]))
                return f'{saved}줄 저장'+(' · 확인 필요 '+'; '.join(errors[:5]) if errors else '')
            pasted={}
            def mirror(store,side,result,source):
                if not store.cable(cable):raise workflow.WorkViewSkip('없음')
                count=0
                for number,(old,core_id,detail) in pasted.items():
                    row=store.core(cable,number)
                    if not workflow.work_view_slot_same(row,old,('core_id','detail')):continue
                    try:store.update_core(cable,number,[core_id,detail,row['status1'],row['status2'],row['signal']]);count+=1
                    except ValueError:pass
                if not count:raise workflow.WorkViewSkip('같은 칸 없음')
            return self.work_view_apply(view,'코어 여러 칸 붙여넣기',action,mirror=mirror)
        if op in ('cable_phase','core_phase','phase_add'):
            # V214: 작업차수 is shared by 현장반영 and 후도면 (copied on every switch),
            # so it is always written to the open drawing only.
            name=text('name',40);live_view='before' if self.scenario_kind()=='before' else 'after'
            if op=='phase_add':
                return self.work_view_apply(live_view,'작업정책: 작업차수 추가',lambda store:workflow.work_view_phase_add(store,name))
            names=workflow.work_phase_names(self.store)
            if name and name not in names:raise ValueError(f'작업차수 「{name}」가 없습니다. 새로 고친 뒤 다시 고르세요.')
            if op=='cable_phase':
                key=text('cable')
                if not self.store.cable(key):raise ValueError(f'이 케이블은 지금 열린 {workflow.SCENARIO_LABELS[self.scenario_kind()]} 도면에 없습니다. 케이블 작업차수는 열린 도면의 케이블에만 줄 수 있어요.')
                return self.work_view_apply(live_view,'작업정책: 케이블 작업차수',lambda store:workflow.set_cable_phase(store,[key],name))
            ids=payload.get('ids')
            ids=[str(x).strip()[:120] for x in (ids if isinstance(ids,list) else [ids]) if str(x or '').strip()][:1000]
            if not ids:raise ValueError('코어ID가 있는 칸만 작업차수를 줄 수 있어요.')
            return self.work_view_apply(live_view,'작업정책: 코어 작업차수',lambda store:workflow.set_core_phase(store,ids,name))
        if op=='node_lock':
            key=text('node');locked=bool(payload.get('locked'))
            def action(store):
                node=need_node(store,key)
                if node['type']!='hamche':raise ValueError('잠금은 함체에만 걸 수 있어요.')
                store.set_node_locked(key,locked);return key
            def mirror(store,side,result,source):
                if not store.node(key):raise workflow.WorkViewSkip('없음')
                action(store)
            return self.work_view_apply(view,'함체 잠금' if locked else '함체 잠금 해제',action,mirror=mirror)
        if op=='all_lock':
            locked=bool(payload.get('locked'))
            def action(store):
                if not any(n['type']=='hamche' for n in store.nodes()):raise ValueError('잠글 함체가 없습니다.')
                return f'{store.set_all_enclosures_locked(locked)}개 변경'
            def mirror(store,side,result,source):
                if not any(n['type']=='hamche' for n in store.nodes()):raise workflow.WorkViewSkip('없음')
                store.set_all_enclosures_locked(locked)
            return self.work_view_apply(view,'전체 함체 잠금' if locked else '전체 함체 잠금 해제',action,mirror=mirror)
        raise ValueError('지원하지 않는 수정입니다.')

    def work_view_switch(self,payload):
        """V214: 현장반영 ↔ 후도면 전환 from the HTML page. The switch runs in this
        window a moment later (its questions and checks appear here), and the page
        reloads when it gets focus again."""
        kind=str(payload.get('kind') or '')
        if kind not in ('before','after'):raise ValueError('현장반영 또는 후도면을 고르세요.')
        if kind==self.scenario_kind():return dict(ok=True,started=False,kind=kind)
        if self.store.conn.hold_commit or self.store._history_depth or self.__dict__.get('pending_drag'):
            raise ValueError('프로그램에서 다른 작업을 처리 중입니다. 잠시 후 다시 누르세요.')
        self.work_view_show_app()
        def run():
            try:self.load_scenario(kind)
            except Exception as error:messagebox.showerror('도면 전환',str(error),parent=self)
        self.after(50,run)
        return dict(ok=True,started=True,kind=kind,label=workflow.SCENARIO_LABELS[kind])

    def work_view_trace(self,payload):
        """V213: 코어 추적 for one view (read-only). 작업전 traces the 현장반영
        drawing, 작업중·작업후 the 후도면, with the desktop trace rules."""
        view=str(payload.get('view') or '');core_id=str(payload.get('id') or '').strip()[:120]
        if not core_id:raise ValueError('추적할 코어ID를 입력하세요.')
        target='before' if view=='before' else 'after';kind=self.scenario_kind()
        if kind=='gis':raise ValueError('임시도면이 열려 있습니다.')
        if target==kind:store=self.store;temp=None
        else:
            path=self.scenario_path(target)
            if not path.exists():
                if target=='after':store=self.store if kind=='before' else None;temp=None
                else:raise ValueError('저장된 현장반영 도면이 없습니다.')
                if store is None:raise ValueError('후도면이 아직 없습니다.')
            else:
                temp=type(self.store)(':memory:');source=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)
                try:source.backup(temp.conn)
                finally:source.close()
                store=temp
        try:
            value=workflow.work_view_trace_value(store.trace_core_paths(core_id))
            value['basis']=workflow.trace_basis(store)
        finally:
            if temp is not None:temp.close()
        return dict(ok=True,value=value)

    def work_view_route(self,payload):
        """V222: 케이블 전체 경로 (where all used cores of one cable go, with the
        number of cores that arrive at each end) for one view, read-only, with
        the program's cable_route_overview rules."""
        view=str(payload.get('view') or '');cable=str(payload.get('cable') or '').strip()[:120]
        if not cable:raise ValueError('케이블을 고르세요.')
        target='before' if view=='before' else 'after';kind=self.scenario_kind()
        if kind=='gis':raise ValueError('임시도면이 열려 있습니다.')
        temp=None
        if target==kind:store=self.store
        else:
            path=self.scenario_path(target)
            if not path.exists():
                if target=='after' and kind=='before':store=self.store
                else:raise ValueError('저장된 도면이 없습니다.')
            else:
                temp=type(self.store)(':memory:');source=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)
                try:source.backup(temp.conn)
                finally:source.close()
                store=temp
        try:
            if not store.cable(cable):raise ValueError('이 케이블은 이 보기의 도면에 없습니다.')
            model=workflow.cable_route_overview(store,cable)
        finally:
            if temp is not None:temp.close()
        ends=[dict(node=str(e['node_id']),name=e['name'],arrive=e['arrive'],stop=e['stop'],
                   cores=[dict(n=c['number'],id=c['core_id'],detail=c['detail'],state=c['state'],end=c['end']) for c in e['cores']]) for e in model['ends']]
        return dict(ok=True,value=dict(cable=cable,colors={str(k):v for k,v in model['colors'].items()},ends=ends,summary=model['summary'],count=model['seed_count']))

    def work_view_server_start(self):
        server=self.__dict__.get('_work_server')
        if server is not None and not server.closed:return server
        server=workflow.WorkViewServer({'page':lambda:self.work_view_text(live=self._work_server.token),
                                        'scene':self.work_view_live_scene,'core':self.work_view_edit_core,'edit':self.work_view_edit,
                                        'show_app':self.work_view_show_app,'trace':self.work_view_trace,'switch':self.work_view_switch,'history':self.work_view_history,'route':self.work_view_route})
        self._work_server=server
        def pump():
            if self.__dict__.get('_work_server') is not server or server.closed:return
            try:server.pump()
            finally:
                try:self.after(60,pump)
                except tk.TclError:pass
        self.after(60,pump)
        return server

    def work_view_start_file(self):
        return app_dir()/'data'/'work_view_start.json'

    def work_view_start_enabled(self):
        """V212: open the HTML 작업도면 when the program starts (default on)."""
        try:return bool(json.loads(self.work_view_start_file().read_text(encoding='utf-8')).get('open_on_start',True))
        except (OSError,ValueError,AttributeError):return True

    def set_work_view_start(self,enabled):
        path=self.work_view_start_file();path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps({'open_on_start':bool(enabled)}),encoding='utf-8')
        root=globals().get('_CLOUD_ROOT_HOME')
        if root:
            # V216: the login page (before an account is known) follows the same switch.
            try:target=Path(root)/'data'/'work_view_start.json';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps({'open_on_start':bool(enabled)}),encoding='utf-8')
            except OSError:pass
        if hasattr(self,'work_view_start_var'):self.work_view_start_var.set(bool(enabled))
        self.status.set('시작할 때 HTML 작업도면을 '+('엽니다' if enabled else '열지 않습니다'))

    def auto_open_work_view(self):
        """V212: the HTML 작업도면 is the main screen; this window stays as the
        sub screen (and keeps the page's server running)."""
        if self.__dict__.get('_work_view_auto_done') or self.__dict__.get('_app_closing'):return None
        self._work_view_auto_done=True
        if self.scenario_kind()=='gis':
            self.login_page_message('임시도면 단계라 작업도면은 열지 않았어요. 기존 화면에서 현장반영으로 전환한 뒤 「작업도면 전·중·후」를 누르세요.')
            self.status.set('임시도면 단계라 HTML 작업도면은 열지 않았습니다 · 현장반영으로 전환한 뒤 「작업도면 전·중·후」를 누르세요');return None
        try:
            self.work_view_scene();server=self.work_view_server_start()
        except Exception as error:
            self.login_page_message('작업도면을 열지 못했어요: '+str(error).splitlines()[0]+' · 기존 화면에서 계속하세요.')
            self.status.set('HTML 작업도면을 열지 못했습니다: '+str(error).splitlines()[0]);return None
        url=server.url()
        if not self.login_page_handoff(url):webbrowser.open(url)
        self.status.set('HTML 작업도면을 열었습니다 (메인 화면) · 이 창은 기존 화면으로 함께 쓸 수 있습니다')
        return url

    def login_page_handoff(self,url):
        """V216: the HTML login page (same tab) moves on to the 작업도면.
        If the page does not take it within 8 s, open a new tab instead."""
        web=globals().get('LOGIN_WEB')
        if not isinstance(web,dict) or not web.get('approved') or web.get('next') or web.get('closed'):return False
        web['next']=url
        def fallback():
            if not web.get('taken'):webbrowser.open(url)
            server=web.get('_server')
            if server is not None:server.close_later(5)
        self.after(8000,fallback)
        return True

    def login_page_message(self,text):
        web=globals().get('LOGIN_WEB')
        if isinstance(web,dict) and web.get('approved'):
            web['message']=text
            server=web.get('_server')
            if server is not None:server.close_later(60)

    def work_view_show_app(self,payload=None):
        """V212: 「기존 화면」 button in the HTML page brings this window to the front."""
        try:
            self.deiconify();self.lift();self.attributes('-topmost',True)
            self.after(400,lambda:self.attributes('-topmost',False));self.focus_force()
        except tk.TclError:pass
        return dict(ok=True)

    def open_work_view(self):
        """V209: 작업도면 (작업전·작업중·작업후) in the browser. The page talks to
        this program through a server only this PC can reach, so it can edit."""
        try:
            self.work_view_scene()  # refuse 임시도면 / missing 현장반영 here, with a message
            server=self.work_view_server_start()
        except Exception as error:
            messagebox.showerror("작업도면 전·중·후","작업도면을 열지 못했습니다.\n"+str(error),parent=self);return None
        url=server.url();webbrowser.open(url)
        self.status.set("작업도면(작업전·작업중·작업후)을 브라우저로 열었습니다 · 코어ID·내역 수정 가능 · 프로그램을 닫으면 화면도 멈춥니다")
        return url

    def export_svg(self):
        path=filedialog.asksaveasfilename(defaultextension=".svg",filetypes=[("SVG 이미지","*.svg")],initialfile="통신코어도면.svg")
        if path:Path(path).write_text(self.drawing_svg(),encoding="utf-8");messagebox.showinfo("SVG 저장",path,parent=self)

    def print_preview(self):
        folder=app_dir()/"print";folder.mkdir(exist_ok=True);path=folder/"도면_인쇄미리보기.html"
        doc='<!doctype html><meta charset="utf-8"><title>도면 인쇄</title><style>@page{size:A0 landscape;margin:10mm}body{margin:0}svg{width:100%;height:auto}</style>'+self.drawing_svg()
        path.write_text(doc,encoding="utf-8");webbrowser.open(path.as_uri())

    def export_json(self):
        path=filedialog.asksaveasfilename(defaultextension=".json",filetypes=[("JSON","*.json")],initialfile="telecom_core_export.json")
        if not path:return
        nodes=[]
        for n in self.store.nodes():
            d={"id":n["id"],"name":n["name"],"x":n["x"],"y":n["y"],"type":n["type"],"status":n["status"],"color":n["color"],"spliceMap":{}}
            extra=json.loads(n["extra_json"] or "{}");d.update(extra)
            if n["type"] in ("rn","sub"):
                pdata=[{"label":r["label"],"coreNo":r["core_id"],"detail":r["detail"]} for r in self.store.conn.execute("SELECT * FROM ports WHERE node_id=? ORDER BY port_index",(n["id"],))]
                d["rnPortsData" if n["type"]=="rn" else "subPortsData"]=pdata
            rows=self.store.conn.execute("SELECT * FROM splices WHERE node_id=?",(n["id"],)).fetchall()
            def legacy(cid):
                if not str(cid).startswith("PORT:"):return cid
                return ("RNPORTS:" if n["type"]=="rn" else "SUBPORTS:")+n["id"]
            for i,s in enumerate(rows):d["spliceMap"][f"연결-{i+1}"]={"c1":{"edgeId":legacy(s["cable1_id"]),"key":s["core1_index"]},"c2":{"edgeId":legacy(s["cable2_id"]),"key":s["core2_index"]}}
            nodes.append(d)
        edges=[]
        for c in self.store.cables():
            d=json.loads(c["extra_json"] or "{}");d.update({"id":c["id"],"n1id":c["n1id"],"n2id":c["n2id"],"number":c["cable_id"],"size":c["size"],"spec":c["spec"],"status":c["status"],"coresData":[{"coreNo":r["core_id"],"detail":r["detail"]} for r in self.store.cores(c["id"])]});edges.append(d)
        survey=[]
        for r in self.store.conn.execute("SELECT * FROM survey_rows ORDER BY created_at,rowid"):
            n=self.store.node(r["node_id"])
            survey.append({"id":r["id"],"nodeId":r["node_id"],"nodeName":n["name"] if n else "", "invalid":bool(r["invalid"]),
              "errorMessage":r["error_message"],"left":{"edgeId":r["left_cable"],"key":str(r["left_index"])},
              "right":{"edgeId":r["right_cable"],"key":str(r["right_index"])},"createdAt":r["created_at"]})
        status1={};status2={};signal={}
        for r in self.store.all_core_rows():
            if not r["core_id"]:continue
            if r["status1"]:status1[r["core_id"]]=r["status1"]
            if r["status2"]:status2[r["core_id"]]=r["status2"]
            if r["signal"]:signal[r["core_id"]]=r["signal"]
        meta=self.store.conn.execute("SELECT value FROM meta WHERE key='legacy_root'").fetchone();obj=json.loads(meta[0]) if meta else {}
        obj.update({"version":5,"nodes":nodes,"edges":edges,"surveyRows":survey,"coreSignalMap":status1,"coreStatus2MapV15":status2,"coreOpticalSignalMapV27":signal})
        obj["_windowsWorkflowV17"]=workflow.state(self.store)
        obj["_windowsAnnotationsV17"]=[dict(r) for r in self.store.conn.execute("SELECT * FROM core_annotations")]
        field_pack=workflow.field_slot_json_pack(self.store)
        if field_pack:obj['_windowsFieldSlotsV72']=field_pack
        else:obj.pop('_windowsFieldSlotsV72',None)
        scenario_folder=app_dir()/"scenarios"/self.store.path.stem;snapshots={}
        for kind in ("gis","before","after"):
            snapshot=scenario_folder/(kind+".sqlite3")
            if snapshot.exists():snapshots[kind]=base64.b64encode(snapshot.read_bytes()).decode("ascii")
        if snapshots:obj["_windowsBeforeAfterSQLite"]={"format":"sqlite3-base64","snapshots":snapshots}
        Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")
        messagebox.showinfo("내보내기 완료",path,parent=self)

    def import_json(self):
        path=filedialog.askopenfilename(filetypes=[("V83 JSON","*.json"),("모든 파일","*.*")])
        if not path:return
        if self.store.nodes() and not messagebox.askyesno("가져오기","현재 데이터를 지우고 가져올까요? 먼저 JSON 내보내기로 백업하는 것을 권장합니다.",parent=self):return
        try:
            raw_data=json.loads(Path(path).read_text(encoding="utf-8-sig"))
            wrapper={k:v for k,v in raw_data.items() if k!="state"} if isinstance(raw_data,dict) and isinstance(raw_data.get("state"),dict) else {}
            data=raw_data.get("state") if wrapper else raw_data
            if not isinstance(data,dict) or not isinstance(data.get("nodes",[]),list) or not isinstance(data.get("edges",[]),list):raise ValueError("V83 도면 JSON 형식이 아닙니다.")
        except Exception as e:messagebox.showerror("가져오기 실패",str(e),parent=self);return
        self.manual_backup(silent=True)
        self.store._history_disabled+=1;self.store.conn.hold_commit+=1
        try:
            self.store.clear_all()
            imported_locks=[]
            root_known={"version","nextNodeId","nextEdgeId","nodes","edges","surveyRows","coreSignalMap","coreMatchMap","coreStatus2MapV15","coreStatus2LockMapV22","coreOpticalSignalMapV27","coreOpticalSignalMapV60"}
            legacy={k:v for k,v in data.items() if k not in root_known}
            if wrapper:legacy["_v83FileWrapper"]=wrapper
            self.store.conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('legacy_root',?)",(json.dumps(legacy,ensure_ascii=False),))
            for n in data.get("nodes",[]):
                known={k:n.get(k) for k in ("id","name","x","y","type","status","color")}
                extra={k:v for k,v in n.items() if k not in known and k!="spliceMap"}
                if extra.get('editLocked') and (known['type'] or 'hamche')=='hamche':
                    imported_locks.append(str(known['id']));extra['editLocked']=False
                known["status"]={"existing":"기설","new":"신설","remove":"철거","cut":"절단"}.get(known["status"],known["status"] or "기설")
                self.store.conn.execute("INSERT INTO nodes(id,name,x,y,type,status,color,extra_json) VALUES(?,?,?,?,?,?,?,?)",
                    (str(known["id"]),str(known["name"] or "함체"),float(known["x"] or 0),float(known["y"] or 0),known["type"] or "hamche",known["status"] or "",known["color"] or "",json.dumps(extra,ensure_ascii=False)))
                if (known["type"] or "") in ("rn","sub"):
                    spec=n.get("rnSpec") if known["type"]=="rn" else n.get("subSpec")
                    self.store.ensure_ports(str(known["id"]),spec)
                    pdata=n.get("rnPortsData") if known["type"]=="rn" else n.get("subPortsData")
                    by_label={r["label"]:r for r in self.store.conn.execute("SELECT * FROM ports WHERE node_id=?",(str(known["id"]),))}
                    for pd in (pdata or []):
                        r=by_label.get(str(pd.get("label") or ""))
                        if r:
                            core_no=pd.get("coreNo") or "";self.store.conn.execute("UPDATE ports SET core_id=?,detail=?,status1=?,status2=?,signal=? WHERE node_id=? AND port_index=?",(core_no,pd.get("detail") or "",(data.get("coreSignalMap") or {}).get(core_no,""),(data.get("coreStatus2MapV15") or {}).get(core_no,""),(data.get("coreOpticalSignalMapV27") or data.get("coreOpticalSignalMapV60") or {}).get(core_no,""),str(known["id"]),r["port_index"]))
            for e in data.get("edges",[]):
                size=int(e.get("size") or len(e.get("coresData") or []) or 12);spec=e.get("spec") or f"{size}C"
                status={"existing":"기설","new":"신설","remove":"철거","cut":"절단"}.get(e.get("status"),e.get("status") or "기설")
                edge_known={"id","n1id","n2id","number","size","spec","status","coresData"};edge_extra={k:v for k,v in e.items() if k not in edge_known}
                self.store.conn.execute("INSERT INTO cables(id,n1id,n2id,cable_id,size,spec,status,extra_json) VALUES(?,?,?,?,?,?,?,?)",
                    (str(e["id"]),str(e["n1id"]),str(e["n2id"]),clean_cable_id(e.get("number","")),size,spec,status,json.dumps(edge_extra,ensure_ascii=False)))
                cds=e.get("coresData") or []
                inserts=[]
                for i in range(1,size+1):
                    cd=cds[i-1] if i<=len(cds) else {};core_no=cd.get("coreNo","")
                    inserts.append((str(e["id"]),i,core_no,cd.get("detail","") ,(data.get("coreSignalMap") or {}).get(core_no,""),(data.get("coreStatus2MapV15") or {}).get(core_no,""),(data.get("coreOpticalSignalMapV27") or data.get("coreOpticalSignalMapV60") or {}).get(core_no,"")))
                self.store.conn.executemany("INSERT INTO cores(cable_id,core_index,core_id,detail,status1,status2,signal) VALUES(?,?,?,?,?,?,?)",inserts)
            for n in data.get("nodes",[]):
                def native_edge(edge_id):
                    value=str(edge_id or "")
                    return "PORT:"+str(n["id"]) if value.startswith(("RNPORTS:","SUBPORTS:")) else value
                for value in (n.get("spliceMap") or {}).values():
                    a,b=value.get("c1") or {},value.get("c2") or {}
                    if a.get("edgeId") and b.get("edgeId"):
                        try:
                            x=(native_edge(a["edgeId"]),int(a.get("key") or a.get("index") or 0));y=(native_edge(b["edgeId"]),int(b.get("key") or b.get("index") or 0));x,y=sorted((x,y))
                            self.store.conn.execute("INSERT OR IGNORE INTO splices VALUES(?,?,?,?,?)",(str(n["id"]),x[0],x[1],y[0],y[1]))
                        except Exception:pass
                for row in (n.get("summaryRows") or []):
                    slots=[]
                    for edge_id,key in (row.get("slots") or {}).items():
                        if str(key).strip():
                            try:slots.append((native_edge(edge_id),int(str(key).strip())))
                            except ValueError:pass
                    if len(slots)==2:
                        x,y=sorted(slots)
                        self.store.conn.execute("INSERT OR IGNORE INTO splices VALUES(?,?,?,?,?)",(str(n["id"]),x[0],x[1],y[0],y[1]))
            for r in data.get("surveyRows",[]):
                left=r.get("left") or {};right=r.get("right") or {};invalid=bool(r.get("invalid"))
                try:li=int(left.get("key") or 0);ri=int(right.get("key") or 0)
                except ValueError:li=ri=0;invalid=True
                self.store.conn.execute("INSERT OR IGNORE INTO survey_rows VALUES(?,?,?,?,?,?,?,?,?)",(
                    str(r.get("id") or "SR-"+uuid.uuid4().hex),str(r.get("nodeId") or ""),str(left.get("edgeId") or ""),li,
                    str(right.get("edgeId") or ""),ri,1 if invalid else 0,str(r.get("errorMessage") or r.get("memo") or ""),str(r.get("createdAt") or "")))
            snapshot_pack=data.get("_windowsBeforeAfterSQLite") or {};snapshots=snapshot_pack.get("snapshots") if isinstance(snapshot_pack,dict) else {}
            if isinstance(snapshots,dict):
                scenario_folder=app_dir()/"scenarios"/self.store.path.stem;scenario_folder.mkdir(parents=True,exist_ok=True)
                for kind in ("gis","before","after"):
                    encoded=snapshots.get(kind)
                    if not encoded:continue
                    temp=scenario_folder/(kind+".import.sqlite3")
                    try:
                        temp.write_bytes(base64.b64decode(encoded,validate=True));check=sqlite3.connect(temp)
                        ok=check.execute("PRAGMA integrity_check").fetchone()[0]=="ok";tables={x[0] for x in check.execute("SELECT name FROM sqlite_master WHERE type='table'")};check.close()
                        if ok and {"nodes","cables","cores","splices"}.issubset(tables):temp.replace(scenario_folder/(kind+".sqlite3"))
                        else:temp.unlink(missing_ok=True)
                    except Exception:temp.unlink(missing_ok=True)
            if '_windowsFieldSlotsV72' in data:workflow.field_slot_json_restore(self.store,data['_windowsFieldSlotsV72'])
            self.store._normalize_temp_core_ids()
            for r in data.get("_windowsAnnotationsV17",[]):
                if isinstance(r,dict) and all(k in r for k in ("core_id","labels","memo")):self.store.conn.execute("INSERT OR REPLACE INTO core_annotations VALUES(?,?,?)",(r["core_id"],r["labels"],r["memo"]))
            for node_id in imported_locks:self.store.conn.execute("UPDATE nodes SET extra_json=json_set(extra_json,'$.editLocked',json('true')) WHERE id=?",(node_id,))
            if isinstance(data.get("_windowsWorkflowV17"),dict):workflow.write_state(self.store,data["_windowsWorkflowV17"],"JSON 가져오기",history=False)
            self.store._bump_revision();self.store.conn.hold_commit-=1;self.store.conn.commit();self.store._history_disabled-=1;self.selected.clear();self.update_title();self.refresh();messagebox.showinfo("가져오기 완료",f"시설 {len(data.get('nodes',[]))}개를 가져왔습니다.",parent=self)
        except Exception as e:self.store.conn.rollback();self.store.conn.hold_commit=max(0,self.store.conn.hold_commit-1);self.store._history_disabled=max(0,self.store._history_disabled-1);messagebox.showerror("가져오기 실패",str(e),parent=self)

    def on_close(self):
        if self.__dict__.get('_work_view_flush_id'):self.work_view_flush()
        if getattr(self,"cloud",None) and not self.cloud.closing:return self.cloud.close()
        self._navigation_closing=True;self._app_closing=True
        server=self.__dict__.pop('_work_server',None)
        if server is not None:server.close()
        workflow.close_reference_drawings(self)
        panel=getattr(self,'_map_allocation_panel',None)
        if panel is not None:panel.destroy(restore_editor=False)
        # V145: 지도 강조를 먼저 끄고 열린 창을 메인 그림판보다 먼저 닫는다.
        # (그림판이 먼저 사라진 뒤 창 닫기 정리가 그림판을 지우려 하면 종료 때 오류창이 떴다.)
        try:self.stop_highlight_blink(clear=True)
        except tk.TclError:pass
        for window in list(self.winfo_children()):
            if isinstance(window,tk.Toplevel):
                try:window.destroy()
                except tk.TclError:pass
        cancel_pending_jobs(self)
        self.store.conn.commit();self.store.backup_to(app_dir()/"backup"/f'{self.store.path.stem}_latest.sqlite3');self.store.close();self.destroy()


def cancel_pending_jobs(root):
    """Cancel every queued after/after_idle job so nothing runs on destroyed widgets."""
    try:jobs=root.tk.splitlist(root.tk.call('after','info'))
    except tk.TclError:return
    # Plain Tcl cancel: the owning widgets still free their Python callbacks when destroyed.
    for job in jobs:
        try:root.tk.call('after','cancel',job)
        except tk.TclError:pass


def stale_widget_error(root,value):
    """True for Tk errors that only mean a closed window/timer was touched late."""
    if not isinstance(value,tk.TclError):return False
    text=str(value)
    if getattr(root,'_app_closing',False):return True
    match=re.match(r'invalid command name "([^"]+)"',text)
    if not match:return False
    name=match.group(1)
    if not name.startswith('.'):return True
    try:return not int(root.tk.call('winfo','exists',name))
    except (tk.TclError,ValueError):return True


def launch_windowless_copy():
    """Let the installed BAT finish after its GUI child is ready and owns its lock.

    The existing updater readiness token stays intact for pending releases. For
    normal starts a private token uses the same ready writer, then is removed.
    No parent console is hidden/killed and the installed launcher is not changed.
    """
    if os.name!='nt' or getattr(sys,'frozen',False) or os.environ.get('TELECOM_LAUNCHED')!='1' or os.environ.get('TELECOM_GUI_DETACHED')=='1':return None
    import time
    home=app_dir();env=os.environ.copy();env['TELECOM_GUI_DETACHED']='1'
    own_marker=not (env.get('TELECOM_READY_PATH') and env.get('TELECOM_READY_TOKEN'));child=None
    try:
        cache=home/'update_cache';cache.mkdir(exist_ok=True)
        if own_marker:
            token=uuid.uuid4().hex;env['TELECOM_READY_TOKEN']=token;env['TELECOM_READY_PATH']=str(cache/('gui_'+token+'.ready'))
        marker=Path(env['TELECOM_READY_PATH']);token=env['TELECOM_READY_TOKEN']
        log=home/'desktop_output.log'
        if log.exists() and log.stat().st_size>2*1024*1024:log.replace(home/'desktop_output.previous.log')
        with log.open('ab') as output:
            child=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve())],cwd=home,env=env,
                                   stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT,
                                   creationflags=subprocess.CREATE_NO_WINDOW,close_fds=True)
    except OSError:
        # Before a child exists, the original foreground launch remains usable.
        if child is None:return None
    try:
        while True:
            try:
                if marker.is_file() and marker.read_text(encoding='utf-8')==token:return 0
            except OSError:pass
            code=child.poll()
            if code is not None:return code
            # Never report failure/trigger updater rollback while the GUI lives.
            time.sleep(.05)
    finally:
        if own_marker:
            try:marker.unlink(missing_ok=True)
            except OSError:pass


def run_desktop():
    with ExitStack() as locks:
        if not getattr(sys,"frozen",False) and (app_dir()/"telecom_updater.py").is_file():
            sys.path.append(str(app_dir()))
            from telecom_updater import InstanceLock
            if os.environ.get("TELECOM_LAUNCHED")!="1":
                locks.enter_context(InstanceLock(app_dir()))
            locks.enter_context(InstanceLock(app_dir(),"telecom_app.lock"))
        root_home=app_dir()
        application=workflow.CloudLogin(globals(),root_home)
        application.update_idletasks()
        # The launcher commits a release only after initialization succeeds.
        ready_path=os.environ.get("TELECOM_READY_PATH")
        ready_token=os.environ.get("TELECOM_READY_TOKEN")
        if ready_path and ready_token:
            marker=Path(ready_path);temporary=marker.with_suffix(".tmp")
            temporary.write_text(ready_token,encoding="utf-8");os.replace(temporary,marker)
        application.mainloop()
        if application.session:workflow.run_cloud_editor(globals(),application.session,root_home)


if __name__ == "__main__":
    AUTO_HTML_ON_START=True
    try:
        result=launch_windowless_copy()
        if result is not None:sys.exit(result)
        run_desktop()
    except Exception:
        error_text=traceback.format_exc();log_path=app_dir()/"startup_error.log";saved=False
        try:log_path.write_text(error_text,encoding="utf-8");saved=True
        except Exception:pass
        try:print(error_text,file=sys.stderr)
        except Exception:pass
        try:messagebox.showerror("V58 실행 오류",("오류 기록: "+str(log_path)+"\n\n" if saved else "오류 기록을 저장하지 못했습니다. 아래 내용을 캡처해 주세요.\n\n")+error_text[-1800:])
        except Exception:pass
        sys.exit(1)
